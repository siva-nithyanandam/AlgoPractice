CREATE OR ALTER VIEW dbo.MCNPV02_APP_CODE_GRP_VW AS(
SELECT distinct t2.CNPC01_APP_CODE_GRP_N,  CNPV02_APP_CODES = STUFF(
             (SELECT ',' + convert(varchar(30),CNPC01_APP_C)
              FROM MCNPC01_APP_CODE t1
              WHERE t1.CNPC01_APP_CODE_GRP_N = t2.CNPC01_APP_CODE_GRP_N and t1.CNPC01_ACTIVE_F='Y'
                  FOR XML PATH (''))
             , 1, 1, '') from MCNPC01_APP_CODE t2
     where t2.CNPC01_APP_CODE_GRP_N is not NULL
     group by CNPC01_APP_CODE_GRP_N)