/*******************************************************************************************/        
/*Created By  : banbilc1                  */        
/*Created On  : 20-Dec-2019                 */        
/*Purpose   :  To populate MCNPH02_TEMP_CONSENT_LEGAL_LANG when the record is deleted in   MCNPN02_TEMP_CONSENT_LEGAL_LANG table          */        
/*Dependent Objects : MCNPN02_TEMP_CONSENT_LEGAL_LANG          */        
/*******************************************************************************************/        
/* Modified By  Modified Date  Defect/Comment            */        
/*******************************************************************************************/        
/**/
/*******************************************************************************************/        
    
        
CREATE OR ALTER  TRIGGER  MCNPN02_TEMP_CONSENT_LEGAL_LANG_DELETE_TR ON MCNPN02_TEMP_CONSENT_LEGAL_LANG        
FOR DELETE        
AS        
	BEGIN 

		 DECLARE @user varchar(100) =  USER      
			   , @UserID varchar(8)       

		 SELECT @userID = CASE WHEN RIGHT(@user,CHARINDEX('\',@user))='' THEN SUBSTRING (@user,(charindex('_',@user)+1),8)  ELSE RIGHT(@user,CHARINDEX('\',@user)) END      


		 INSERT INTO MCNPH02_TEMP_CONSENT_LEGAL_LANG 
		 (
			 CNPN02_TEMP_CONSENT_LL_K		,CNPN02_USER_D				,CNPN02_SCA_D				,CNPN02_LL_D
			,CNPC01_APP_C					,CNPC01_SEC_APP_C			,CNPC02_COUNTRY_ISO3_C		,CNPN02_CONSENT_S			,CNPN02_CONSENT_CAPTURE_S	
			,CNPC05_COUNTRY_LANG_C			,CNPN02_CONSENT_CONTEXT_D	,CNPN02_VIN_C				,CNPN02_PHYSICAL_DEVICE_D	,CNPC04_STATUS_C
			,CNPN02_START_S					,CNPN02_END_S				,CNPN02_AGENT_D				,CNPN02_CAMPAIGN_D			,CNPN02_SMS_SHORT_D
			,CNPN02_CREATE_S				,CNPN02_CREATE_USER_D		,CNPN02_CREATE_PROCESS_C	,CNPN02_CREATE_APP_C
			,CNPN02_UPDATE_S				,CNPN02_UPDATE_USER_D		,CNPN02_UPDATE_PROCESS_C	,CNPN02_UPDATE_APP_C
			,CNPH02_HISTORY_ACTION_C
			,CNPH02_CREATE_S				,CNPH02_CREATE_USER_D		,CNPH02_CREATE_PROCESS_C	,CNPH02_CREATE_APP_C
			,CNPH02_UPDATE_S				,CNPH02_UPDATE_USER_D		,CNPH02_UPDATE_PROCESS_C	,CNPH02_UPDATE_APP_C
		 )

		 SELECT CNPN02_TEMP_CONSENT_LL_K	,CNPN02_USER_D				,CNPN02_SCA_D				,CNPN02_LL_D
			   ,CNPC01_APP_C				,CNPC01_SEC_APP_C			,CNPC02_COUNTRY_ISO3_C		,CNPN02_CONSENT_S			,CNPN02_CONSENT_CAPTURE_S
			   ,CNPC05_COUNTRY_LANG_C		,CNPN02_CONSENT_CONTEXT_D	,CNPN02_VIN_C				,CNPN02_PHYSICAL_DEVICE_D	,CNPC04_STATUS_C
			   ,CNPN02_START_S				,CNPN02_END_S				,CNPN02_AGENT_D				,CNPN02_CAMPAIGN_D			,CNPN02_SMS_SHORT_D
			   ,CNPN02_CREATE_S				,CNPN02_CREATE_USER_D		,CNPN02_CREATE_PROCESS_C	,CNPN02_CREATE_APP_C
			   ,CNPN02_UPDATE_S				,CNPN02_UPDATE_USER_D		,CNPN02_UPDATE_PROCESS_C	,CNPN02_UPDATE_APP_C
			   ,'D'
			   ,GETUTCDATE()				,@UserID					,'N02 Delete TR'	, 100624
			   ,GETUTCDATE()				,@UserID					,'N02 Delete TR'	, 100624

		 FROM deleted

	END
GO

ENABLE TRIGGER MCNPN02_TEMP_CONSENT_LEGAL_LANG_DELETE_TR ON MCNPN02_TEMP_CONSENT_LEGAL_LANG
GO    