/*******************************************************************************************/        
/*Created By  : banbilc1                  */        
/*Created On  : 20-Dec-2019                 */        
/*Purpose   :  To populate MCNPH03_CONSENT_PERMISSION when the record is deleted in   MCNPP01_CONSENT_PERMISSION table          */        
/*Dependent Objects : MCNPP01_CONSENT_PERMISSION          */        
/*******************************************************************************************/        
/* Modified By  Modified Date  Defect/Comment            */        
/*******************************************************************************************/        
/**/
/*******************************************************************************************/        
    
        
CREATE OR ALTER  TRIGGER  MCNPP01_CONSENT_PERMISSION_DELETE_TR ON MCNPP01_CONSENT_PERMISSION        
FOR DELETE        
AS        
	BEGIN 

		 DECLARE @user varchar(100) =  USER      
			   , @UserID varchar(8)       

		 SELECT @userID = CASE WHEN RIGHT(@user,CHARINDEX('\',@user))='' THEN SUBSTRING (@user,(charindex('_',@user)+1),8)  ELSE RIGHT(@user,CHARINDEX('\',@user)) END      


		 INSERT INTO MCNPH03_CONSENT_PERMISSION 
		 (
			 CNPP01_CONSENT_PERMISSION_K	,CNPN01_CONSENT_LL_K	,CNPC07_CONSENT_K		,CNPP01_USER_D		,CNPP01_SCA_D	
			,CNPC01_APP_C					,CNPC01_SEC_APP_C		,CNPC02_COUNTRY_ISO3_C	,CNPC04_STATUS_C	,CNPD01_DEVICE_D
			,CNPC03_DEVICE_TYPE_D			,CNPP01_PERMISSION_S	,CNPP01_START_S			,CNPP01_END_S		,CNPP01_CAPTURED_S
			,CNPP01_CREATE_S				,CNPP01_CREATE_USER_D	,CNPP01_CREATE_PROCESS_C,CNPP01_CREATE_APP_C
			,CNPP01_UPDATE_S				,CNPP01_UPDATE_USER_D	,CNPP01_UPDATE_PROCESS_C,CNPP01_UPDATE_APP_C
			,CNPH03_HISTORY_ACTION_C
			,CNPH03_CREATE_S				,CNPH03_CREATE_USER_D	,CNPH03_CREATE_PROCESS_C,CNPH03_CREATE_APP_C
			,CNPH03_UPDATE_S				,CNPH03_UPDATE_USER_D	,CNPH03_UPDATE_PROCESS_C,CNPH03_UPDATE_APP_C
		 )

		 SELECT CNPP01_CONSENT_PERMISSION_K	,CNPN01_CONSENT_LL_K		,CNPC07_CONSENT_K		,CNPP01_USER_D		,CNPP01_SCA_D
			   ,CNPC01_APP_C				,CNPC01_SEC_APP_C			,CNPC02_COUNTRY_ISO3_C	,CNPC04_STATUS_C	,CNPD01_DEVICE_D
			   ,CNPC03_DEVICE_TYPE_D		,CNPP01_PERMISSION_S		,CNPP01_START_S			,CNPP01_END_S		,CNPP01_CAPTURED_S
			   ,CNPP01_CREATE_S				,CNPP01_CREATE_USER_D		,CNPP01_CREATE_PROCESS_C,CNPP01_CREATE_APP_C
			   ,CNPP01_UPDATE_S				,CNPP01_UPDATE_USER_D		,CNPP01_UPDATE_PROCESS_C,CNPP01_UPDATE_APP_C
			   ,'D'
			   ,GETUTCDATE()				,@UserID					,'P01 Delete TR'	, 100624
			   ,GETUTCDATE()				,@UserID					,'P01 Delete TR'	, 100624

		 FROM deleted

	END
GO

ENABLE TRIGGER MCNPP01_CONSENT_PERMISSION_DELETE_TR ON MCNPP01_CONSENT_PERMISSION
GO    