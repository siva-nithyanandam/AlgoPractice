/*******************************************************************************************/        
/*Created By  : banbilc1                  */        
/*Created On  : 20-Dec-2019                 */        
/*Purpose   :  To populate MCNPH06_CONSENT_LL_DEVICE when the record is deleted in   MCNPN03_CONSENT_LL_DEVICE table          */        
/*Dependent Objects : MCNPN03_CONSENT_LL_DEVICE          */        
/*******************************************************************************************/        
/* Modified By  Modified Date  Defect/Comment            */        
/*******************************************************************************************/        
/**/
/*******************************************************************************************/        
    
        
CREATE OR ALTER  TRIGGER  MCNPN03_CONSENT_LL_DEVICE_DELETE_TR ON MCNPN03_CONSENT_LL_DEVICE        
FOR DELETE        
AS        
	BEGIN 

		 DECLARE @user varchar(100) =  USER      
			   , @UserID varchar(8)       

		 SELECT @userID = CASE WHEN RIGHT(@user,CHARINDEX('\',@user))='' THEN SUBSTRING (@user,(charindex('_',@user)+1),8)  ELSE RIGHT(@user,CHARINDEX('\',@user)) END      


		 INSERT INTO MCNPH06_CONSENT_LL_DEVICE 
		 (	 
			 CNPN01_CONSENT_LL_K	,CNPD01_DEVICE_D		,CNPC03_DEVICE_TYPE_D	,CNPC04_STATUS_C
			,CNPN03_CREATE_S		,CNPN03_CREATE_USER_D	,CNPN03_CREATE_PROCESS_C,CNPN03_CREATE_APP_C
			,CNPN03_UPDATE_S		,CNPN03_UPDATE_USER_D	,CNPN03_UPDATE_PROCESS_C,CNPN03_UPDATE_APP_C
			,CNPH06_HISTORY_ACTION_C
			,CNPH06_CREATE_S		,CNPH06_CREATE_USER_D	,CNPH06_CREATE_PROCESS_C,CNPH06_CREATE_APP_C
			,CNPH06_UPDATE_S		,CNPH06_UPDATE_USER_D	,CNPH06_UPDATE_PROCESS_C,CNPH06_UPDATE_APP_C
		 )

		 SELECT  CNPN01_CONSENT_LL_K	,CNPD01_DEVICE_D		,CNPC03_DEVICE_TYPE_D	,CNPC04_STATUS_C
				,CNPN03_CREATE_S		,CNPN03_CREATE_USER_D	,CNPN03_CREATE_PROCESS_C,CNPN03_CREATE_APP_C
				,CNPN03_UPDATE_S		,CNPN03_UPDATE_USER_D	,CNPN03_UPDATE_PROCESS_C,CNPN03_UPDATE_APP_C
			   ,'D'
			   ,GETUTCDATE()				,@UserID					,'S01 Delete TR'	, 100624
			   ,GETUTCDATE()				,@UserID					,'S01 Delete TR'	, 100624

		 FROM deleted

	END
GO

ENABLE TRIGGER MCNPN03_CONSENT_LL_DEVICE_DELETE_TR ON MCNPN03_CONSENT_LL_DEVICE
GO    