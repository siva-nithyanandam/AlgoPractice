/*******************************************************************************************/        
/*Created By  : banbilc1                  */        
/*Created On  : 20-Dec-2019                 */        
/*Purpose   :  To populate MCNPH04_CONSENT_PREFERENCE when the record is deleted in   MCNPF01_CONSENT_PREFERENCE table          */        
/*Dependent Objects : MCNPF01_CONSENT_PREFERENCE          */        
/*******************************************************************************************/        
/* Modified By  Modified Date  Defect/Comment            */        
/*******************************************************************************************/        
/**/
/*******************************************************************************************/        
    
        
CREATE OR ALTER  TRIGGER  MCNPF01_CONSENT_PREFERENCE_DELETE_TR ON MCNPF01_CONSENT_PREFERENCE        
FOR DELETE        
AS        
	BEGIN 

		 DECLARE @user varchar(100) =  USER      
			   , @UserID varchar(8)       

		 SELECT @userID = CASE WHEN RIGHT(@user,CHARINDEX('\',@user))='' THEN SUBSTRING (@user,(charindex('_',@user)+1),8)  ELSE RIGHT(@user,CHARINDEX('\',@user)) END      


		 INSERT INTO MCNPH04_CONSENT_PREFERENCE 
		 (	 CNPF01_CONSENT_PREFERENCE_K	,CNPC07_CONSENT_K		,CNPF01_USER_D			,CNPF01_SCA_D		,CNPC01_APP_C
			,CNPC01_SEC_APP_C				,CNPC02_COUNTRY_ISO3_C	,CNPC04_STATUS_C		,CNPD01_DEVICE_D	,CNPC03_DEVICE_TYPE_D
			,CNPF01_PREFERENCE_S			,CNPF01_START_S			,CNPF01_END_S			,CNPF01_CAPTURED_S
			,CNPF01_CREATE_S				,CNPF01_CREATE_USER_D	,CNPF01_CREATE_PROCESS_C,CNPF01_CREATE_APP_C
			,CNPF01_UPDATE_S				,CNPF01_UPDATE_USER_D	,CNPF01_UPDATE_PROCESS_C,CNPF01_UPDATE_APP_C
			,CNPH04_HISTORY_ACTION_C
			,CNPH04_CREATE_S				,CNPH04_CREATE_USER_D	,CNPH04_CREATE_PROCESS_C,CNPH04_CREATE_APP_C
			,CNPH04_UPDATE_S				,CNPH04_UPDATE_USER_D	,CNPH04_UPDATE_PROCESS_C,CNPH04_UPDATE_APP_C
		 )

		 SELECT  CNPF01_CONSENT_PREFERENCE_K,CNPC07_CONSENT_K		,CNPF01_USER_D			,CNPF01_SCA_D		,CNPC01_APP_C
				,CNPC01_SEC_APP_C			,CNPC02_COUNTRY_ISO3_C	,CNPC04_STATUS_C		,CNPD01_DEVICE_D	,CNPC03_DEVICE_TYPE_D
				,CNPF01_PREFERENCE_S		,CNPF01_START_S			,CNPF01_END_S			,CNPF01_CAPTURED_S
				,CNPF01_CREATE_S			,CNPF01_CREATE_USER_D	,CNPF01_CREATE_PROCESS_C,CNPF01_CREATE_APP_C
				,CNPF01_UPDATE_S			,CNPF01_UPDATE_USER_D	,CNPF01_UPDATE_PROCESS_C,CNPF01_UPDATE_APP_C
			   ,'D'
			   ,GETUTCDATE()				,@UserID					,'F01 Delete TR'	, 100624
			   ,GETUTCDATE()				,@UserID					,'F01 Delete TR'	, 100624

		 FROM deleted

	END
GO

ENABLE TRIGGER MCNPF01_CONSENT_PREFERENCE_DELETE_TR ON MCNPF01_CONSENT_PREFERENCE
GO    