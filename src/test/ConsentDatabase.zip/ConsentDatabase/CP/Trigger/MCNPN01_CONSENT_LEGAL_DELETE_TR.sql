/*******************************************************************************************/        
/*Created By  : banbilc1                  */        
/*Created On  : 20-Dec-2019                 */        
/*Purpose   :  To populate MCNPH01_CONSENT_LEGAL_LANG when the record is deleted in   MCNPN01_CONSENT_LEGAL_LANG table          */        
/*Dependent Objects : MCNPN01_CONSENT_LEGAL_LANG          */        
/*******************************************************************************************/        
/* Modified By  Modified Date  Defect/Comment            */        
/*******************************************************************************************/        
/**/
/*******************************************************************************************/        
    
        
CREATE OR ALTER  TRIGGER  MCNPN01_CONSENT_LEGAL_DELETE_TR ON MCNPN01_CONSENT_LEGAL_LANG        
FOR DELETE        
AS        
	BEGIN 

		 DECLARE @user varchar(100) =  USER      
			   , @UserID varchar(8)       

		 SELECT @userID = CASE WHEN RIGHT(@user,CHARINDEX('\',@user))='' THEN SUBSTRING (@user,(charindex('_',@user)+1),8)  ELSE RIGHT(@user,CHARINDEX('\',@user)) END      


		 INSERT INTO MCNPH01_CONSENT_LEGAL_LANG 
		 (
		 CNPN01_CONSENT_LL_K		,CNPN01_USER_D			,CNPN01_SCA_D				,CNPN01_LL_D			,CNPC01_APP_C				,CNPC01_SEC_APP_C
		,CNPC02_COUNTRY_ISO3_C		,CNPN01_CONSENT_S		,CNPN01_CONSENT_CAPTURE_S	,CNPC05_COUNTRY_LANG_C	,CNPN01_CONSENT_CONTEXT_D	,CNPN01_VIN_C
		,CNPN01_PHYSICAL_DEVICE_D	,CNPC04_STATUS_C		,CNPN01_AGENT_D				,CNPN01_CAMPAIGN_D		,CNPN01_SMS_SHORT_D			
		,CNPN01_CREATE_S			,CNPN01_CREATE_USER_D	,CNPN01_CREATE_PROCESS_C	,CNPN01_CREATE_APP_C	
		,CNPN01_UPDATE_S			,CNPN01_UPDATE_USER_D	,CNPN01_UPDATE_PROCESS_C	,CNPN01_UPDATE_APP_C
		,CNPH01_HISTORY_ACTION_C
		,CNPH01_CREATE_S	,CNPH01_CREATE_USER_D	,CNPH01_CREATE_PROCESS_C	,CNPH01_CREATE_APP_C	,CNPH01_UPDATE_S	,CNPH01_UPDATE_USER_D	,CNPH01_UPDATE_PROCESS_C	,CNPH01_UPDATE_APP_C
		 )

		 SELECT CNPN01_CONSENT_LL_K		,CNPN01_USER_D	,CNPN01_SCA_D	,CNPN01_LL_D	,CNPC01_APP_C	,CNPC01_SEC_APP_C
		,CNPC02_COUNTRY_ISO3_C	,CNPN01_CONSENT_S	,CNPN01_CONSENT_CAPTURE_S	,CNPC05_COUNTRY_LANG_C	,CNPN01_CONSENT_CONTEXT_D	,CNPN01_VIN_C
		,CNPN01_PHYSICAL_DEVICE_D	,CNPC04_STATUS_C	,CNPN01_AGENT_D	,CNPN01_CAMPAIGN_D	,CNPN01_SMS_SHORT_D
		,CNPN01_CREATE_S	,CNPN01_CREATE_USER_D	,CNPN01_CREATE_PROCESS_C	,CNPN01_CREATE_APP_C
		,CNPN01_UPDATE_S	,CNPN01_UPDATE_USER_D	,CNPN01_UPDATE_PROCESS_C	,CNPN01_UPDATE_APP_C
		,'D'
		,GETUTCDATE()		,@UserID	,'N01 Delete TR'	, 100624
		,GETUTCDATE()		,@UserID	,'N01 Delete TR'	, 100624

		 FROM deleted

	END
GO

ENABLE TRIGGER MCNPN01_CONSENT_LEGAL_DELETE_TR ON MCNPN01_CONSENT_LEGAL_LANG    
GO 

  