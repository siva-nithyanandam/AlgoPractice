/*******************************************************************************************/        
/*Created By  : banbilc1                  */        
/*Created On  : 20-Dec-2019                 */        
/*Purpose   :  To populate MCNPH05_CONSENT_SUPPRESSION when the record is deleted in   MCNPS01_CONSENT_SUPPRESSION table          */        
/*Dependent Objects : MCNPS01_CONSENT_SUPPRESSION          */        
/*******************************************************************************************/        
/* Modified By  Modified Date  Defect/Comment            */        
/*******************************************************************************************/        
/**/
/*******************************************************************************************/        
    
        
CREATE OR ALTER  TRIGGER  MCNPS01_CONSENT_SUPPRESSION_DELETE_TR ON MCNPS01_CONSENT_SUPPRESSION        
FOR DELETE        
AS        
	BEGIN 

		 DECLARE @user varchar(100) =  USER      
			   , @UserID varchar(8)       

		 SELECT @userID = CASE WHEN RIGHT(@user,CHARINDEX('\',@user))='' THEN SUBSTRING (@user,(charindex('_',@user)+1),8)  ELSE RIGHT(@user,CHARINDEX('\',@user)) END      


		 INSERT INTO MCNPH05_CONSENT_SUPPRESSION 
		 (	 
			 CNPS01_CONSENT_SUPPRESSION_K	,CNPC07_CONSENT_K		,CNPS01_USER_D			,CNPS01_SCA_D		,CNPC01_APP_C
			,CNPC01_SEC_APP_C				,CNPC02_COUNTRY_ISO3_C	,CNPC04_STATUS_C		,CNPD01_DEVICE_D	,CNPC03_DEVICE_TYPE_D
			,CNPS01_SUPPRESSION_S			,CNPS01_START_S			,CNPS01_END_S			,CNPS01_CAPTURED_S
			,CNPS01_CREATE_S				,CNPS01_CREATE_USER_D	,CNPS01_CREATE_PROCESS_C,CNPS01_CREATE_APP_C
			,CNPS01_UPDATE_S				,CNPS01_UPDATE_USER_D	,CNPS01_UPDATE_PROCESS_C,CNPS01_UPDATE_APP_C
			,CNPH05_HISTORY_ACTION_C
			,CNPH05_CREATE_S				,CNPH05_CREATE_USER_D	,CNPH05_CREATE_PROCESS_C,CNPH05_CREATE_APP_C
			,CNPH05_UPDATE_S				,CNPH05_UPDATE_USER_D	,CNPH05_UPDATE_PROCESS_C,CNPH05_UPDATE_APP_C
		 )

		 SELECT  CNPS01_CONSENT_SUPPRESSION_K,CNPC07_CONSENT_K		,CNPS01_USER_D			,CNPS01_SCA_D		,CNPC01_APP_C
				,CNPC01_SEC_APP_C			 ,CNPC02_COUNTRY_ISO3_C	,CNPC04_STATUS_C		,CNPD01_DEVICE_D	,CNPC03_DEVICE_TYPE_D
				,CNPS01_SUPPRESSION_S		 ,CNPS01_START_S		,CNPS01_END_S			,CNPS01_CAPTURED_S
				,CNPS01_CREATE_S			 ,CNPS01_CREATE_USER_D	,CNPS01_CREATE_PROCESS_C,CNPS01_CREATE_APP_C
				,CNPS01_UPDATE_S			 ,CNPS01_UPDATE_USER_D	,CNPS01_UPDATE_PROCESS_C,CNPS01_UPDATE_APP_C
			   ,'D'
			   ,GETUTCDATE()				,@UserID					,'S01 Delete TR'	, 100624
			   ,GETUTCDATE()				,@UserID					,'S01 Delete TR'	, 100624

		 FROM deleted

	END
GO

ENABLE TRIGGER MCNPS01_CONSENT_SUPPRESSION_DELETE_TR ON MCNPS01_CONSENT_SUPPRESSION
GO    