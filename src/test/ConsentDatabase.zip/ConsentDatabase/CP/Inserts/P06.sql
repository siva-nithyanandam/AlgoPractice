IF OBJECT_ID('tempdb..#temp') IS NOT NULL  BEGIN DROP TABLE #TEMP END

select * into #temp from 
(
Select 1000 as POU_D,1000	'Data_Catg_d','Marketing Via Text' as pou_x,	'Operational' as POU_CATG_N
union all Select 1001 as POU_D,1000	'Data_Catg_d','Marketing Via Email' as pou_x,	'Operational' as POU_CATG_N
union all Select 1004 as POU_D,1000	'Data_Catg_d','Sensitive & non-sensitive data to 3rd Party for independent use' as pou_x,	'Operational' as POU_CATG_N
union all Select 1005 as POU_D,1000	'Data_Catg_d','3rd Party service to customer (sensitive and non-sensitive data)' as pou_x,	'Operational' as POU_CATG_N
union all Select 1008 as POU_D,1000	'Data_Catg_d','Operate CRM Models for Digital Marketing' as pou_x,	'Operational' as POU_CATG_N
union all Select 1009 as POU_D,1000	'Data_Catg_d','Operate CRM Models for non-Digital Marketing' as pou_x,	'Operational' as POU_CATG_N
union all Select 1010 as POU_D,1000	'Data_Catg_d','Use Customer Profile to Fulfill Services' as pou_x,	'Operational' as POU_CATG_N
union all Select 1011 as POU_D,1000	'Data_Catg_d','Use External Data with Internal Data for Digital Marketing' as pou_x,	'Operational' as POU_CATG_N
union all Select 1012 as POU_D,1000	'Data_Catg_d','Pilot or Proof of Concept' as pou_x,	'Operational' as POU_CATG_N
union all Select 1013 as POU_D,1001	'Data_Catg_d','Fraud detection and prevention' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1014 as POU_D,1000	'Data_Catg_d','Consumer sales and services' as pou_x,	'Operational' as POU_CATG_N
union all Select 1015 as POU_D,1001	'Data_Catg_d','Business operations (tax, finance, etc.)' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1016 as POU_D,1001	'Data_Catg_d','Supplier performance and satisfaction' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1017 as POU_D,1001	'Data_Catg_d','Compliance and Litigation' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1018 as POU_D,1001	'Data_Catg_d','Personalization of customer services' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1019 as POU_D,1001	'Data_Catg_d','Credit and financing' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1020 as POU_D,1001	'Data_Catg_d','Consumer direct marketing � non-digital' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1021 as POU_D,1001	'Data_Catg_d','Consumer direct marketing - digital' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1022 as POU_D,1001	'Data_Catg_d','Warranty' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1023 as POU_D,1001	'Data_Catg_d','Dealer operations and performance' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1024 as POU_D,1001	'Data_Catg_d','Product improvement, research and development' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1025 as POU_D,1001	'Data_Catg_d','Data combination (creation of customer profile with internal data only)' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1026 as POU_D,1001	'Data_Catg_d','Data enrichment (creation of customer profile with internal and external sources)' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1027 as POU_D,1001	'Data_Catg_d','Product/Service Safety and Security' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1028 as POU_D,1001	'Data_Catg_d','Perform contract or provide services' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1029 as POU_D,1001	'Data_Catg_d','Perform analysis to support documented and approved current CRM models' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1030 as POU_D,1000	'Data_Catg_d','Marketing in Vehicle' as pou_x,	'Operational' as POU_CATG_N
union all Select 1031 as POU_D,1000	'Data_Catg_d','Selling Personal Data' as pou_x,	'Operational' as POU_CATG_N
union all Select 1032 as POU_D,1001	'Data_Catg_d','Use Internal Profile' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1033 as POU_D,1001	'Data_Catg_d','Elevated' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1034 as POU_D,1001	'Data_Catg_d','Sensitive Data' as pou_x,	'Analysis' as POU_CATG_N
union all Select 1035 as POU_D,1000	'Data_Catg_d','Marketing via ''Push Notification''' as pou_x,	'Operational' as POU_CATG_N
union all Select 1036 as POU_D,1000	'Data_Catg_d','GPS for Vehicle' as pou_x,	'Operational' as POU_CATG_N
union all Select 1037 as POU_D,1000	'Data_Catg_d','GPS for Mobile Phone' as pou_x,	'Operational' as POU_CATG_N
union all Select 1038 as POU_D,1000	'Data_Catg_d','Collect Location Information' as pou_x,	'Operational' as POU_CATG_N
union all Select 1039 as POU_D,1000	'Data_Catg_d','Collect Personal Information' as pou_x,	'Operational' as POU_CATG_N
union all Select 1040 as POU_D,1000	'Data_Catg_d','Collect Vehicle Information' as pou_x,	'Operational' as POU_CATG_N
) a 



INSERT INTO  DBO.MCNPC06_POU  (

CNPC06_POU_D,CNPC06_DATA_CATG_D,
CNPC06_POU_EXP_CATG_X,
CNPC06_POU_X,
CNPC06_CREATE_S,
CNPC06_CREATE_USER_D,
CNPC06_CREATE_PROCESS_C,
CNPC06_CREATE_APP_C,
CNPC06_UPDATE_S,
CNPC06_UPDATE_USER_D,
CNPC06_UPDATE_PROCESS_C,
CNPC06_UPDATE_APP_C,
CNPC06_POU_CATG_N
)
SELECT POU_D,Data_Catg_d,POU_CATG_N ,pou_x, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	,POU_CATG_N
from #temp
where  pou_d  not in (select isnull(CNPC06_POU_D,0) from MCNPC06_POU)


update c06
set CNPC06_POU_EXP_CATG_X = POU_CATG_N

--select  CNPC06_POU_D , POU_D
--, CNPC06_POU_EXP_CATG_X , POU_CATG_N
from MCNPC06_POU C06
, #temp tmp
where CNPC06_POU_D = POU_D
and isnull(CNPC06_POU_EXP_CATG_X,'') <> POU_CATG_N

select CNPC06_POU_D,CNPC06_DATA_CATG_D,CNPC06_POU_EXP_CATG_X,CNPC06_POU_X,CNPC06_POU_CATG_N
 from MCNPC06_POU
