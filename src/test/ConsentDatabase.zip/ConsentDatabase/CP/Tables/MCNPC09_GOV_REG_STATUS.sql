
USE [SCACP]
GO

 
CREATE TABLE dbo.[MCNPC09_GOV_REG_STATUS](
	[CNPC07_CONSENT_K] [bigint] NOT NULL,
	[CNPC02_COUNTRY_ISO3_C] [char](3) NOT NULL,
	[CNPC04_STATUS_C] [char](1) NOT NULL,
	[CNPC09_EFF_START_Y] [date] NULL,
	[CNPC09_EFF_END_Y] [date] NULL,
	[CNPC09_COMMENTS_X] [nvarchar](255) NULL,
	[CNPC09_CREATE_S] [datetime] NOT NULL,
	[CNPC09_CREATE_USER_D] [varchar](8) NOT NULL,
	[CNPC09_CREATE_PROCESS_C] [varchar](100) NOT NULL,
	[CNPC09_CREATE_APP_C] int NOT NULL,
	[CNPC09_UPDATE_S] [datetime] NOT NULL,
	[CNPC09_UPDATE_USER_D] [varchar](8) NOT NULL,
	[CNPC09_UPDATE_PROCESS_C] [varchar](100) NOT NULL,
	[CNPC09_UPDATE_APP_C] int NOT NULL
) ON [PRIMARY]

GO

ALTER TABLE dbo.[MCNPC09_GOV_REG_STATUS]  WITH CHECK ADD  CONSTRAINT [MCNPC091] FOREIGN KEY([CNPC02_COUNTRY_ISO3_C])
REFERENCES dbo.[MCNPC02_COUNTRY] ([CNPC02_COUNTRY_ISO3_C])
GO


ALTER TABLE dbo.[MCNPC09_GOV_REG_STATUS]  WITH CHECK ADD  CONSTRAINT [MCNPC092] FOREIGN KEY([CNPC04_STATUS_C])
REFERENCES dbo.MCNPC04_STATUS ([CNPC04_STATUS_C])
GO

--INSERT INTO dbo.MCNPC09_GOV_REG_STATUS VALUES
-- (4	,'DEU','H','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(39,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(41,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(28,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(29,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(30,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(36,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(31,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(32,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(33,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(34,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(35,'USA','1','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--,(1	,'DEU','S','2019-08-21',NULL,'', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
--;

SELECT * FROM dbo.MCNPC09_GOV_REG_STATUS
-- DELETE FROM   dbo.MCNPC09_GOV_REG_STATUS