
GO


CREATE TABLE dbo.MCNPC07_CONSENT
(
 CNPC07_CONSENT_K		bigint  NOT NULL
,CNPC06_POU_K	bigint
,CNPC07_CONSENT_CATG_X   varchar(15) NOT NULL
,CNPC07_CONSENT_N  varchar(120)
,CNPC07_CONSENT_X  varchar(120)
,[CNPC07_CREATE_S] [datetime] NOT NULL,
[CNPC07_CREATE_USER_D] [varchar](8) NOT NULL,
[CNPC07_CREATE_PROCESS_C] [varchar](100) NOT NULL,
[CNPC07_CREATE_APP_C] int NOT NULL,
[CNPC07_UPDATE_S] [datetime] NOT NULL,
[CNPC07_UPDATE_USER_D] [varchar](8) NOT NULL,
[CNPC07_UPDATE_PROCESS_C] [varchar](100) NOT NULL,
[CNPC07_UPDATE_APP_C] int NOT NULL
 CONSTRAINT [MCNPC071] PRIMARY KEY CLUSTERED 
(
	CNPC07_CONSENT_K ASC
)

)
GO
ALTER TABLE MCNPC07_CONSENT ADD CONSTRAINT [MCNPC072] FOREIGN KEY(CNPC06_POU_K) REFERENCES  dbo.MCNPC06_POU(CNPC06_POU_K)
GO
ALTER TABLE MCNPC07_CONSENT ADD CONSTRAINT [MCNPC073] UNIQUE  (CNPC07_CONSENT_N)
GO


--INSERT INTO dbo.MCNPC07_CONSENT VALUES

-- (1,1		,'Permission','SMS',''																				, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)						
--,(2,2		,'Permission','EMAIL',''																		   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(4,3		,'Permission','MAIL',''																			   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(5,NULL	,'Preference','VEHICLE SALES OFFERS AND INFORMATION',              NULL							   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(6,NULL	,'Preference','VEHICLE SERVICE OFFERS AND INFORMATION',              NULL						   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(7,NULL	,'Preference','VEHICLE PERSONALIZATION AND ACCESSORIES',              NULL						   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(8,NULL	,'Preference','INVEHICLE TECHNOLOGIES',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(9,NULL	,'Preference','FORD PERFORMANCE PREFERENCE',              NULL									   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(10,NULL	,'Preference','AXZ PLAN',              NULL														   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(13,NULL	,'Preference','PHONE',              NULL														   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(15,NULL	,'Preference','GENUINE DIRECT E-MAIL',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(16,NULL	,'Preference','GENUINE DIRECT MAIL',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(17,NULL	,'Preference','GENUINE DIRECT PHONE',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(18,NULL	,'Preference','GENUINE DIRECT SMS',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(19,NULL	,'Preference','SIRIUS E-MAIL',              NULL												   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(20,NULL	,'Preference','SIRIUS MAIL',              NULL													   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(21,NULL	,'Preference','SIRIUS PHONE',              NULL													   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(22,NULL	,'Preference','SIRIUS SMS',              NULL													   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(23,NULL	,'Preference','OWNER ADVANTAGE REWARDS',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(24,NULL	,'Preference','VIEWPOINT E-MAIL',              NULL												   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(25,NULL	,'Preference','VIEWPOINT MAIL',              NULL												   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(26,NULL	,'Preference','VIEWPOINT PHONE',              NULL												   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(27,NULL	,'Preference','VIEWPOINT SMS',              NULL												   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(28,NULL	,'Preference','FORD PRODUCT UPDATES E-MAIL',              NULL									   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(29,NULL	,'Preference','FORD SALES OFFERS E-MAIL',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(30,NULL	,'Preference','FORD SERVICE OFFERS E-MAIL',              NULL									   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(31,NULL	,'Preference','LINCOLN PRODUCT UPDATES E-MAIL',              NULL								   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(32,NULL	,'Preference','LINCOLN SALES OFFERS E-MAIL',              NULL									   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(33,NULL	,'Preference','LINCOLN SERVICE OFFERS E-MAIL',              NULL								   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(34,NULL	,'Preference','CORPORATE PHILANTHROPIC E-MAIL',              NULL								   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(35,NULL	,'Preference','CORPORATE CONTESTS SWEEPSTAKES E-MAIL',              NULL						   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(36,NULL	,'Preference','CORPORATE FORD GENUINE PARTS AND MOTORCRAFT E-MAIL',   NULL						   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(37,NULL	,'Preference','CORPORATE COMMERCIAL VEHICLES E-MAIL',              NULL							   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(38,NULL	,'Preference','CORPORATE FORD PERFORMANCE E-MAIL',              NULL							   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(39,NULL	,'Preference','FORDPASS E-MAIL',              NULL												   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(40,NULL	,'Preference','FORDPASS PREFERENCE',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(41,NULL	,'Preference','LINCOLN WAY E-MAIL',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(42,NULL	,'Suppression','FMCC DEALER',              NULL													   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(43,NULL	,'Suppression','FMCC BRANCH',              NULL													   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(44,NULL	,'Suppression','FMCC SERVICE CENTER',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(45,NULL	,'Suppression','FMCC CENTRAL OPS',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(46,NULL	,'Suppression','FMCC LEGAL',              NULL													   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(47,NULL	,'Suppression','FMCC BRANCH ADDRESS',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(48,NULL	,'Suppression','CONVERT 809 LEGACY',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(49,NULL	,'Suppression','DISPUTE RESOLU BOARD',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(50,NULL	,'Suppression','CAC LEGAL',              NULL													   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(51,NULL	,'Suppression','REACQUIRED VEHICLE',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(52,NULL	,'Suppression','CONSUMER AND GOV INF',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(53,NULL	,'Suppression','OGC',              NULL															   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(54,NULL	,'Suppression','SMALL CLAIMS',              NULL												   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(55,NULL	,'Suppression','FIRESTONE LITIGANT',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(56,NULL	,'Suppression','REPOSSESSION',              NULL												   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(57,NULL	,'Suppression','BANKRUPTCY',              NULL													   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(58,NULL	,'Suppression','FFCRA INDICATOR(CAN)',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(59,NULL	,'Suppression','EXPERIAN VULGAR',              NULL												   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(60,NULL	,'Suppression','DEALER ADDRESS MATCH',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(61,NULL	,'Suppression','Total Suppression',              NULL											   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(62,NULL	,'Suppression','Customer Deletion Request',              NULL									   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(63,NULL	,'Suppression','Litigation Suppression',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(64,NULL	,'Suppression','Ford Credit Repossession',              NULL									   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(65,NULL	,'Suppression','Temporary Suppression',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(66,NULL	,'Suppression','DEALER ADDRESS MATCH',              NULL										   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(67,NULL	,'Suppression','Vulgar',              NULL														   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)

;
 select * from MCNPC07_CONSENT

 -- DELETE FROM dbo.MCNPC07_CONSENT


 select * from dbo.MCNPC07_CONSENT
 /*
 insert into dbo.MCNPC07_CONSENT
 values  (68, NULL   ,'Permission','Phone Permission',''																		, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
 , (69, NULL   ,'Permission','SMS Permission',''																				, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
 , (70, NULL   ,'Permission','Mail Permission',''																				, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
 , (71, NULL   ,'Permission','Email Permission',''																				, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
 , (72, NULL   ,'Permission','Mobile Permission',''																				, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
 ;
 */
select * from SCACP.dbo.MCNPC08_CONSENT_RELATION
select * from SCACP.dbo.MCNPC12_SUPPRESSION_TERM
select * from SCACP.dbo.MCNPC13_PRIVACY_DEVICE_MAPPING
select * from SCACP.dbo.MCNPC08_CONSENT_RELATION