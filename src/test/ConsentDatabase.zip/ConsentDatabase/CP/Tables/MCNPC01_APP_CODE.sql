
USE [SCACP]
GO


CREATE TABLE [dbo].[MCNPC01_APP_CODE](
	[CNPC01_APP_C] int NOT NULL,
	[CNPC01_APP_N] nvarchar(120) NULL,
	[CNPC01_APP_X] nvarchar(255) NULL,
	[CNPC01_CREATE_S] [datetime] NOT NULL,
	[CNPC01_CREATE_USER_D] [varchar](8) NOT NULL,
	[CNPC01_CREATE_PROCESS_C] [varchar](100) NOT NULL,
	[CNPC01_CREATE_APP_C] int NOT NULL,
	[CNPC01_UPDATE_S] [datetime] NOT NULL,
	[CNPC01_UPDATE_USER_D] [varchar](8) NOT NULL,
	[CNPC01_UPDATE_PROCESS_C] [varchar](100) NOT NULL,
	[CNPC01_UPDATE_APP_C] int  NOT NULL,
 CONSTRAINT [MCNPC011] PRIMARY KEY CLUSTERED 
(
	[CNPC01_APP_C] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
 
 


 INSERT INTO  [dbo].[MCNPC01_APP_CODE]   
 VALUES
 ( 100392 ,'','OWNER WEB'	, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,( 100433 ,'','SMARTVINCENT', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,( 100504 ,'','FORDPASS'	, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,( 100530 ,'','LincolnWay'	, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,(100577,NULL,'FordBrandsites'			, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,(100578,NULL,'Lincoln Brandsites'		, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,(100608,NULL,'ICI DCX'					, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,(100624,NULL,'Consent Platform NA'		, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 

 ;

insert into [SCACP].[dbo].[MCNPC01_APP_CODE]
  values (100629,NULL,'VSDN','2019-11-15 12:28:01.220','mbuckne5','manual','-1','2019-11-15 12:28:01.220','mbuckne5','manual','-1')

  INSERT INTO  [dbo].[MCNPC01_APP_CODE]  
 select  app_c , NULL,app_x , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1
 from 

(
 select   	'Account Manager - NA'	  as app_x, 		100586	 as app_c
union all select   	'Amazon Alexa Application'	  as app_x, 		100722	 as app_c
union all select   	'Applink Remote Management and Reporting'	  as app_x, 		100711	 as app_c
--union all select   	'FordBrandsites'	  as app_x, 		100577	 as app_c
--union all select   	'Lincoln Brandsites'	  as app_x, 		100578	 as app_c
union all select   	'CKS Analytical'	  as app_x, 		100704	 as app_c
union all select   	'CKS Dealer'	  as app_x, 		100714	 as app_c
union all select   	'CKS Wholesale'	  as app_x, 		100713	 as app_c
union all select   	'CKS-X (Heavy Analytics)'	  as app_x, 		100706	 as app_c
union all select   	'Composite Service layer'	  as app_x, 		100729	 as app_c
union all select   	'Connected Electric Vehicle Services'	  as app_x, 		100603	 as app_c
--union all select   	'Consent Platform'	  as app_x, 		100624	 as app_c
union all select   	'DA Home to Vehicle'	  as app_x, 		100728	 as app_c
union all select   	'Data Fulfillment Application'	  as app_x, 		100732	 as app_c
union all select   	'Data Supply Chain'	  as app_x, 		100733	 as app_c
union all select   	'Enterprise Data Hub'	  as app_x, 		100730	 as app_c
union all select   	'ESPARS : Extended Service Plan Analysis & Rpt sys'	  as app_x, 		100703	 as app_c
union all select   	'ESPS:� Extended Service Plan System'	  as app_x, 		100701	 as app_c
union all select   	'Ford Performance Vehicles (AEM Campaigns)'	  as app_x, 		100719	 as app_c
union all select   	'Ford Telematics'	  as app_x, 		100717	 as app_c
union all select   	'Ford Vehicle Programs'	  as app_x, 		100707	 as app_c
--union all select   	'FordPass App'	  as app_x, 		100504	 as app_c
union all select   	'FordPass Dealer Interface'	  as app_x, 		100725	 as app_c
union all select   	'FSM FCS CRM Dynamics 365'	  as app_x, 		100724	 as app_c
union all select   	'GCAMP: Global Campaign Management System'	  as app_x, 		100705	 as app_c
union all select   	'In-Vehicle Security Services'	  as app_x, 		100710	 as app_c
union all select   	'lincoln Pick Up & Delivery'	  as app_x, 		100726	 as app_c
--union all select   	'Lincoln Way App'	  as app_x, 		100530	 as app_c
union all select   	'Media site'	  as app_x, 		100715	 as app_c
union all select   	'Motorcraft.com - 2015'	  as app_x, 		100423	 as app_c
union all select   	'North American Vehicle Information System'	  as app_x, 		100702	 as app_c
--union all select   	'Owner.com'	  as app_x, 		100392	 as app_c
union all select   	'QMarkets for Innovation Portal'	  as app_x, 		100720	 as app_c
union all select   	'SCA-C Consumer Account Profile'	  as app_x, 		100547	 as app_c
union all select   	'SCA-Vehicle'	  as app_x, 		100716	 as app_c
union all select   	'SDE - DSC TZ'	  as app_x, 		100734	 as app_c
union all select   	'SYNC Analytics 3.2v2'	  as app_x, 		100727	 as app_c
union all select   	'Trip Planner'	  as app_x, 		100731	 as app_c
union all select   	'Vehicle Health & Alerts'	  as app_x, 		100527	 as app_c
union all select   	'Vehicle Health & Alerts 3.0'	  as app_x, 		100605	 as app_c
union all select   	'Vehicle Incentives System'	  as app_x, 		100708	 as app_c
union all select   	'Vehicle POI'	  as app_x, 		100723	 as app_c
union all select   	'Vehicle Service Delivery Network'	  as app_x, 		100718	 as app_c
) tmp


select * from [dbo].[MCNPC01_APP_CODE]



insert into [MCNPC01_APP_CODE]
  values (100561,NULL,'CVBOP',GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 

 
 insert into [MCNPC01_APP_CODE]
  values (  100531	,NULL,	'FORDPASS GLOBAL LOYALTY PLATFORM',GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 

  
   insert into [MCNPC01_APP_CODE]   values (  100592	,NULL,	'CVAS-CVPP AUTHORIZATION SERVICE',GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
 

 select * from [MCNPC01_APP_CODE] 

 --update [MCNPC01_APP_CODE] set CNPC01_APP_X ='FORDPASS GLOBAL LOYALTY PLATFORM', CNPC01_UPDATE_S =GETUTCDATE() , CNPC01_UPDATE_USER_D ='banbilc1' where CNPC01_APP_C =100531

 ALTER TABLE [MCNPC01_APP_CODE] ADD CNPC01_ACTIVE_F char(1) NULL  DEFAULT 'Y' 

 --UPDATE [MCNPC01_APP_CODE] SET CNPC01_ACTIVE_F = 'Y' WHERE  CNPC01_APP_C = 100604
 --UPDATE [MCNPC01_APP_CODE] SET CNPC01_ACTIVE_F = 'N' WHERE  CNPC01_APP_C <>100604

 ALTER TABLE [MCNPC01_APP_CODE] ADD CNPC01_APP_CODE_GRP_N varchar(30) NULL

 UPDATE MCNPC01_APP_CODE set CNPC01_APP_CODE_GRP_N = 'PERMISSIONS CONSOLE'
 where CNPC01_APP_C in (100392,100433,100504,100530,100554,100555,100580,100589,100591,100597,100610)

