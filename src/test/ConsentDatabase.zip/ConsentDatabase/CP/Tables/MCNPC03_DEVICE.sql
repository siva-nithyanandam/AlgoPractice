
USE [SCACP]
GO



CREATE TABLE  [dbo].[MCNPC03_DEVICE](
	[CNPC03_DEVICE_TYPE_D] bigint NOT NULL,
	[CNPC03_DEVICE_TYPE_X] [varchar](50) NOT NULL,
	[CNPC03_CREATE_S] [datetime] NOT NULL,
	[CNPC03_CREATE_USER_D] [varchar](8) NOT NULL,
	[CNPC03_CREATE_PROCESS_C] [varchar](100) NOT NULL,
	[CNPC03_CREATE_APP_C] int NOT NULL,
	[CNPC03_UPDATE_S] [datetime] NOT NULL,
	[CNPC03_UPDATE_USER_D] [varchar](8) NOT NULL,
	[CNPC03_UPDATE_PROCESS_C] [varchar](100) NOT NULL,
	[CNPC03_UPDATE_APP_C] int NOT NULL
 CONSTRAINT [MCNPC031] PRIMARY KEY CLUSTERED 
(
	[CNPC03_DEVICE_TYPE_D] ASC
)


)

GO

INSERT INTO  [dbo].[MCNPC03_DEVICE] VALUES
 (1,'Email'			 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(2,'Home Email'	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(3,'Work Email'	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(4,'Phone'			 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(5,'Home Phone'	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(6,'Work Phone'	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(7,'Mobile Phone'	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(8,'Credit Card'	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(9,'VIN'			 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	;

GO

select * from [MCNPC03_DEVICE]
INSERT INTO  [dbo].[MCNPC03_DEVICE] VALUES
 (10, 'Home Telephone' 	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(11,'Cellular'			 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)		
,(12,'ALTERNATE PHONE'	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(13,'Business Telephone' , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(14,'Primary Residence'	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(15,'Personal Email'	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,(16,'Business Email'	 , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
;
GO


ALTER TABLE [dbo].[MCNPC03_DEVICE] ADD CONSTRAINT [MCNPC032] UNIQUE  ([CNPC03_DEVICE_TYPE_X])
GO