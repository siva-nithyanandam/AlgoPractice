
GO
 
CREATE TABLE dbo.MCNPC08_CONSENT_RELATION
(
 CNPC08_PARENT_CONSENT_K		bigint 
,CNPC08_CHILD_CONSENT_K	bigint
,[CNPC08_CREATE_S] [datetime] NOT NULL,
[CNPC08_CREATE_USER_D] [varchar](8) NOT NULL,
[CNPC08_CREATE_PROCESS_C] [varchar](100) NOT NULL,
[CNPC08_CREATE_APP_C] int NOT NULL,
[CNPC08_UPDATE_S] [datetime] NOT NULL,
[CNPC08_UPDATE_USER_D] [varchar](8) NOT NULL,
[CNPC08_UPDATE_PROCESS_C] [varchar](100) NOT NULL,
[CNPC08_UPDATE_APP_C] int NOT NULL
 
)
GO
ALTER TABLE MCNPC08_CONSENT_RELATION ADD CONSTRAINT MCNPC081 FOREIGN KEY(CNPC08_PARENT_CONSENT_K) REFERENCES  dbo.MCNPC07_CONSENT(CNPC07_CONSENT_K)
GO
ALTER TABLE MCNPC08_CONSENT_RELATION ADD CONSTRAINT MCNPC082 FOREIGN KEY(CNPC08_CHILD_CONSENT_K) REFERENCES  dbo.MCNPC07_CONSENT(CNPC07_CONSENT_K)
GO


--INSERT INTO dbo.MCNPC08_CONSENT_RELATION VALUES

-- (2,39  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,41  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,28  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,29  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,30  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,36  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,31  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,32  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,33  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,34  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,35  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,39  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,41  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,28  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,29  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,30  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,36  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,31  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,32  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,33  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,34  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)
--,(2,35  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)

SELECT * FROM dbo.MCNPC08_CONSENT_RELATION
--DELETE FROM dbo.MCNPC08_CONSENT_RELATION