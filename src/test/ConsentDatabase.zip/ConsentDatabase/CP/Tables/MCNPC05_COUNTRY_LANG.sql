
USE [SCACP]
GO

 
CREATE TABLE dbo.[MCNPC05_COUNTRY_LANG](
	[CNPC05_COUNTRY_LANG_C] [char](5) NOT NULL,
	[CNPC02_COUNTRY_ISO2_C] [char](2) NOT NULL,
	[CNPC05_LANG_ISO2_C] [char](2) NOT NULL,
	[CNPC05_COUNTRY_LANG_N] [nvarchar](120) NOT NULL,
	[CNPC05_CREATE_S] [datetime] NOT NULL,
	[CNPC05_CREATE_USER_D] [varchar](8) NOT NULL,
	[CNPC05_CREATE_PROCESS_C] [varchar](100) NOT NULL,
	[CNPC05_CREATE_APP_C] int NOT NULL,
	[CNPC05_UPDATE_S] [datetime] NOT NULL,
	[CNPC05_UPDATE_USER_D] [varchar](8) NOT NULL,
	[CNPC05_UPDATE_PROCESS_C] [varchar](100) NOT NULL,
	[CNPC05_UPDATE_APP_C] int NOT NULL,
 CONSTRAINT [MCNPC051] PRIMARY KEY CLUSTERED 
(
	[CNPC05_COUNTRY_LANG_C] ASC
) ,
 CONSTRAINT [MCNPC052] UNIQUE NONCLUSTERED 
(
	[CNPC02_COUNTRY_ISO2_C] ASC,
	[CNPC05_LANG_ISO2_C] ASC
) 
)  

ALTER TABLE dbo.[MCNPC05_COUNTRY_LANG]  WITH CHECK ADD  CONSTRAINT [MCNPC053] FOREIGN KEY([CNPC02_COUNTRY_ISO2_C])
REFERENCES dbo.[MCNPC02_COUNTRY] ([CNPC02_COUNTRY_ISO2_C])
GO
 

INSERT INTO  dbo.[MCNPC05_COUNTRY_LANG]  VALUES

 ('en-BR','BR','EN','English'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('en-CA','CA','EN','English'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('en-UK','IN','EN','English'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('en-US','US','EN','English'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('es-AR','AR','ES','Spanish'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('es-CA','CA','ES','Spanish'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('es-CL','CL','ES','Spanish'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('es-CO','CO','ES','Spanish'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('es-EC','EC','ES','Spanish'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('es-MX','MX','ES','Spanish'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('es-US','US','ES','Spanish'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('es-VE','VE','ES','Spanish'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('fr-CA','CA','FR','French'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('fr-MX','MX','FR','French'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('fr-US','US','FR','French'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('hi-IN','IN','HI','Hindi'		   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('mr-IN','IN','MR','Marathi'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('pt-BR','BR','PT','Portuguese'   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('UNKWN','UN','UN','UNKNOWN'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('zh-cn','CN','ZH','Chinese'	   , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	

GO

select * from dbo.[MCNPC05_COUNTRY_LANG] 
 