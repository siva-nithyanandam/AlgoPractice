
USE [SCACP]
GO



CREATE TABLE [dbo].[MCNPC04_STATUS](
	[CNPC04_STATUS_C] [char](1) NOT NULL,
	[CNPC04_STATUS_N] nvarchar(120) NOT NULL,
	[CNPC04_STATUS_X] nvarchar(255) NULL,
	[CNPC04_CREATE_S] [datetime] NOT NULL,
	[CNPC04_CREATE_USER_D] [varchar](8) NOT NULL,
	[CNPC04_CREATE_PROCESS_C] [varchar](100) NOT NULL,
	[CNPC04_CREATE_APP_C] int NOT NULL,
	[CNPC04_UPDATE_S] [datetime] NOT NULL,
	[CNPC04_UPDATE_USER_D] [varchar](8) NOT NULL,
	[CNPC04_UPDATE_PROCESS_C] [varchar](100) NOT NULL,
	[CNPC04_UPDATE_APP_C] int NOT NULL
 CONSTRAINT [MCNPC041] PRIMARY KEY CLUSTERED 
(
	[CNPC04_STATUS_C] ASC
)


)

GO
INSERT INTO [dbo].[MCNPC04_STATUS]  VALUES
 ('0',	'Explicit No'						,'Consumer explicitly revoked consent or opted-out'																		  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('1',	'Explicit Yes'						,'Consumer explicitly consented or opted-in'																			  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('D',	'Deleted'							,'POU has been removed from LL in CLIMES, resulting in Consent record deletion'											  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('G',	'Government Regulation, default Yes','Government mandated value of Yes that can be overridden by consumers'													  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('H',	'Government Regulation, default No'	,'Government mandated value of No that can be overridden by consumers'													  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('M',	'Implicit Consent'					,'Consumer implicitly provided consent'																					  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('N',	'Express No'						,'Consumer expressly opted out for the privacy option'																	  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('R',	'Replaced'							,'Legal Language has been replaced with subsequent version that no longer has a POU. Consumer Consent status _____'		  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('S',	'Government Regulation, static No'	,'Government mandated value of No that cannot be overridden by consumers'												  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
,('Y',	'Express Yes'						,'Consumer expressly opted in for the privacy option'																	  , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	)	
;
select * from  [dbo].[MCNPC04_STATUS] 


