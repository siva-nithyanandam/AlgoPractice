
--drop table MCNPC13_PRIVACY_DEVICE_MAPPING
CREATE TABLE dbo.MCNPC13_PRIVACY_DEVICE_MAPPING
 (
 CNPC13_PRIVACY_DEVICE_MAP_D		bigint NOT NULL IDENTITY(1,1),
 CNPC07_CONSENT_K					bigint,
 CNPC13_CONSUMER_TYP_X				varchar(120) NULL,
 CNPC02_REGION_C					char(3) NULL,
 CNPC03_DEVICE_TYPE_D				bigint NULL,
 CNPC13_DEVICE_ATTRIBUTE_X			varchar(250) NULL,
 CNPC13_CREATE_S					datetime NOT NULL,
 CNPC13_CREATE_USER_D				varchar(8) NOT NULL,
 CNPC13_CREATE_PROCESS_C			varchar(100) NOT NULL,
 CNPC13_CREATE_APP_C				int NOT NULL,
 CNPC13_UPDATE_S					datetime NOT NULL,
 CNPC13_UPDATE_USER_D				varchar(8) NOT NULL,
 CNPC13_UPDATE_PROCESS_C			varchar(100) NOT NULL,
 CNPC13_UPDATE_APP_C				int NOT NULL

 CONSTRAINT MCNPC131 PRIMARY KEY  CLUSTERED (CNPC13_PRIVACY_DEVICE_MAP_D)
)
 ALTER TABLE MCNPC13_PRIVACY_DEVICE_MAPPING ADD CONSTRAINT MCNPC132 FOREIGN KEY (CNPC03_DEVICE_TYPE_D) REFERENCES MCNPC03_DEVICE(CNPC03_DEVICE_TYPE_D)
 GO
  
 ALTER TABLE MCNPC13_PRIVACY_DEVICE_MAPPING ADD CONSTRAINT MCNPC133 FOREIGN KEY (CNPC07_CONSENT_K) REFERENCES MCNPC07_CONSENT(CNPC07_CONSENT_K)
 GO
  

  insert into  MCNPC13_PRIVACY_DEVICE_MAPPING   (CNPC07_CONSENT_K,CNPC13_CONSUMER_TYP_X,CNPC02_REGION_C,CNPC03_DEVICE_TYPE_D,CNPC13_DEVICE_ATTRIBUTE_X,CNPC13_CREATE_S,CNPC13_CREATE_USER_D,CNPC13_CREATE_PROCESS_C,CNPC13_CREATE_APP_C,CNPC13_UPDATE_S,CNPC13_UPDATE_USER_D,CNPC13_UPDATE_PROCESS_C,CNPC13_UPDATE_APP_C)

  select CNPC07_CONSENT_K,ConsumerType,Region,CNPC03_DEVICE_TYPE_D, Devicevalue	, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	 	 from (
SELECT 'PhonePermission'	 as 'PrivacyType',	'Person' as 'ConsumerType',	'NA'	 as 'Region',	'Home Telephone'	 as 'DeviceType'	,'Primary Number'	 as 'Devicevalue'
union all SELECT 'PhonePermission'	 as 'PrivacyType',	'Person' as 'ConsumerType',	'NA'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Secondary Number'	 as 'Devicevalue'
union all SELECT 'PhonePermission'	 as 'PrivacyType',	'Person' as 'ConsumerType',	'NA'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Mobile Number'		 as 'Devicevalue'
union all SELECT 'PhonePermission'	 as 'PrivacyType',	'Person' as 'ConsumerType',	'NA'	 as 'Region',	'ALTERNATE PHONE'	 as 'DeviceType'	,'Alternate Number'	 as 'Devicevalue'
union all SELECT 'PhonePermission'	 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'NA'	 as 'Region',	'Business Telephone' as 'DeviceType'	,'Primary Number'	 as 'Devicevalue'
union all SELECT 'PhonePermission'	 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'NA'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Secondary Number'	 as 'Devicevalue'
union all SELECT 'PhonePermission'	 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'NA'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Mobile Number'		 as 'Devicevalue'
union all SELECT 'PhonePermission'	 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'NA'	 as 'Region',	'ALTERNATE PHONE'	 as 'DeviceType'	,'Alternate Number'	 as 'Devicevalue'
union all SELECT 'SMSPermission'		 as 'PrivacyType',	'Person' as 'ConsumerType',	'NA'	 as 'Region',	'Home Telephone'	 as 'DeviceType'	,'Primary Number'	 as 'Devicevalue'
union all SELECT 'SMSPermission'		 as 'PrivacyType',	'Person' as 'ConsumerType',	'NA'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Secondary Number'	 as 'Devicevalue'
union all SELECT 'SMSPermission'		 as 'PrivacyType',	'Person' as 'ConsumerType',	'NA'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Mobile Number'	 as 'Devicevalue'
union all SELECT 'SMSPermission'		 as 'PrivacyType',	'Person' as 'ConsumerType',	'NA'	 as 'Region',	'ALTERNATE PHONE'	 as 'DeviceType'	,'Alternate Number'	 as 'Devicevalue'
union all SELECT 'SMSPermission'		 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'NA'	 as 'Region',	'Business Telephone' as 'DeviceType'	,'Primary Number'	 as 'Devicevalue'
union all SELECT 'SMSPermission'		 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'NA'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Secondary Number'	 as 'Devicevalue'
union all SELECT 'SMSPermission'		 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'NA'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Mobile Number'	 as 'Devicevalue'
union all SELECT 'SMSPermission'		 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'NA'	 as 'Region',	'ALTERNATE PHONE'	 as 'DeviceType'	,'Alternate Number'	 as 'Devicevalue'
union all SELECT 'MailPermission'	 as 'PrivacyType',	'Person' as 'ConsumerType',	'NA'	 as 'Region',	'Primary Residence'	 as 'DeviceType'	,'Address'			 as 'Devicevalue'
union all SELECT 'MailPermission'	 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'NA'	 as 'Region',	'Primary Residence'	 as 'DeviceType'	,'Address'			as 'Devicevalue'
union all SELECT 'EmailPermission'	 as 'PrivacyType',	'Person' as 'ConsumerType',	'NA'	 as 'Region',	'Email'				 as 'DeviceType'	,'Email(s)'			as 'Devicevalue'
union all SELECT 'EmailPermission'	 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'NA'	 as 'Region',	'Email'				 as 'DeviceType'	,'Email(s)'			as 'Devicevalue'
union all SELECT 'PhonePermission'	 as 'PrivacyType',	'Person' as 'ConsumerType',	'EU'	 as 'Region',	'Home Telephone'	 as 'DeviceType'	,'Primary Number'	 as 'Devicevalue'
union all SELECT 'PhonePermission'	 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'EU'	 as 'Region',	'Business Telephone' as 'DeviceType'	,'Primary Number'	 as 'Devicevalue'
union all SELECT 'MobilePermission'	 as 'PrivacyType',	'Person' as 'ConsumerType',	'EU'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Mobile Number'	 as 'Devicevalue'
union all SELECT 'MobilePermission'	 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'EU'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Mobile Number'	 as 'Devicevalue'
union all SELECT 'SMSPermission'		 as 'PrivacyType',	'Person' as 'ConsumerType',	'EU'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Mobile Number'	 as 'Devicevalue'
union all SELECT 'SMSPermission'		 as 'PrivacyType',	'Org'	 as 'ConsumerType',	'EU'	 as 'Region',	'Cellular'			 as 'DeviceType'	,'Mobile Number'	 as 'Devicevalue'
union all SELECT 'MailPermission'	 as 'PrivacyType',	'Person' as 'ConsumerType',	'EU'	 as 'Region',	'Primary Residence'	 as 'DeviceType'	,'Address'			 as 'Devicevalue'

) tmp
inner join MCNPC07_CONSENT C07
on  PrivacyType = CNPC07_CONSENT_N
inner join MCNPC03_DEVICE C03
on C03.CNPC03_DEVICE_TYPE_X = DeviceType



 insert into  MCNPC13_PRIVACY_DEVICE_MAPPING   (CNPC07_CONSENT_K,CNPC13_CONSUMER_TYP_X,CNPC02_REGION_C,CNPC03_DEVICE_TYPE_D,CNPC13_DEVICE_ATTRIBUTE_X,CNPC13_CREATE_S,CNPC13_CREATE_USER_D,CNPC13_CREATE_PROCESS_C,CNPC13_CREATE_APP_C,CNPC13_UPDATE_S,CNPC13_UPDATE_USER_D,CNPC13_UPDATE_PROCESS_C,CNPC13_UPDATE_APP_C)
 select CNPC07_CONSENT_K,ConsumerType,Region,CNPC03_DEVICE_TYPE_D, Devicevalue	, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1	 	 from (
 SELECT 'MailPermission'	 as 'PrivacyType',	'Org' as 'ConsumerType',	'EU'	 as 'Region',	'Primary Residence'	 as 'DeviceType'	,'Address'			 as 'Devicevalue'
 union all SELECT 'EmailPermission'	 as 'PrivacyType',	'Person' as 'ConsumerType',	'EU'	 as 'Region',	'Personal Email'			 as 'DeviceType'	,'Email(s)'	 as 'Devicevalue'
  union all SELECT 'EmailPermission'	 as 'PrivacyType',	'Org' as 'ConsumerType',	'EU'	 as 'Region',	'Business Email'			 as 'DeviceType'	,'Email(s)'	 as 'Devicevalue'
 
) tmp
inner join MCNPC07_CONSENT C07
on  PrivacyType = CNPC07_CONSENT_N
inner join MCNPC03_DEVICE C03
on C03.CNPC03_DEVICE_TYPE_X = DeviceType


select * from MCNPC07_CONSENT