USE SCACP
GO


CREATE OR ALTER VIEW  ppr.MCNPV04_DMD_DETAILS_VW
AS
SELECT		ROW_NUMBER() OVER( ORDER BY L09.CNPL01_REQUEST_SEQ_R  asc) SNO,
    L09.CNPL01_REQUEST_SEQ_R               as REQUEST_SEQUENCE_NUMBER,
	L09.CNPL01_REQUEST_S					 as REQUEST_TIMESTAMP,
	L10.CNPL10_CREATE_S						 as CREATE_TIMESTAMP,
	CNPL10_ID_VALUE_D		                 as ID_VALUE,
	CNPL10_ID_SOURCE_N                       as ID_SOURCE, 
	CNPL10_ID_KEY_D                          as ID_KEY,
	CNPL10_ID_REFERENCE_X					as ID_REFERENCE,
	CNPL09_APP_C                           as APPLICATION_CODE,
	CNPL09_FIRST_N                         as FIRST_NAME,
	CNPL09_MIDDLE_N                        as MIDDLE_NAME,
	CNPL09_LAST_N                          as LAST_NAME,
	CNPL09_NICK_N                          as NICK_NAME,
	CNPL09_FORMER_LAST_N                   as FORMER_LAST_NAME,
	CNPL09_ADDR_LINE_1_X                   as ADDRESS_LINE1,
	CNPL09_ADDR_LINE_2_X                   as ADDRESS_LINE2,
	CNPL09_CITY_N                          as CITY_NAME,
	CNPL09_STATE_N                         as STATE_NAME,
	CNPL09_POSTAL_C                        as POSTAL_CODE,
	CNPL09_COUNTRY_C                       as COUNTRY_CODE,

	CNPL09_PRIMARY_PHONE_R                 as PRIMARY_PHONE,
	CNPL09_PRIMARY_PHONE_TYPE_X				 as PRIMARY_PHONE_TYP,
	CNPL09_SECONDARY_PHONE_R               as SECONDARY_PHONE,
	CNPL09_SECONDARY_PHONE_TYPE_X			 as SECONDARY_PHONE_TYP,
	CNPL09_OTHER_EMAIL_X					 as OTHER_EMAIL,

	CNPL09_HOME_PHONE_R                    as HOME_PHONE, --to be removed
	CNPL09_MOBILE_PHONE_R                  as MOBILE_PHONE, --to be removed
	CNPL09_PRIMARY_EMAIL_X                 as PRIMARY_EMAIL,
	CNPC13_DEL_METHOD_C                    as DELIVERY_METHOD,
	CNPL09_VIN_C                           as VIN
	from ppr.MCNPL09_DMD_CONSUMER_REQUEST L09  
	INNER JOIN  ppr.MCNPL10_DMD_CONSUMER_REQUEST_DTL L10 
	on L09.CNPL01_REQUEST_SEQ_R	=	L10.CNPL01_REQUEST_SEQ_R



GO
 
 
   


