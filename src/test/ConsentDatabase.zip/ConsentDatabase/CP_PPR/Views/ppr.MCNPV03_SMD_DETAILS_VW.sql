USE [SCACP]
GO


CREATE OR ALTER VIEW  ppr.MCNPV03_SMD_DETAILS_VW
AS
SELECT	ROW_NUMBER() OVER( ORDER BY L07.[CNPL01_REQUEST_SEQ_R]  asc) SNO,
    L07.[CNPL01_REQUEST_SEQ_R]               as REQUEST_SEQUENCE_NUMBER,
	L07.CNPL01_REQUEST_S					 as REQUEST_TIMESTAMP,
	L08.CNPL08_CREATE_S						 as CREATE_TIMESTAMP,
	CNPL08_ID_VALUE_D		                 as ID_VALUE,
	CNPL08_ID_SOURCE_N                       as ID_SOURCE, 
	CNPL08_ID_KEY_D                          as ID_KEY,
	CNPL08_ID_REFERENCE_X					 as ID_REFERENCE,
	[CNPL07_APP_C]                           as APPLICATION_CODE,
	[CNPL07_FIRST_N]                         as FIRST_NAME,
	[CNPL07_MIDDLE_N]                        as MIDDLE_NAME,
	[CNPL07_LAST_N]                          as LAST_NAME,
	[CNPL07_NICK_N]                          as NICK_NAME,
	[CNPL07_FORMER_LAST_N]                   as FORMER_LAST_NAME,
	[CNPL07_ADDR_LINE_1_X]                   as ADDRESS_LINE1,
	[CNPL07_ADDR_LINE_2_X]                   as ADDRESS_LINE2,
	[CNPL07_CITY_N]                          as CITY_NAME,
	[CNPL07_STATE_N]                         as STATE_NAME,
	[CNPL07_POSTAL_C]                        as POSTAL_CODE,
	[CNPL07_COUNTRY_C]                       as COUNTRY_CODE,
	
	CNPL07_PRIMARY_PHONE_R                   as PRIMARY_PHONE,
	CNPL07_PRIMARY_PHONE_TYPE_X				 as PRIMARY_PHONE_TYP,
	CNPL07_SECONDARY_PHONE_R                 as SECONDARY_PHONE,
	CNPL07_SECONDARY_PHONE_TYPE_X			 as SECONDARY_PHONE_TYP,
	CNPL07_OTHER_EMAIL_X					 as OTHER_EMAIL,

	[CNPL07_HOME_PHONE_R]                    as HOME_PHONE,
	[CNPL07_MOBILE_PHONE_R]                  as MOBILE_PHONE,
	[CNPL07_PRIMARY_EMAIL_X]                 as PRIMARY_EMAIL,
	[CNPC13_DEL_METHOD_C]                    as DELIVERY_METHOD,
	[CNPL07_VIN_C]                           as VIN
	from [ppr].MCNPL07_SMD_CONSUMER_REQUEST L07  
	INNER JOIN  [ppr].MCNPL08_SMD_CONSUMER_REQUEST_DTL L08 
	on L07.CNPL01_REQUEST_SEQ_R	=	L08.CNPL01_REQUEST_SEQ_R

GO
 
   