USE [SCACP]
GO

 

CREATE OR ALTER VIEW  ppr.MCNPV02_DNS_DETAILS_VW
AS
SELECT	ROW_NUMBER() OVER( ORDER BY L05.[CNPL01_REQUEST_SEQ_R]  asc) SNO,
    L05.[CNPL01_REQUEST_SEQ_R]               as REQUEST_SEQUENCE_NUMBER,
	L05.CNPL01_REQUEST_S					 as REQUEST_TIMESTAMP,
	L06.CNPL06_CREATE_S						 as CREATE_TIMESTAMP,
	CNPL06_ID_VALUE_D		                 as ID_VALUE,
	CNPL06_ID_SOURCE_N                       as ID_SOURCE, 
	CNPL06_ID_KEY_D                          as ID_KEY,
	CNPL06_ID_REFERENCE_X					 as ID_REFERENCE,
	[CNPL05_APP_C]                           as APPLICATION_CODE,
	[CNPL05_FIRST_N]                         as FIRST_NAME,
	[CNPL05_MIDDLE_N]                        as MIDDLE_NAME,
	[CNPL05_LAST_N]                          as LAST_NAME,
	[CNPL05_NICK_N]                          as NICK_NAME,
	[CNPL05_FORMER_LAST_N]                   as FORMER_LAST_NAME,
	[CNPL05_ADDR_LINE_1_X]                   as ADDRESS_LINE1,
	[CNPL05_ADDR_LINE_2_X]                   as ADDRESS_LINE2,
	[CNPL05_CITY_N]                          as CITY_NAME,
	[CNPL05_STATE_N]                         as STATE_NAME,
	[CNPL05_POSTAL_C]                        as POSTAL_CODE,
	[CNPL05_COUNTRY_C]                       as COUNTRY_CODE,

	CNPL05_PRIMARY_PHONE_R                   as PRIMARY_PHONE,
	CNPL05_PRIMARY_PHONE_TYPE_X				 as PRIMARY_PHONE_TYP,
	CNPL05_SECONDARY_PHONE_R                 as SECONDARY_PHONE,
	CNPL05_SECONDARY_PHONE_TYPE_X			 as SECONDARY_PHONE_TYP,
	CNPL05_OTHER_EMAIL_X					 as OTHER_EMAIL,

	[CNPL05_HOME_PHONE_R]                    as HOME_PHONE,
	[CNPL05_MOBILE_PHONE_R]                  as MOBILE_PHONE,
	[CNPL05_PRIMARY_EMAIL_X]                 as PRIMARY_EMAIL,
	[CNPC13_DEL_METHOD_C]                    as DELIVERY_METHOD,
	[CNPL05_VIN_C]                           as VIN
	from [ppr].[MCNPL05_DNS_CONSUMER_REQUEST] L05  
	LEFT OUTER  JOIN  [ppr].[MCNPL06_DNS_CONSUMER_REQUEST_DTL] L06 
	on L05.CNPL01_REQUEST_SEQ_R	=	L06.CNPL01_REQUEST_SEQ_R

GO
 

