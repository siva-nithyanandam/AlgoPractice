USE [SCACP]
GO
--drop table cCNPa.MCNPC11_CCNPA_REQUEST_TYPE 
CREATE  TABLE ppr.MCNPC11_REQUEST_TYPE 
(
 CNPC11_REQUEST_TYP_C		varchar(4)		  NOT NULL 
,CNPC11_REQUEST_TYP_X		varchar(30)		  NOT NULL
,CNPC11_CREATE_S				datetime		  NOT NULL
,CNPC11_CREATE_USER_D		varchar	(8)		  NOT NULL
,CNPC11_CREATE_PROCESS_C		varchar (100)	  NOT NULL
,CNPC11_CREATE_APP_C			int				  NOT NULL
,CNPC11_UPDATE_S				datetime		  NOT NULL
,CNPC11_UPDATE_USER_D		varchar	 (8)	  NOT NULL
,CNPC11_UPDATE_PROCESS_C		varchar	 (100)	  NOT NULL
,CNPC11_UPDATE_APP_C			int				  NOT NULL

CONSTRAINT [MCNPC111] PRIMARY KEY  (CNPC11_REQUEST_TYP_C)
)

GO


INSERT INTO ppr.MCNPC11_REQUEST_TYPE 
VALUES
  ('DNS','Do Not Sell/Share my Data',getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('SMD','Show Me My Data'		    ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('DMD','Delete My Data'		    ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
;
GO