USE [SCACNP]
GO 
CREATE  TABLE ppr.MCNPC12_STATUS_CODE
(
 CNPC12_STATUS_C				char(1)			  NOT NULL 
,CNPC12_STATUS_X				varchar(20)		  NOT NULL
,CNPC12_CREATE_S				datetime		  NOT NULL
,CNPC12_CREATE_USER_D		varchar(8)		  NOT NULL
,CNPC12_CREATE_PROCESS_C		varchar(100)	  NOT NULL
,CNPC12_CREATE_APP_C			int				  NOT NULL
,CNPC12_UPDATE_S				datetime		  NOT NULL
,CNPC12_UPDATE_USER_D		varchar(8)		  NOT NULL
,CNPC12_UPDATE_PROCESS_C		varchar(100)	  NOT NULL
,CNPC12_UPDATE_APP_C			int				  NOT NULL

CONSTRAINT [MCNPC121] PRIMARY KEY  (CNPC12_STATUS_C)
)

GO

INSERT INTO ppr.MCNPC12_STATUS_CODE 
VALUES
  ('N'  ,'New'				 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('V'  ,'Verified'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('I'  ,'InProgress'		 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('D'  ,'Deleted'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('C'  ,'Completed'		 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('E'  ,'Extended'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('R'	,'Ready'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
;
GO

/*US1272884 CCPA - PPR New Valid Value for Request Status Code - Canceled  (services and DB) */
INSERT INTO ppr.MCNPC12_STATUS_CODE 
VALUES
('X' ,'Cancel' ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)


 
INSERT INTO ppr.MCNPC12_STATUS_CODE 
VALUES
('H'	,'Enriched'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)


GO
DELETE FROM  ppr.MCNPC12_STATUS_CODE  WHERE CNPC12_STATUS_C in ('D','V')
GO
select * from  ppr.MCNPC12_STATUS_CODE 


INSERT INTO   ppr.MCNPC12_STATUS_CODE 
VALUES
('V'	,'Verifying'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)

GO