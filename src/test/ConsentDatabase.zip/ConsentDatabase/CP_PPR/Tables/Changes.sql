select * from information_schema.columns where column_name like '%APP_N%'
GO
sp_rename 'ppr.MCNPL06_DNS_CONSUMER_REQUEST_DTL.CNPL06_APP_N'		,'CNPL06_ID_SOURCE_N'
GO
sp_rename 'ppr.MCNPL08_SMD_CONSUMER_REQUEST_DTL.CNPL08_APP_N'		,'CNPL08_ID_SOURCE_N'
GO
sp_rename 'ppr.MCNPL10_DMD_CONSUMER_REQUEST_DTL.CNPL10_APP_N'		,'CNPL10_ID_SOURCE_N'
GO
sp_rename 'ppr.MCNPL02_CONSUMER_REQUEST_DTL.CNPL02_APP_N'			,'CNPL02_ID_SOURCE_N'
GO

select * from information_schema.columns where column_name like '%APP_X%'
GO
sp_rename 'ppr.MCNPL06_DNS_CONSUMER_REQUEST_DTL.CNPL06_APP_X'	,'CNPL06_ID_KEY_D'
GO
sp_rename 'ppr.MCNPL08_SMD_CONSUMER_REQUEST_DTL.CNPL08_APP_X'	,'CNPL08_ID_KEY_D'
GO
sp_rename 'ppr.MCNPL10_DMD_CONSUMER_REQUEST_DTL.CNPL10_APP_X'	,'CNPL10_ID_KEY_D'
GO
sp_rename 'ppr.MCNPL02_CONSUMER_REQUEST_DTL.CNPL02_APP_X'		,'CNPL02_ID_KEY_D'
GO

select * from information_schema.columns where column_name like '%CUST_D%'
GO
sp_rename 'ppr.MCNPL02_CONSUMER_REQUEST_DTL.CNPL02_CUST_D','CNPL02_ID_VALUE_D'
GO
sp_rename 'ppr.MCNPL06_DNS_CONSUMER_REQUEST_DTL.CNPL06_CUST_D','CNPL06_ID_VALUE_D'
GO
sp_rename 'ppr.MCNPL08_SMD_CONSUMER_REQUEST_DTL.CNPL08_CUST_D','CNPL08_ID_VALUE_D'
GO
sp_rename 'ppr.MCNPL10_DMD_CONSUMER_REQUEST_DTL.CNPL10_CUST_D','CNPL10_ID_VALUE_D'
GO

select * from information_schema.columns where column_name like '%CNPL02_GSR_D%'
GO
sp_rename 'ppr.MCNPL02_CONSUMER_REQUEST_DTL.CNPL02_GSR_D','CNPL02_ID_REFERENCE_X'
GO


