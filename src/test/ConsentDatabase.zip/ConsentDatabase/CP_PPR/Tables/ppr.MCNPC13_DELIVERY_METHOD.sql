
USE [SCACP]
GO

CREATE TABLE ppr.MCNPC13_DELIVERY_METHOD
(
 CNPC13_DEL_METHOD_C		char(1)			  NOT NULL 
,CNPC13_DEL_METHOD_X		varchar(10)		  NOT NULL
,CNPC13_CREATE_S			datetime		  NOT NULL
,CNPC13_CREATE_USER_D		varchar(8)		  NOT NULL
,CNPC13_CREATE_PROCESS_C	varchar(100)	  NOT NULL
,CNPC13_CREATE_APP_C		int				  NOT NULL
,CNPC13_UPDATE_S			datetime		  NOT NULL
,CNPC13_UPDATE_USER_D	varchar (8)		  NOT NULL
,CNPC13_UPDATE_PROCESS_C	varchar(100)	  NOT NULL
,CNPC13_UPDATE_APP_C		int				  NOT NULL

CONSTRAINT [MCNPC131] PRIMARY KEY  (CNPC13_DEL_METHOD_C)

)
GO 

INSERT INTO ppr.MCNPC13_DELIVERY_METHOD 
VALUES
 ('M', 'Mail'		,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1),
('E', 'Electronic' ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
;
 
 GO


ALTER TABLE ppr.MCNPC13_DELIVERY_METHOD  ALTER COLUMN CNPC13_DEL_METHOD_X		varchar(25)		  NOT NULL
GO


INSERT INTO ppr.MCNPC13_DELIVERY_METHOD 
VALUES

 ('O', 'Other Email' ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
;

UPDATE ppr.MCNPC13_DELIVERY_METHOD  SET CNPC13_DEL_METHOD_X ='Primary Email' , CNPC13_UPDATE_S=GETDATE()   WHERE CNPC13_DEL_METHOD_C ='E'
GO
select * from  ppr.MCNPC13_DELIVERY_METHOD 
GO

