
/*******************************************************************************************/        
/*Created By  : banbilc1                  */        
/*Created On  : 17-Oct-2019                 */        
/*Purpose   :  To populate L06 -L10 tables on change of L01 status to "Ready"             */        
/*Dependent Objects : [ppr].[MCNPL01_CONSUMER_REQUEST]             */        
/*******************************************************************************************/        
/* Modified By  Modified Date  Defect/Comment            */        
/*******************************************************************************************/        
/**/
/*******************************************************************************************/        
        
        
CREATE OR ALTER  TRIGGER [ppr].[MCNPL01_REQUEST_UPDATE_TR] ON ppr.MCNPL01_CONSUMER_REQUEST         
FOR UPDATE        
AS        
BEGIN 

   -- Variable declaration
	DECLARE  @L01ID		bigint 
		  ,  @ReqDate	datetime
		  ,  @ReqType	varchar(4)

		  ,  @user		varchar(100) =  USER  
		  ,  @userID	varchar(8)
		  ,  @CurrentTS datetime = GETUTCDATE()

	-- get L01 ID
	SELECT   @L01ID =  CNPL01_REQUEST_SEQ_R ,@ReqDate = CNPL01_REQUEST_S  , @ReqType= CNPC11_REQUEST_TYP_C  FROM inserted  WHERE CNPC12_STATUS_C ='R'
	
	SELECT @userID = CASE WHEN RIGHT(@user,CHARINDEX('\',@user))='' THEN SUBSTRING (@user,(charindex('_',@user)+1),8)  ELSE RIGHT(@user,CHARINDEX('\',@user)) END   

	IF @L01ID IS NOT NULL
	BEGIN 
		--Create and store L02 record of L01
		IF OBJECT_ID('tempdb.#L02') >0
		BEGIN 
			DROP TABLE #L02
		END
		SELECT * INTO #L02 FROM  ppr.MCNPL02_CONSUMER_REQUEST_DTL WHERE CNPL01_REQUEST_SEQ_R = @L01ID

		IF @ReqType = 'DNS'
			BEGIN 
					--INSERT INTO L06
					INSERT INTO ppr.MCNPL06_DNS_CONSUMER_REQUEST_DTL  (  CNPL01_REQUEST_SEQ_R		,CNPL02_REQUEST_DTL_SEQ_R
																		,CNPL06_ID_SOURCE_N				,CNPL06_ID_KEY_D				,CNPL06_ID_VALUE_D
																		,CNPL06_CREATE_S			,CNPL06_CREATE_USER_D		,CNPL06_CREATE_PROCESS_C		,CNPL06_CREATE_APP_C
																		,CNPL06_UPDATE_S			,CNPL06_UPDATE_USER_D		,CNPL06_UPDATE_PROCESS_C		,CNPL06_UPDATE_APP_C
																		,CNPL06_ID_REFERENCE_X
																		)
				
					SELECT												 CNPL01_REQUEST_SEQ_R		,CNPL02_REQUEST_DTL_SEQ_R	
																		,CNPL02_ID_SOURCE_N				,CNPL02_ID_KEY_D				,CNPL02_ID_VALUE_D
																		,@CurrentTS					, @userID					, 'L01_update_TR'				,100624
																		,@CurrentTS					, @userID					, 'L01_update_TR'				,100624
																		,CNPL02_ID_REFERENCE_X
						FROM  #L02  
						WHERE CNPC11_REQUEST_TYP_C ='DNS'
			END

		IF @ReqType = 'SMD'
			BEGIN 
					--Insert into SMD 
					INSERT INTO ppr.MCNPL07_SMD_CONSUMER_REQUEST  ( CNPL01_REQUEST_SEQ_R	,CNPL01_REQUEST_S			,CNPL07_APP_C	
																	,CNPL07_FIRST_N			,CNPL07_MIDDLE_N			,CNPL07_LAST_N			 ,CNPL07_NICK_N					,CNPL07_FORMER_LAST_N
																	,CNPL07_ADDR_LINE_1_X	,CNPL07_ADDR_LINE_2_X		,CNPL07_CITY_N			 ,CNPL07_STATE_N				,CNPL07_POSTAL_C,CNPL07_COUNTRY_C
																	,CNPL07_HOME_PHONE_R	,CNPL07_MOBILE_PHONE_R		,CNPL07_PRIMARY_EMAIL_X	 ,CNPC13_DEL_METHOD_C			,CNPL07_VIN_C
																	,CNPL07_CREATE_S		,CNPL07_CREATE_USER_D		,CNPL07_CREATE_PROCESS_C ,CNPL07_CREATE_APP_C
																	,CNPL07_UPDATE_S		,CNPL07_UPDATE_USER_D		,CNPL07_UPDATE_PROCESS_C ,CNPL07_UPDATE_APP_C 
																	,CNPL07_PRIMARY_PHONE_R	,CNPL07_PRIMARY_PHONE_TYPE_X,CNPL07_SECONDARY_PHONE_R,CNPL07_SECONDARY_PHONE_TYPE_X	,CNPL07_OTHER_EMAIL_X																	
																	)
					SELECT											 CNPL01_REQUEST_SEQ_R	,CNPL01_REQUEST_S		,CNPL01_APP_C	
																	,CNPL01_FIRST_N			,CNPL01_MIDDLE_N		,CNPL01_LAST_N			 ,CNPL01_NICK_N			,CNPL01_FORMER_LAST_N
																	,CNPL01_ADDR_LINE_1_X	,CNPL01_ADDR_LINE_2_X	,CNPL01_CITY_N			 ,CNPL01_STATE_N		,CNPL01_POSTAL_C,CNPL01_COUNTRY_C
																	,CNPL01_HOME_PHONE_R	,CNPL01_MOBILE_PHONE_R	,CNPL01_PRIMARY_EMAIL_X	 ,CNPC13_DEL_METHOD_C	,CNPL01_VIN_C							   
																	,@CurrentTS				,@userID				,'L01_update_TR'		 ,100624
																	,@CurrentTS				,@userID				,'L01_update_TR'		 ,100624
																	,CNPL01_PRIMARY_PHONE_R	,CNPL01_PRIMARY_PHONE_TYPE_X,CNPL01_SECONDARY_PHONE_R,CNPL01_SECONDARY_PHONE_TYPE_X	,CNPL01_OTHER_EMAIL_X
					FROM inserted
					WHERE  CNPC12_STATUS_C ='R' AND CNPC11_REQUEST_TYP_C ='SMD'
								

					--INSERT INTO SMD DTL
					INSERT INTO ppr.MCNPL08_SMD_CONSUMER_REQUEST_DTL  (  CNPL01_REQUEST_SEQ_R		,CNPL02_REQUEST_DTL_SEQ_R
																		,CNPL08_ID_SOURCE_N				,CNPL08_ID_KEY_D				,CNPL08_ID_VALUE_D
																		,CNPL08_CREATE_S			,CNPL08_CREATE_USER_D		,CNPL08_CREATE_PROCESS_C		,CNPL08_CREATE_APP_C
																		,CNPL08_UPDATE_S			,CNPL08_UPDATE_USER_D		,CNPL08_UPDATE_PROCESS_C		,CNPL08_UPDATE_APP_C
																		,CNPL08_ID_REFERENCE_X
																		)
				
					SELECT												 CNPL01_REQUEST_SEQ_R		,CNPL02_REQUEST_DTL_SEQ_R	
																		,CNPL02_ID_SOURCE_N				,CNPL02_ID_KEY_D				,CNPL02_ID_VALUE_D
																		,@CurrentTS					, @userID					,'L01_update_TR'				,100624
																		,@CurrentTS					, @userID					,'L01_update_TR'				,100624
																		,CNPL02_ID_REFERENCE_X
						FROM  #L02  
						WHERE CNPC11_REQUEST_TYP_C ='SMD'
			END

		IF @ReqType = 'DMD'
			BEGIN 
					--Insert into SMD 
					INSERT INTO ppr.MCNPL09_DMD_CONSUMER_REQUEST  ( CNPL01_REQUEST_SEQ_R	,CNPL01_REQUEST_S		,CNPL09_APP_C	
																	,CNPL09_FIRST_N			,CNPL09_MIDDLE_N		,CNPL09_LAST_N			 ,CNPL09_NICK_N			,CNPL09_FORMER_LAST_N
																	,CNPL09_ADDR_LINE_1_X	,CNPL09_ADDR_LINE_2_X	,CNPL09_CITY_N			 ,CNPL09_STATE_N		,CNPL09_POSTAL_C,CNPL09_COUNTRY_C
																	,CNPL09_HOME_PHONE_R	,CNPL09_MOBILE_PHONE_R	,CNPL09_PRIMARY_EMAIL_X	 ,CNPC13_DEL_METHOD_C	,CNPL09_VIN_C
																	,CNPL09_CREATE_S		,CNPL09_CREATE_USER_D	,CNPL09_CREATE_PROCESS_C ,CNPL09_CREATE_APP_C
																	,CNPL09_UPDATE_S		,CNPL09_UPDATE_USER_D	,CNPL09_UPDATE_PROCESS_C ,CNPL09_UPDATE_APP_C 
																	,CNPL09_PRIMARY_PHONE_R	,CNPL09_PRIMARY_PHONE_TYPE_X,CNPL09_SECONDARY_PHONE_R,CNPL09_SECONDARY_PHONE_TYPE_X	,CNPL09_OTHER_EMAIL_X
																	)
					SELECT											 CNPL01_REQUEST_SEQ_R	,CNPL01_REQUEST_S		,CNPL01_APP_C	
																	,CNPL01_FIRST_N			,CNPL01_MIDDLE_N		,CNPL01_LAST_N			 ,CNPL01_NICK_N			,CNPL01_FORMER_LAST_N
																	,CNPL01_ADDR_LINE_1_X	,CNPL01_ADDR_LINE_2_X	,CNPL01_CITY_N			 ,CNPL01_STATE_N		,CNPL01_POSTAL_C,CNPL01_COUNTRY_C
																	,CNPL01_HOME_PHONE_R	,CNPL01_MOBILE_PHONE_R	,CNPL01_PRIMARY_EMAIL_X	 ,CNPC13_DEL_METHOD_C	,CNPL01_VIN_C							   
																	,@CurrentTS				,@userID				,'L01_update_TR'		 ,100624
																	,@CurrentTS				,@userID				,'L01_update_TR'		 ,100624
																	,CNPL01_PRIMARY_PHONE_R	,CNPL01_PRIMARY_PHONE_TYPE_X,CNPL01_SECONDARY_PHONE_R,CNPL01_SECONDARY_PHONE_TYPE_X	,CNPL01_OTHER_EMAIL_X
					FROM inserted
					WHERE  CNPC12_STATUS_C ='R' AND CNPC11_REQUEST_TYP_C ='DMD'
								

					--INSERT INTO SMD DTL
					INSERT INTO ppr.MCNPL10_DMD_CONSUMER_REQUEST_DTL  (  CNPL01_REQUEST_SEQ_R		,CNPL02_REQUEST_DTL_SEQ_R
																		,CNPL10_ID_SOURCE_N				,CNPL10_ID_KEY_D				,CNPL10_ID_VALUE_D
																		,CNPL10_CREATE_S			,CNPL10_CREATE_USER_D		,CNPL10_CREATE_PROCESS_C		,CNPL10_CREATE_APP_C
																		,CNPL10_UPDATE_S			,CNPL10_UPDATE_USER_D		,CNPL10_UPDATE_PROCESS_C		,CNPL10_UPDATE_APP_C
																		,CNPL10_ID_REFERENCE_X
																		)
				
					SELECT												 CNPL01_REQUEST_SEQ_R		,CNPL02_REQUEST_DTL_SEQ_R	
																		,CNPL02_ID_SOURCE_N				,CNPL02_ID_KEY_D				,CNPL02_ID_VALUE_D
																		,@CurrentTS					, @userID					,'L01_update_TR'				,100624
																		,@CurrentTS					, @userID					,'L01_update_TR'				,100624
																		,CNPL02_ID_REFERENCE_X
					FROM  #L02  
					WHERE CNPC11_REQUEST_TYP_C ='DMD'
			END
	
		END
END
GO


ENABLE TRIGGER [ppr].[MCNPL01_REQUEST_UPDATE_TR] ON ppr.MCNPL01_CONSUMER_REQUEST         