 USE SCAPP 
 GO
/***************************************************************************/
CREATE LOGIN [FORD\USWF-SCACP-CCPA-DEV-RW] FROM WINDOWS;  
GO
/**********************		CREATE USER  ************************************/ 

CREATE USER [FORD\USWF-SCACP-CCPA-DEV-RW] FOR LOGIN [FORD\USWF-SCACP-CCPA-DEV-RW]-- WITH DEFAULT_SCHEMA=[dbo]
GO


/**********************		ASSIGN ROLE TO USER  ************************************/ 
ALTER ROLE db_datareader ADD MEMBER  [FORD\USWF-SCACP-CCPA-DEV-RW]
GO
ALTER ROLE db_datawriter ADD MEMBER  [FORD\USWF-SCACP-CCPA-DEV-RW]
GO
 

