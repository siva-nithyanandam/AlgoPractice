--select * from MPPRW01_REQUEST_WORKFLOW
/*******************************************************************************************/        
/*Created By  : banbilc1                  */        
/*Created On  : 06-Feb-2020                 */        
/*Purpose   :  To update workflow id in L01            */        
/*Dependent Objects : [MPPRL01_CONSUMER_REQUEST]             */        
/*******************************************************************************************/        
/* Modified By  Modified Date  Defect/Comment            */        
/*******************************************************************************************/        
/**/
/*******************************************************************************************/        
        
        
CREATE OR ALTER  TRIGGER [MPPRW01_REQUEST_WORKFLOW_INS_TR] ON MPPRW01_REQUEST_WORKFLOW         
FOR INSERT        
AS        
BEGIN 

   -- Variable declaration
	DECLARE  @user		varchar(100) =  USER  
		  ,  @userID	varchar(8)
		  
	SELECT @userID = CASE WHEN RIGHT(@user,CHARINDEX('\',@user))='' THEN SUBSTRING (@user,(charindex('_',@user)+1),8)  ELSE RIGHT(@user,CHARINDEX('\',@user)) END   
	  
   UPDATE L01
   SET   L01.PPRL01_WORKFLOW_D		= tmp.PPRW01_WORKFLOW_D 
    ,    L01.PPRL01_UPDATE_S		= GETUTCDATE()
	,	 L01.PPRL01_UPDATE_USER_D	= @userID
	,	 L01.PPRL01_UPDATE_PROCESS_C= 'MPPRW01_REQUEST_WORKFLOW_INS_TR'
	,	 L01.PPRL01_UPDATE_APP_C    = 100738
   FROM  inserted tmp
   INNER JOIN MPPRL01_CONSUMER_REQUEST L01 
   ON 		  tmp.PPRW01_REQUEST_SEQ_R = L01.PPRL01_REQUEST_SEQ_R
   WHERE   ISNULL(L01.PPRL01_WORKFLOW_D,'') <> tmp.PPRW01_WORKFLOW_D

END
GO


ENABLE TRIGGER [MPPRW01_REQUEST_WORKFLOW_INS_TR] ON MPPRW01_REQUEST_WORKFLOW          