--select * from MPPRL01_CONSUMER_REQUEST
--update MPPRL01_CONSUMER_REQUEST set PPRC02_STATUS_C='R' where PPRL01_REQUEST_SEQ_R =24
/*******************************************************************************************/        
/*Created By  : banbilc1                  */        
/*Created On  : 17-Oct-2019                 */        
/*Purpose   :  To populate L06 -L10 tables on change of L01 status to "Ready"             */        
/*Dependent Objects : [MPPRL01_CONSUMER_REQUEST]             */        
/*******************************************************************************************/        
/* Modified By  Modified Date  Defect/Comment            */        
/*******************************************************************************************/        
/**/
/*******************************************************************************************/        
        
        
CREATE OR ALTER  TRIGGER [MPPRL01_REQUEST_UPDATE_TR] ON MPPRL01_CONSUMER_REQUEST         
FOR UPDATE        
AS        
BEGIN 

   -- Variable declaration
	DECLARE  @L01ID		bigint 
		  ,  @ReqDate	datetime
		  ,  @ReqType	varchar(4)

		  ,  @user		varchar(100) =  USER  
		  ,  @userID	varchar(8)
		  ,  @CurrentTS datetime = GETUTCDATE()

	-- get L01 ID
	SELECT   @L01ID =  PPRL01_REQUEST_SEQ_R ,@ReqDate = PPRL01_REQUEST_S  , @ReqType= PPRC01_REQUEST_TYP_C  FROM inserted  WHERE PPRC02_STATUS_C ='R'
	
	SELECT @userID = CASE WHEN RIGHT(@user,CHARINDEX('\',@user))='' THEN SUBSTRING (@user,(charindex('_',@user)+1),8)  ELSE RIGHT(@user,CHARINDEX('\',@user)) END   

	IF @L01ID IS NOT NULL
	BEGIN 
		--Create and store L02 record of L01
		IF OBJECT_ID('tempdb.#L02') >0
		BEGIN 
			DROP TABLE #L02
		END
		SELECT L02.* ,L01.PPRC01_REQUEST_TYP_C INTO #L02 FROM  MPPRL02_CONSUMER_REQUEST_DTL L02 
		INNER JOIN MPPRL01_CONSUMER_REQUEST L01
		ON L02.PPRL01_REQUEST_SEQ_R = L01.PPRL01_REQUEST_SEQ_R
		WHERE L02.PPRL01_REQUEST_SEQ_R = @L01ID

		IF @ReqType = 'DNS'
			BEGIN 
					--INSERT INTO L06
					INSERT INTO MPPRL06_DNS_CONSUMER_REQUEST_DTL  (  PPRL01_REQUEST_SEQ_R		,PPRL02_REQUEST_DTL_SEQ_R
																		,PPRL06_ID_SOURCE_N				,PPRL06_ID_KEY_D				,PPRL06_ID_VALUE_D
																		,PPRL06_CREATE_S			,PPRL06_CREATE_USER_D		,PPRL06_CREATE_PROCESS_C		,PPRL06_CREATE_APP_C
																		,PPRL06_UPDATE_S			,PPRL06_UPDATE_USER_D		,PPRL06_UPDATE_PROCESS_C		,PPRL06_UPDATE_APP_C
																		,PPRL06_ID_REFERENCE_X
																		)
				
					SELECT												 PPRL01_REQUEST_SEQ_R		,PPRL02_REQUEST_DTL_SEQ_R	
																		,PPRL02_ID_SOURCE_N				,PPRL02_ID_KEY_D				,PPRL02_ID_VALUE_D
																		,@CurrentTS					, @userID					, 'L01_update_TR'				,100624
																		,@CurrentTS					, @userID					, 'L01_update_TR'				,100624
																		,PPRL02_ID_REFERENCE_X
						FROM  #L02  
						WHERE PPRC01_REQUEST_TYP_C ='DNS'
			END

		IF @ReqType = 'SMD'
			BEGIN 
					--Insert into SMD 
					INSERT INTO MPPRL07_SMD_CONSUMER_REQUEST  ( PPRL01_REQUEST_SEQ_R	,PPRL01_REQUEST_S			,PPRL07_APP_C	
																	,PPRL07_FIRST_N			,PPRL07_MIDDLE_N			,PPRL07_LAST_N			 ,PPRL07_NICK_N					,PPRL07_FORMER_LAST_N
																	,PPRL07_ADDR_LINE_1_X	,PPRL07_ADDR_LINE_2_X		,PPRL07_CITY_N			 ,PPRL07_STATE_N				,PPRL07_POSTAL_C,PPRL07_COUNTRY_C
																	,PPRL07_PRIMARY_EMAIL_X	 ,PPRC03_DEL_METHOD_C			,PPRL07_VIN_C
																	,PPRL07_CREATE_S		,PPRL07_CREATE_USER_D		,PPRL07_CREATE_PROCESS_C ,PPRL07_CREATE_APP_C
																	,PPRL07_UPDATE_S		,PPRL07_UPDATE_USER_D		,PPRL07_UPDATE_PROCESS_C ,PPRL07_UPDATE_APP_C 
																	,PPRL07_PRIMARY_PHONE_R	,PPRL07_PRIMARY_PHONE_TYPE_X,PPRL07_SECONDARY_PHONE_R,PPRL07_SECONDARY_PHONE_TYPE_X	,PPRL07_OTHER_EMAIL_X																	
																	)
					SELECT											 PPRL01_REQUEST_SEQ_R	,PPRL01_REQUEST_S		,PPRL01_APP_C	
																	,PPRL01_FIRST_N			,PPRL01_MIDDLE_N		,PPRL01_LAST_N			 ,PPRL01_NICK_N			,PPRL01_FORMER_LAST_N
																	,PPRL01_ADDR_LINE_1_X	,PPRL01_ADDR_LINE_2_X	,PPRL01_CITY_N			 ,PPRL01_STATE_N		,PPRL01_POSTAL_C,PPRL01_COUNTRY_C																	
																	,PPRL01_PRIMARY_EMAIL_X	 ,PPRC03_DEL_METHOD_C	,PPRL01_VIN_C							   
																	,@CurrentTS				,@userID				,'L01_update_TR'		 ,100624
																	,@CurrentTS				,@userID				,'L01_update_TR'		 ,100624
																	,PPRL01_PRIMARY_PHONE_R	,PPRL01_PRIMARY_PHONE_TYPE_X,PPRL01_SECONDARY_PHONE_R,PPRL01_SECONDARY_PHONE_TYPE_X	,PPRL01_OTHER_EMAIL_X
					FROM inserted
					WHERE  PPRC02_STATUS_C ='R' AND PPRC01_REQUEST_TYP_C ='SMD'
								

					--INSERT INTO SMD DTL
					INSERT INTO MPPRL08_SMD_CONSUMER_REQUEST_DTL  (  PPRL01_REQUEST_SEQ_R		,PPRL02_REQUEST_DTL_SEQ_R
																		,PPRL08_ID_SOURCE_N				,PPRL08_ID_KEY_D				,PPRL08_ID_VALUE_D
																		,PPRL08_CREATE_S			,PPRL08_CREATE_USER_D		,PPRL08_CREATE_PROCESS_C		,PPRL08_CREATE_APP_C
																		,PPRL08_UPDATE_S			,PPRL08_UPDATE_USER_D		,PPRL08_UPDATE_PROCESS_C		,PPRL08_UPDATE_APP_C
																		,PPRL08_ID_REFERENCE_X
																		)
				
					SELECT												 PPRL01_REQUEST_SEQ_R		,PPRL02_REQUEST_DTL_SEQ_R	
																		,PPRL02_ID_SOURCE_N				,PPRL02_ID_KEY_D				,PPRL02_ID_VALUE_D
																		,@CurrentTS					, @userID					,'L01_update_TR'				,100624
																		,@CurrentTS					, @userID					,'L01_update_TR'				,100624
																		,PPRL02_ID_REFERENCE_X
						FROM  #L02  
						WHERE PPRC01_REQUEST_TYP_C ='SMD'
			END

		IF @ReqType = 'DMD'
			BEGIN 
					--Insert into SMD 
					INSERT INTO MPPRL09_DMD_CONSUMER_REQUEST  (		PPRL01_REQUEST_SEQ_R		,PPRL01_REQUEST_S		,PPRL09_APP_C	
																	,PPRL09_FIRST_N			,PPRL09_MIDDLE_N		,PPRL09_LAST_N			 ,PPRL09_NICK_N			,PPRL09_FORMER_LAST_N
																	,PPRL09_ADDR_LINE_1_X	,PPRL09_ADDR_LINE_2_X	,PPRL09_CITY_N			 ,PPRL09_STATE_N		,PPRL09_POSTAL_C,PPRL09_COUNTRY_C
																	,PPRL09_PRIMARY_EMAIL_X	 ,PPRC03_DEL_METHOD_C	,PPRL09_VIN_C
																	,PPRL09_CREATE_S		,PPRL09_CREATE_USER_D	,PPRL09_CREATE_PROCESS_C ,PPRL09_CREATE_APP_C
																	,PPRL09_UPDATE_S		,PPRL09_UPDATE_USER_D	,PPRL09_UPDATE_PROCESS_C ,PPRL09_UPDATE_APP_C 
																	,PPRL09_PRIMARY_PHONE_R	,PPRL09_PRIMARY_PHONE_TYPE_X,PPRL09_SECONDARY_PHONE_R,PPRL09_SECONDARY_PHONE_TYPE_X	,PPRL09_OTHER_EMAIL_X
																	)
					SELECT											 PPRL01_REQUEST_SEQ_R	,PPRL01_REQUEST_S		,PPRL01_APP_C	
																	,PPRL01_FIRST_N			,PPRL01_MIDDLE_N		,PPRL01_LAST_N			 ,PPRL01_NICK_N			,PPRL01_FORMER_LAST_N
																	,PPRL01_ADDR_LINE_1_X	,PPRL01_ADDR_LINE_2_X	,PPRL01_CITY_N			 ,PPRL01_STATE_N		,PPRL01_POSTAL_C,PPRL01_COUNTRY_C
																	,PPRL01_PRIMARY_EMAIL_X	 ,PPRC03_DEL_METHOD_C	,PPRL01_VIN_C							   
																	,@CurrentTS				,@userID				,'L01_update_TR'		 ,100624
																	,@CurrentTS				,@userID				,'L01_update_TR'		 ,100624
																	,PPRL01_PRIMARY_PHONE_R	,PPRL01_PRIMARY_PHONE_TYPE_X,PPRL01_SECONDARY_PHONE_R,PPRL01_SECONDARY_PHONE_TYPE_X	,PPRL01_OTHER_EMAIL_X
					FROM inserted
					WHERE  PPRC02_STATUS_C ='R' AND PPRC01_REQUEST_TYP_C ='DMD'
								

					--INSERT INTO SMD DTL
					INSERT INTO MPPRL10_DMD_CONSUMER_REQUEST_DTL  (  PPRL01_REQUEST_SEQ_R		,PPRL02_REQUEST_DTL_SEQ_R
																		,PPRL10_ID_SOURCE_N				,PPRL10_ID_KEY_D				,PPRL10_ID_VALUE_D
																		,PPRL10_CREATE_S			,PPRL10_CREATE_USER_D		,PPRL10_CREATE_PROCESS_C		,PPRL10_CREATE_APP_C
																		,PPRL10_UPDATE_S			,PPRL10_UPDATE_USER_D		,PPRL10_UPDATE_PROCESS_C		,PPRL10_UPDATE_APP_C
																		,PPRL10_ID_REFERENCE_X
																		)
				
					SELECT												 PPRL01_REQUEST_SEQ_R		,PPRL02_REQUEST_DTL_SEQ_R	
																		,PPRL02_ID_SOURCE_N				,PPRL02_ID_KEY_D				,PPRL02_ID_VALUE_D
																		,@CurrentTS					, @userID					,'L01_update_TR'				,100624
																		,@CurrentTS					, @userID					,'L01_update_TR'				,100624
																		,PPRL02_ID_REFERENCE_X
					FROM  #L02  
					WHERE PPRC01_REQUEST_TYP_C ='DMD'
			END
	
		END
END
GO


ENABLE TRIGGER [MPPRL01_REQUEST_UPDATE_TR] ON MPPRL01_CONSUMER_REQUEST         