
--CREATE TABLE MPPRF02_PROCESS_LOG   ( --error log
--  PPRF02_LOG_SEQ_R	 int  NOT NULL   IDENTITY(1,1) ,
--  PPRF02_APP_C   varchar(6)  NOT NULL  ,
--  CNPL01_REQUEST_SEQ_R bigint  NOT NULL  ,
  
--  --PPRxx_SUB_APP_N        VARCHAR(34) NOT NULL,

--  PPRF02_APP_TBL_N   varchar(100)   NULL  ,
--  PPRF02_APP_ATTR_N   varchar(100)   NULL  ,
--  PPRF02_ERROR_TYP_X   varchar(20)  NOT NULL  ,  --error/warning
--  PPRF02_ERROR_X   varchar(2000)  NOT NULL  , 
--  PPRF02_ERROR_FILE_N   varchar(50)  NOT NULL  ,

--  PPRF02_CREATE_S   datetime  NOT NULL  ,
--  PPRF02_CREATE_USER_D   varchar(8)  NOT NULL  ,
--  PPRF02_CREATE_PROCESS_C varchar(100) NOT NULL ,
--  PPRF02_CREATE_APP_C  int NOT NULL,
--  PPRF02_UPDATE_S   datetime  NOT NULL    ,
--  PPRF02_UPDATE_USER_D   varchar(8)  NOT NULL  ,
--  PPRF02_UPDATE_PROCESS_C varchar(100) NOT NULL ,
--  PPRF02_UPDATE_APP_C  int NOT NULL,
--   CONSTRAINT [MPPRF021] PRIMARY KEY CLUSTERED 
--   (PPRF02_LOG_SEQ_R) 
--   )
--GO




-- sp_rename 'MPPRF02_PROCESS_LOG','MPPRF02_PROCESS_LOG_old'
-- GO
-- sp_rename 'MPPRF021', 'MPPRF021_old'
-- GO
  --DROP TABLE IF EXISTS MPPRF02_PROCESS_LOG
 CREATE TABLE MPPRF02_PROCESS_LOG   ( --error log										
  PPRF02_LOG_SEQ_R	 int  NOT NULL   IDENTITY(1,1) ,									
  PPRF02_APP_C   varchar(6)  NOT NULL  ,												
  CNPL01_REQUEST_SEQ_R bigint  NOT NULL  ,												
  PPRF02_SUB_APP_N        varchar(34) NOT NULL DEFAULT '',											
  PPRF02_APP_TBL_N   varchar(100)   NULL  ,												
  PPRF02_APP_ATTR_N   varchar(100)   NULL  ,											
  PPRF02_ERROR_TYP_X   varchar(20)  NOT NULL  ,  --error/warning						
  PPRF02_ERROR_X   varchar(2000)  NOT NULL  , 											
  PPRF02_ERROR_FILE_N   varchar(50)  NOT NULL  ,										
  PPRF02_CREATE_S   datetime  NOT NULL  ,												
  PPRF02_CREATE_USER_D   varchar(8)  NOT NULL  ,										
  PPRF02_CREATE_PROCESS_C varchar(100) NOT NULL ,										
  PPRF02_CREATE_APP_C  int NOT NULL,													
  PPRF02_UPDATE_S   datetime  NOT NULL    ,
  PPRF02_UPDATE_USER_D   varchar(8)  NOT NULL  ,
  PPRF02_UPDATE_PROCESS_C varchar(100) NOT NULL ,
  PPRF02_UPDATE_APP_C  int NOT NULL,
   CONSTRAINT [MPPRF021] PRIMARY KEY CLUSTERED 
   (PPRF02_LOG_SEQ_R) 
   )
GO



--select * from MPPRF02_PROCESS_LOG
--select * from MPPRF02_PROCESS_LOG_old

 GRANT SELECT ON dbo.MPPRF02_PROCESS_LOG to public 
 GO
 GRANT INSERT ON  dbo.MPPRF02_PROCESS_LOG to public 
 GO
 GRANT DELETE ON  dbo.MPPRF02_PROCESS_LOG to public 
 GO
















