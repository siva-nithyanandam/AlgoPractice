
--drop table  MPPRC01_CPPRA_REQUEST_TYPE 
CREATE  TABLE MPPRC01_REQUEST_TYPE 
(
 PPRC01_REQUEST_TYP_C		varchar(4)		  NOT NULL 
,PPRC01_REQUEST_TYP_X		varchar(30)		  NOT NULL
,PPRC01_CREATE_S			datetime		  NOT NULL
,PPRC01_CREATE_USER_D		varchar	(8)		  NOT NULL
,PPRC01_CREATE_PROCESS_C	varchar (100)	  NOT NULL
,PPRC01_CREATE_APP_C		int				  NOT NULL
,PPRC01_UPDATE_S			datetime		  NOT NULL
,PPRC01_UPDATE_USER_D		varchar (8)		  NOT NULL
,PPRC01_UPDATE_PROCESS_C	varchar(100)	  NOT NULL
,PPRC01_UPDATE_APP_C		int				  NOT NULL

CONSTRAINT [MPPRC011] PRIMARY KEY  (PPRC01_REQUEST_TYP_C)
)

GO


INSERT INTO MPPRC01_REQUEST_TYPE 
VALUES
  ('DNS','Do Not Sell/Share my Data',getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('SMD','Show Me My Data'		    ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('DMD','Delete My Data'		    ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
;
GO

 GRANT SELECT ON dbo.MPPRC01_REQUEST_TYPE to public 
 GO
 GRANT INSERT ON  dbo.MPPRC01_REQUEST_TYPE to public 
 GO
 GRANT DELETE ON  dbo.MPPRC01_REQUEST_TYPE to public 
 GO
