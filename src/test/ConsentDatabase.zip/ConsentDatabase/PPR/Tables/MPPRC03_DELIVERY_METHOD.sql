

CREATE TABLE MPPRC03_DELIVERY_METHOD
(
 PPRC03_DEL_METHOD_C		char(1)			  NOT NULL 
,PPRC03_DEL_METHOD_X		varchar(25)		  NOT NULL
,PPRC03_CREATE_S			datetime		  NOT NULL
,PPRC03_CREATE_USER_D		varchar(8)		  NOT NULL
,PPRC03_CREATE_PROCESS_C	varchar(100)	  NOT NULL
,PPRC03_CREATE_APP_C		int				  NOT NULL
,PPRC03_UPDATE_S			datetime		  NOT NULL
,PPRC03_UPDATE_USER_D	varchar (8)		  NOT NULL
,PPRC03_UPDATE_PROCESS_C	varchar(100)	  NOT NULL
,PPRC03_UPDATE_APP_C		int				  NOT NULL

CONSTRAINT [MPPRC031] PRIMARY KEY  (PPRC03_DEL_METHOD_C)

)
GO 

INSERT INTO MPPRC03_DELIVERY_METHOD 
VALUES
 ('M', 'Mail'		,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1),
 ('E', 'Primary Email' ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1),
 ('O', 'Other Email' ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
; 
 GO 
 

 

 
select * from  MPPRC03_DELIVERY_METHOD 
GO


 GRANT SELECT ON dbo.MPPRC03_DELIVERY_METHOD to public 
 GO
 GRANT INSERT ON  dbo.MPPRC03_DELIVERY_METHOD to public 
 GO
 GRANT DELETE ON  dbo.MPPRC03_DELIVERY_METHOD to public 
 GO
