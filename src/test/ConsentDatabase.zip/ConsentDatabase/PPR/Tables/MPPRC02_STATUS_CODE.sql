

CREATE  TABLE MPPRC02_STATUS_CODE
(
 PPRC02_STATUS_C				char(1)			  NOT NULL 
,PPRC02_STATUS_X				varchar(20)		  NOT NULL
,PPRC02_CREATE_S				datetime		  NOT NULL
,PPRC02_CREATE_USER_D			varchar(8)		  NOT NULL
,PPRC02_CREATE_PROCESS_C		varchar(100)	  NOT NULL
,PPRC02_CREATE_APP_C			int				  NOT NULL
,PPRC02_UPDATE_S				datetime		  NOT NULL
,PPRC02_UPDATE_USER_D			varchar(8)		  NOT NULL
,PPRC02_UPDATE_PROCESS_C		varchar(100)	  NOT NULL
,PPRC02_UPDATE_APP_C			int				  NOT NULL

CONSTRAINT [MPPRC021] PRIMARY KEY  (PPRC02_STATUS_C)
)

GO

INSERT INTO MPPRC02_STATUS_CODE 
VALUES
  ('N'  ,'New'				 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('V'  ,'Verified'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('I'  ,'InProgress'		 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('D'  ,'Deleted'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('C'  ,'Completed'		 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('E'  ,'Extended'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('R'	,'Ready'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
, ('X'  ,'Cancel'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)
;


INSERT INTO  MPPRC02_STATUS_CODE
VALUES
('H'	,'Enriched'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)

GO


DELETE FROM  MPPRC02_STATUS_CODE  WHERE PPRC02_STATUS_C in ('D','V')
GO



select * from  MPPRC02_STATUS_CODE 


 GRANT SELECT ON dbo.MPPRC02_STATUS_CODE to public 
 GO
 GRANT INSERT ON  dbo.MPPRC02_STATUS_CODE to public 
 GO
 GRANT DELETE ON  dbo.MPPRC02_STATUS_CODE to public 
 GO

 INSERT INTO  MPPRC02_STATUS_CODE
VALUES
('V'	,'Verifying'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)

GO



INSERT INTO  MPPRC02_STATUS_CODE VALUES  ('P'	,'Hold'			 ,getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)

INSERT INTO  MPPRC02_STATUS_CODE VALUES  ('S'	,'Ready For Delivery',getutcdate(),'banbilc1','manual',-1,getutcdate(),'banbilc1','manual',-1)

