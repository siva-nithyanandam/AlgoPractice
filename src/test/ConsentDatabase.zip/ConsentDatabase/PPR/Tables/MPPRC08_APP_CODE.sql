
CREATE TABLE [dbo].[MPPRC08_APP_CODE](
	[PPRC08_APP_C] int NOT NULL,
	[PPRC08_APP_N] nvarchar(120) NULL,
	[PPRC08_APP_X] nvarchar(255) NULL,
	[PPRC08_CREATE_S] [datetime] NOT NULL,
	[PPRC08_CREATE_USER_D] [varchar](8) NOT NULL,
	[PPRC08_CREATE_PROCESS_C] [varchar](100) NOT NULL,
	[PPRC08_CREATE_APP_C] int NOT NULL,
	[PPRC08_UPDATE_S] [datetime] NOT NULL,
	[PPRC08_UPDATE_USER_D] [varchar](8) NOT NULL,
	[PPRC08_UPDATE_PROCESS_C] [varchar](100) NOT NULL,
	[PPRC08_UPDATE_APP_C] int  NOT NULL,
 CONSTRAINT [MPPRC081] PRIMARY KEY CLUSTERED 
(
	[PPRC08_APP_C] ASC
)
)
GO
  

 INSERT INTO  [dbo].MPPRC08_APP_CODE   
 VALUES
 ( 100392 ,'','OWNER WEB'	, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,( 100433 ,'','SMARTVINCENT', GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,( 100504 ,'','FORDPASS'	, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,( 100530 ,'','LincolnWay'	, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,(100577,NULL,'FordBrandsites'			, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,(100578,NULL,'Lincoln Brandsites'		, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,(100608,NULL,'ICI DCX'					, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
,(100624,NULL,'Consent Platform NA'		, GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 

 ;
 
insert into MPPRC08_APP_CODE
  values (100629,NULL,'VSDN',GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 

  INSERT INTO  [dbo].MPPRC08_APP_CODE  
 select  app_c , NULL,app_x , GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1
 from 

(
 select   	'Account Manager - NA'	  as app_x, 		100586	 as app_c
union all select   	'Amazon Alexa Application'	  as app_x, 		100722	 as app_c
union all select   	'Applink Remote Management and Reporting'	  as app_x, 		100711	 as app_c
--union all select   	'FordBrandsites'	  as app_x, 		100577	 as app_c
--union all select   	'Lincoln Brandsites'	  as app_x, 		100578	 as app_c
union all select   	'CKS Analytical'	  as app_x, 		100704	 as app_c
union all select   	'CKS Dealer'	  as app_x, 		100714	 as app_c
union all select   	'CKS Wholesale'	  as app_x, 		100713	 as app_c
union all select   	'CKS-X (Heavy Analytics)'	  as app_x, 		100706	 as app_c
union all select   	'Composite Service layer'	  as app_x, 		100729	 as app_c
union all select   	'Connected Electric Vehicle Services'	  as app_x, 		100603	 as app_c
--union all select   	'Consent Platform'	  as app_x, 		100624	 as app_c
union all select   	'DA Home to Vehicle'	  as app_x, 		100728	 as app_c
union all select   	'Data Fulfillment Application'	  as app_x, 		100732	 as app_c
union all select   	'Data Supply Chain'	  as app_x, 		100733	 as app_c
union all select   	'Enterprise Data Hub'	  as app_x, 		100730	 as app_c
union all select   	'ESPARS : Extended Service Plan Analysis & Rpt sys'	  as app_x, 		100703	 as app_c
union all select   	'ESPS:� Extended Service Plan System'	  as app_x, 		100701	 as app_c
union all select   	'Ford Performance Vehicles (AEM Campaigns)'	  as app_x, 		100719	 as app_c
union all select   	'Ford Telematics'	  as app_x, 		100717	 as app_c
union all select   	'Ford Vehicle Programs'	  as app_x, 		100707	 as app_c
--union all select   	'FordPass App'	  as app_x, 		100504	 as app_c
union all select   	'FordPass Dealer Interface'	  as app_x, 		100725	 as app_c
union all select   	'FSM FCS CRM Dynamics 365'	  as app_x, 		100724	 as app_c
union all select   	'GCAMP: Global Campaign Management System'	  as app_x, 		100705	 as app_c
union all select   	'In-Vehicle Security Services'	  as app_x, 		100710	 as app_c
union all select   	'lincoln Pick Up & Delivery'	  as app_x, 		100726	 as app_c
--union all select   	'Lincoln Way App'	  as app_x, 		100530	 as app_c
union all select   	'Media site'	  as app_x, 		100715	 as app_c
union all select   	'Motorcraft.com - 2015'	  as app_x, 		100423	 as app_c
union all select   	'North American Vehicle Information System'	  as app_x, 		100702	 as app_c
--union all select   	'Owner.com'	  as app_x, 		100392	 as app_c
union all select   	'QMarkets for Innovation Portal'	  as app_x, 		100720	 as app_c
union all select   	'SCA-C Consumer Account Profile'	  as app_x, 		100547	 as app_c
union all select   	'SCA-Vehicle'	  as app_x, 		100716	 as app_c
union all select   	'SDE - DSC TZ'	  as app_x, 		100734	 as app_c
union all select   	'SYNC Analytics 3.2v2'	  as app_x, 		100727	 as app_c
union all select   	'Trip Planner'	  as app_x, 		100731	 as app_c
union all select   	'Vehicle Health & Alerts'	  as app_x, 		100527	 as app_c
union all select   	'Vehicle Health & Alerts 3.0'	  as app_x, 		100605	 as app_c
union all select   	'Vehicle Incentives System'	  as app_x, 		100708	 as app_c
union all select   	'Vehicle POI'	  as app_x, 		100723	 as app_c
union all select   	'Vehicle Service Delivery Network'	  as app_x, 		100718	 as app_c
) tmp



insert into MPPRC08_APP_CODE
  values (100561,NULL,'CVBOP',GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 

  GO
  GRANT SELECT ON dbo.MPPRC08_APP_CODE to public 
 GO
 GRANT INSERT ON  dbo.MPPRC08_APP_CODE to public 
 GO
 GRANT DELETE ON  dbo.MPPRC08_APP_CODE to public 
 GO


 
 insert into MPPRC08_APP_CODE
  values (  100531	,NULL,	'FORDPASS GLOBAL LOYALTY PLATFORM',GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 

   insert into MPPRC08_APP_CODE
  values (  100592	,NULL,	'CVAS-CVPP AUTHORIZATION SERVICE',GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 
  
 select * from MPPRC08_APP_CODE 


 Could you please add �CV Authorization Service�  Source id: 100592 to your Database.
 --update [MPPRC08_APP_CODE] set pprc08_APP_X ='FORDPASS GLOBAL LOYALTY PLATFORM', pprc08_UPDATE_S =GETUTCDATE() , pprc08_UPDATE_USER_D ='banbilc1' where pprc08_APP_C =100531


 insert into MPPRC08_APP_CODE
  values ( 100628 , NULL , 'Privacy Protection',GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1) 


   insert into MPPRC08_APP_CODE   values ( 100735 , NULL , 'FordDirect',GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1)
   
   insert into MPPRC08_APP_CODE   values ( 100738 , NULL , 'CCPA-Foundational Consumer Platform',GETUTCDATE(),'banbilc1','manual',-1, GETUTCDATE(),'banbilc1','manual',-1)	  