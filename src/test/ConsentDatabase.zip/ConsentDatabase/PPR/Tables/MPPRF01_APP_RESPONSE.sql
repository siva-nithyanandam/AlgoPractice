--CREATE TABLE MPPRF01_APP_RESPONSE (
--  PPRF01_APP_RESP_SEQ_R int  NOT NULL   IDENTITY(1,1)  ,
--  PPRF01_APP_C		 varchar(6)  NOT NULL  , --itms number
--  CNPL01_REQUEST_SEQ_R   bigint  NOT NULL  ,
--  PPRF01_INTERNAL_CATG_C   char(2)  NOT NULL  ,
--  --PPRF01_SUB_APP_N        VARCHAR(34) NOT NULL, 
--  PPRF01_APP_TBL_N   varchar(100)  NOT NULL  ,
--  PPRF01_APP_ATTR_N   varchar(100)  NOT NULL  ,
--  PPRF01_APP_ATTR_VAL   varchar(2000)  NOT NULL  ,
--  PPRF01_APP_ATTR_SEQ_R   int  NOT NULL  ,
--  PPRF01_CONSUMER_CATG_C char(2)  ,
--  PPRF01_STD_ATTR_N varchar(100) ,
--  PPRF01_CREATE_S   datetime  NOT NULL  ,
--  PPRF01_CREATE_USER_D   varchar(8)  NOT NULL  ,
--  PPRF01_CREATE_PROCESS_C varchar(100) NOT NULL ,
--  PPRF01_CREATE_APP_C  int NOT NULL,
--  PPRF01_UPDATE_S   datetime  NOT NULL    ,
--  PPRF01_UPDATE_USER_D   varchar(8)  NOT NULL  ,
--  PPRF01_UPDATE_PROCESS_C varchar(100) NOT NULL ,
--  PPRF01_UPDATE_APP_C  int NOT NULL,
--  CONSTRAINT [MPPRF011] PRIMARY KEY CLUSTERED 
--   (PPRF01_APP_RESP_SEQ_R)
-- );
--GO

/**************************************************************************/

 --sp_rename 'MPPRF01_APP_RESPONSE','MPPRF01_APP_RESPONSE_old'
 --GO
 --sp_rename 'MPPRF011', 'MPPRF011_old'
 --GO
 -- DROP TABLE IF EXISTS MPPRF01_APP_RESPONSE
 CREATE  TABLE MPPRF01_APP_RESPONSE (										
  PPRF01_APP_RESP_SEQ_R   int  NOT NULL   IDENTITY(1,1)  ,					
  PPRF01_APP_C			  varchar(6)  NOT NULL  , --itms number					
  CNPL01_REQUEST_SEQ_R    bigint  NOT NULL  ,								
  PPRF01_INTERNAL_CATG_C  char(2)	   NOT NULL  ,								
  PPRF01_SUB_APP_N        varchar(34)   NOT NULL DEFAULT '', 							
  PPRF01_APP_TBL_N       varchar(100)   NOT NULL  ,								
  PPRF01_APP_ATTR_N       varchar(100)  NOT NULL  ,								
  PPRF01_APP_ATTR_VAL     varchar(2000)  NOT NULL  ,							
  PPRF01_APP_ATTR_SEQ_R   int  NOT NULL  ,									
  PPRF01_CREATE_S   datetime  NOT NULL  ,									
  PPRF01_CREATE_USER_D   varchar(8)  NOT NULL  ,							
  PPRF01_CREATE_PROCESS_C varchar(100) NOT NULL ,							
  PPRF01_CREATE_APP_C  int NOT NULL,										
  PPRF01_UPDATE_S   datetime  NOT NULL    ,									
  PPRF01_UPDATE_USER_D   varchar(8)  NOT NULL  ,							
  PPRF01_UPDATE_PROCESS_C varchar(100) NOT NULL ,
  PPRF01_UPDATE_APP_C  int NOT NULL,
  CONSTRAINT [MPPRF011] PRIMARY KEY CLUSTERED 
   (PPRF01_APP_RESP_SEQ_R)
 );

  
 GRANT SELECT ON dbo.MPPRF01_APP_RESPONSE to public 
 GO
 GRANT INSERT ON  dbo.MPPRF01_APP_RESPONSE to public 
 GO
 GRANT DELETE ON  dbo.MPPRF01_APP_RESPONSE to public 
 GO

 ALTER TABLE MPPRF01_APP_RESPONSE ALTER COLUMN [PPRF01_APP_ATTR_VAL] varchar(2000)  NULL 
 GO
