 
 

CREATE OR ALTER VIEW   MPPRV02_DNS_DETAILS_VW
AS
SELECT	ROW_NUMBER() OVER( ORDER BY L05.[PPRL01_REQUEST_SEQ_R]  asc) SNO,
    L05.[PPRL01_REQUEST_SEQ_R]               as REQUEST_SEQUENCE_NUMBER,
	L05.PPRL01_REQUEST_S					 as REQUEST_TIMESTAMP,
	L06.PPRL06_CREATE_S						 as CREATE_TIMESTAMP,
	PPRL06_ID_VALUE_D		                 as ID_VALUE,
	PPRL06_ID_SOURCE_N                       as ID_SOURCE, 
	PPRL06_ID_KEY_D                          as ID_KEY,
	PPRL06_ID_REFERENCE_X					 as ID_REFERENCE,
	[PPRL05_APP_C]                           as APPLICATION_CODE,
	[PPRL05_FIRST_N]                         as FIRST_NAME,
	[PPRL05_MIDDLE_N]                        as MIDDLE_NAME,
	[PPRL05_LAST_N]                          as LAST_NAME,
	[PPRL05_NICK_N]                          as NICK_NAME,
	[PPRL05_FORMER_LAST_N]                   as FORMER_LAST_NAME,
	[PPRL05_ADDR_LINE_1_X]                   as ADDRESS_LINE1,
	[PPRL05_ADDR_LINE_2_X]                   as ADDRESS_LINE2,
	[PPRL05_CITY_N]                          as CITY_NAME,
	[PPRL05_STATE_N]                         as STATE_NAME,
	[PPRL05_POSTAL_C]                        as POSTAL_CODE,
	[PPRL05_COUNTRY_C]                       as COUNTRY_CODE,

	PPRL05_PRIMARY_PHONE_R                   as PRIMARY_PHONE,
	PPRL05_PRIMARY_PHONE_TYPE_X				 as PRIMARY_PHONE_TYP,
	PPRL05_SECONDARY_PHONE_R                 as SECONDARY_PHONE,
	PPRL05_SECONDARY_PHONE_TYPE_X			 as SECONDARY_PHONE_TYP,
	PPRL05_OTHER_EMAIL_X					 as OTHER_EMAIL,

	[PPRL05_PRIMARY_EMAIL_X]                 as PRIMARY_EMAIL,
	[PPRC03_DEL_METHOD_C]                    as DELIVERY_METHOD,
	[PPRL05_VIN_C]                           as VIN
	from  [MPPRL05_DNS_CONSUMER_REQUEST] L05  
	LEFT OUTER  JOIN  [MPPRL06_DNS_CONSUMER_REQUEST_DTL] L06 
	on L05.PPRL01_REQUEST_SEQ_R	=	L06.PPRL01_REQUEST_SEQ_R

GO
 

         GRANT SELECT ON dbo.MPPRV02_DNS_DETAILS_VW to public 
 GO
