 

CREATE OR ALTER VIEW  MPPRV03_SMD_DETAILS_VW
AS
SELECT	ROW_NUMBER() OVER( ORDER BY L07.[PPRL01_REQUEST_SEQ_R]  asc) SNO,
    L07.[PPRL01_REQUEST_SEQ_R]               as REQUEST_SEQUENCE_NUMBER,
	L07.PPRL01_REQUEST_S					 as REQUEST_TIMESTAMP,
	L08.PPRL08_CREATE_S						 as CREATE_TIMESTAMP,
	PPRL08_ID_VALUE_D		                 as ID_VALUE,
	PPRL08_ID_SOURCE_N                       as ID_SOURCE, 
	PPRL08_ID_KEY_D                          as ID_KEY,
	PPRL08_ID_REFERENCE_X					 as ID_REFERENCE,
	[PPRL07_APP_C]                           as APPLICATION_CODE,
	[PPRL07_FIRST_N]                         as FIRST_NAME,
	[PPRL07_MIDDLE_N]                        as MIDDLE_NAME,
	[PPRL07_LAST_N]                          as LAST_NAME,
	[PPRL07_NICK_N]                          as NICK_NAME,
	[PPRL07_FORMER_LAST_N]                   as FORMER_LAST_NAME,
	[PPRL07_ADDR_LINE_1_X]                   as ADDRESS_LINE1,
	[PPRL07_ADDR_LINE_2_X]                   as ADDRESS_LINE2,
	[PPRL07_CITY_N]                          as CITY_NAME,
	[PPRL07_STATE_N]                         as STATE_NAME,
	[PPRL07_POSTAL_C]                        as POSTAL_CODE,
	[PPRL07_COUNTRY_C]                       as COUNTRY_CODE,
	
	PPRL07_PRIMARY_PHONE_R                   as PRIMARY_PHONE,
	PPRL07_PRIMARY_PHONE_TYPE_X				 as PRIMARY_PHONE_TYP,
	PPRL07_SECONDARY_PHONE_R                 as SECONDARY_PHONE,
	PPRL07_SECONDARY_PHONE_TYPE_X			 as SECONDARY_PHONE_TYP,
	PPRL07_OTHER_EMAIL_X					 as OTHER_EMAIL,

	[PPRL07_PRIMARY_EMAIL_X]                 as PRIMARY_EMAIL,
	[PPRC03_DEL_METHOD_C]                    as DELIVERY_METHOD,
	[PPRL07_VIN_C]                           as VIN
	from  MPPRL07_SMD_CONSUMER_REQUEST L07  
	INNER JOIN   MPPRL08_SMD_CONSUMER_REQUEST_DTL L08 
	on L07.PPRL01_REQUEST_SEQ_R	=	L08.PPRL01_REQUEST_SEQ_R

GO
 
        GRANT SELECT ON dbo.MPPRV03_SMD_DETAILS_VW to public 
 GO
