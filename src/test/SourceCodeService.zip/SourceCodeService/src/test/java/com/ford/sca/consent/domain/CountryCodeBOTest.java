package com.ford.sca.consent.domain;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;


@RunWith(MockitoJUnitRunner.Silent.class)
public class CountryCodeBOTest {

  @Spy
  private CountryCodeBO countryCodeBO;

  @Test
  public void test_all_the_fields() {
    countryCodeBO.setCountryName("");
    countryCodeBO.setIso2CodeCountry("US");
    countryCodeBO.setIso3CodeCountry("USA");
    Assert.assertNotNull(countryCodeBO.getCountryName());
    Assert.assertNotNull(countryCodeBO.getIso2CodeCountry());
    Assert.assertNotNull(countryCodeBO.getIso3CodeCountry());
   
  }
}
