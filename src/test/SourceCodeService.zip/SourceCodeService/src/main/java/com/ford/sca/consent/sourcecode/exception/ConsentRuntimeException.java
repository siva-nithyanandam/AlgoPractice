package com.ford.sca.consent.sourcecode.exception;

import com.ford.sca.consent.sourcecode.util.ResponseCodes;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class ConsentRuntimeException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private ResponseCodes responseCodes;

  /**
   * To construct ConsentRuntimeException with {@link ResponseCodes} and Message String.
   *
   * @param responseCodes {@link ResponseCodes}
   * @param message    - String
   */
  public ConsentRuntimeException(final ResponseCodes responseCodes, final String message) {
    super(message);
    this.responseCodes = responseCodes;
  }
}
