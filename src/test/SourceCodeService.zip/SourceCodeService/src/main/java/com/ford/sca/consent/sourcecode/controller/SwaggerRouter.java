package com.ford.sca.consent.sourcecode.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value = "Swagger", hidden = true)
public class SwaggerRouter {

  /**
   * To redirect to swagger page when no endpoint is given.
   * @return Swagger page
   */
  @GetMapping(path = "/")
  @ApiOperation(value = "Swagger Documentation",
      notes = "Redirects default uri to swagger documentation", hidden = true)
  public ModelAndView getApiInfo() {
    return new ModelAndView("redirect:/swagger-ui.html");
  }

  /**
   * For Health check.
   */
  /*@ApiOperation(value = "Health check", nickname = "sample test get")
  @GetMapping(value = "/health", produces = "application/json")
  public ResponseEntity<HealthDto> health() {
    final HealthDto healthDto = new HealthDto();
    healthDto.setStatus("pass");

    final HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.setContentType(MediaType.APPLICATION_JSON);

    return new ResponseEntity<HealthDto>(healthDto, httpHeaders, HttpStatus.OK);
  }*/
}
