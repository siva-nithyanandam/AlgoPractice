package com.ford.sca.consent.sourcecode.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ford.sca.consent.sourcecode.services.Mediator;
import com.ford.sca.consent.sourcecode.transport.ApiParams;
import com.ford.sca.consent.sourcecode.transport.GenericResponse;
import com.ford.sca.consent.sourcecode.transport.SourceCodeRequest;
import com.ford.sca.consent.sourcecode.util.AuditActivityUtil;
import com.ford.sca.consent.sourcecode.util.LogAround;
import com.ford.sca.consent.sourcecode.util.LoggerBuilder;
import com.ford.sca.consent.sourcecode.util.RegexUtil;
import com.ford.sca.consent.sourcecode.util.ScaConsentApiResponses;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.models.HttpMethod;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(path = "/source-code-management")
@Api("To Manage Source Codes in Consent Platform")
public class SourceCodeController {

  @Autowired
  private AuditActivityUtil auditActivityUtil;

  @Autowired
  private Mediator mediator;

  @PreAuthorize("hasPermission('aud', 'createResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "To Create Source Code")
  @PostMapping(value = "/v1/sourcecodes", consumes = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public GenericResponse createSourceCode(
      @ApiParam(value = "request body", required = true) @RequestBody SourceCodeRequest sourceCodeRequest,
      @ApiParam(value = "appCd.", required = true) @RequestParam(value = "appCd") 
      @Pattern(regexp= RegexUtil.APPCD_REGEX,message="AppID not in Number Format") final Integer appCd,
      @ApiParam(value = "Requester ID.", required = true) @RequestParam  @Pattern(regexp = "\\w+", message = "Invalid field(s) provided") 
      @Size(min = 2, max = 10, message = "Invalid field(s) provided") final String cdsId,
      final HttpServletRequest httpRequest, final HttpServletResponse response) {

    // 1. Build ApiParams
    ApiParams apiParams = mediator.buildApiParams(httpRequest, appCd, cdsId, null);

    // 2. Save request attributes
    auditActivityUtil.storeRequestHeaderAttributes(httpRequest);
    auditActivityUtil.setResponseHeaderAttributes(response);

    // 3. publish request audit activity
    LoggerBuilder.logApiRequestResponse(apiParams, sourceCodeRequest, httpRequest, HttpMethod.POST);
    auditActivityUtil.publishAuditMessage_request(httpRequest, sourceCodeRequest, apiParams);

    // 4. process request
    GenericResponse genericResponse = mediator
        .validateAndCreateRecord(apiParams, sourceCodeRequest, httpRequest);
    response.setStatus(genericResponse.getHttpStatus().value());

    // 5. publish response audit activity
    LoggerBuilder.logApiRequestResponse(apiParams, genericResponse, httpRequest, HttpMethod.POST);
    auditActivityUtil
        .publishAuditMessage_response(httpRequest, genericResponse, sourceCodeRequest, apiParams);

    // 6. Return response
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'updateResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "To Update Source Code")
  @PutMapping(value = "/v1/sourcecodes", consumes = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public GenericResponse updateSourceCode(
      @ApiParam(value = "request body", required = true) @RequestBody SourceCodeRequest sourceCodeRequest,
      @ApiParam(value = "appCd.", required = true) @RequestParam(value = "appCd") 
      @Pattern(regexp= RegexUtil.APPCD_REGEX,message="AppID not in Number Format") final Integer appCd,
      @ApiParam(value = "Requester ID.", required = true) @RequestParam @Pattern(regexp = "\\w+", message = "Invalid field(s) provided") 
      @Size(min = 2, max = 10, message = "Invalid field(s) provided") final String cdsId,
      final HttpServletRequest httpRequest, final HttpServletResponse response) {

    // 1. Build ApiParams
    ApiParams apiParams = mediator.buildApiParams(httpRequest, appCd, cdsId, null);

    // 2. Save request attributes
    auditActivityUtil.storeRequestHeaderAttributes(httpRequest);
    auditActivityUtil.setResponseHeaderAttributes(response);

    // 3. publish request audit activity
    LoggerBuilder.logApiRequestResponse(apiParams, sourceCodeRequest, httpRequest, HttpMethod.PUT);
    auditActivityUtil.publishAuditMessage_request(httpRequest, sourceCodeRequest, apiParams);

    // 4. process request
    GenericResponse genericResponse = mediator
        .validateAndUpdateRecord(apiParams, sourceCodeRequest, httpRequest);
    response.setStatus(genericResponse.getHttpStatus().value());

    // 5. publish response audit activity
    LoggerBuilder.logApiRequestResponse(apiParams, genericResponse, httpRequest, HttpMethod.PUT);
    auditActivityUtil
        .publishAuditMessage_response(httpRequest, genericResponse, sourceCodeRequest, apiParams);

    // 6. Return response
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "To Retrieve Source Code from Cache if not from Table")
  @GetMapping(value = "/v1/sourcecodes/fromCacheAndTable/{retrieveAppCd}", produces = MediaType.APPLICATION_JSON_VALUE )
  @LogAround
  public GenericResponse retrieveSourceCodeFromCacheAndTable(
		  @ApiParam(value = "appCd.", required = true) @RequestParam(value = "appCd") 
		  @Pattern(regexp= RegexUtil.APPCD_REGEX,message="AppID not in Number Format") final Integer appCd,
      @ApiParam(value = "Requester ID.", required = true) @RequestParam  @Pattern(regexp = "\\w+", message = "Invalid field(s) provided") 
	  @Size(min = 2, max = 10, message = "Invalid field(s) provided") final String cdsId,
      @ApiParam(value = "Retrieve App Code.", required = true) @PathVariable @Pattern(regexp= RegexUtil.APPCD_REGEX,message="AppID not in Number Format") 
	  Integer retrieveAppCd,
     
      final HttpServletRequest httpRequest, final HttpServletResponse response) {

    // 1. Build ApiParams
    ApiParams apiParams = mediator
        .buildApiParams(httpRequest, appCd, cdsId, retrieveAppCd);

    // 2. Save request attributes
    auditActivityUtil.storeRequestHeaderAttributes(httpRequest);
    auditActivityUtil.setResponseHeaderAttributes(response);

    // 3. publish request audit activity
    LoggerBuilder.printInfo(log, logger -> logger.methodName("retrieveSourceCodeFromCacheAndTable")
        .requesterAppCd(appCd).requesterCdsId(cdsId).appCdToProcess(retrieveAppCd));
    auditActivityUtil.publishAuditMessage_request(httpRequest, null, apiParams);

    // 4. process request
    GenericResponse genericResponse = mediator
        .validateAndRetrieveRecordFromCacheAndTable(apiParams, httpRequest);
    response.setStatus(genericResponse.getHttpStatus().value());

    // 5. publish response audit activity
    LoggerBuilder.logApiRequestResponse(apiParams, genericResponse, httpRequest, HttpMethod.GET);
    auditActivityUtil
        .publishAuditMessage_response(httpRequest, genericResponse, null, apiParams);

    // 6. Return response
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "To Retrieve Source Code from Table only")
  @GetMapping(value = "/v1/sourcecodes/fromTable/{retrieveAppCd}", produces = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public GenericResponse retrieveSourceCodeFromTable(
	@ApiParam(value = "Application ID.", required = true) @RequestParam @Pattern(regexp= RegexUtil.APPCD_REGEX,message="AppID not in Number Format") 
	final Integer appCd,
	@ApiParam(value = "Requester ID.", required = true) @RequestParam  @Pattern(regexp = "\\w+", message = "Invalid field(s) provided") 
	@Size(min = 2, max = 10, message = "Invalid field(s) provided")final String cdsId,
	@ApiParam(value = "Retrieve App Code.", required = true) @PathVariable @Pattern(regexp= RegexUtil.APPCD_REGEX,message="AppID not in Number Format") 
	Integer retrieveAppCd,
      final HttpServletRequest httpRequest, final HttpServletResponse response) {

    // 1. Build ApiParams
    ApiParams apiParams = mediator
        .buildApiParams(httpRequest, appCd, cdsId, retrieveAppCd);

    // 2. Save request attributes
    auditActivityUtil.storeRequestHeaderAttributes(httpRequest);
    auditActivityUtil.setResponseHeaderAttributes(response);

    // 3. publish request audit activity
    LoggerBuilder.printInfo(log, logger -> logger.methodName("retrieveSourceCodeFromTable")
        .requesterAppCd(appCd).requesterCdsId(cdsId).appCdToProcess(retrieveAppCd));
    auditActivityUtil.publishAuditMessage_request(httpRequest, null, apiParams);

    // 4. process request
    GenericResponse genericResponse = mediator
        .validateAndRetrieveRecordFromTable(apiParams, httpRequest);
    response.setStatus(genericResponse.getHttpStatus().value());

    // 5. publish response audit activity
    LoggerBuilder.logApiRequestResponse(apiParams, genericResponse, httpRequest, HttpMethod.GET);
    auditActivityUtil
        .publishAuditMessage_response(httpRequest, genericResponse, null, apiParams);

    // 6. Return response
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'adminResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "To Delete Source Code")
  @DeleteMapping(value = "/v1/sourcecodes/{deleteAppCd}", produces = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public GenericResponse deleteSourceCode(
	@ApiParam(value = "Application ID.", required = true) @RequestParam @Pattern(regexp= RegexUtil.APPCD_REGEX,message="AppID not in Number Format") 
	final Integer appCd,
	@ApiParam(value = "Requester ID.", required = true) @RequestParam  @Pattern(regexp = "\\w+", message = "Invalid field(s) provided") 
	@Size(min = 2, max = 10, message = "Invalid field(s) provided") final String cdsId,
	@ApiParam(value = "Delete App Code.", required = true) @PathVariable @Pattern(regexp= RegexUtil.APPCD_REGEX,message="AppID not in Number Format") 
	Integer deleteAppCd,
      final HttpServletRequest httpRequest, final HttpServletResponse response) {

    // 1. Build ApiParams
    ApiParams apiParams = mediator
        .buildApiParams(httpRequest, appCd, cdsId, deleteAppCd);

    // 2. Save request attributes
    auditActivityUtil.storeRequestHeaderAttributes(httpRequest);
    auditActivityUtil.setResponseHeaderAttributes(response);

    // 3. publish request audit activity
    LoggerBuilder.printInfo(log, logger -> logger.methodName("deleteSourceCode")
        .requesterAppCd(appCd).requesterCdsId(cdsId).appCdToProcess(deleteAppCd));
    auditActivityUtil.publishAuditMessage_request(httpRequest, null, apiParams);

    // 4. process request
    GenericResponse genericResponse = mediator
        .validateAndDeleteRecord(apiParams, httpRequest);
    response.setStatus(genericResponse.getHttpStatus().value());

    // 5. publish response audit activity
    LoggerBuilder.logApiRequestResponse(apiParams, genericResponse, httpRequest, HttpMethod.DELETE);
    auditActivityUtil
        .publishAuditMessage_response(httpRequest, genericResponse, null, apiParams);

    // 6. Return response
    return genericResponse;
  }
 

  @PreAuthorize("hasPermission('aud', 'adminResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "To refresh all app codes in cache")
  @PostMapping(value = "/v1/refreshcache")
  @LogAround
  public GenericResponse refreshAppCodesInCache(final HttpServletRequest httpRequest,
      final HttpServletResponse response) {
    GenericResponse genericResponse = mediator.refreshCache();
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }
}
