package com.ford.sca.consent.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.ford.sca.consent.sourcecode.transport.GenericResponse;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

@Entity
@Setter
@Getter
@Table(name = "[MCNPC01_APP_CODE]")
public class AppCodeBO extends GenericResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CNPC01_APP_C]")
  private Integer appId;

  @Nationalized
  @Column(name = "[CNPC01_APP_N]")
  private String appName;

  @Nationalized
  @Column(name = "[CNPC01_APP_X]")
  private String appDesc;

  @Column(name = "CNPC01_CREATE_S")
  private Date createDate;

  @Column(name = "CNPC01_CREATE_USER_D")
  private String createUser;

  @Column(name = "CNPC01_CREATE_PROCESS_C")
  private String createProcess;

  @Column(name = "CNPC01_CREATE_APP_C")
  private Integer createAppCode;

  @Column(name = "CNPC01_UPDATE_S")
  private Date updateDate;

  @Column(name = "CNPC01_UPDATE_USER_D")
  private String updateUser;

  @Column(name = "CNPC01_UPDATE_PROCESS_C")
  private String updateProcess;

  @Column(name = "CNPC01_UPDATE_APP_C")
  private Integer updateAppCode;

  @Column(name = "[CNPC01_ACTIVE_F]")
  private String activeFlag;

  @Column(name = "[CNPC01_EFF_FROM_S]")
  private Date effFromDate;

  @Column(name = "[CNPC01_EFF_TO_S]")
  private Date effToDate;
}