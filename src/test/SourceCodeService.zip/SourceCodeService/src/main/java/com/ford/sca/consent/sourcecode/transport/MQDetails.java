package com.ford.sca.consent.sourcecode.transport;

import lombok.Getter;

@Getter
public enum MQDetails {

  AUDIT_ACTIVITY("consent.log.exchange", "consent.log.activity"),
  SCA_C_EVENT("consent.event.log.exchange", "consent.event.log.queue");
  
  private String exchangeNm;
  private String routingKeyNm;

  MQDetails(String exchangeNm, String routingKeyNm) {
    this.exchangeNm = exchangeNm;
    this.routingKeyNm = routingKeyNm;
  }
}
