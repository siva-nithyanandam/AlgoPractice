package com.ford.sca.consent.sourcecode.validators;

import com.ford.sca.consent.sourcecode.transport.ApiParams;
import com.ford.sca.consent.sourcecode.transport.GenericResponse;
import com.ford.sca.consent.sourcecode.transport.SourceCodeRequest;
import com.ford.sca.consent.sourcecode.util.GenericAssister;
import com.ford.sca.consent.sourcecode.util.LogAround;
import com.ford.sca.consent.sourcecode.util.LoggerBuilder;
import com.ford.sca.consent.sourcecode.util.ResponseBuilder;
import com.ford.sca.consent.sourcecode.util.ResponseCodes;
import java.util.Date;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CreateRequestValidator implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;

  @Override
  @LogAround
  public Future<GenericResponse> validate(final ApiParams apiParams,
      final SourceCodeRequest sourceCodeRequest, final HttpServletRequest request) {

    GenericResponse genericResponse = null;
    if (sourceCodeRequest.getAppCd() == null) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .methodName("validate").message("Empty AppId Provided for Create."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.APP_CODE_NOT_FOUND_IN_REQ);
    } else if (sourceCodeRequest.getAppCd() <= 0) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("Invalid app id was provided"));
      genericResponse = responseBuilder
          .generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else if (GenericAssister.isEmptyString(sourceCodeRequest.getAppName())) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("Empty App name Provided."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else if (GenericAssister.isEmptyString(sourceCodeRequest.getAppDesc())) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("Empty App description Provided."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else if (GenericAssister.isEmptyString(apiParams.getRequesterCdsId())) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("Empty requester CDS ID Provided."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else if (null == sourceCodeRequest.getEffFromDate()
        || null == sourceCodeRequest.getEffToDate()) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("Empty effective start or end date."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else if (sourceCodeRequest.getEffToDate().before(new Date())) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("Effective end date should be greater than current date."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else if (sourceCodeRequest.getEffFromDate().after(sourceCodeRequest.getEffToDate())) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("Effective start date is after effective end date."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    }
    return new AsyncResult<>(genericResponse);
  }
}