package com.ford.sca.consent.sourcecode.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.jwt.JwtDecoder;

@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableWebSecurity
public class AdfsConfig extends GlobalMethodSecurityConfiguration {

  private final transient AdfsPermissionEvaluator adfsPermissionEvaluator;

  /**
   * Initialize ADFS config with appropriate evaluator.
   *
   * @param adfsPermissionEvaluator {@link AdfsPermissionEvaluator}
   */
  @Autowired
  public AdfsConfig(final AdfsPermissionEvaluator adfsPermissionEvaluator) {
    super();
    this.adfsPermissionEvaluator = adfsPermissionEvaluator;
  }

  /*****************************************************************************************
   * Resource Server (handle incoming Bearer tokens).
   ****************************************************************************************/

  @Override
  protected MethodSecurityExpressionHandler createExpressionHandler() {
    final DefaultMethodSecurityExpressionHandler expressionHandler =
        new DefaultMethodSecurityExpressionHandler();
    expressionHandler.setPermissionEvaluator(adfsPermissionEvaluator);
    return expressionHandler;
  }

  @Configuration
  @Order(10)
  public static class ResourceServerSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Autowired
    private transient JwtDecoder jwtDecoder;

    @Override
    protected void configure(final HttpSecurity http) throws Exception {
      http
          .antMatcher("/source-code-management/**")
          .authorizeRequests()
          .anyRequest().authenticated()
          .and()
          .sessionManagement()
          .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
          .and()
          .oauth2ResourceServer()
          .jwt()
          .decoder(jwtDecoder);
    }
  }
}