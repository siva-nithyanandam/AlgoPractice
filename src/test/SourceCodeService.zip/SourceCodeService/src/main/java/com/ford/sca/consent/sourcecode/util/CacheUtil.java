package com.ford.sca.consent.sourcecode.util;

import com.ford.sca.consent.domain.AppCodeBO;
import com.ford.sca.consent.domain.CountryCodeBO;
import com.ford.sca.consent.domain.MessageLangServiceViewBO;
import com.ford.sca.consent.sourcecode.repository.AppCodeRepository;
import com.ford.sca.consent.sourcecode.repository.CountryCodeRepository;
import com.ford.sca.consent.sourcecode.repository.MessageLangServiceViewRepository;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CacheUtil {

  @Autowired
  private AppCodeRepository appCodeRepository;

  @Autowired
  private CountryCodeRepository countryCodeRepository;

  @Autowired
  private MessageLangServiceViewRepository messageLangServiceViewRepository;

  /**
   * This method checks for the AppId.
   *
   * @param appId appId of the caller
   * @return {@link AppCodeBO}
   */
  @Cacheable(cacheNames = "appCodeInfo", key = "#appId")
  public AppCodeBO getAppCodeDtls(Integer appId) {
    String methodName = "getAppCodeDtls";
    LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).newAppCd(appId)
        .message("Not available in cache, Reading from table"));
    return appCodeRepository.findByAppId(appId);
  }

  /**
   * Empty cache for given appCode.
   * @param appId appId of the caller
   * @return {@link AppCodeBO}
   */
  @CachePut(cacheNames = "appCodeInfo", key = "#appId")
  public AppCodeBO emptyAppCodeDtlsInCache(final Integer appId) {
    String methodName = "emptyAppCodeDtlsInCache";
    LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).newAppCd(appId)
        .message("Emptying cache for this appId"));
    return null;
  }

  /**
   * The error message will store it "errorMessages" cache (consider as a map), if not available. It
   * will fetch it from redis server, if data available in cache server.
   *
   * @param errorMsgId error message code
   * @return message description as a String
   */
  @Cacheable(cacheNames = "errorMessages", key = "#errorMsgId")
  public String getErrorMessage(String errorMsgId) {
    String methodName = "getErrorMessage";
    String errorDesc = null;
    String logStartMessage = "Getting Error Message for : " + errorMsgId;
    LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).message(logStartMessage));
    Optional<MessageLangServiceViewBO> msgOptional =
        messageLangServiceViewRepository.findById(errorMsgId);
    if (msgOptional.isPresent()) {
      errorDesc = msgOptional.get().getMessageDesc();
    }
    String logMessage = "Retrieved Error Message Description : " + errorDesc;
    LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).message(logMessage));
    return errorDesc;
  }

  /**
   * The CountryCodeBO will be store in "countryInfo" cache (consider as a map), if not available.
   * It will fetch it from DB, otherwise data available in cache server.
   *
   * @param countryCode iso3 country code
   * @return CountryCodeBO the whole object is returned
   */
  @Cacheable(cacheNames = "countryInfo", key = "#countryCode")
  public CountryCodeBO getCountryCodeByISO3(String countryCode) {
    String methodName = "getCountryCodeByISO3";
    LoggerBuilder.printInfo(log,
        logger -> logger.methodName(methodName).message("Getting Country by code: " + countryCode));
    CountryCodeBO findByIso3CodeCountry = countryCodeRepository.findByIso3CodeCountry(countryCode);
    String logMessage = findByIso3CodeCountry != null
        ? "Retrieved Country : " + findByIso3CodeCountry.getCountryName()
        : "Null Country Retrieved";
    LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).message(logMessage));
    return findByIso3CodeCountry;
  }

  /**
   * To add given appCode details into Cache.
   * @param appId given appId
   * @param appCodeBO {@link AppCodeBO}
   * @return {@link AppCodeBO}
   */
  @CachePut(cacheNames = "appCodeInfo", key = "#appId")
  public AppCodeBO addAppCodeDtls(final Integer appId, final AppCodeBO appCodeBO) {
    String methodName = "addAppCodeDtls";
    LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName)
        .message("Adding app code details in cache").newAppCd(appId));
    return appCodeBO;
  }

  /**
   * To remove given appCode from cache.
   * @param appId given appId
   */
  @CacheEvict(cacheNames = "appCodeInfo", key = "#appId")
  public void removeAppCodeDtls(final Integer appId) {
    String methodName = "removeAppCodeDtls";
    LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName)
        .message("Removing app code details in cache").newAppCd(appId));
  }
}
