package com.ford.sca.consent.sourcecode.controller;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolationException;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ford.sca.consent.sourcecode.transport.GenericResponse;
import com.ford.sca.consent.sourcecode.util.AuditActivityUtil;
import com.ford.sca.consent.sourcecode.util.LoggerBuilder;
import com.ford.sca.consent.sourcecode.util.ResponseBuilder;
import com.ford.sca.consent.sourcecode.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@RestController
@Slf4j
public class GlobalExceptionHandler {

  private String className = this.getClass().getSimpleName();

  @Autowired
  private AuditActivityUtil auditActivityUtil;

  @Autowired
  private ResponseBuilder responseBuilder;


  /**
   * Exception thrown internally when http method not found.
   */
  @ResponseStatus(code = HttpStatus.METHOD_NOT_ALLOWED)
  @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
  public GenericResponse handleHttpRequestMethodNotSupportedException(HttpServletRequest request,
      HttpServletResponse response, Exception ex) {
    auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);

    GenericResponse genericResponse =
        responseBuilder.generateResponse(ResponseCodes.UNSUPPORTED_METHOD_ERROR);

    LoggerBuilder.printError(log, logger -> logger.className(className)
        .methodName("handleHttpRequestMethodNotSupportedException").exception(ex));


    // Get copy of MDC context to send to sub-threads
    Map<String, String> webThreadContext = MDC.getCopyOfContextMap();
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      auditActivityUtil.constructAuditServiceResponseAndPublish(request, response, genericResponse);
    });
    return genericResponse;
  }

  /**
   * Exception thrown internally when access denied.
   */
  @ExceptionHandler(AccessDeniedException.class)
  public GenericResponse handleAccessDeniedException(HttpServletRequest request,
      HttpServletResponse response, Exception ex) {
    auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);
    response.setStatus(HttpStatus.UNAUTHORIZED.value());


    GenericResponse genericResponse =
        responseBuilder.generateResponse(ResponseCodes.UNAUTHORIZED_ERROR);

    LoggerBuilder.printError(log, logger -> logger.className(className)
        .methodName("handleAccessDeniedException").exception(ex));

    // Get copy of MDC context to send to sub-threads
    Map<String, String> webThreadContext = MDC.getCopyOfContextMap();
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      auditActivityUtil.constructAuditServiceResponseAndPublish(request, response, genericResponse);
    });
    return genericResponse;
  }

  /**
   * Exception thrown internally when required parameter is missing.
   */
  @ExceptionHandler(MissingServletRequestParameterException.class)
  public GenericResponse handleMissingParams(HttpServletRequest request,
      HttpServletResponse response, Exception ex) {
    auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);

    GenericResponse genericResponse =
        responseBuilder.generateResponse(ResponseCodes.INVALID_REQUEST_URL);

    response.setStatus(genericResponse.getHttpStatus().value());

    LoggerBuilder.printError(log,
        logger -> logger.className(className).methodName("handleMissingParams").exception(ex));

    // Get copy of MDC context to send to sub-threads
    Map<String, String> webThreadContext = MDC.getCopyOfContextMap();
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      auditActivityUtil.constructAuditServiceResponseAndPublish(request, response, genericResponse);
    });
    return genericResponse;
  }

  /**
   * Exception thrown internally when general exception occurred.
   */
  @ExceptionHandler(Exception.class)
  public GenericResponse handleException(HttpServletRequest request, HttpServletResponse response,
      Exception ex) {
    auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);

    GenericResponse genericResponse =
        responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);

    response.setStatus(genericResponse.getHttpStatus().value());

    LoggerBuilder.printError(log, logger -> logger.className(className)
        .methodName("handleException").exception(ex).message(ex.getMessage()));

    // Get copy of MDC context to send to sub-threads
    Map<String, String> webThreadContext = MDC.getCopyOfContextMap();
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      auditActivityUtil.constructAuditServiceResponseAndPublish(request, response, genericResponse);
    });
    return genericResponse;
  }
  
  /**
   * Exception thrown internally when ConstraintViolationexception occurred.
   */
  @ExceptionHandler(ConstraintViolationException.class)
  public GenericResponse handleConstraintViolationException(HttpServletRequest request, HttpServletResponse response,
		  ConstraintViolationException ex) {
	auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);

    GenericResponse genericResponse =
        responseBuilder.generateResponse(ex.getMessage(),request);

    response.setStatus(genericResponse.getHttpStatus().value());

    LoggerBuilder.printError(log, logger -> logger.className(className)
        .methodName("handleException").exception(ex).message(ex.getMessage()));

    // Get copy of MDC context to send to sub-threads
    Map<String, String> webThreadContext = MDC.getCopyOfContextMap();
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      auditActivityUtil.constructAuditServiceResponseAndPublish(request, response, genericResponse);
    });
    return genericResponse;
  }
}
