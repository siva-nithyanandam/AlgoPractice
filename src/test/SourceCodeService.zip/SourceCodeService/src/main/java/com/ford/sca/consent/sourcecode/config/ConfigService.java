package com.ford.sca.consent.sourcecode.config;

import com.ford.sca.consent.sourcecode.datastore.RequestScopeDataStore;
import com.ford.sca.consent.sourcecode.executor.RequestScopeAwareExecutor;
import java.util.concurrent.Executor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.context.WebApplicationContext;

@Configuration
@EnableAsync
public class ConfigService {

  private final ConfigProperties configProperties;

  /**
   * To initialize ConfigService.
   *
   * @param configProperties {@link ConfigProperties}
   */
  @Autowired
  public ConfigService(final ConfigProperties configProperties) {
    this.configProperties = configProperties;
  }

  /**
   * Configuring an executor to be used with async annotation, in order to provide the child threads
   * with scope attributes.
   *
   * @return executor of the type RequestScopeAwareExecutor
   */
  @Bean(name = "taskExecutor")
  public Executor getAsyncScopeAwareExecutor() {
    final RequestScopeAwareExecutor executor = new RequestScopeAwareExecutor();
    executor.setCorePoolSize(configProperties.getTaskExecuter().getCorePoolSize());
    /*executor.setMaxPoolSize(50);
    executor.setQueueCapacity(11);*/
    executor.initialize();
    return executor;
  }

  /**
   * Configuring data store bean and set its scope to be request scope.
   *
   * @return data store bean which its type is RequestScopeDataStore
   */
  @Bean
  @Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
  public RequestScopeDataStore requestScopedCapDataStore() {
    return new RequestScopeDataStore();
  }

}
