package com.ford.sca.consent.sourcecode.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;

import lombok.Getter;

/**
 * Contains validation response code statics.
 */
@Getter
public enum ResponseCodes {
  SUCCESS(true, HttpStatus.OK, Constants.SUCCESS_TEXT, null), 
  SUPPRESSED_CONSUMER(true, HttpStatus.OK, "The consumer is suppressed", null),
  CREATE_SUCCESS(true, HttpStatus.CREATED, "Record Successfully Created", null),
  UPDATE_SUCCESS(true, HttpStatus.OK, "Record Successfully Updated", null),
  INVALID_REQUEST_URL(false,HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
	   "MSG-0001"),
  APP_CODE_NOT_EXISTS_IN_CAP(false, HttpStatus.EXPECTATION_FAILED,
          Constants.FAILURE_TEXT, "MSG-0002"),
  APP_CODE_NOT_FOUND_IN_REQ(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0005"),
  APP_CODE_NOT_IN_NUMBER_FORMAT(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0047"),
  APP_CODE_NOT_EXISTS_IN_DB(false, HttpStatus.EXPECTATION_FAILED, Constants. FAILURE_TEXT,
      "MSG-0002"),
  SEC_APP_CODE_NOT_EXISTS_IN_DB(false, HttpStatus.EXPECTATION_FAILED, Constants. FAILURE_TEXT,
      "MSG-0261"),
  INVALID_FIELDS_PROVIDED(false, HttpStatus.EXPECTATION_FAILED, Constants. FAILURE_TEXT,
      "MSG-0010"),
  NO_POU_FOUND_IN_CP(false, HttpStatus.EXPECTATION_FAILED, Constants. FAILURE_TEXT,
      "MSG-0030"),
  COUNTRY_CODE_NOT_EXISTS(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT, 
      "MSG-0049"),
  INVALID_COUNTRY_CODE(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT, "MSG-0042"),
  COUNTRY_CODE_NOT_FOUND_IN_REQ(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT, "MSG-0004"),
  SERVICE_UNAVAILABLE_ERROR(false, HttpStatus.SERVICE_UNAVAILABLE, Constants.FAILURE_TEXT,
      "MSG-0094"),
  INVALID_REQ_FIELD_EXCEPTION(false, HttpStatus.EXPECTATION_FAILED,
      Constants.FAILURE_TEXT, "MSG-0010"),
  UNEXPECTED_BEHAVIOR(false, HttpStatus.EXPECTATION_FAILED,
      Constants.FAILURE_TEXT, "MSG-0177"),
  INVALID_INPUT_FIELD_EXCEPTION(false, HttpStatus.PRECONDITION_FAILED,
      Constants.FAILURE_TEXT, "MSG-0023"),
  VALUE_EXCEEDS_MAX_LENGTH(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT, 
      "MSG-0177"),
  BINDING_ERROR(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT, "MSG-0010"),
  INTERNAL_SERVER_ERROR(false, HttpStatus.INTERNAL_SERVER_ERROR, Constants.FAILURE_TEXT, 
      "MSG-9999"),
  UNAUTHORIZED_ERROR(false, HttpStatus.UNAUTHORIZED, Constants.FAILURE_TEXT,
      "MSG-9997"),
  NO_PERMISSIONS_AVAILABLE(false,HttpStatus.EXPECTATION_FAILED,Constants.FAILURE_TEXT,
          "MSG-0039"),
  NO_PREFERENCES_AVAILABLE( false,HttpStatus.EXPECTATION_FAILED,Constants.FAILURE_TEXT,
          "MSG-0040"),
  NO_SUPPRESSIONS_AVAILABLE(false,HttpStatus.EXPECTATION_FAILED,Constants.FAILURE_TEXT,
          "MSG-1100"),
  UNABLE_TO_INSERT_CONSENT_DATA(false,HttpStatus.EXPECTATION_FAILED,Constants.FAILURE_TEXT,
          "MSG-1107"),
  NO_PRIVACY_DATA_FOUND(false,HttpStatus.EXPECTATION_FAILED,Constants.FAILURE_TEXT,
          "MSG-1101"),
  REQUIRED_FIELDS_ARE_MISSING(false,HttpStatus.PRECONDITION_FAILED,Constants.FAILURE_TEXT,
	       "MSG-0009"),
  UNSUPPORTED_METHOD_ERROR(false, HttpStatus.METHOD_NOT_ALLOWED, Constants.FAILURE_TEXT,
      "MSG-9998"),
  PREFERENCE_STATUS_INVALID(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
	      "MSG-0138"),
  PREFERENCE_NOT_EXISTS(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
	      "MSG-0014"),
  ;
	
  private static Map<String, ResponseCodes> mapping = new HashMap<>();
  
  static {
	    Arrays.stream(ResponseCodes.values()).forEach(type->mapping.put(type.getMsgId(), type));
	}

  private boolean isSuccess;
  private HttpStatus httpStatus;
  private String responseMessage;
  private String msgId;

  ResponseCodes(boolean isSuccess, HttpStatus httpStatus, String responseMessage, 
      String msgId) {
    this.isSuccess = isSuccess;
    this.httpStatus = httpStatus;
    this.responseMessage = responseMessage;
    this.msgId = msgId;
  }
  
  public static int getHttpStatusValue(final String msgId){
	return mapping.get(msgId).getHttpStatus().value();
  }
  
}
