package com.ford.sca.consent.sourcecode.validators;

import com.ford.sca.consent.domain.AppCodeBO;
import com.ford.sca.consent.sourcecode.repository.AppCodeRepository;
import com.ford.sca.consent.sourcecode.transport.ApiParams;
import com.ford.sca.consent.sourcecode.transport.GenericResponse;
import com.ford.sca.consent.sourcecode.transport.SourceCodeRequest;
import com.ford.sca.consent.sourcecode.util.GenericAssister;
import com.ford.sca.consent.sourcecode.util.LogAround;
import com.ford.sca.consent.sourcecode.util.LoggerBuilder;
import com.ford.sca.consent.sourcecode.util.ResponseBuilder;
import com.ford.sca.consent.sourcecode.util.ResponseCodes;
import java.util.Date;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UpdateRequestValidator implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;

  @Autowired
  private AppCodeRepository appCodeRepository;

  @Override
  @LogAround
  public Future<GenericResponse> validate(final ApiParams apiParams,
      final SourceCodeRequest sourceCodeRequest, final HttpServletRequest request) {

    GenericResponse genericResponse = null;
    final Date current = new Date();
    if (sourceCodeRequest.getAppCd() == null) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .methodName("validate").message("Empty AppId Provided for Update."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.APP_CODE_NOT_FOUND_IN_REQ);
    } else if (GenericAssister.isEmptyString(apiParams.getRequesterCdsId())) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("Empty requester CDS ID Provided."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else if (GenericAssister
        .isAllStringsEmpty(sourceCodeRequest.getAppName(), sourceCodeRequest.getAppDesc())
        && null == sourceCodeRequest.getEffFromDate()
        && null == sourceCodeRequest.getEffToDate()) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("None given for update."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else if (null != sourceCodeRequest.getEffFromDate() && null == sourceCodeRequest
        .getEffToDate()) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("When effective from date is given, end date also required."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else if (null != sourceCodeRequest.getEffToDate() && sourceCodeRequest.getEffToDate()
        .after(current) && sourceCodeRequest.getEffFromDate() == null) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .newAppCd(sourceCodeRequest.getAppCd()).methodName("validate")
          .message("When extending effective end date, from date also required."));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else {
      AppCodeBO appCodeBo = appCodeRepository.findByAppId(sourceCodeRequest.getAppCd());
      if (null == appCodeBo) {
        LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
            .methodName("validate").message("AppCode to update doesn't exist in DB"));
        genericResponse = responseBuilder.generateResponse(ResponseCodes.APP_CODE_NOT_EXISTS_IN_DB);
      }
    }
    return new AsyncResult<>(genericResponse);
  }
}