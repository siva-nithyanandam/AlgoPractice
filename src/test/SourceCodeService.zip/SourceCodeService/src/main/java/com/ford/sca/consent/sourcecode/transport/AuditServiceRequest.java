package com.ford.sca.consent.sourcecode.transport;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuditServiceRequest {
  
  private String serviceId;
  private String capUserId;
  private String appId;
  private String jsonType;
  private Date tranDateTime;
  private String resourceUri;
  private String jsonBody; // actual message of req/res
  private String responseCode;
  private String requestStatus; // New/Failed/Success
  private String httpMethod;
  private String dataCenter;
  private String org;
  private String environment;
  private String traceId;
  private String spanId;
  private String correlationId;
  private String vcapRequestId;
  private String buildVersion;
  private Date requestTimeStamp;
  private String scaId;
  private String countryCode;
  
  public Date getTranDateTime() {
    return (null != this.tranDateTime) ? new Date(this.tranDateTime.getTime()) : null;
  }

  /**
   * Setting tranDateTime after cloning.
   * @param tranDateTime tranDateTime
   */
  public void setTranDateTime(final Date tranDateTime) {
    if (null != tranDateTime) {
      this.tranDateTime = new Date(tranDateTime.getTime());
    }
  }

}
