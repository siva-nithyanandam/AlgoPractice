package com.ford.sca.consent.sourcecode.transport;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.ford.sca.consent.sourcecode.util.RegexUtil;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(description = "Class representing a Source Code Request in the application.")
@Setter
@Getter
public class SourceCodeRequest implements Serializable {

	private static final long serialVersionUID = -330969790437503098L;

	@ApiModelProperty(notes = "APP ID", required = true)
	@NotBlank
	@Pattern(regexp = RegexUtil.APPCD_REGEX, message = "AppID is not active in CP")
	@Size(min=1, max = 6, message = "AppID is not active in CP")
	private Integer appCd;
  
	@ApiModelProperty(notes = "App Name",  required = true,
			example = "FORD PASS")
	@Pattern(regexp = "^[a-zA-Z0-9]{1,20}$", message = "Invalid App Name")
	@Size(min=1, max = 20, message = "Invalid length of App Name string")
	private String appName;
	
	@ApiModelProperty(notes = "App Description", required = false,
			example = "FORD PASS")
	@Pattern(regexp = "^[a-zA-Z0-9]{1,30}$", message = "Invalid App Description")
	@Size(min=1, max = 30, message = "Invalid length of App Description")
	private String appDesc;
	
	@ApiModelProperty(notes = "Effective From Date", required = false,
			example = "2020-01-13T20:00:00.000Z")
	@Pattern(regexp ="^\\d.+Z$", message = "Invalid effFromDate")
	@Size(min=24, max = 24, message = "Invalid length of effFromDate")
	private Date effFromDate;
  
	@ApiModelProperty(notes = "Effective To Date", required = false,
			example = "2020-01-13T20:00:00.000Z")
	@Pattern(regexp ="^\\d.+Z$", message = "Invalid effToDate")
	@Size(min=24, max = 24, message = "Invalid length of effToDate")
	private Date effToDate;
}
