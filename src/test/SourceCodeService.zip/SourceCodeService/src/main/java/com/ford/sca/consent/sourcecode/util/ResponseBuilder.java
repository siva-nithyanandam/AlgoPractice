package com.ford.sca.consent.sourcecode.util;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.sca.consent.sourcecode.transport.GenericResponse;

@Component
public class ResponseBuilder {

  @Autowired
  private CacheUtil cacheUtil;

  /**
   * To generate response to the caller.
   *
   * @param responseCode {@link ResponseCodes}
   * @return {@link GenericResponse}
   */
  public GenericResponse generateResponse(ResponseCodes responseCode) {
    GenericResponse genericResponse;
    if (responseCode.isSuccess()) {
      genericResponse =
          new GenericResponse(responseCode.getHttpStatus(), responseCode.getResponseMessage());
    } else {
      genericResponse = new GenericResponse(responseCode.getHttpStatus(),
          responseCode.getResponseMessage(), responseCode.getMsgId(),
          cacheUtil.getErrorMessage(responseCode.getMsgId()), Calendar.getInstance().getTime());
    }
    return genericResponse;
  }
  
  public GenericResponse generateResponse(String message,HttpServletRequest request) {
	  GenericResponse genericResponse=null;
	  if (message.indexOf(Constants.APP_CODE_NUMBER_FORMAT_ERROR_MSG)!=-1) {
		  genericResponse =generateResponse(ResponseCodes.APP_CODE_NOT_IN_NUMBER_FORMAT);
	  } else if(message.indexOf(Constants.APP_CODE_SIZE_ERROR_MSG)!=-1) {
		  genericResponse =generateResponse(ResponseCodes.APP_CODE_NOT_EXISTS_IN_CAP);
	  }
	  return genericResponse;
  }
}