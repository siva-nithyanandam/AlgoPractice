package com.ford.sca.consent.sourcecode.transport;

import java.util.Date;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Validated
public class GenericResponse {
	
	// Ignore this field sending back to caller always
	  @JsonIgnore
	  private HttpStatus httpStatus;
	  /*
	  // Ignore this field sending back to caller when it is null
	  @JsonInclude(JsonInclude.Include.NON_NULL)
	  private String responseMessage;

	  // Ignore this field sending back to caller when it is null
	  @JsonInclude(JsonInclude.Include.NON_NULL)
	  private String status;

	  // Ignore this field sending back to caller when it is null
	  @JsonInclude(JsonInclude.Include.NON_NULL)
	  private String errorMsgId;

	  // Ignore this field sending back to caller when it is null
	  @JsonInclude(JsonInclude.Include.NON_NULL)
	  private String errorMsg;

	  // Ignore this field sending back to caller when it is null
	  @JsonInclude(JsonInclude.Include.NON_NULL)
	  private Date errorTime;
	  */
	  @ApiModelProperty(notes = "response Message", example = "Invalid responseMessage")
		@Pattern(regexp = "\\w*", message = "Invalid responseMessage")
		@Size(max = 250, message = "Invalid length of responseMessage")
		@JsonInclude(JsonInclude.Include.NON_NULL)
		private String responseMessage;

		// Ignore this field sending back to caller when it is null
		@ApiModelProperty(notes = "Status", example = "Record successfully created", required = true)
		@Pattern(regexp = "\\w*", message = "Invalid status")
		@Size(max = 50, message = "Invalid length of status")
		@JsonInclude(JsonInclude.Include.NON_NULL)
		private String status;

		// Ignore this field sending back to caller when it is null
		@ApiModelProperty(notes = "Error Message ID", example = "MSG-0100")
		@Pattern(regexp = "\\w*", message = "Invalid errorMsgId")
		@Size(max = 10, message = "Invalid length of errorMsgId")
		@JsonInclude(JsonInclude.Include.NON_NULL)
		private String errorMsgId;

		// Ignore this field sending back to caller when it is null
		@ApiModelProperty(notes = "Error Message", example = "Invalid app id")
		@Pattern(regexp = "\\w*", message = "Invalid errorMsg")
		@Size(max = 50, message = "Invalid length of errorMsg")
		@JsonInclude(JsonInclude.Include.NON_NULL)
		private String errorMsg;

		// Ignore this field sending back to caller when it is null
		@ApiModelProperty(notes = "Time at which error occurred", example = "2020-01-13T20:00:00.000Z", required = true)
		//@Pattern(regexp = "^\\d.+Z{24,24}$", message = "Invalid errorTime")
		//@Size(max = 24, message = "Invalid length of errorTime")
		@JsonInclude(JsonInclude.Include.NON_NULL)
		private Date errorTime;
	  
	  /**
	   * Default no-arg constructor to aid specific extending subclasses.
	   **/
	  public GenericResponse() {
	    super();
	  }

	  /**
	   * To generate {@link GenericResponse} for success response.
	   *
	   * @param httpStatus HttpStatus
	   * @param responseMessage Success message
	   */
	  public GenericResponse(HttpStatus httpStatus, String responseMessage) {
	    this.httpStatus = httpStatus;
	    this.responseMessage = responseMessage;
	  }

	  /**
	   * To generate {@link GenericResponse} for failure response.
	   *
	   * @param httpStatus HttpStatus
	   * @param status Failure message
	   * @param errorMsgId Error message ID
	   * @param errorMsg Error message
	   * @param errorTime When error happened
	   */
	  public GenericResponse(HttpStatus httpStatus, String status, String errorMsgId, String errorMsg,
	      Date errorTime) {
	    this.httpStatus = httpStatus;
	    this.status = status;
	    this.errorMsgId = errorMsgId;
	    this.responseMessage = errorMsg;
	    this.errorTime = errorTime;
	  }
  
 
}

