package com.ford.sca.consent.sourcecode.transport;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ApiParams {
  private String resourceUri;
  private Integer requesterAppCd;
  private String requesterCdsId;
  private Date requestTimeStamp;
  private Integer appCdToProcess;
}