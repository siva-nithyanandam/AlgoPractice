package com.ford.sca.consent.sourcecode.config;

import lombok.Getter;
import lombok.Setter;
import java.util.List;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "config-properties")
@Getter
@Setter
public class ConfigProperties {

	private float timerIntervalDays;

	@NestedConfigurationProperty
	private TaskExecutorConfig taskExecuter;

	private Map<String, List<String>> resourcePermissions;
}
