package com.ford.sca.consent.sourcecode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;
import org.springframework.security.oauth2.provider.expression.OAuth2MethodSecurityExpressionHandler;
import org.springframework.beans.factory.annotation.Value;

import com.ford.sca.consent.sourcecode.util.RegexUtil;
import com.google.common.collect.Lists;

import springfox.bean.validators.configuration.BeanValidatorPluginsConfiguration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.OAuthBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.AllowableRangeValues;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.GrantType;
import springfox.documentation.service.ImplicitGrant;
import springfox.documentation.service.LoginEndpoint;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableCaching
@EntityScan("com.ford.sca.consent")
@Import(BeanValidatorPluginsConfiguration.class)
public class SourceCodeServiceLauncher {
	
	@Value("${token_url}")
	private String tokenUrl;

  /**
   * To launch this application through SpringBoot.
   * @param args args
   */
  public static void main(final String[] args) {
    SpringApplication.run(SourceCodeServiceLauncher.class, args);
  }

  /**
   * To create OAuth2 header section in the swagger API.
   */
  @Bean
  public Docket newsApi() {
	  return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.any())
				.paths(PathSelectors.regex("/source-code-management.*")).build()
				.globalOperationParameters(Lists.newArrayList(new ParameterBuilder().name("Authorization")
						.description("OAuth2 bearer token").modelRef(new ModelRef("string"))
						.parameterType("header").required(true)
						.allowableValues(new AllowableRangeValues("1","4500"))
						.pattern(RegexUtil.TOKEN_REGEX).build()))
				.securitySchemes(Arrays.asList(consumerAccessTokenSecurityScheme()))
				.securityContexts(Arrays.asList(securityContext()))
				.protocols(Stream.of("https").collect(Collectors.toCollection(HashSet::new))).apiInfo(apiInfo());
  }
  
  private SecurityScheme consumerAccessTokenSecurityScheme() {
		GrantType grantType = new ImplicitGrant(new LoginEndpoint(tokenUrl),
				"ConsumerAccessToken");
		AuthorizationScope authorizationScope1 = new AuthorizationScope("scope", "description");
		List<AuthorizationScope> authorizationScopeList = new ArrayList<AuthorizationScope>();
		authorizationScopeList.add(authorizationScope1);
		return new OAuthBuilder().name("ConsumerAccessToken").grantTypes(Arrays.asList(grantType))
				.scopes(authorizationScopeList).build();
	}

	// Security
	private AuthorizationScope[] emptyScopes() {
		return Collections.emptyList().toArray(new AuthorizationScope[0]);
	}

	// Security
	private SecurityContext securityContext() {
		return SecurityContext.builder()
				.securityReferences(Arrays.asList(
						SecurityReference.builder().reference("ConsumerAccessToken").scopes(emptyScopes()).build()))
				.build();
	}

  /**
   * To create API information.
   */
  private ApiInfo apiInfo() {
    return new ApiInfoBuilder()
        .title("Source Code Manager Service")
        .description("To manage source code").version("1.0").build();
  }

  /**
   * To create security configurations.
   */
  @Bean
  public GlobalMethodSecurityConfiguration globalMethodSecurityConfiguration() {
    return new GlobalMethodSecurityConfiguration() {
      @Override
      protected MethodSecurityExpressionHandler createExpressionHandler() {
        return new OAuth2MethodSecurityExpressionHandler();
      }
    };
  }
}