package com.ford.sca.consent.sourcecode.util;

public class RegexUtil {

	private RegexUtil() {
	}

	public static final String GUID_REGEX = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$";
	public static final String APPCD_REGEX = "^[1-9][0-9]{0,5}$";
	public static final String TOKEN_REGEX = "^[Bb]earer [A-Za-z0-9-_=]+.[A-Za-z0-9-_=]+.?[A-Za-z0-9-_.+/=]*$";
}
