package com.ford.sca.consent.sourcecode.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.domain.AppCodeBO;

@Repository
public interface AppCodeRepository extends JpaRepository<AppCodeBO, Integer> {

  AppCodeBO findByAppId(Integer appId);

}
