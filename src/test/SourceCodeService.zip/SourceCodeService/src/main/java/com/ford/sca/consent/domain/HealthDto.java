package com.ford.sca.consent.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HealthDto {

  private String status;
}
