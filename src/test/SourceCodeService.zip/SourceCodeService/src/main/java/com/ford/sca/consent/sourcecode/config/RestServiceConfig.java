package com.ford.sca.consent.sourcecode.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ConfigurationProperties(prefix = "config-properties.rest-service")
public class RestServiceConfig {
	private int connectTimeout;
	private int readTimeout;
	private int backoffLow;
	private int backoffHigh;
	private int backoffMaxInterval;
	private int backoffAttemptNum;
}
