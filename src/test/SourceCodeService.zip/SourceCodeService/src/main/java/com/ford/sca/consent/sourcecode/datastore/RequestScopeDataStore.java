package com.ford.sca.consent.sourcecode.datastore;

public class RequestScopeDataStore {

  //Add your variables to store in request scope
}
