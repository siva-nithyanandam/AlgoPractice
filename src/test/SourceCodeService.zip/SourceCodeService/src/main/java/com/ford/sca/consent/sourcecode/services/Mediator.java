package com.ford.sca.consent.sourcecode.services;

import com.ford.sca.consent.domain.AppCodeBO;
import com.ford.sca.consent.sourcecode.exception.ConsentRuntimeException;
import com.ford.sca.consent.sourcecode.repository.AppCodeRepository;
import com.ford.sca.consent.sourcecode.transport.ApiParams;
import com.ford.sca.consent.sourcecode.transport.GenericResponse;
import com.ford.sca.consent.sourcecode.transport.SourceCodeRequest;
import com.ford.sca.consent.sourcecode.util.CacheUtil;
import com.ford.sca.consent.sourcecode.util.Constants;
import com.ford.sca.consent.sourcecode.util.GenericAssister;
import com.ford.sca.consent.sourcecode.util.LogAround;
import com.ford.sca.consent.sourcecode.util.LoggerBuilder;
import com.ford.sca.consent.sourcecode.util.ResponseBuilder;
import com.ford.sca.consent.sourcecode.util.ResponseCodes;
import com.ford.sca.consent.sourcecode.validators.AppIdValidator;
import com.ford.sca.consent.sourcecode.validators.CreateRequestValidator;
import com.ford.sca.consent.sourcecode.validators.DeleteAppIdValidator;
import com.ford.sca.consent.sourcecode.validators.UpdateRequestValidator;
import com.ford.sca.consent.sourcecode.validators.Validator;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class Mediator {

  private List<Validator> createRequestValidators;
  private List<Validator> updateRequestValidators;
  private List<Validator> retrieveRequestValidators;
  private List<Validator> deleteRequestValidators;

  @Autowired
  ResponseBuilder responseBuilder;

  @Autowired
  CacheUtil cacheUtil;

  @Autowired
  private AppCodeRepository appCodeRepository;

  @Autowired
  private SourceCodeTimer sourceCodeTimer;

  @Autowired
  public Mediator(final AppIdValidator appIdValidator,
      final CreateRequestValidator createRequestValidator,
      final UpdateRequestValidator updateRequestValidator,
      final DeleteAppIdValidator deleteAppIdValidator) {
    //Create request validators
    createRequestValidators = new ArrayList<>();
    createRequestValidators.add(appIdValidator);
    createRequestValidators.add(createRequestValidator);

    //Update request validators
    updateRequestValidators = new ArrayList<>();
    updateRequestValidators.add(appIdValidator);
    updateRequestValidators.add(updateRequestValidator);

    //Retrieve request validators
    retrieveRequestValidators = new ArrayList<>();
    retrieveRequestValidators.add(appIdValidator);

    //Delete request validators
    deleteRequestValidators = new ArrayList<>();
    deleteRequestValidators.add(appIdValidator);
    deleteRequestValidators.add(deleteAppIdValidator);
  }

  /**
   * To build ApiParams with required attributes.
   *
   * @param request
   * @param reqAppCd       - Requester Application Id.
   * @param reqCdsId       - Requester CDS ID.
   * @param appCdToProcess
   * @return Encapsulated {@link ApiParams} for given attributes.
   */
  public ApiParams buildApiParams(final HttpServletRequest request, final Integer reqAppCd,
      final String reqCdsId, final Integer appCdToProcess) {
    final ApiParams apiParams = new ApiParams();
    apiParams.setResourceUri(constructResourceUri(request));
    apiParams.setRequesterAppCd(reqAppCd);
    apiParams.setRequesterCdsId(reqCdsId);
    apiParams.setRequestTimeStamp(new Date());
    apiParams.setAppCdToProcess(appCdToProcess);
    return apiParams;
  }

  /**
   * construct resource uri string needed for audit activity and logging purposes.
   *
   * @param request is HttpServletRequest
   * @return String is the constructed resource uri
   */
  public static String constructResourceUri(final HttpServletRequest request) {
    return new StringBuilder().append(request.getScheme()).append(Constants.COLON_SLASHES)
        .append(request.getServerName()).append(Constants.COLON)
        .append(request.getServerPort()).append(request.getRequestURI())
        .append(Constants.QUESTION_MARK)
        .append(request.getQueryString()).toString();
  }

  /**
   * To validate and create given app code details.
   *
   * @param apiParams         {@link ApiParams}
   * @param sourceCodeRequest {@link SourceCodeRequest}
   * @param httpRequest       {@link HttpServletRequest}
   * @return {@link GenericResponse}
   */
  @LogAround
  public GenericResponse validateAndCreateRecord(final ApiParams apiParams,
      final SourceCodeRequest sourceCodeRequest, final HttpServletRequest httpRequest) {

    GenericResponse genericResponse;
    //1. Validate given request attributes
    Optional<GenericResponse> failedValidationResponse = validate(createRequestValidators,
        apiParams, sourceCodeRequest, httpRequest);
    if (failedValidationResponse.isPresent()) {
      LoggerBuilder.printError(log, logger -> logger.methodName("validateAndCreateRequest")
          .requesterAppCd(apiParams.getRequesterAppCd()).message("Validation failed"));
      genericResponse = failedValidationResponse.get();
    } else {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndCreateRequest")
          .message("All the validations are passed"));
      //2. Save request
      AppCodeBO appCodeBO = populateAppCodeBOForCreate(apiParams, sourceCodeRequest, httpRequest);
      appCodeRepository.save(appCodeBO);
      sourceCodeTimer.refreshCache(appCodeBO);
      genericResponse = responseBuilder.generateResponse(ResponseCodes.CREATE_SUCCESS);
    }
    return genericResponse;
  }

  /**
   * To validate and update given app code details.
   *
   * @param apiParams         {@link ApiParams}
   * @param sourceCodeRequest {@link SourceCodeRequest}
   * @param httpRequest       {@link HttpServletRequest}
   * @return {@link GenericResponse}
   */
  @LogAround
  public GenericResponse validateAndUpdateRecord(ApiParams apiParams,
      SourceCodeRequest sourceCodeRequest, HttpServletRequest httpRequest) {
    GenericResponse genericResponse;
    //1. Validate given request attributes
    Optional<GenericResponse> failedValidationResponse = validate(updateRequestValidators,
        apiParams, sourceCodeRequest, httpRequest);
    if (failedValidationResponse.isPresent()) {
      LoggerBuilder.printError(log, logger -> logger.methodName("validateAndUpdateRequest")
          .requesterAppCd(apiParams.getRequesterAppCd()).message("Validation failed"));
      genericResponse = failedValidationResponse.get();
    } else {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndUpdateRequest")
          .message("All the validations are passed"));
      //2. Save request
      AppCodeBO appCodeBO = popoulateAppCodeBOForUpdate(apiParams, sourceCodeRequest, httpRequest);
      appCodeRepository.save(appCodeBO);
      sourceCodeTimer.refreshCache(appCodeBO);
      genericResponse = responseBuilder.generateResponse(ResponseCodes.UPDATE_SUCCESS);
    }
    return genericResponse;
  }

  /**
   * To validate and retrieve app code details for given app code from cache if not available get
   * from table.
   *
   * @param apiParams   {@link ApiParams}
   * @param httpRequest {@link HttpServletRequest}
   * @return {@link GenericResponse}
   */
  @LogAround
  public GenericResponse validateAndRetrieveRecordFromCacheAndTable(final ApiParams apiParams,
      final HttpServletRequest httpRequest) {
    GenericResponse genericResponse;
    //1. Validate given request attributes
    Optional<GenericResponse> failedValidationResponse = validate(retrieveRequestValidators,
        apiParams, null, httpRequest);
    if (failedValidationResponse.isPresent()) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .methodName("validateAndRetrieveRecordFromCacheAndTable").message("Validation failed"));
      genericResponse = failedValidationResponse.get();
    } else {
      LoggerBuilder.printInfo(log, logger -> logger.message("All the validations are passed")
          .methodName("validateAndRetrieveRecordFromCacheAndTable"));
      //2. Save request
      AppCodeBO appCodeBO = cacheUtil.getAppCodeDtls(apiParams.getAppCdToProcess());
      if (null != appCodeBO) {
        genericResponse = appCodeBO;
        genericResponse.setHttpStatus(HttpStatus.OK);
      } else {
        genericResponse = responseBuilder
            .generateResponse(ResponseCodes.APP_CODE_NOT_EXISTS_IN_DB);
      }
    }
    return genericResponse;
  }

  /**
   * To validate and retrieve app code details for given app code from table alone.
   *
   * @param apiParams   {@link ApiParams}
   * @param httpRequest {@link HttpServletRequest}
   * @return {@link GenericResponse}
   */
  @LogAround
  public GenericResponse validateAndRetrieveRecordFromTable(final ApiParams apiParams,
      final HttpServletRequest httpRequest) {
    GenericResponse genericResponse;
    //1. Validate given request attributes
    Optional<GenericResponse> failedValidationResponse = validate(retrieveRequestValidators,
        apiParams, null, httpRequest);
    if (failedValidationResponse.isPresent()) {
      LoggerBuilder.printError(log, logger -> logger.requesterAppCd(apiParams.getRequesterAppCd())
          .methodName("validateAndRetrieveRecordFromTable").message("Validation failed"));
      genericResponse = failedValidationResponse.get();
    } else {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndRetrieveRecordFromTable")
          .message("All the validations are passed"));
      //2. Save request
      Optional<AppCodeBO> appCodeBO = appCodeRepository.findById(apiParams.getAppCdToProcess());
      if (appCodeBO.isPresent()) {
        genericResponse = appCodeBO.get();
        genericResponse.setHttpStatus(HttpStatus.OK);
      } else {
        genericResponse = responseBuilder
            .generateResponse(ResponseCodes.APP_CODE_NOT_EXISTS_IN_DB);
      }
    }
    return genericResponse;
  }

  /**
   * To validate and delete app code details for given app code.
   *
   * @param apiParams   {@link ApiParams}
   * @param httpRequest {@link HttpServletRequest}
   * @return {@link GenericResponse}
   */
  @LogAround
  public GenericResponse validateAndDeleteRecord(final ApiParams apiParams,
      final HttpServletRequest httpRequest) {
    GenericResponse genericResponse;
    //1. Validate given request attributes
    Optional<GenericResponse> failedValidationResponse = validate(deleteRequestValidators,
        apiParams, null, httpRequest);
    if (failedValidationResponse.isPresent()) {
      LoggerBuilder.printError(log, logger -> logger.methodName("validateAndDeleteRequest")
          .requesterAppCd(apiParams.getRequesterAppCd()).message("Validation failed"));
      genericResponse = failedValidationResponse.get();
    } else {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndDeleteRequest")
          .message("All the validations are passed"));
      //2. Save request
      appCodeRepository.deleteById(apiParams.getAppCdToProcess());
      sourceCodeTimer.removeTimerAndCacheEntry(apiParams.getAppCdToProcess());
      genericResponse = responseBuilder.generateResponse(ResponseCodes.SUCCESS);
    }
    return genericResponse;
  }

  /**
   * To clean and load app code details in cache.
   *
   * @return {@link GenericResponse}
   */
  @LogAround
  public GenericResponse refreshCache() {
    sourceCodeTimer.refreshCache();
    return responseBuilder.generateResponse(ResponseCodes.SUCCESS);
  }

  private AppCodeBO populateAppCodeBOForCreate(final ApiParams apiParams,
      final SourceCodeRequest sourceCodeRequest, final HttpServletRequest httpRequest) {
    final AppCodeBO appCodeBO = new AppCodeBO();
    appCodeBO.setAppId(sourceCodeRequest.getAppCd());
    appCodeBO.setAppName(sourceCodeRequest.getAppName());
    appCodeBO.setAppDesc(sourceCodeRequest.getAppDesc());
    appCodeBO.setActiveFlag("N");
    appCodeBO.setEffFromDate(sourceCodeRequest.getEffFromDate());
    appCodeBO.setEffToDate(sourceCodeRequest.getEffToDate());
    final Date now = Calendar.getInstance().getTime();
    appCodeBO.setCreateDate(now);
    appCodeBO.setCreateUser(apiParams.getRequesterCdsId());
    appCodeBO.setCreateAppCode(apiParams.getRequesterAppCd());
    appCodeBO.setCreateProcess(GenericAssister
        .truncateString(MDC.get(Constants.BUILD_VERSION_HEADER_NAME),
            Constants.MAX_BUILD_VERSION_LENGTH));
    appCodeBO.setUpdateDate(now);
    appCodeBO.setUpdateUser(apiParams.getRequesterCdsId());
    appCodeBO.setUpdateAppCode(apiParams.getRequesterAppCd());
    appCodeBO.setUpdateProcess(GenericAssister
        .truncateString(MDC.get(Constants.BUILD_VERSION_HEADER_NAME),
            Constants.MAX_BUILD_VERSION_LENGTH));
    return appCodeBO;
  }

  private AppCodeBO popoulateAppCodeBOForUpdate(final ApiParams apiParams,
      final SourceCodeRequest sourceCodeRequest, final HttpServletRequest httpRequest) {
    Optional<AppCodeBO> appCodeBOOptional = appCodeRepository
        .findById(sourceCodeRequest.getAppCd());
    AppCodeBO appCodeBO = appCodeBOOptional.get();
    if (GenericAssister.isNotEmptyString(sourceCodeRequest.getAppName())) {
      appCodeBO.setAppName(sourceCodeRequest.getAppName());
    }
    if (GenericAssister.isNotEmptyString(sourceCodeRequest.getAppDesc())) {
      appCodeBO.setAppDesc(sourceCodeRequest.getAppDesc());
    }
    if (sourceCodeRequest.getEffFromDate() != null) {
      appCodeBO.setEffFromDate(sourceCodeRequest.getEffFromDate());
    }
    if (sourceCodeRequest.getEffToDate() != null) {
      appCodeBO.setEffToDate(sourceCodeRequest.getEffToDate());
    }
    final Date now = Calendar.getInstance().getTime();
    appCodeBO.setUpdateDate(now);
    appCodeBO.setUpdateUser(apiParams.getRequesterCdsId());
    appCodeBO.setUpdateAppCode(apiParams.getRequesterAppCd());
    appCodeBO.setUpdateProcess(GenericAssister
        .truncateString(MDC.get(Constants.BUILD_VERSION_HEADER_NAME),
            Constants.MAX_BUILD_VERSION_LENGTH));
    return appCodeBO;
  }

  /**
   * To invoke all required validator implementations asynchronously.
   */
  @LogAround
  public Optional<GenericResponse> validate(final List<Validator> validators,
      final ApiParams apiParams, final SourceCodeRequest sourceCodeRequest,
      final HttpServletRequest httpRequest) {

    final List<Future<GenericResponse>> validationResponses = new ArrayList<>();

    // Trigger each secondary validator's validate()
    validators.stream().forEach(validator -> validationResponses
        .add(validator.validate(apiParams, sourceCodeRequest, httpRequest)));

    // Return any of failure validation
    return validationResponses.stream().map(cfResp -> parseValidationResponse(apiParams, cfResp))
        .filter(Objects::nonNull).findAny();
  }

  /**
   * To parse validation response from each validator.
   *
   * @param apiParams API parameters
   * @param cfResp    Validation response
   * @return Parsed validation response
   */
  private GenericResponse parseValidationResponse(final ApiParams apiParams,
      final Future<GenericResponse> cfResp) {
    GenericResponse genericResponse;
    try {
      genericResponse = cfResp.get();
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.exceptionMessage(e.getMessage()).exception(e)
          .newAppCd(apiParams.getRequesterAppCd()).methodName("parseValidationResponse")
          .message("Exception in one of the validators"));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
    }
    return genericResponse;
  }
}