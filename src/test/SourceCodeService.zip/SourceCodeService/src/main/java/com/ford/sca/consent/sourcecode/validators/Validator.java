package com.ford.sca.consent.sourcecode.validators;

import com.ford.sca.consent.sourcecode.transport.ApiParams;
import com.ford.sca.consent.sourcecode.transport.GenericResponse;
import com.ford.sca.consent.sourcecode.transport.SourceCodeRequest;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import org.springframework.scheduling.annotation.Async;

public interface Validator {

  /**
   * To validate according to the provided validator
   *
   * @param apiParams         {@link ApiParams}
   * @param sourceCodeRequest {@link SourceCodeRequest}
   * @param request           {@link HttpServletRequest}
   * @return {@link GenericResponse}
   */
  @Async("taskExecutor")
  Future<GenericResponse> validate(final ApiParams apiParams,
      final SourceCodeRequest sourceCodeRequest, final HttpServletRequest request);
}
