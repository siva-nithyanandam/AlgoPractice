package com.ford.sca.consent.sourcecode.services;

import com.ford.sca.consent.domain.AppCodeBO;
import com.ford.sca.consent.sourcecode.config.ConfigProperties;
import com.ford.sca.consent.sourcecode.repository.AppCodeRepository;
import com.ford.sca.consent.sourcecode.util.CacheUtil;
import com.ford.sca.consent.sourcecode.util.Constants;
import com.ford.sca.consent.sourcecode.util.LogAround;
import com.ford.sca.consent.sourcecode.util.LoggerBuilder;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SourceCodeTimer {

  private final Map<String, Timer> timerMap = new HashMap<>();
  private ConfigProperties configProperties;
  private CacheUtil cacheUtil;
  private AppCodeRepository appCodeRepository;

  @Autowired
  public SourceCodeTimer(final ConfigProperties configProperties, final CacheUtil cacheUtil,
      final AppCodeRepository appCodeRepository) {
    this.configProperties = configProperties;
    this.cacheUtil = cacheUtil;
    this.appCodeRepository = appCodeRepository;

    addNextInitiatorSchedule();
  }

  /**
   * Adding next initiator schedule.
   */
  private void addNextInitiatorSchedule() {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("addNextInitiaterSchedule"));
    long delay = (long) (configProperties.getTimerIntervalDays() * Constants.TOTAL_MILLIS_PER_DAY);

    Timer timer = new Timer();
    timer.schedule(new TimerTask() {
      @Override
      public void run() {
        LoggerBuilder.printInfo(log, logger -> logger.methodName("addNextInitiaterSchedule")
            .message("Running next duration schedule to update cache"));
        updateCacheForNextDuration();
        LoggerBuilder.printInfo(log, logger -> logger.methodName("addNextInitiaterSchedule")
            .message("Next scheduled run is at")
            .dateTime(new Date(new Date().getTime() + delay).toString()));
      }
    }, 0, delay);
  }

  /**
   * On start of this app, recreate timers for applicable appCodes.
   */
  @LogAround
  private void updateCacheForNextDuration() {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("updateCacheForNextDuration"));
    timerMap.clear();
    List<AppCodeBO> appCodeBOList = appCodeRepository.findAll();
    long currentTimeMillis = new Date().getTime();
    for (AppCodeBO appCodeBO : appCodeBOList) {
      if (null != appCodeBO.getEffFromDate()
          && appCodeBO.getEffFromDate().getTime() > currentTimeMillis) {
        filterEffectiveAndAddTimer(appCodeBO);
      }
      if (null != appCodeBO.getEffToDate()
          && appCodeBO.getEffToDate().getTime() > currentTimeMillis) {
        filterNonEffectiveAndAddTimer(appCodeBO);
      }
    }
  }

  /**
   * Find and add timer if given AppCodeBO is about to be effective.
   *
   * @param appCodeBO {@link AppCodeBO}
   */
  @LogAround
  public void filterEffectiveAndAddTimer(final AppCodeBO appCodeBO) {
    cacheUtil.emptyAppCodeDtlsInCache(appCodeBO.getAppId());
    if (null != appCodeBO.getEffFromDate()
        && appCodeBO.getEffFromDate().getTime() < (new Date().getTime() +
        (configProperties.getTimerIntervalDays() * Constants.TOTAL_MILLIS_PER_DAY))) {
      addTimerToUpdateCache(appCodeBO, Constants.ADD_TASK, appCodeBO.getEffFromDate());
    }
  }

  /**
   * Find and add timer if given AppCodeBO is about to be non effective.
   *
   * @param appCodeBO {@link AppCodeBO}
   */
  @LogAround
  public void filterNonEffectiveAndAddTimer(final AppCodeBO appCodeBO) {
    if (null != appCodeBO.getEffToDate()
        && appCodeBO.getEffToDate().getTime() < (new Date().getTime() +
        (configProperties.getTimerIntervalDays() * Constants.TOTAL_MILLIS_PER_DAY))) {
      addTimerToUpdateCache(appCodeBO, Constants.REMOVE_TASK, appCodeBO.getEffToDate());
    }
  }

  /**
   * To manage all future dated appCodes into cache.
   *
   * @param appCodeBO    {@link AppCodeBO}
   * @param task         Either Add or Remove
   * @param scheduleTime What time it has to added/removed from cache
   */
  private void addTimerToUpdateCache(final AppCodeBO appCodeBO, final String task,
      final Date scheduleTime) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("addTimerToUpdateCache")
        .newAppCd(appCodeBO.getAppId()).message("Scheduling timer to " + task)
        .dateTime(scheduleTime.toString()));

    purgeExistingTimerIfAny(appCodeBO.getAppId(), task);

    Timer timer = new Timer();
    timer.schedule(new TimerTask() {
      @Override
      public void run() {
        LoggerBuilder.printInfo(log, logger -> logger.methodName("addTimerToUpdateCache")
            .newAppCd(appCodeBO.getAppId()).message("updating cache to " + task)
            .dateTime(scheduleTime.toString()));
        if (task == Constants.ADD_TASK) {
          appCodeBO.setActiveFlag("Y");
          cacheUtil.addAppCodeDtls(appCodeBO.getAppId(), appCodeBO);
        } else {
          appCodeBO.setActiveFlag("N");
          cacheUtil.emptyAppCodeDtlsInCache(appCodeBO.getAppId());
        }
        appCodeBO.setUpdateDate(Calendar.getInstance().getTime());
        appCodeBO.setUpdateProcess("SourceCodeTimer-class");
        appCodeRepository.save(appCodeBO);
        timer.cancel();
        timer.purge();
        timerMap.remove(appCodeBO.getAppId() + Constants.HASH_DELIMETER + task);
      }
    }, scheduleTime);

    LoggerBuilder.printInfo(log, logger -> logger.methodName("addTimerToUpdateCache")
        .newAppCd(appCodeBO.getAppId()).message("Adding to timerMap for " + task));
    timerMap.put(appCodeBO.getAppId() + Constants.HASH_DELIMETER + task, timer);
  }

  /**
   * To find same appCode timer task already scheduled, if so, purge it and remove from Map.
   *
   * @param appCd - appCd to be processed.
   * @param task      - String - "Add" or "Remove"
   */
  private void purgeExistingTimerIfAny(final Integer appCd, final String task) {
    Timer existingTimer = timerMap.get(appCd + Constants.HASH_DELIMETER + task);
    if (existingTimer != null) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("purgeExistingTimerIfAny")
          .newAppCd(appCd).message("Cancelling existing schedule"));
      existingTimer.cancel();
      existingTimer.purge();
      timerMap.remove(appCd + Constants.HASH_DELIMETER + task);
    }
  }

  /**
   * To clean and load all app code details in cache.
   */
  public void refreshCache() {
    timerMap.clear();
    List<AppCodeBO> appCodeBOList = appCodeRepository.findAll();
    final Date current = new Date();
    for (AppCodeBO appCodeBO : appCodeBOList) {
      if (null != appCodeBO.getEffToDate() && appCodeBO.getEffToDate().after(current)) {
        refreshCache(appCodeBO);
      } else {
        cacheUtil.emptyAppCodeDtlsInCache(appCodeBO.getAppId());
      }
    }
  }

  /**
   * To clean and load app code details in cache.
   */
  @LogAround
  public void refreshCache(final AppCodeBO appCodeBO) {
    if (null != appCodeBO.getEffFromDate() && null != appCodeBO.getEffToDate()) {
      if (appCodeBO.getEffToDate().after(new Date())) {
        filterEffectiveAndAddTimer(appCodeBO);
      }
      filterNonEffectiveAndAddTimer(appCodeBO);
    }
  }

  /**
   *
   * To remove all appCode details both from Timer and cache.
   * @param appCdToProcess - appCd to be deleted
   */
  public void removeTimerAndCacheEntry(Integer appCdToProcess) {
    cacheUtil.removeAppCodeDtls(appCdToProcess);
    purgeExistingTimerIfAny(appCdToProcess, Constants.ADD_TASK);
    purgeExistingTimerIfAny(appCdToProcess, Constants.REMOVE_TASK);
  }
}