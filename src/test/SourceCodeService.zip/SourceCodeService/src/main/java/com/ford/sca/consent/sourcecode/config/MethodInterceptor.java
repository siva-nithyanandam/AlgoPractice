package com.ford.sca.consent.sourcecode.config;

import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MethodInterceptor extends HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String theMethod = request.getMethod();
        if (HttpMethod.HEAD.matches(theMethod) || HttpMethod.OPTIONS.matches(theMethod)|| HttpMethod.TRACE.matches(theMethod)
        		//|| HttpMethod.POST.matches(theMethod) || HttpMethod.PUT.matches(theMethod) || HttpMethod.DELETE.matches(theMethod)
				|| HttpMethod.PATCH.matches(theMethod) ) {
            response.sendError(HttpStatus.METHOD_NOT_ALLOWED.value());
            return false;
        }
        return true;
    }
}