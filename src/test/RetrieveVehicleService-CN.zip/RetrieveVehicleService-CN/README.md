# Account Service
A template repository for SCA-CAP account related services.

## Prerequisites 

- Java 8
- Install lombok plugin
- Install scala plugin(for performance test using Gatling)

## Build and Deploy

The project can be built using below gradle command
```bash
$ ./gradlew clean build
```
The built artifact can be deployed through PCF CLI with the following command
```bash
$ cf push -f manifest-{env}.yml
```
*Note: env is the enviornment in which the application is deployed eg QA, PR etc

## Testing
This project supports three different types of automated testing, unit tests,functional tests, and performance tests.
Gradle build is configured such that each type of testing can be run individually and test results are stored in separate
directories.

Use the following command to run the unit tests:
```bash
$ gradle clean test
```
Use the following command to run the functional (user acceptance) tests:
```bash
$ gradle clean functionalTest
```
Use the following command to run the performance tests:
```bash
$ gradle clean performanceTest
```
Notes: 
- By default, functional test expects a running instance of the application.
- When running the functional tests, the URL of the host that will be called based on two things; the URLs found in 
the src/funtionalTest/resources/application.yml file, and the value assigned to the 'lcp' environment variable. When 
running from the command line us this command to set lcp to the desired value:
```bash
$ export lcp="<value>"
```

The same applicable for performanceTest as well .


## Documentation

Swagger Docs: [http://localhost:
