package com.ford.sca.cap.domain;

import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.NotEmpty;

@Getter
@Setter
public class OAuthTokenRequest implements Serializable {

  private static final long serialVersionUID = 5483092160915549676L;

  @NotNull
  @NotEmpty
  private String clientId;

  @NotNull
  @NotEmpty
  private String clientSecret;
}
