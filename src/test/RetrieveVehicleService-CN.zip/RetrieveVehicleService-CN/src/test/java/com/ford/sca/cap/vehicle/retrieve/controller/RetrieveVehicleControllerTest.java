package com.ford.sca.cap.vehicle.retrieve.controller;

import com.ford.sca.cap.vehicle.retrieve.service.RetrieveVehicleService;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.AuditActivityUtil;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RetrieveVehicleControllerTest {

  @InjectMocks
  private RetrieveVehicleController retrieveVehicleController;

  @Mock
  private AuditActivityUtil auditActivityUtil;

  @Mock
  private RetrieveVehicleService retrieveVehicleService;

  @Mock
  private ResponseBuilder responseBuilder;


  /**
   * Success case
   */
  @Test
  public void ensure_retrieve_vehicle_for_user_is_returns_success() {
    //GIVEN
    HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpResponse = Mockito.mock(HttpServletResponse.class);
    Mockito.when(retrieveVehicleService.retrieveVehicle(Mockito.any(),Mockito.any()))
        .thenReturn(new GenericResponse(HttpStatus.OK, "Success"));
    //WHEN
    GenericResponse response = retrieveVehicleController
        .retrieveVehiclesForUser("1234", "100504", "F", httpRequest, httpResponse);

    //THEN
    Assert.assertEquals(HttpStatus.OK, response.getHttpStatus());
  }

  /**
   * When AppId is empty
   */
  @Test
  public void test_retrieve_vehicle_for_user_when_appId_is_empty() {
    //GIVEN
    HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpResponse = Mockito.mock(HttpServletResponse.class);
    Mockito.when(retrieveVehicleService.retrieveVehicle(Mockito.any(),Mockito.any()))
        .thenReturn(new GenericResponse(HttpStatus.OK, "Success"));
    Mockito.when(responseBuilder.generateResponse(ResponseCodes.APP_CODE_NOT_FOUND_IN_REQ))
        .thenReturn(new GenericResponse(ResponseCodes.APP_CODE_NOT_FOUND_IN_REQ.getHttpStatus(),
            ResponseCodes.APP_CODE_NOT_FOUND_IN_REQ.getResponseMessage()));
    //WHEN
    GenericResponse response = retrieveVehicleController
        .retrieveVehiclesForUser("1234", null, "F", httpRequest, httpResponse);
    //THEN
    Assert.assertEquals(ResponseCodes.APP_CODE_NOT_FOUND_IN_REQ.getHttpStatus(),
        response.getHttpStatus());
  }

  /**
   * When AppId is not numeric
   */
  @Test
  public void test_retrieve_vehicle_for_user_when_appId_is_not_numeric() {
    //GIVEN
    HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpResponse = Mockito.mock(HttpServletResponse.class);
    Mockito.when(retrieveVehicleService.retrieveVehicle(Mockito.any(),Mockito.any()))
        .thenReturn(new GenericResponse(HttpStatus.OK, "Success"));
    Mockito.when(responseBuilder.generateResponse(ResponseCodes.APP_CODE_NOT_IN_NUMBER_FORMAT))
        .thenReturn(new GenericResponse(ResponseCodes.APP_CODE_NOT_IN_NUMBER_FORMAT.getHttpStatus(),
            ResponseCodes.APP_CODE_NOT_IN_NUMBER_FORMAT.getResponseMessage()));
    //WHEN
    GenericResponse response = retrieveVehicleController
        .retrieveVehiclesForUser("1234", "appId", "F", httpRequest, httpResponse);
    //THEN
    Assert.assertEquals(ResponseCodes.APP_CODE_NOT_IN_NUMBER_FORMAT.getHttpStatus(),
        response.getHttpStatus());
  }

  /**
   * To validate required field missing
   */
  @Test
  public void validate_throwRequiredFieldsMissing() {
    //GIVEN
    HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpResponse = Mockito.mock(HttpServletResponse.class);
    Mockito.when(responseBuilder.generateResponse(ResponseCodes.INVALID_REQUEST_URL))
        .thenReturn(new GenericResponse(ResponseCodes.INVALID_REQUEST_URL.getHttpStatus(),
            ResponseCodes.INVALID_REQUEST_URL.getResponseMessage()));
    //WHEN
    GenericResponse response = retrieveVehicleController
        .throwRequiredFieldsMissing(httpRequest, httpResponse);
    //THEN
    Assert.assertEquals(ResponseCodes.INVALID_REQUEST_URL.getHttpStatus(),
        response.getHttpStatus());
  }

  /**
   * To validate required field missing for capUserId
   */
  @Test
  public void throwRequiredFieldsMissingForCapUserID() {
    //GIVEN
    HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpResponse = Mockito.mock(HttpServletResponse.class);
    Mockito.when(responseBuilder.generateResponse(ResponseCodes.INVALID_REQUEST_URL))
        .thenReturn(new GenericResponse(ResponseCodes.INVALID_REQUEST_URL.getHttpStatus(),
            ResponseCodes.INVALID_REQUEST_URL.getResponseMessage()));
    //WHEN
    GenericResponse response = retrieveVehicleController
        .throwRequiredFieldsMissingForCapUserID("123", httpRequest, httpResponse);
    //THEN
    Assert.assertEquals(ResponseCodes.INVALID_REQUEST_URL.getHttpStatus(),
        response.getHttpStatus());
  }
}
