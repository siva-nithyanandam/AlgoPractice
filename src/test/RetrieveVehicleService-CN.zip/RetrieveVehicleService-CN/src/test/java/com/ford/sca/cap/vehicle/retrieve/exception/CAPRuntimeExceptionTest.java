package com.ford.sca.cap.vehicle.retrieve.exception;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CAPRuntimeExceptionTest {

  @Test
  public void test_instance() {
    CAPRuntimeException capRuntimeException = new CAPRuntimeException("sample",
        new NullPointerException("test"));
    Assert.assertEquals("sample", capRuntimeException.getMessage());
    Assert.assertTrue(capRuntimeException.getCause() instanceof NullPointerException);
  }
}
