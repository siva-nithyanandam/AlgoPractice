package com.ford.sca.cap.vehicle.retrieve.service.statics;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.CNMobileWebOther;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.NaMobileWebOther;
import java.util.Locale;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BrandCodeTest {


  @InjectMocks
  CNMobileWebOther CNMobileWebOtherService;

  @InjectMocks
  NaMobileWebOther NAMobileWebOtherService;


  @Test
  public void testFordBrandCodeWhenInputsAreInvalid() {
    Map<String, String> brandCodeMapChina = CNMobileWebOtherService.getBrandCodeMap();
    boolean testChina1 = BrandCode.checkMatchBrandCodeWithMake(null, "Ford", brandCodeMapChina,
        Locale.US);
    boolean testChina2 = BrandCode.checkMatchBrandCodeWithMake("F", null, brandCodeMapChina,
        Locale.US);
    boolean testChina3 = BrandCode.checkMatchBrandCodeWithMake("FORD", "", brandCodeMapChina,
        Locale.US);

    assertFalse(testChina1 && testChina2 && testChina3);
  }

  @Test
  public void testFordBrandCode() {
    Map<String, String> brandCodeMapChina = CNMobileWebOtherService.getBrandCodeMap();
    boolean testChina1 = BrandCode.checkMatchBrandCodeWithMake("100380", "Ford", brandCodeMapChina,
        Locale.US);
    boolean testChina2 = BrandCode.checkMatchBrandCodeWithMake("F", "Ford", brandCodeMapChina,
        Locale.US);
    boolean testChina3 = BrandCode.checkMatchBrandCodeWithMake("FORD", "Ford", brandCodeMapChina,
        Locale.US);

    Map<String, String> brandCodeMapNA = NAMobileWebOtherService.getBrandCodeMap();
    boolean testNA1 = BrandCode.checkMatchBrandCodeWithMake("100380", "Ford", brandCodeMapNA,
        Locale.US);
    boolean testNA2 = BrandCode.checkMatchBrandCodeWithMake("F", "Ford", brandCodeMapNA, Locale.US);
    boolean testNA3 = BrandCode.checkMatchBrandCodeWithMake("FORD", "Ford", brandCodeMapNA,
        Locale.US);

    assertTrue(testChina1 && testChina2 && testChina3 && testNA1 && testNA2 && testNA3);

  }

  @Test
  public void testLincoldBrandCode() {
    Map<String, String> brandCodeMapChina = CNMobileWebOtherService.getBrandCodeMap();
    boolean testChina1 = BrandCode
        .checkMatchBrandCodeWithMake("100376", "Lincoln", brandCodeMapChina, Locale.US);
    boolean testChina2 = BrandCode.checkMatchBrandCodeWithMake("L", "Lincoln", brandCodeMapChina,
        Locale.US);
    boolean testChina3 = BrandCode
        .checkMatchBrandCodeWithMake("LINCOLN", "Lincoln", brandCodeMapChina, Locale.US);

    Map<String, String> brandCodeMapNA = NAMobileWebOtherService.getBrandCodeMap();
    boolean testNA1 = BrandCode.checkMatchBrandCodeWithMake("100376", "Lincoln", brandCodeMapNA,
        Locale.US);
    boolean testNA2 = BrandCode.checkMatchBrandCodeWithMake("L", "Lincoln", brandCodeMapNA,
        Locale.US);
    boolean testNA3 = BrandCode.checkMatchBrandCodeWithMake("LINCOLN", "Lincoln", brandCodeMapNA,
        Locale.US);

    assertTrue(testChina1 && testChina2 && testChina3 && testNA1 && testNA2 && testNA3);
  }

  @Test
  public void testMercuryBrandCode() {

    Map<String, String> brandCodeMapChina = CNMobileWebOtherService.getBrandCodeMap();
    boolean testChina1 = BrandCode
        .checkMatchBrandCodeWithMake("100377", "Mercury", brandCodeMapChina, Locale.US);
    boolean testChina2 = BrandCode.checkMatchBrandCodeWithMake("M", "Mercury", brandCodeMapChina,
        Locale.US);
    boolean testChina3 = BrandCode
        .checkMatchBrandCodeWithMake("MERCURY", "Mercury", brandCodeMapChina, Locale.US);

    Map<String, String> brandCodeMapNA = NAMobileWebOtherService.getBrandCodeMap();
    boolean testNA1 = BrandCode.checkMatchBrandCodeWithMake("100377", "Mercury", brandCodeMapNA,
        Locale.US);
    boolean testNA2 = BrandCode.checkMatchBrandCodeWithMake("M", "Mercury", brandCodeMapNA,
        Locale.US);
    boolean testNA3 = BrandCode.checkMatchBrandCodeWithMake("MERCURY", "Mercury", brandCodeMapNA,
        Locale.US);

    assertTrue(testChina1 && testChina2 && testChina3 && testNA1 && testNA2 && testNA3);
  }

  @Test
  public void testInvalidBrandCode() {
    Map<String, String> brandCodeMapChina = CNMobileWebOtherService.getBrandCodeMap();
    boolean testChina1 = BrandCode
        .checkMatchBrandCodeWithMake("9999999", "Ford", brandCodeMapChina, Locale.US);
    boolean testChina2 = BrandCode.checkMatchBrandCodeWithMake("MDR", "Lincoln", brandCodeMapChina,
        Locale.US);
    boolean testChina3 = BrandCode
        .checkMatchBrandCodeWithMake("ABCDEF", "Mercury", brandCodeMapChina, Locale.US);
    boolean testChina4 = BrandCode.checkMatchBrandCodeWithMake("M", "dsjhdsfjh", brandCodeMapChina,
        Locale.US);

    Map<String, String> brandCodeMapNA = NAMobileWebOtherService.getBrandCodeMap();
    boolean testNA1 = BrandCode.checkMatchBrandCodeWithMake("9999999", "Ford", brandCodeMapNA,
        Locale.US);
    boolean testNA2 = BrandCode.checkMatchBrandCodeWithMake("MDR", "Lincoln", brandCodeMapNA,
        Locale.US);
    boolean testNA3 = BrandCode.checkMatchBrandCodeWithMake("ABCDEF", "Mercury", brandCodeMapNA,
        Locale.US);
    boolean testNA4 = BrandCode.checkMatchBrandCodeWithMake("M", "asdas", brandCodeMapNA, Locale.US);

    assertFalse(
        testChina1 || testChina2 || testChina3 || testChina4 || testNA1 || testNA2 || testNA3
            || testNA4);
  }

  @Test
  public void testMakeNotMatchWithBrandCode() {
    Map<String, String> brandCodeMapChina = CNMobileWebOtherService.getBrandCodeMap();
    boolean testChina1 = BrandCode.checkMatchBrandCodeWithMake("100377", "Ford", brandCodeMapChina,
        Locale.US);
    boolean testChina2 = BrandCode.checkMatchBrandCodeWithMake("M", "Ford", brandCodeMapChina,
        Locale.US);
    boolean testChina3 = BrandCode
        .checkMatchBrandCodeWithMake("Lincoln", "Ford", brandCodeMapChina, Locale.US);

    Map<String, String> brandCodeMapNA = NAMobileWebOtherService.getBrandCodeMap();
    boolean testNA1 = BrandCode.checkMatchBrandCodeWithMake("100377", "Ford", brandCodeMapNA,
        Locale.US);
    boolean testNA2 = BrandCode.checkMatchBrandCodeWithMake("M", "Ford", brandCodeMapNA, Locale.US);
    boolean testNA3 = BrandCode.checkMatchBrandCodeWithMake("Lincoln", "Ford", brandCodeMapNA,
        Locale.US);

    assertFalse(testChina1 || testChina2 || testChina3 || testNA1 || testNA2 || testNA3);
  }

  @Test
  public void testBrandCodeExist() {
    //WHEN and THEN
    Assert.assertTrue(BrandCode.isBrandCodeExist(NAMobileWebOtherService, "F"));
  }

  @Test
  public void testBrandCodeNotExist() {
    //WHEN and THEN
    Assert.assertFalse(BrandCode.isBrandCodeExist(NAMobileWebOtherService, "ABCD"));
  }

}