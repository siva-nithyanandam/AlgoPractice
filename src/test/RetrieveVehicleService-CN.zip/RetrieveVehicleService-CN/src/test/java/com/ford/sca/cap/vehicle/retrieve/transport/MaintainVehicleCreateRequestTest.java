package com.ford.sca.cap.vehicle.retrieve.transport;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MaintainVehicleCreateRequestTest {

  @Spy
  private MaintainVehicleCreateRequest request;

  @Test
  public void test_all_the_fields() {

    request.setVehicle(new Vehicle());
    Assert.assertNotNull(request.getVehicle());
  }
}
