package com.ford.sca.cap.vehicle.retrieve.transport;

import java.util.Date;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MessageHeadersTest {

  @Spy
  private MessageHeaders messageHeaders;

  @Test
  public void test_all_the_fields() {

    messageHeaders.setAppId(1);
    messageHeaders.setCallingServiceName("");
    messageHeaders.setEvenRequestTimeStamp(new Date());
    messageHeaders.setEventInitiatorName("");
    messageHeaders.setEventName("");
    messageHeaders.setEventType("");
    messageHeaders.setGuid("");
    messageHeaders.setCorrelationId("");

    Assert.assertNotNull(messageHeaders.getAppId());
    Assert.assertNotNull(messageHeaders.getCallingServiceName());
    Assert.assertNotNull(messageHeaders.getEvenRequestTimeStamp());
    Assert.assertNotNull(messageHeaders.getEventInitiatorName());
    Assert.assertNotNull(messageHeaders.getEventName());
    Assert.assertNotNull(messageHeaders.getEventType());
    Assert.assertNotNull(messageHeaders.getGuid());
    Assert.assertNotNull(messageHeaders.getCorrelationId());
  }
}
