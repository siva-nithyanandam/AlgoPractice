package com.ford.sca.cap.vehicle.retrieve.service.statics;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;


@RunWith(MockitoJUnitRunner.Silent.class)
public class ConsumerTypeTest {

  @Test
  public void consumerTypePersonTest() {
    ConsumerType p = ConsumerType.PERSON;

    boolean test1 = p.getType().equals("P");
    boolean test2 = p.getDesc().equals("Person");
    assertTrue(test1 && test2);
  }

  @Test
  public void consumerTypeOrganizationTest() {
    ConsumerType o = ConsumerType.ORGANISATION;

    boolean test1 = o.getType().equals("O");
    boolean test2 = o.getDesc().equals("Organisation");
    assertTrue(test1 && test2);
  }


}
