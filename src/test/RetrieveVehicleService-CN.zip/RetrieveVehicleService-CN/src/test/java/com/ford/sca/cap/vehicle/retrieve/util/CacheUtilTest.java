package com.ford.sca.cap.vehicle.retrieve.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.ford.sca.cap.domain.AppCodeBO;
import com.ford.sca.cap.domain.CountryCodeBO;
import com.ford.sca.cap.domain.MessageLangServiceViewBO;
import com.ford.sca.cap.vehicle.retrieve.repository.AppCodeRepository;
import com.ford.sca.cap.vehicle.retrieve.repository.CountryCodeRepository;
import com.ford.sca.cap.vehicle.retrieve.repository.MessageLangServiceViewRepository;
import java.util.Optional;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CacheUtilTest {

  @InjectMocks
  private CacheUtil cacheUtil;

  @Mock
  private MessageLangServiceViewRepository messageLangServiceViewRepository;

  @Mock
  private CountryCodeRepository countryCodeRepository;

  @Mock
  private AppCodeRepository appCodeRepository;

  @Test
  public void TestGetErrorMessageBadMessageId() {
    String errorId = "56XX89QQ_!";
    when(messageLangServiceViewRepository.findById(errorId)).thenReturn(Optional.empty());
    String messageDesc = cacheUtil.getErrorMessage(errorId);
    assertNull(messageDesc);
  }

  @Test
  public void TestGetErrorMessageGoodMessageId() {
    String errorId = "MSG-0003";
    String errorDesc = "CAPUserID does not exist in CAP";
    MessageLangServiceViewBO messageBo = new MessageLangServiceViewBO();
    messageBo.setMessageCode(errorId);
    messageBo.setMessageDesc(errorDesc);
    when(messageLangServiceViewRepository.findById(errorId)).thenReturn(Optional.of(messageBo));
    String messageDesc = cacheUtil.getErrorMessage(errorId);
    assertEquals(errorDesc, messageDesc);
  }


  @Test
  public void test_get_country_code3_exists() {
    String countryCode = "USA";
    CountryCodeBO countryCodeBo = new CountryCodeBO();
    countryCodeBo.setIso3CodeCountry(countryCode);
    when(countryCodeRepository.findByIso3CodeCountry(countryCode)).thenReturn(countryCodeBo);
    CountryCodeBO retrievedCountryCodeBo = cacheUtil.getCountryCodeByISO3(countryCode);
    assertNotNull(retrievedCountryCodeBo);
    assertEquals(countryCode, retrievedCountryCodeBo.getIso3CodeCountry());
  }

  @Test
  public void test_get_country_code_not_exist() {
    String countryCode = "XXX";
    when(countryCodeRepository.findByIso3CodeCountry(countryCode)).thenReturn(null);
    CountryCodeBO retrievedCountryCodeBo = cacheUtil.getCountryCodeByISO3(countryCode);
    assertNull(retrievedCountryCodeBo);
  }

  /**
   * TO check app code details successfully retrieved.
   */
  @Test
  public void test_getting_appCodeDetails_Success() {
    //GIVEN
    when(appCodeRepository.findByAppIdAndActiveFlag(Mockito.anyInt(), anyString()))
        .thenReturn(new AppCodeBO());

    //WHEN
    AppCodeBO appCodeBO = cacheUtil.getAppCodeDtls(Integer.valueOf(100504));

    //THEN
    Assert.assertNotNull(appCodeBO);
  }


  @Test
  public void test_get_country_code2_exists() {
    String countryCode = "US";
    CountryCodeBO countryCodeBo = new CountryCodeBO();
    countryCodeBo.setIso2CodeCountry(countryCode);
    when(countryCodeRepository.findByIso2CodeCountry(countryCode)).thenReturn(countryCodeBo);
    CountryCodeBO retrievedCountryCodeBo = cacheUtil.getCountryCodeByISO2(countryCode);
    assertNotNull(retrievedCountryCodeBo);
    assertEquals(countryCode, retrievedCountryCodeBo.getIso2CodeCountry());
  }

  @Test
  public void test_get_country_code2_not_exists() {
    String countryCode = "US";
    when(countryCodeRepository.findByIso2CodeCountry(countryCode)).thenReturn(null);
    CountryCodeBO retrievedCountryCodeBo = cacheUtil.getCountryCodeByISO2(countryCode);
    assertNull(retrievedCountryCodeBo);
  }
}
