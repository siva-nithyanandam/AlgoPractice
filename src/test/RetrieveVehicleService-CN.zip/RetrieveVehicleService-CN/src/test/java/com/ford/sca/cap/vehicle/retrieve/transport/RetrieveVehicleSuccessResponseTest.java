package com.ford.sca.cap.vehicle.retrieve.transport;

import java.util.ArrayList;
import java.util.Date;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RetrieveVehicleSuccessResponseTest {

  @Spy
  private RetrieveVehicleSuccessResponse response;

  @Test
  public void test_all_the_fields() {

    response.setUserVehicleList(new ArrayList<>());

    Assert.assertNotNull(response.getUserVehicleList());
  }
}
