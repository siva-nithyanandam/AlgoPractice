package com.ford.sca.cap.vehicle.retrieve.transport;

import com.ford.sca.cap.vehicle.retrieve.domain.UserAccountBO;
import com.ford.sca.cap.vehicle.retrieve.domain.UserAccountPK;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ApiParamsTest {

  @Spy
  private ApiParams apiParams;

  @Test
  public void test_all_the_fields() {

    apiParams.setTenantId(1);
    apiParams.setAppId("100504");
    apiParams.setVinCode("1FDFDFSFS");
    apiParams.setBrandCode("F");
    apiParams.setCountryCode("US");
    apiParams.setUserId("SD232-23ASDS");

    Assert.assertNotNull(apiParams.getTenantId());
    Assert.assertNotNull(apiParams.getAppId());
    Assert.assertNotNull(apiParams.getVinCode());
    Assert.assertNotNull(apiParams.getBrandCode());
    Assert.assertNotNull(apiParams.getCountryCode());
    Assert.assertNotNull(apiParams.getUserId());
  }
}
