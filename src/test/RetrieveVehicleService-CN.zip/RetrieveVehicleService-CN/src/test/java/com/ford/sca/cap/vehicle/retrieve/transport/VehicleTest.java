package com.ford.sca.cap.vehicle.retrieve.transport;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class VehicleTest {

  @Spy
  private Vehicle vehicle;

  @Test
  public void test_all_the_fields() {

    vehicle.setVersionDescription("");
    vehicle.setColor("");
    vehicle.setCylinders(1);
    vehicle.setDrivetrain("");
    vehicle.setEngineDisp("");
    vehicle.setFuel("");
    vehicle.setMake("");
    vehicle.setColor("");
    vehicle.setModelName("");
    vehicle.setModelSeries("");
    vehicle.setModelTyp("");
    vehicle.setModelYear("");
    vehicle.setSparkPlug(1);
    vehicle.setTransmissionTyp("");
    vehicle.setVin("");

    Assert.assertNotNull(vehicle.getVersionDescription());
    Assert.assertNotNull(vehicle.getColor());
    Assert.assertNotNull(vehicle.getCylinders());
    Assert.assertNotNull(vehicle.getDrivetrain());
    Assert.assertNotNull(vehicle.getEngineDisp());
    Assert.assertNotNull(vehicle.getFuel());
    Assert.assertNotNull(vehicle.getMake());
    Assert.assertNotNull(vehicle.getColor());
    Assert.assertNotNull(vehicle.getModelName());
    Assert.assertNotNull(vehicle.getModelSeries());
    Assert.assertNotNull(vehicle.getModelTyp());
    Assert.assertNotNull(vehicle.getModelYear());
    Assert.assertNotNull(vehicle.getSparkPlug());
    Assert.assertNotNull(vehicle.getTransmissionTyp());
    Assert.assertNotNull(vehicle.getVin());
  }
}
