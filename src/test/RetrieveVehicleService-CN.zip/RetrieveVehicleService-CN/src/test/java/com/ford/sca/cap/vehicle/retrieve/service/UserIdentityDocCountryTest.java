package com.ford.sca.cap.vehicle.retrieve.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserIdentityDocCountryTest {

  /**
   * To check given country is available
   */
  @Test
  public void ensure_given_country_is_available() {
    //WHEN & THEN
    Assert.assertTrue(UserIdentityDocCountry.isThisCountryAvailable("BRA"));
  }

  /**
   * To check given country is not available
   */
  @Test
  public void ensure_given_country_is_not_available() {
    //WHEN & THEN
    Assert.assertFalse(UserIdentityDocCountry.isThisCountryAvailable("IND"));
  }

  /**
   * To check given country is not available wrt CASE
   */
  @Test
  public void ensure_given_country_is_not_available_wrt_case() {
    //WHEN & THEN
    Assert.assertFalse(UserIdentityDocCountry.isThisCountryAvailable("bra"));
  }

  @Test
  public void ensure_given_null_country_is_not_available() {
    boolean test = UserIdentityDocCountry.isThisCountryNotAvailable(null);
    Assert.assertTrue(test);
  }

  @Test
  public void isThisCountryNotAvailableForAvailableCountryTest() {
    boolean test = UserIdentityDocCountry.isThisCountryNotAvailable("BRA");
    Assert.assertTrue(!test);
  }
}
