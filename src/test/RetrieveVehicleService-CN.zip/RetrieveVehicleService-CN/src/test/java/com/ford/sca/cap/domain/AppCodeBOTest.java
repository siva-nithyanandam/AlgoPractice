package com.ford.sca.cap.domain;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AppCodeBOTest {

  @Spy
  private AppCodeBO appCodeBO;

  @Test
  public void test_all_the_fields() {
    appCodeBO.setValidationGrpCode("MOBILE_NA");
    appCodeBO.setActiveFlag("F");
    appCodeBO.setAppId(100432);
    appCodeBO.setAppName("Test");
    appCodeBO.setLanguage("EN");
    appCodeBO.setPswdChngFlag("Y");
    appCodeBO.setTenantId(1);

    Assert.assertNotNull(appCodeBO.getValidationGrpCode());
    Assert.assertNotNull(appCodeBO.getActiveFlag());
    Assert.assertNotNull(appCodeBO.getAppId());
    Assert.assertNotNull(appCodeBO.getAppName());
    Assert.assertNotNull(appCodeBO.getLanguage());
    Assert.assertNotNull(appCodeBO.getPswdChngFlag());
    Assert.assertNotNull(appCodeBO.getTenantId());
  }
}
