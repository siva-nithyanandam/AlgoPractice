package com.ford.sca.cap.vehicle.retrieve.controller;

import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.AuditActivityUtil;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

@RunWith(MockitoJUnitRunner.Silent.class)
public class GlobalExceptionHandlerTest {

  @InjectMocks
  private GlobalExceptionHandler globalExceptionHandler;

  @Mock
  private AuditActivityUtil auditActivityUtil;

  @Mock
  private ResponseBuilder responseBuilder;

  @Test
  public void validate_handleIllegalMethodArgument() {
    //GIVEN
    HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpResponse = Mockito.mock(HttpServletResponse.class);
    Mockito.when(responseBuilder.generateResponse(ResponseCodes.VALUE_EXCEEDS_MAX_LENGTH))
        .thenReturn(new GenericResponse(ResponseCodes.VALUE_EXCEEDS_MAX_LENGTH.getHttpStatus(),
            ResponseCodes.VALUE_EXCEEDS_MAX_LENGTH.getResponseMessage()));
    MDC.setContextMap(new HashMap<>());
    //WHEN
    GenericResponse response = globalExceptionHandler
        .handleIllegalMethodArgument(httpRequest, httpResponse, new Exception());
    //THEN
    Assert.assertEquals(ResponseCodes.VALUE_EXCEEDS_MAX_LENGTH.getHttpStatus(),
        response.getHttpStatus());
  }

  @Test
  public void validate_httpMessageNotReadableException() {
    //GIVEN
    HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpResponse = Mockito.mock(HttpServletResponse.class);
    Mockito.when(responseBuilder.generateResponse(ResponseCodes.BINDING_ERROR))
        .thenReturn(new GenericResponse(ResponseCodes.BINDING_ERROR.getHttpStatus(),
            ResponseCodes.BINDING_ERROR.getResponseMessage()));
    MDC.setContextMap(new HashMap<>());
    //WHEN
    GenericResponse response = globalExceptionHandler
        .httpMessageNotReadableException(httpRequest, httpResponse, new Exception());
    //THEN
    Assert.assertEquals(ResponseCodes.BINDING_ERROR.getHttpStatus(),
        response.getHttpStatus());
  }

  @Test
  public void validate_handlemissingServletRequestParameterException() {
    //GIVEN
    HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpResponse = Mockito.mock(HttpServletResponse.class);
    Mockito.when(responseBuilder.generateResponse(ResponseCodes.APPID_CAPUSERID_VIN_NOT_AVAILABLE))
        .thenReturn(
            new GenericResponse(ResponseCodes.APPID_CAPUSERID_VIN_NOT_AVAILABLE.getHttpStatus(),
                ResponseCodes.APPID_CAPUSERID_VIN_NOT_AVAILABLE.getResponseMessage()));
    MDC.setContextMap(new HashMap<>());
    //WHEN
    GenericResponse response = globalExceptionHandler
        .handlemissingServletRequestParameterException(httpRequest, httpResponse, new Exception());
    //THEN
    Assert.assertEquals(ResponseCodes.APPID_CAPUSERID_VIN_NOT_AVAILABLE.getHttpStatus(),
        response.getHttpStatus());
  }
}
