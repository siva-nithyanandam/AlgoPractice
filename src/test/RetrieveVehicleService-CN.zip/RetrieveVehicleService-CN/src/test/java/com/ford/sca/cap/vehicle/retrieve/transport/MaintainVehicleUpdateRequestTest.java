package com.ford.sca.cap.vehicle.retrieve.transport;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MaintainVehicleUpdateRequestTest {

  @Spy
  private MaintainVehicleUpdateRequest request;

  @Test
  public void test_all_the_fields() {

    request.setBrandCode("");
    request.setReturnOutput("");
    request.setVehicleAttributes(new RequestVehicleAttributes());

    Assert.assertNotNull(request.getBrandCode());
    Assert.assertNotNull(request.getReturnOutput());
    Assert.assertNotNull(request.getVehicleAttributes());
  }
}
