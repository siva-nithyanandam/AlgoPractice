package com.ford.sca.cap.vehicle.retrieve.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.cap.vehicle.retrieve.messaging.RabbitMqSender;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.servlet.HandlerMapping;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AuditActivityUtilTest {

  @InjectMocks
  private AuditActivityUtil auditActivityUtil;

  @Mock
  private ObjectMapper objectMapper;

  @Mock
  private RabbitMqSender rabbitMqSender;

  /**
   * To validate publishing audit request - success
   */
  @Test
  public void validate_audit_request_success() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";

    HttpServletRequest request = new MockHttpServletRequest();
    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setBrandCode("F");

    Map<String, String> webThreadContext = new HashMap<>();
    MDC.setContextMap(webThreadContext);
    try {
      Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("sample");
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }

    //WHEN
    auditActivityUtil.publishAuditMessage_request(request, apiParams);

    //THEN
    //Wait for 1 secs as setting attribute been done by sub-thread
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      Assert.fail(e.getMessage());
    }
    Mockito.verify(rabbitMqSender, Mockito.times(1))
        .send(Mockito.any(), Mockito.any());
  }

  /**
   * To validate publishing audit response - success
   */
  @Test
  public void validate_audit_response_success() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";

    HttpServletRequest request = new MockHttpServletRequest();
    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setBrandCode("F");
    GenericResponse response = new GenericResponse(
        ResponseCodes.SUCCESS.getHttpStatus(), ResponseCodes.SUCCESS.getResponseMessage());
    Map<String, String> webThreadContext = new HashMap<>();
    MDC.setContextMap(webThreadContext);
    try {
      Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("sample");
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }
    //WHEN
    auditActivityUtil.publishAuditMessage_response(request, response, apiParams);

    //THEN
    //Wait for 1 secs as setting attribute been done by sub-thread
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      Assert.fail(e.getMessage());
    }
    Mockito.verify(rabbitMqSender, Mockito.times(1))
        .send(Mockito.any(), Mockito.any());
  }

  /*@Test
  public void testCreateAuditServiceRequest() {
    //GIVEN
    ApiParams apiParams = new ApiParams();
    HttpServletRequest mockedHttpServletRequest = Mockito.mock(HttpServletRequest.class);
    MDC.setContextMap(new HashMap<>());
    //WHEN
    AuditServiceRequest auditServiceRequest = auditActivityUtil
        .createAuditServiceRequest(mockedHttpServletRequest, apiParams);

    //THEN
    Assert.assertNotNull(auditServiceRequest);
  }*/

  /*@Test
  public void testCreateAuditServiceResponse() {
    //GIVEN
    ApiParams apiParams = new ApiParams();
    HttpServletRequest mockedHttpServletRequest = Mockito.mock(HttpServletRequest.class);
    MDC.setContextMap(new HashMap<>());
    GenericResponse response = new GenericResponse(
        ResponseCodes.SUCCESS.getHttpStatus(), ResponseCodes.SUCCESS.getResponseMessage());
    try {
      Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("Sample");
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }
    //WHEN
    AuditServiceRequest auditServiceRequest = auditActivityUtil
        .createAuditServiceResponse(mockedHttpServletRequest, response, apiParams);

    //THEN
    Assert.assertNotNull(auditServiceRequest);
    Assert.assertNotNull(auditServiceRequest.getJsonBody());
  }*/

  /*@Test
  public void testCreateAuditServiceResponse_failure() {
    //GIVEN
    ApiParams apiParams = new ApiParams();
    HttpServletRequest mockedHttpServletRequest = Mockito.mock(HttpServletRequest.class);
    MDC.setContextMap(new HashMap<>());
    GenericResponse response = new GenericResponse(
        ResponseCodes.SUCCESS.getHttpStatus(), ResponseCodes.SUCCESS.getResponseMessage());
    try {
      Mockito.when(objectMapper.writeValueAsString(Mockito.any()))
          .thenThrow(JsonProcessingException.class);
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }
    //WHEN
    AuditServiceRequest auditServiceRequest = auditActivityUtil
        .createAuditServiceResponse(mockedHttpServletRequest, response, apiParams);

    //THEN
    Assert.assertNotNull(auditServiceRequest);
    Assert.assertNull(auditServiceRequest.getJsonBody());
  }*/

/*  *//**
   * To test publish audit message throwing json parsing exception
   *//*
  @Test
  public void testPublishAuditMessage_failure() {
    //GIVEN
    AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
    auditServiceRequest.setJsonType("Sample");
    try {
      Mockito.when(objectMapper.writeValueAsString(Mockito.any()))
          .thenThrow(JsonProcessingException.class);
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }
    //WHEN
    auditActivityUtil.publishAuditMessage(auditServiceRequest);

    //THEN
    Mockito.verify(rabbitMqSender, Mockito.times(0))
        .send(Mockito.any(), Mockito.any());
  }

  *//**
   * To test publish audit message throwing some generic exception
   *//*
  @Test
  public void testPublishAuditMessage_failure2() {
    //GIVEN
    AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
    auditServiceRequest.setJsonType("Sample");
    try {
      Mockito.when(objectMapper.writeValueAsString(Mockito.any()))
          .thenThrow(NullPointerException.class);
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }
    //WHEN
    auditActivityUtil.publishAuditMessage(auditServiceRequest);

    //THEN
    Mockito.verify(rabbitMqSender, Mockito.times(0))
        .send(Mockito.any(), Mockito.any());
  }*/

  @Test
  public void testStoreRequestHeaderAttributes_withoutCorrelationId() {
    //GIVEN
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    //WHEN
    auditActivityUtil.storeRequestHeaderAttributes(httpServletRequest);
    //THEN
    Assert.assertNotNull(MDC.getCopyOfContextMap());
  }

  @Test
  public void testStoreRequestHeaderAttributes_withDataCenter() {
    //GIVEN
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    try {
      Field dataCenterField = auditActivityUtil.getClass().getDeclaredField("dataCenter");
      dataCenterField.setAccessible(true);
      dataCenterField.set(auditActivityUtil, "sample");
    } catch (NoSuchFieldException e) {
      Assert.fail(e.getMessage());
    } catch (IllegalAccessException e) {
      Assert.fail(e.getMessage());
    }
    //WHEN
    auditActivityUtil.storeRequestHeaderAttributes(httpServletRequest);
    //THEN
    Assert.assertNotNull(MDC.getCopyOfContextMap());
  }
  
  @Test
  public void testStoreRequestHeaderAttributes_withDataCenterLength2() {
    //GIVEN
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    try {
      Field dataCenterField = auditActivityUtil.getClass().getDeclaredField("dataCenter");
      dataCenterField.setAccessible(true);
      dataCenterField.set(auditActivityUtil, "sa");
    } catch (NoSuchFieldException e) {
      Assert.fail(e.getMessage());
    } catch (IllegalAccessException e) {
      Assert.fail(e.getMessage());
    }
    //WHEN
    auditActivityUtil.storeRequestHeaderAttributes(httpServletRequest);
    //THEN
    Assert.assertNotNull(MDC.getCopyOfContextMap());
  }

  @Test
  public void testStoreRequestHeaderAttributes_withCorrelationId() {
    //GIVEN
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    Mockito.when(httpServletRequest.getHeader(Constants.CORRELATION_ID_HEADER_NAME))
        .thenReturn("sample");
    //WHEN
    auditActivityUtil.storeRequestHeaderAttributes(httpServletRequest);
    //THEN
    Assert.assertNotNull(MDC.getCopyOfContextMap());
  }

  @Test
  public void testSettingResponseHeaderAttributes() {
    //GIVEN
    HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
    MDC.setContextMap(new HashMap<>());
    //WHEN
    auditActivityUtil.setResponseHeaderAttributes(httpServletResponse);
    //THEN
    Mockito.verify(httpServletResponse, Mockito.times(3))
        .setHeader(Mockito.anyString(), Mockito.any());
  }

  @Test
  public void testConstructAuditServiceResponseAndPublish_with_jsonbody_success() {
    //GIVEN
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
    GenericResponse response = new GenericResponse(HttpStatus.OK, "Success");
    MDC.setContextMap(new HashMap<>());
    try {
      Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("Sample");
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }
    // WHEN
    auditActivityUtil.constructAuditServiceResponseAndPublish(httpServletRequest,
        httpServletResponse, response);
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      Assert.fail(e.getMessage());
    }
    // THEN
    Mockito.verify(rabbitMqSender, Mockito.times(2)).send(Mockito.any(), Mockito.any());
  }

  @Test
  public void testConstructAuditServiceResponseAndPublish_without_jsonbody_success() {
    //GIVEN
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
    GenericResponse response = new GenericResponse(HttpStatus.OK, "Success");
    MDC.setContextMap(new HashMap<>());
    try {
      Mockito.when(objectMapper.writeValueAsString(Mockito.any()))
          .thenThrow(JsonProcessingException.class);
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }
    //WHEN
    auditActivityUtil
        .constructAuditServiceResponseAndPublish(httpServletRequest, httpServletResponse, response);
    //THEN
    Mockito.verify(rabbitMqSender, Mockito.times(0))
        .send(Mockito.any(), Mockito.any());
  }

  @Test
  public void testConstructAuditServiceResponseAndPublish_with_pathvariable() {
    //GIVEN
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
    GenericResponse response = new GenericResponse(HttpStatus.OK, "Success");
    MDC.setContextMap(new HashMap<>());
    Mockito.when(httpServletRequest.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE))
        .thenReturn(new HashMap<>());
    try {
      Mockito.when(objectMapper.writeValueAsString(Mockito.any()))
          .thenThrow(JsonProcessingException.class);
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }
    //WHEN
    auditActivityUtil
        .constructAuditServiceResponseAndPublish(httpServletRequest, httpServletResponse, response);
    //THEN
    Mockito.verify(rabbitMqSender, Mockito.times(0))
        .send(Mockito.any(), Mockito.any());
  }
}
