package com.ford.sca.cap.vehicle.retrieve.validators;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyFloat;
import static org.mockito.Mockito.when;

import com.ford.sca.cap.vehicle.retrieve.domain.UserAccountPK;
import com.ford.sca.cap.vehicle.retrieve.repository.UserAccountRepository;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import java.util.Date;
import java.util.concurrent.Future;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.dao.InvalidDataAccessResourceUsageException;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CapUserIdManagerTest {

  @InjectMocks
  private CapUserIdManager capUserIdManager;

  @Mock
  private ResponseBuilder responseBuilderService;

  @Mock
  private UserAccountRepository userAccountRepository;

  /**
   * To assert the reaction of CAPUserIdManager when valid CAPUserId provided in the request -
   * Create Vehicle.
   */
  @Test
  public void testRetrieveVehicle_validCAPUserId() {
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";
    Integer tenantId = 1;
    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setTenantId(tenantId);

    when(userAccountRepository.existsById(any())).thenReturn(true);
    Future<GenericResponse> response =
        capUserIdManager.checkAndConstruct(apiParams, null, null);
    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNull(genericResponse);

    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * TO test when given capUserId is empty.
   */
  @Test
  public void testRetrieveVehicle_CAPUserIdIsEmpty() {
    ApiParams apiParams = new ApiParams();
    when(responseBuilderService.generateResponse(ResponseCodes.CAP_USER_ID_NOT_FOUND_IN_REQ))
        .thenReturn(
            new GenericResponse(ResponseCodes.CAP_USER_ID_NOT_FOUND_IN_REQ.getHttpStatus(), "",
                ResponseCodes.CAP_USER_ID_NOT_FOUND_IN_REQ.getMsgId(), "", new Date()));
    Future<GenericResponse> response =
        capUserIdManager.checkAndConstruct(apiParams, null, null);

    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNotNull(genericResponse);
      Assert.assertEquals(ResponseCodes.CAP_USER_ID_NOT_FOUND_IN_REQ.getHttpStatus(),
          genericResponse.getHttpStatus());
      Assert.assertEquals(ResponseCodes.CAP_USER_ID_NOT_FOUND_IN_REQ.getMsgId(),
          genericResponse.getErrorMsgId());
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * To assert the reaction of CAPUserIdManager when CAPUserId doesn't exist in CAP.
   */
  @Test
  public void testRetrieveVehicle_CAPUserIdDoesNotExitInCAP() {
    String appId = "100504";
    String invalidCAPUserId = "53BAF089-B770-4553-B02E-Inv";
    Integer tenantId = 1;
    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(invalidCAPUserId);
    apiParams.setTenantId(tenantId);

    when(userAccountRepository.existsById(any()))
        .thenReturn(false);
    when(responseBuilderService.generateResponse(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP))
        .thenReturn(
            new GenericResponse(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.getHttpStatus(), "",
                ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.getMsgId(), "", new Date()));
    Future<GenericResponse> response =
        capUserIdManager.checkAndConstruct(apiParams, null, null);

    validateCapUserIdNotInDB(response);
  }

  /**
   * To assert the reaction of CAPUserIdManager when DB throws an error.
   */
  @Test
  public void testRetrieveVehicle_dbError() {
    String appId = "100504";
    String invalidCAPUserId = "53BAF089-B770-4553-B02E-Inv";
    Integer tenantId = 1;
    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(invalidCAPUserId);
    apiParams.setTenantId(tenantId);

    when(userAccountRepository.existsById(any()))
        .thenThrow(InvalidDataAccessResourceUsageException.class);
    when(responseBuilderService.generateResponse(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP))
        .thenReturn(
            new GenericResponse(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.getHttpStatus(), "",
                ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.getMsgId(), "", new Date()));
    Future<GenericResponse> response =
        capUserIdManager.checkAndConstruct(apiParams, null, null);

    validateCapUserIdNotInDB(response);
  }

  /**
   * To assert the reaction of CAPUserIdManager when DB throws an error.
   */
  @Test
  public void testRetrieveVehicle_dbError1() {
    String appId = "100504";
    String invalidCAPUserId = "53BAF089-B770-4553-B02E-Inv";
    Integer tenantId = 1;
    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(invalidCAPUserId);
    apiParams.setTenantId(tenantId);

    when(userAccountRepository.existsById(any()))
        .thenThrow(RuntimeException.class);
    when(responseBuilderService.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR))
        .thenReturn(
            new GenericResponse(ResponseCodes.INTERNAL_SERVER_ERROR.getHttpStatus(), "",
                ResponseCodes.INTERNAL_SERVER_ERROR.getMsgId(), "", new Date()));
    Future<GenericResponse> response =
        capUserIdManager.checkAndConstruct(apiParams, null, null);

    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNotNull(genericResponse);
      Assert.assertEquals(ResponseCodes.INTERNAL_SERVER_ERROR.getHttpStatus(),
          genericResponse.getHttpStatus());
      Assert.assertEquals(ResponseCodes.INTERNAL_SERVER_ERROR.getMsgId(),
          genericResponse.getErrorMsgId());
    } catch (Exception e) {
      Assert.fail();
    }
  }

  private void validateCapUserIdNotInDB(Future<GenericResponse> response) {
    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNotNull(genericResponse);
      Assert.assertEquals(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.getHttpStatus(),
          genericResponse.getHttpStatus());
      Assert.assertEquals(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.getMsgId(),
          genericResponse.getErrorMsgId());
    } catch (Exception e) {
      Assert.fail();
    }
  }
}
