package com.ford.sca.cap.vehicle.retrieve.transport;

import java.util.ArrayList;
import java.util.Date;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserVehicleTest {

  @Spy
  private UserVehicle userVehicle;

  @Test
  public void test_all_the_fields() {

    userVehicle.setLatestMileageDate(new Date());
    userVehicle.setLatestMileage(1);
    userVehicle.setPurchaseDate(new Date());
    userVehicle.setMileageSource(1);
    userVehicle.setWarrantyStartDate(new Date());
    userVehicle.setAssignedDealer("");
    userVehicle.setVehicleRole("");
    userVehicle.setAccessDate(new Date());
    userVehicle.setVhrReadyDate(new Date());
    userVehicle.setSyncVehicleIndicator("");
    userVehicle.setLifeStyleXML("");
    userVehicle.setSteeringWheelTyp(1);
    userVehicle.setHeadUnitTyp(1);
    userVehicle.setVehicleImageId(1);
    userVehicle.setOwnerIndicator("");
    userVehicle.setOwnerCycle("");
    userVehicle.setVehicleUpdateDate(new Date());
    userVehicle.setAverageDailyMiles(1);
    userVehicle.setSellingDealer("");
    userVehicle.setVehicleRegistrationDate(new Date());
    userVehicle.setLicensePlate("");
    userVehicle.setPrimaryVehicleIndicator("");
    userVehicle.setConfigurationId(1);
    userVehicle.setDrivingConditionId(1);
    userVehicle.setPreferredDealer("");
    userVehicle.setVersionDescription("");
    userVehicle.setEngineDisp("");
    userVehicle.setSeries("");
    userVehicle.setSparkPlug(1);
    userVehicle.setDrivetrain("");
    userVehicle.setTransmissionType("");
    userVehicle.setPurchaseDate(new Date());
    userVehicle.setCylinders(1);
    userVehicle.setFuel("");
    userVehicle.setMake("");
    userVehicle.setModelType("");
    userVehicle.setModelYear("");
    userVehicle.setColor("");
    userVehicle.setVin("");
    userVehicle.setProductVariant("");
    userVehicle.setVehicleName("");
    userVehicle.setUserProvidedMileage(1);
    userVehicle.setAppId("");
    userVehicle.setCapUserId("");
    userVehicle.setEstimatedMileage(1);
    userVehicle.setTcuEnabled("");

    Assert.assertNotNull(userVehicle.getLatestMileageDate());
    Assert.assertNotNull(userVehicle.getLatestMileage());
    Assert.assertNotNull(userVehicle.getPurchaseDate());
    Assert.assertNotNull(userVehicle.getMileageSource());
    Assert.assertNotNull(userVehicle.getWarrantyStartDate());
    Assert.assertNotNull(userVehicle.getAssignedDealer());
    Assert.assertNotNull(userVehicle.getVehicleRole());
    Assert.assertNotNull(userVehicle.getAccessDate());
    Assert.assertNotNull(userVehicle.getVhrReadyDate());
    Assert.assertNotNull(userVehicle.getSyncVehicleIndicator());
    Assert.assertNotNull(userVehicle.getLifeStyleXML());
    Assert.assertNotNull(userVehicle.getSteeringWheelTyp());
    Assert.assertNotNull(userVehicle.getHeadUnitTyp());
    Assert.assertNotNull(userVehicle.getVehicleImageId());
    Assert.assertNotNull(userVehicle.getOwnerIndicator());
    Assert.assertNotNull(userVehicle.getOwnerCycle());
    Assert.assertNotNull(userVehicle.getVehicleUpdateDate());
    Assert.assertNotNull(userVehicle.getAverageDailyMiles());
    Assert.assertNotNull(userVehicle.getSellingDealer());
    Assert.assertNotNull(userVehicle.getVehicleRegistrationDate());
    Assert.assertNotNull(userVehicle.getLicensePlate());
    Assert.assertNotNull(userVehicle.getPrimaryVehicleIndicator());
    Assert.assertNotNull(userVehicle.getConfigurationId());
    Assert.assertNotNull(userVehicle.getDrivingConditionId());
    Assert.assertNotNull(userVehicle.getPreferredDealer());
    Assert.assertNotNull(userVehicle.getVersionDescription());
    Assert.assertNotNull(userVehicle.getEngineDisp());
    Assert.assertNotNull(userVehicle.getSeries());
    Assert.assertNotNull(userVehicle.getSparkPlug());
    Assert.assertNotNull(userVehicle.getDrivetrain());
    Assert.assertNotNull(userVehicle.getTransmissionType());
    Assert.assertNotNull(userVehicle.getPurchaseDate());
    Assert.assertNotNull(userVehicle.getCylinders());
    Assert.assertNotNull(userVehicle.getFuel());
    Assert.assertNotNull(userVehicle.getMake());
    Assert.assertNotNull(userVehicle.getModelType());
    Assert.assertNotNull(userVehicle.getModelYear());
    Assert.assertNotNull(userVehicle.getColor());
    Assert.assertNotNull(userVehicle.getVin());
    Assert.assertNotNull(userVehicle.getProductVariant());
    Assert.assertNotNull(userVehicle.getVehicleName());
    Assert.assertNotNull(userVehicle.getUserProvidedMileage());
    Assert.assertNotNull(userVehicle.getAppId());
    Assert.assertNotNull(userVehicle.getCapUserId());
    Assert.assertNotNull(userVehicle.getEstimatedMileage());
    Assert.assertNotNull(userVehicle.getTcuEnabled());
  }
}
