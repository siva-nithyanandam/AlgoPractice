package com.ford.sca.cap.domain;

import java.util.Date;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CountryCodeBOTest {

  @Spy
  private CountryCodeBO countryCodeBO;

  @Test
  public void test_all_the_fields() {
    countryCodeBO.setCountryName("");
    countryCodeBO.setCreateAppCode(123);
    countryCodeBO.setCreateDate(new Date());
    countryCodeBO.setCreateProcess("sdfsd");
    countryCodeBO.setCreateUser("dfsdf");
    countryCodeBO.setIso2CodeCountry("US");
    countryCodeBO.setIso3CodeCountry("USA");
    countryCodeBO.setMdmEffectiveDate(new Date());
    countryCodeBO.setMdmEnabledFlag("Y");
    countryCodeBO.setUpdateAppCode(123);
    countryCodeBO.setUpdateDate(new Date());
    countryCodeBO.setUpdateProcess("sdfs");
    countryCodeBO.setUpdateUser("sfsd");

    Assert.assertNotNull(countryCodeBO.getCountryName());
    Assert.assertNotNull(countryCodeBO.getCreateDate());
    Assert.assertNotNull(countryCodeBO.getCreateProcess());
    Assert.assertNotNull(countryCodeBO.getCreateUser());
    Assert.assertNotNull(countryCodeBO.getIso2CodeCountry());
    Assert.assertNotNull(countryCodeBO.getCreateAppCode());
    Assert.assertNotNull(countryCodeBO.getIso3CodeCountry());
    Assert.assertNotNull(countryCodeBO.getMdmEffectiveDate());
    Assert.assertNotNull(countryCodeBO.getMdmEnabledFlag());
    Assert.assertNotNull(countryCodeBO.getUpdateAppCode());
    Assert.assertNotNull(countryCodeBO.getUpdateDate());
    Assert.assertNotNull(countryCodeBO.getUpdateProcess());
    Assert.assertNotNull(countryCodeBO.getUpdateUser());
  }
}
