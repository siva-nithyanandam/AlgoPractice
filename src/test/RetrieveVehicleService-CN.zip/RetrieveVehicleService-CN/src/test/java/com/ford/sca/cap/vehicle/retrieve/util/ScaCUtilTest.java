package com.ford.sca.cap.vehicle.retrieve.util;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.cap.domain.CountryCodeBO;
import com.ford.sca.cap.vehicle.retrieve.messaging.RabbitMqSender;
import com.ford.sca.cap.vehicle.retrieve.repository.MarketingProfileRepository;
import com.ford.sca.cap.vehicle.retrieve.service.statics.Flags;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ScaCUtilTest {

  @Spy
  @InjectMocks
  private ScaCUtil scaCUtil;

  @Mock
  private RabbitMqSender rabbitMqSender;

  @Mock
  private CacheUtil cacheUtil;

  @Mock
  private MarketingProfileRepository marketingProfileRepository;

  @Mock
  private ObjectMapper objectMapper;

  private ApiParams apiParams;
  private CountryCodeBO countryCodeBo;

  @Before
  public void setUp() {
    doNothing().when(rabbitMqSender).send(Mockito.any(), Mockito.any());

    apiParams = new ApiParams();
    apiParams.setAppId("100504");
    apiParams.setUserId("ID123456789");

    countryCodeBo = new CountryCodeBO();
    countryCodeBo.setMdmEnabledFlag(Flags.ACTIVE);

    // objectMapper = Mockito.mock(ObjectMapper.class);
  }

  @Test
  public void test_push_to_sca_c_for_ISO2_success() {
    // GIVEN
    apiParams.setCountryCode("US");
    when(marketingProfileRepository.existsById(apiParams.getUserId())).thenReturn(false);
    when(cacheUtil.getCountryCodeByISO2(apiParams.getCountryCode())).thenReturn(countryCodeBo);
    try {
      when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("Sample");
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }
    // WHEN
    scaCUtil.pushToScaC(apiParams);

    // THEN
    verify(rabbitMqSender, times(1)).send(Mockito.any(), Mockito.any());
  }

  @Test
  public void test_push_to_sca_c_for_ISO3_success() {
    // GIVEN
    apiParams.setCountryCode("USA");
    when(marketingProfileRepository.existsById(apiParams.getUserId())).thenReturn(false);
    when(cacheUtil.getCountryCodeByISO3(apiParams.getCountryCode())).thenReturn(countryCodeBo);
    try {
      when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("Sample");
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }

    // WHEN
    scaCUtil.pushToScaC(apiParams);

    // THEN
    verify(rabbitMqSender, times(1)).send(Mockito.any(), Mockito.any());
  }

  @Test
  public void test_push_to_sca_c_failure() {
    // GIVEN
    apiParams.setCountryCode("US");
    when(marketingProfileRepository.existsById(apiParams.getUserId())).thenReturn(false);
    when(cacheUtil.getCountryCodeByISO2(apiParams.getCountryCode())).thenReturn(countryCodeBo);
    try {
      when(objectMapper.writeValueAsString(Mockito.any()))
          .thenThrow(new RuntimeException("Testing"));
    } catch (JsonProcessingException e) {
      Assert.fail(e.getMessage());
    }
    // WHEN
    scaCUtil.pushToScaC(apiParams);

    // THEN
    verify(rabbitMqSender, times(0)).send(Mockito.any(), Mockito.any());
  }

  /**
   * To test pushing to sca-c for a userId which already exists in sca-c
   */
  @Test
  public void test_push_to_sca_c_with_id_already_exists() {
    // GIVEN
    apiParams.setCountryCode("US");
    when(marketingProfileRepository.existsById(apiParams.getUserId())).thenReturn(true);
    // WHEN
    scaCUtil.pushToScaC(apiParams);
    // THEN
    verify(rabbitMqSender, times(0)).send(Mockito.any(), Mockito.any());
  }

  @Test
  public void test_push_to_sca_c_with_country_not_exist() {
    // GIVEN
    when(marketingProfileRepository.existsById(apiParams.getUserId())).thenReturn(false);
    // WHEN
    scaCUtil.pushToScaC(apiParams);
    // THEN
    verify(rabbitMqSender, times(0)).send(Mockito.any(), Mockito.any());
  }

  /**
   * To test pushing to sca-c with invalid country code
   */
  @Test
  public void test_push_to_sca_c_with_invalid_country() {
    // GIVEN
    apiParams.setCountryCode("USUSUSUS");
    when(marketingProfileRepository.existsById(apiParams.getUserId())).thenReturn(false);
    // WHEN
    scaCUtil.pushToScaC(apiParams);
    // THEN
    verify(rabbitMqSender, times(0)).send(Mockito.any(), Mockito.any());
  }
}
