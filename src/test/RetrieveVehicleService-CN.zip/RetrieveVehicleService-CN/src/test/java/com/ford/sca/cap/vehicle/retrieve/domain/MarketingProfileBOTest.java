package com.ford.sca.cap.vehicle.retrieve.domain;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MarketingProfileBOTest {

  @Spy
  private MarketingProfileBO marketingProfileBO;

  @Test
  public void test_all_the_fields() {
    marketingProfileBO.setMpUserId("123");
    Assert.assertNotNull(marketingProfileBO.getMpUserId());
  }
}
