package com.ford.sca.cap.vehicle.retrieve.transport;

import java.util.Date;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RequestVehicleAttributesTest {

  @Spy
  private RequestVehicleAttributes requestVehicleAttributes;

  @Test
  public void test_all_the_fields() {

    requestVehicleAttributes.setPrimaryVehicleIndicator("");
    requestVehicleAttributes.setAverageDailyMiles(1);
    requestVehicleAttributes.setConfigurationId(1);
    requestVehicleAttributes.setDrivingConditionId(1);
    requestVehicleAttributes.setHeadUnitTyp(1);
    requestVehicleAttributes.setLicensePlate("");
    requestVehicleAttributes.setLifeStyleXML("");
    requestVehicleAttributes.setMileageUpdateDate(new Date());
    requestVehicleAttributes.setPreferredDealer("");
    requestVehicleAttributes.setProductVariant("");
    requestVehicleAttributes.setSmsMessagesXML("");
    requestVehicleAttributes.setSteeringWheelTyp(1);
    requestVehicleAttributes.setSyncVehicleIndicator("");
    requestVehicleAttributes.setUserProvidedMileage(1);
    requestVehicleAttributes.setVehicleImageId(1);
    requestVehicleAttributes.setVehicleName("");
    requestVehicleAttributes.setVehicleRegistrationDate(new Date());
    requestVehicleAttributes.setVhrReadyDate(new Date());

    Assert.assertNotNull(requestVehicleAttributes.getPrimaryVehicleIndicator());
    Assert.assertNotNull(requestVehicleAttributes.getAverageDailyMiles());
    Assert.assertNotNull(requestVehicleAttributes.getConfigurationId());
    Assert.assertNotNull(requestVehicleAttributes.getDrivingConditionId());
    Assert.assertNotNull(requestVehicleAttributes.getHeadUnitTyp());
    Assert.assertNotNull(requestVehicleAttributes.getLicensePlate());
    Assert.assertNotNull(requestVehicleAttributes.getLifeStyleXML());
    Assert.assertNotNull(requestVehicleAttributes.getMileageUpdateDate());
    Assert.assertNotNull(requestVehicleAttributes.getPreferredDealer());
    Assert.assertNotNull(requestVehicleAttributes.getProductVariant());
    Assert.assertNotNull(requestVehicleAttributes.getSmsMessagesXML());
    Assert.assertNotNull(requestVehicleAttributes.getSteeringWheelTyp());
    Assert.assertNotNull(requestVehicleAttributes.getSyncVehicleIndicator());
    Assert.assertNotNull(requestVehicleAttributes.getUserProvidedMileage());
    Assert.assertNotNull(requestVehicleAttributes.getVehicleImageId());
    Assert.assertNotNull(requestVehicleAttributes.getVehicleName());
    Assert.assertNotNull(requestVehicleAttributes.getVehicleRegistrationDate());
    Assert.assertNotNull(requestVehicleAttributes.getVhrReadyDate());
  }
}
