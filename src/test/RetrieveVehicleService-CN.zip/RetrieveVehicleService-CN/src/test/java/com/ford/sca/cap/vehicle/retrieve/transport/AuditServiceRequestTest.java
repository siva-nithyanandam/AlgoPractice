package com.ford.sca.cap.vehicle.retrieve.transport;

import java.util.Date;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AuditServiceRequestTest {

  @Spy
  private AuditServiceRequest auditServiceRequest;

  @Test
  public void test_all_the_fields() {

    auditServiceRequest.setVcapRequestId("");
    auditServiceRequest.setJsonType("");
    auditServiceRequest.setRequestStatus("");
    auditServiceRequest.setJsonBody("");
    auditServiceRequest.setResponseCode("");
    auditServiceRequest.setAppId("");
    auditServiceRequest.setBuildVersion("");
    auditServiceRequest.setCapUserId("");
    auditServiceRequest.setCorrelationId("");
    auditServiceRequest.setDataCenter("");
    auditServiceRequest.setEnvironment("");
    auditServiceRequest.setHttpMethod("");
    auditServiceRequest.setOrg("");
    auditServiceRequest.setResourceUri("");
    auditServiceRequest.setServiceId("");
    auditServiceRequest.setSpanId("");
    auditServiceRequest.setTraceId("");

    Assert.assertNotNull(auditServiceRequest.getVcapRequestId());
    Assert.assertNotNull(auditServiceRequest.getJsonType());
    Assert.assertNotNull(auditServiceRequest.getRequestStatus());
    Assert.assertNotNull(auditServiceRequest.getJsonBody());
    Assert.assertNotNull(auditServiceRequest.getResponseCode());
    Assert.assertNotNull(auditServiceRequest.getAppId());
    Assert.assertNotNull(auditServiceRequest.getBuildVersion());
    Assert.assertNotNull(auditServiceRequest.getCapUserId());
    Assert.assertNotNull(auditServiceRequest.getCorrelationId());
    Assert.assertNotNull(auditServiceRequest.getDataCenter());
    Assert.assertNotNull(auditServiceRequest.getEnvironment());
    Assert.assertNotNull(auditServiceRequest.getHttpMethod());
    Assert.assertNotNull(auditServiceRequest.getOrg());
    Assert.assertNotNull(auditServiceRequest.getResourceUri());
    Assert.assertNotNull(auditServiceRequest.getServiceId());
    Assert.assertNotNull(auditServiceRequest.getSpanId());
    Assert.assertNotNull(auditServiceRequest.getTraceId());

    auditServiceRequest.setTranDateTime(null);
    Assert.assertNull(auditServiceRequest.getTranDateTime());

    auditServiceRequest.setTranDateTime(new Date());
    Assert.assertNotNull(auditServiceRequest.getTranDateTime());
  }
}
