package com.ford.sca.cap.vehicle.retrieve.service.ruleengines;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.ford.sca.cap.vehicle.retrieve.domain.UserAccountPK;
import com.ford.sca.cap.vehicle.retrieve.domain.UserVehicleBO;
import com.ford.sca.cap.vehicle.retrieve.repository.UserAccountRepository;
import com.ford.sca.cap.vehicle.retrieve.repository.UserVehicleRepository;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import com.ford.sca.cap.vehicle.retrieve.util.ScaCUtil;
import com.ford.sca.cap.vehicle.retrieve.validators.CapUserIdManager;
import com.ford.sca.cap.vehicle.retrieve.validators.Validator;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

@RunWith(MockitoJUnitRunner.Silent.class)
public class NAMobileWebTest {

  @Spy
  @InjectMocks
  private NaMobileWebOther naMobileWebOther;

  @Spy
  @InjectMocks
  private CapUserIdManager capUserIdManager;

  @Mock
  private ResponseBuilder responseBuilderService;

  @Mock
  private UserAccountRepository userAccountRepository;

  @Mock
  private UserVehicleRepository userVehicleRepository;

  @Mock
  private ScaCUtil scaCUtil;

  @Mock
  private EntityManager entityManager;

  @Test
  public void isRequestBehalfOfThisImpl_success_flow() {
    boolean isRequestBehalfOfNAImpl = naMobileWebOther.isRequestBehalfOfThisImpl("MOBILE_NA");
    Assert.assertTrue(isRequestBehalfOfNAImpl);
  }

  @Test
  public void isRequestBehalfOfThisImpl_failure_flow() {
    boolean isRequestBehalfOfNAImpl = naMobileWebOther.isRequestBehalfOfThisImpl("Mobile_NA_1");
    Assert.assertFalse(isRequestBehalfOfNAImpl);
  }

  /**
   * To check Validators are added.
   */
  @Test
  public void validate_getValidators_returns_Validators() {
    List<Validator> validators = naMobileWebOther.getValidators();
    assertTrue(validators.size() > 0);
  }

  /**
   * To check brand code map been populated for MOBILE_NA rule engine
   */
  @Test
  public void validateBrandCodeMap() {
    Map<String, String> brandCodeMap = naMobileWebOther.getBrandCodeMap();
    assertTrue(brandCodeMap.size() > 0);
  }

  /**
   * To check validation invocations - Success
   */
  @Test
  public void testValidationFunctionality_Success() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";
    Integer tenantId = 1;

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setTenantId(tenantId);

    List<Validator> validators = new ArrayList<>();
    validators.add(capUserIdManager);

    when(userAccountRepository.existsById(new UserAccountPK(capUserId, tenantId))).thenReturn(true);
    when(naMobileWebOther.getValidators()).thenReturn(validators);
    //WHEN
    Optional<GenericResponse> genericResponse = naMobileWebOther.validate(apiParams, null);
    //THEN
    Assert.assertFalse(genericResponse.isPresent());
  }

  /**
   * To check validation invocations - Failure
   */
  @Test
  public void testValidationFunctionality_Failure() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";
    Integer tenantId = 1;

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setTenantId(tenantId);

    List<Validator> validators = new ArrayList<>();
    validators.add(capUserIdManager);

    when(userAccountRepository.existsById(new UserAccountPK(capUserId, tenantId)))
        .thenThrow(new RuntimeException("Testing"));
    when(responseBuilderService.generateResponse(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP))
        .thenReturn(
            new GenericResponse(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.getHttpStatus(), "",
                ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.getMsgId(), "", new Date()));
    when(naMobileWebOther.getValidators()).thenReturn(validators);
    //WHEN
    Optional<GenericResponse> genericResponse = naMobileWebOther.validate(apiParams, null);
    //THEN
    try {
      Assert.assertTrue(genericResponse.isPresent());
      Assert.assertEquals(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.getHttpStatus(),
          genericResponse.get().getHttpStatus());
      Assert.assertEquals(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.getMsgId(),
          genericResponse.get().getErrorMsgId());
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * To check trigger DB process with brand code of success flow
   */
  @Test
  public void triggerDBProcess_withBrandCode_Success() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setBrandCode("F");

    List<UserVehicleBO> userVehicleBOList = new ArrayList<>();
    userVehicleBOList.add(buildUserVehicleBO());

    CriteriaBuilder mockedCriteriaBuilder = Mockito.mock(CriteriaBuilder.class);
    CriteriaQuery mockedCriteriaQry = Mockito.mock(CriteriaQuery.class);
    when(mockedCriteriaBuilder.createQuery(any())).thenReturn(mockedCriteriaQry);
    Root<UserVehicleBO> mockedRoot = Mockito.mock(Root.class);
    when(mockedCriteriaQry.from(UserVehicleBO.class)).thenReturn(mockedRoot);
    Path path = Mockito.mock(Path.class);
    when(path.get(anyString())).thenReturn(mockedRoot);
    when(mockedRoot.get(anyString())).thenReturn(path);
    TypedQuery mockedTypedQuery = Mockito.mock(TypedQuery.class);
    when(mockedTypedQuery.getResultList()).thenReturn(userVehicleBOList);
    when(entityManager.createQuery(mockedCriteriaQry)).thenReturn(mockedTypedQuery);
    when(entityManager.getCriteriaBuilder()).thenReturn(mockedCriteriaBuilder);
    //WHEN
    GenericResponse response = naMobileWebOther.triggerDBProcesses(apiParams, null);
    //THEN
    validateTriggerDBProcessSuccess(response, apiParams);
  }

  /**
   * To check trigger DB process with brand code and vin code of success flow
   */
  @Test
  public void triggerDBProcess_withBrandCodeAndVinCode_Success() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";
    String vinCode = "1FA6P8CF2H5302091";

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setBrandCode("F");
    apiParams.setVinCode(vinCode);

    List<UserVehicleBO> userVehicleBOList = new ArrayList<>();
    userVehicleBOList.add(buildUserVehicleBO());

    CriteriaBuilder mockedCriteriaBuilder = Mockito.mock(CriteriaBuilder.class);
    CriteriaQuery mockedCriteriaQry = Mockito.mock(CriteriaQuery.class);
    when(mockedCriteriaBuilder.createQuery(any())).thenReturn(mockedCriteriaQry);
    Root<UserVehicleBO> mockedRoot = Mockito.mock(Root.class);
    when(mockedCriteriaQry.from(UserVehicleBO.class)).thenReturn(mockedRoot);
    Path path = Mockito.mock(Path.class);
    when(path.get(anyString())).thenReturn(mockedRoot);
    when(mockedRoot.get(anyString())).thenReturn(path);
    TypedQuery mockedTypedQuery = Mockito.mock(TypedQuery.class);
    when(mockedTypedQuery.getResultList()).thenReturn(userVehicleBOList);
    when(entityManager.createQuery(mockedCriteriaQry)).thenReturn(mockedTypedQuery);
    when(entityManager.getCriteriaBuilder()).thenReturn(mockedCriteriaBuilder);
    //WHEN
    GenericResponse response = naMobileWebOther.triggerDBProcesses(apiParams, null);
    //THEN
    validateTriggerDBProcessSuccess(response, apiParams);
  }

  private void validateTriggerDBProcessSuccess(GenericResponse response,
      ApiParams apiParams) {
    try {
      Assert.assertNotNull(response);
      Assert.assertNotNull(apiParams.getCountryCode());
      Assert.assertEquals(ResponseCodes.SUCCESS.getResponseMessage(), response.getStatus());
      Assert.assertEquals(ResponseCodes.SUCCESS.getHttpStatus(), response.getHttpStatus());
    } catch (Exception e) {
      Assert.fail();
    }
  }

  private void validateTriggerDBProcessFailure(GenericResponse response) {
    try {
      Assert.assertNotNull(response);
      Assert.assertEquals(ResponseCodes.NO_DATA_FOR_USER.getMsgId(), response.getErrorMsgId());
      Assert
          .assertEquals(ResponseCodes.NO_DATA_FOR_USER.getHttpStatus(), response.getHttpStatus());
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * To check trigger DB process without brand code of success flow
   */
  @Test
  public void triggerDBProcess_withOutBrandCode_Success() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);

    List<UserVehicleBO> userVehicleBOList = new ArrayList<>();
    userVehicleBOList.add(buildUserVehicleBO());

    CriteriaBuilder mockedCriteriaBuilder = Mockito.mock(CriteriaBuilder.class);
    CriteriaQuery mockedCriteriaQry = Mockito.mock(CriteriaQuery.class);
    when(mockedCriteriaBuilder.createQuery(any())).thenReturn(mockedCriteriaQry);
    Root<UserVehicleBO> mockedRoot = Mockito.mock(Root.class);
    when(mockedCriteriaQry.from(UserVehicleBO.class)).thenReturn(mockedRoot);
    Path path = Mockito.mock(Path.class);
    when(path.get(anyString())).thenReturn(mockedRoot);
    when(mockedRoot.get(anyString())).thenReturn(path);
    TypedQuery mockedTypedQuery = Mockito.mock(TypedQuery.class);
    when(mockedTypedQuery.getResultList()).thenReturn(userVehicleBOList);
    when(entityManager.createQuery(mockedCriteriaQry)).thenReturn(mockedTypedQuery);
    when(entityManager.getCriteriaBuilder()).thenReturn(mockedCriteriaBuilder);
    //WHEN
    GenericResponse response = naMobileWebOther.triggerDBProcesses(apiParams, null);
    //THEN
    validateTriggerDBProcessSuccess(response, apiParams);
  }

  /**
   * To check trigger DB process without brand code of success flow
   */
  @Test
  public void triggerDBProcess_withOutBrandCodeAndWithVinCode_Success() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";
    String vinCode = "1FA6P8CF2H5302091";

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setVinCode(vinCode);

    CriteriaBuilder mockedCriteriaBuilder = Mockito.mock(CriteriaBuilder.class);
    CriteriaQuery mockedCriteriaQry = Mockito.mock(CriteriaQuery.class);
    when(mockedCriteriaBuilder.createQuery(any())).thenReturn(mockedCriteriaQry);
    Root<UserVehicleBO> mockedRoot = Mockito.mock(Root.class);
    when(mockedCriteriaQry.from(UserVehicleBO.class)).thenReturn(mockedRoot);
    Path path = Mockito.mock(Path.class);
    when(path.get(anyString())).thenReturn(mockedRoot);
    when(mockedRoot.get(anyString())).thenReturn(path);
    TypedQuery mockedTypedQuery = Mockito.mock(TypedQuery.class);
    when(mockedTypedQuery.getResultList()).thenReturn(new ArrayList(){{add(buildUserVehicleBO());}});
    when(entityManager.createQuery(mockedCriteriaQry)).thenReturn(mockedTypedQuery);
    when(entityManager.getCriteriaBuilder()).thenReturn(mockedCriteriaBuilder);

    when(userVehicleRepository
        .findById(Mockito.any()))
        .thenReturn(Optional.of(buildUserVehicleBO()));
    //WHEN
    GenericResponse response = naMobileWebOther.triggerDBProcesses(apiParams, null);
    //THEN
    validateTriggerDBProcessSuccess(response, apiParams);
  }

  private UserVehicleBO buildUserVehicleBO() {
    UserVehicleBO userVehicleBO = new UserVehicleBO();
    userVehicleBO.setCountryCode("US");
    return userVehicleBO;
  }

  /**
   * To check trigger DB process with brand code of failure flow
   */
  @Test
  public void triggerDBProcess_withBrandCode_Failure() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setBrandCode("F");

    List<UserVehicleBO> userVehicleBOList = new ArrayList<>();
    when(responseBuilderService.generateResponse(ResponseCodes.NO_DATA_FOR_BRAND_CODE))
        .thenReturn(
            new GenericResponse(ResponseCodes.NO_DATA_FOR_BRAND_CODE.getHttpStatus(), "",
                ResponseCodes.NO_DATA_FOR_BRAND_CODE.getMsgId(), "", new Date()));
    CriteriaBuilder mockedCriteriaBuilder = Mockito.mock(CriteriaBuilder.class);
    CriteriaQuery mockedCriteriaQry = Mockito.mock(CriteriaQuery.class);
    when(mockedCriteriaBuilder.createQuery(any())).thenReturn(mockedCriteriaQry);
    Root<UserVehicleBO> mockedRoot = Mockito.mock(Root.class);
    when(mockedCriteriaQry.from(UserVehicleBO.class)).thenReturn(mockedRoot);
    Path path = Mockito.mock(Path.class);
    when(path.get(anyString())).thenReturn(mockedRoot);
    when(mockedRoot.get(anyString())).thenReturn(path);
    TypedQuery mockedTypedQuery = Mockito.mock(TypedQuery.class);
    when(mockedTypedQuery.getResultList()).thenReturn(userVehicleBOList);
    when(entityManager.createQuery(mockedCriteriaQry)).thenReturn(mockedTypedQuery);
    when(entityManager.getCriteriaBuilder()).thenReturn(mockedCriteriaBuilder);
    //WHEN
    GenericResponse response = naMobileWebOther.triggerDBProcesses(apiParams, null);
    //THEN
    try {
      Assert.assertNotNull(response);
      Assert
          .assertEquals(ResponseCodes.NO_DATA_FOR_BRAND_CODE.getMsgId(), response.getErrorMsgId());
      Assert
          .assertEquals(ResponseCodes.NO_DATA_FOR_BRAND_CODE.getHttpStatus(),
              response.getHttpStatus());
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * To check trigger DB process with vin code of failure flow
   */
  @Test
  public void triggerDBProcess_withVinCode_Failure() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setVinCode("1234");

    List<UserVehicleBO> userVehicleBOList = new ArrayList<>();
    when(responseBuilderService.generateResponse(ResponseCodes.NO_DATA_FOR_VIN_CODE))
        .thenReturn(
            new GenericResponse(ResponseCodes.NO_DATA_FOR_VIN_CODE.getHttpStatus(), "",
                ResponseCodes.NO_DATA_FOR_VIN_CODE.getMsgId(), "", new Date()));
    CriteriaBuilder mockedCriteriaBuilder = Mockito.mock(CriteriaBuilder.class);
    CriteriaQuery mockedCriteriaQry = Mockito.mock(CriteriaQuery.class);
    when(mockedCriteriaBuilder.createQuery(any())).thenReturn(mockedCriteriaQry);
    Root<UserVehicleBO> mockedRoot = Mockito.mock(Root.class);
    when(mockedCriteriaQry.from(UserVehicleBO.class)).thenReturn(mockedRoot);
    Path path = Mockito.mock(Path.class);
    when(path.get(anyString())).thenReturn(mockedRoot);
    when(mockedRoot.get(anyString())).thenReturn(path);
    TypedQuery mockedTypedQuery = Mockito.mock(TypedQuery.class);
    when(mockedTypedQuery.getResultList()).thenReturn(userVehicleBOList);
    when(entityManager.createQuery(mockedCriteriaQry)).thenReturn(mockedTypedQuery);
    when(entityManager.getCriteriaBuilder()).thenReturn(mockedCriteriaBuilder);
    //WHEN
    GenericResponse response = naMobileWebOther.triggerDBProcesses(apiParams, null);
    //THEN
    try {
      Assert.assertNotNull(response);
      Assert
          .assertEquals(ResponseCodes.NO_DATA_FOR_VIN_CODE.getMsgId(), response.getErrorMsgId());
      Assert
          .assertEquals(ResponseCodes.NO_DATA_FOR_VIN_CODE.getHttpStatus(),
              response.getHttpStatus());
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * To check trigger DB process with brand code and vin code of failure flow
   */
  @Test
  public void triggerDBProcess_withBrandCode_andVinCode_Failure() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setVinCode("1234");
    apiParams.setBrandCode("F");

    List<UserVehicleBO> userVehicleBOList = new ArrayList<>();
    when(responseBuilderService.generateResponse(ResponseCodes.NO_DATA_FOR_VIN_AND_BRAND_CODE))
        .thenReturn(
            new GenericResponse(ResponseCodes.NO_DATA_FOR_VIN_AND_BRAND_CODE.getHttpStatus(), "",
                ResponseCodes.NO_DATA_FOR_VIN_AND_BRAND_CODE.getMsgId(), "", new Date()));
    CriteriaBuilder mockedCriteriaBuilder = Mockito.mock(CriteriaBuilder.class);
    CriteriaQuery mockedCriteriaQry = Mockito.mock(CriteriaQuery.class);
    when(mockedCriteriaBuilder.createQuery(any())).thenReturn(mockedCriteriaQry);
    Root<UserVehicleBO> mockedRoot = Mockito.mock(Root.class);
    when(mockedCriteriaQry.from(UserVehicleBO.class)).thenReturn(mockedRoot);
    Path path = Mockito.mock(Path.class);
    when(path.get(anyString())).thenReturn(mockedRoot);
    when(mockedRoot.get(anyString())).thenReturn(path);
    TypedQuery mockedTypedQuery = Mockito.mock(TypedQuery.class);
    when(mockedTypedQuery.getResultList()).thenReturn(userVehicleBOList);
    when(entityManager.createQuery(mockedCriteriaQry)).thenReturn(mockedTypedQuery);
    when(entityManager.getCriteriaBuilder()).thenReturn(mockedCriteriaBuilder);
    //WHEN
    GenericResponse response = naMobileWebOther.triggerDBProcesses(apiParams, null);
    //THEN
    try {
      Assert.assertNotNull(response);
      Assert
          .assertEquals(ResponseCodes.NO_DATA_FOR_VIN_AND_BRAND_CODE.getMsgId(), response.getErrorMsgId());
      Assert
          .assertEquals(ResponseCodes.NO_DATA_FOR_VIN_AND_BRAND_CODE.getHttpStatus(),
              response.getHttpStatus());
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * To check trigger DB process of failure flow
   */
  @Test
  public void triggerDBProcess_Failure() {
    //GIVEN
    String appId = "100504";
    String capUserId = "0729C64B-EFFB-4593-C551-000004753123";

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);

    List<UserVehicleBO> userVehicleBOList = new ArrayList<>();
    when(responseBuilderService.generateResponse(ResponseCodes.NO_DATA_FOR_USER))
        .thenReturn(
            new GenericResponse(ResponseCodes.NO_DATA_FOR_USER.getHttpStatus(), "",
                ResponseCodes.NO_DATA_FOR_USER.getMsgId(), "", new Date()));
    CriteriaBuilder mockedCriteriaBuilder = Mockito.mock(CriteriaBuilder.class);
    CriteriaQuery mockedCriteriaQry = Mockito.mock(CriteriaQuery.class);
    when(mockedCriteriaBuilder.createQuery(any())).thenReturn(mockedCriteriaQry);
    Root<UserVehicleBO> mockedRoot = Mockito.mock(Root.class);
    when(mockedCriteriaQry.from(UserVehicleBO.class)).thenReturn(mockedRoot);
    Path path = Mockito.mock(Path.class);
    when(path.get(anyString())).thenReturn(mockedRoot);
    when(mockedRoot.get(anyString())).thenReturn(path);
    TypedQuery mockedTypedQuery = Mockito.mock(TypedQuery.class);
    when(mockedTypedQuery.getResultList()).thenReturn(userVehicleBOList);
    when(entityManager.createQuery(mockedCriteriaQry)).thenReturn(mockedTypedQuery);
    when(entityManager.getCriteriaBuilder()).thenReturn(mockedCriteriaBuilder);
    //WHEN
    GenericResponse response = naMobileWebOther.triggerDBProcesses(apiParams, null);
    //THEN
    try {
      Assert.assertNotNull(response);
      Assert
          .assertEquals(ResponseCodes.NO_DATA_FOR_USER.getMsgId(), response.getErrorMsgId());
      Assert
          .assertEquals(ResponseCodes.NO_DATA_FOR_USER.getHttpStatus(),
              response.getHttpStatus());
    } catch (Exception e) {
      Assert.fail();
    }
  }

  @Test
  public void validate_triggerPostDBProcesses() {
    //GIVEN
    ApiParams apiParams = new ApiParams();

    Map<String, String> webThreadContext = new HashMap<>();
    MDC.setContextMap(webThreadContext);
    doNothing().when(scaCUtil).pushToScaC(Mockito.any());

    //WHEN
    naMobileWebOther.triggerPostDBProcesses(apiParams);

    //THEN
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      Assert.fail(e.getMessage());
    }
    verify(scaCUtil, times(1)).pushToScaC(Mockito.any());
  }


}
