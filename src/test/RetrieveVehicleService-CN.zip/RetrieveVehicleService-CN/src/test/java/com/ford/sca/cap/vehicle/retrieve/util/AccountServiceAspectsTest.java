package com.ford.sca.cap.vehicle.retrieve.util;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AccountServiceAspectsTest {
  
  @InjectMocks
  AccountServiceAspects accAspects;
  

  @Test
  public void logMethodTest() throws Throwable{
    final ProceedingJoinPoint proceedingJoinPoint= mock(ProceedingJoinPoint.class);
    Signature sig = mock(Signature.class);
    when(proceedingJoinPoint.getSignature()).thenReturn(sig);
    when(proceedingJoinPoint.getSignature().getDeclaringType()).thenReturn(String.class);
    when(proceedingJoinPoint.getSignature().getName()).thenReturn("String");
    when(proceedingJoinPoint.proceed()).thenReturn(new String("String"));
    final LogAround annotation = mock(LogAround.class);
    accAspects.logMethod(proceedingJoinPoint, annotation);
  }
}
