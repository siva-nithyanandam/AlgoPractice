package com.ford.sca.cap.vehicle.retrieve;

import static org.junit.Assert.assertNotNull;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@RunWith(MockitoJUnitRunner.Silent.class)
public class RetrieveVehicleServiceLauncherTest {

  @Spy
  private RetrieveVehicleServiceLauncher retrieveVehicleServiceLauncher;

  @Test
  public void test_newsApi() {
    Assert.assertNotNull(retrieveVehicleServiceLauncher.newsApi());
  }

  @Test
  public void testGlobal() {
    assertNotNull(retrieveVehicleServiceLauncher.globalMethodSecurityConfiguration()
        .preInvocationAuthorizationAdvice());
  }
}
