package com.ford.sca.cap.vehicle.retrieve.util;

import static org.junit.Assert.assertTrue;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RunWith(MockitoJUnitRunner.Silent.class)
public class LoggerBuilderTest {
  @InjectMocks
  LoggerBuilder log;


  @SuppressWarnings("static-access")
  @Test
  public void printinfoTest() {
    Class<String> ex = String.class;
    log.printInfo(ex, null);
  }

  @SuppressWarnings("static-access")
  @Test
  public void printdebugTest() {
    final Logger LOG = LoggerFactory.getLogger(AuditActivityUtil.class);
    log.printDebug(LOG, null);
    assertTrue(LOG.isDebugEnabled());
  }
  
  @SuppressWarnings("static-access")
  @Test
  public void printdebugNonNullConsumerTest() {
    final Logger LOG = LoggerFactory.getLogger(AuditActivityUtil.class);
    log.printDebug(LOG, logger->logger.message("Test Log"));
    assertTrue(LOG.isDebugEnabled());
  }
  
  @SuppressWarnings("static-access")
  @Test
  public void printdebugNullTest() {
    final Logger LOG = LoggerFactory.getLogger(AuditActivityUtil.class);
    log.printDebug(null , logger->logger.message("Test Log"));
    assertTrue(LOG.isDebugEnabled());
  }

  @SuppressWarnings("static-access")
  @Test
  public void printerrorTest() {
    final Logger LOG = LoggerFactory.getLogger(AuditActivityUtil.class);
    log.printError(LOG, null);
    assertTrue(LOG.isErrorEnabled());
  }
  
  @SuppressWarnings("static-access")
  @Test
  public void printerrorNullTest() {
    final Logger LOG = LoggerFactory.getLogger(AuditActivityUtil.class);
    Class<String> ex = String.class;
    log.printError(ex, null);
    assertTrue(LOG.isErrorEnabled());
  }
}
