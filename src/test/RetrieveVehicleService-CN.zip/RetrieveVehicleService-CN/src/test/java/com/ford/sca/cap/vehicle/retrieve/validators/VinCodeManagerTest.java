package com.ford.sca.cap.vehicle.retrieve.validators;

import static org.mockito.Mockito.when;

import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import java.util.Date;
import java.util.concurrent.Future;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class VinCodeManagerTest {

  @InjectMocks
  private VinCodeManager vinCodeManager;

  @Mock
  private ResponseBuilder responseBuilderService;

  /**
   * When a given brand code is empty, ignore it and return success validation.
   */
  @Test
  public void whenVinCodeIsEmpty_returnSuccess() {
    ApiParams apiParams = new ApiParams();

    Future<GenericResponse> response =
        vinCodeManager.checkAndConstruct(apiParams, null, null);
    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNull(genericResponse);
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * When a valid brand code is given in the request for NA, return success
   */
  @Test
  public void whenVinCodeGiven_andThatIsValid() {
    ApiParams apiParams = new ApiParams();
    apiParams.setVinCode("1FA6P8CF2H5302091");
    Future<GenericResponse> response =
        vinCodeManager.checkAndConstruct(apiParams, null, null);
    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNull(genericResponse);
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * When a invalid brand code is given in the request for NA, return failure
   */
  @Test
  public void whenVinCodeGiven_andThatIsInvalid() {
    ApiParams apiParams = new ApiParams();
    apiParams.setVinCode("1FA6P8CF2H5302091111111");
    when(responseBuilderService.generateResponse(ResponseCodes.NO_DATA_FOR_VIN_CODE))
        .thenReturn(
            new GenericResponse(ResponseCodes.NO_DATA_FOR_VIN_CODE.getHttpStatus(), "",
                ResponseCodes.NO_DATA_FOR_VIN_CODE.getMsgId(), "", new Date()));
    Future<GenericResponse> response =
        vinCodeManager.checkAndConstruct(apiParams, null, null);
    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNotNull(genericResponse);
      Assert.assertEquals(ResponseCodes.NO_DATA_FOR_VIN_CODE.getHttpStatus(),
          genericResponse.getHttpStatus());
      Assert.assertEquals(ResponseCodes.NO_DATA_FOR_VIN_CODE.getMsgId(),
          genericResponse.getErrorMsgId());
    } catch (Exception e) {
      Assert.fail();
    }
  }
}
