package com.ford.sca.cap.vehicle.retrieve.domain;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserAccountBOTest {

  @Spy
  private UserAccountBO userAccountBO;

  @Test
  public void test_all_the_fields() {
    UserAccountPK userAccountPK = new UserAccountPK("123", 1);
    userAccountPK.setTenantId(1);
    userAccountPK.setUserId("124");
    userAccountBO.setUserAccountPK(userAccountPK);
    userAccountBO.setCapUserIDCountry("");
    userAccountBO.setCompanyName("");
    userAccountBO.setConsumerType("");
    userAccountBO.setCountryCode("");
    userAccountBO.setEmail("");
    userAccountBO.setFirstName("");
    userAccountBO.setLastName("");

    Assert.assertNotNull(userAccountPK.getTenantId());
    Assert.assertNotNull(userAccountPK.getUserId());
    Assert.assertNotNull(userAccountBO.getUserAccountPK());
    Assert.assertNotNull(userAccountBO.getCapUserIDCountry());
    Assert.assertNotNull(userAccountBO.getCompanyName());
    Assert.assertNotNull(userAccountBO.getConsumerType());
    Assert.assertNotNull(userAccountBO.getCountryCode());
    Assert.assertNotNull(userAccountBO.getEmail());
    Assert.assertNotNull(userAccountBO.getFirstName());
    Assert.assertNotNull(userAccountBO.getLastName());
  }
}
