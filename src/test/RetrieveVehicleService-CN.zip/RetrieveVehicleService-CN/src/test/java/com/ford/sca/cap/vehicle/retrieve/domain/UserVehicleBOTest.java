package com.ford.sca.cap.vehicle.retrieve.domain;

import java.util.Date;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserVehicleBOTest {

  @Spy
  private UserVehicleBO userVehicleBO;

  @Test
  public void test_all_the_fields() {
    UserVehiclePK userVehiclePK = new UserVehiclePK("123", 1, "01sdfsdf");
    userVehicleBO.setUserVehiclePK(userVehiclePK);
    userVehicleBO.setLatestOdometerReading(100000);
    userVehicleBO.setSyncVehicleIndicator("Y");
    userVehicleBO.setPrimaryVehicleIndicator("Y");
    userVehicleBO.setUserProvidedMileage(20000);
    userVehicleBO.setAverageDailyMiles(10);
    userVehicleBO.setMileageUpdateDate(new Date());
    userVehicleBO.setCountryCode("CHN");
    userVehicleBO.setAccessDate(new Date());
    userVehicleBO.setAssignedDealer("Sample");
    userVehicleBO.setColor("Silver");
    userVehicleBO.setConfigurationId(1);
    userVehicleBO.setCylinders(8);
    userVehicleBO.setDrivetrain("4 wheel");
    userVehicleBO.setDrivingConditionId(1);
    userVehicleBO.setEngineDisp("Test");
    userVehicleBO.setFuel("Gasoline");
    userVehicleBO.setHeadUnitTyp(1);
    userVehicleBO.setLatestMileage(30000);
    userVehicleBO.setLatestMileageDate(new Date());
    userVehicleBO.setLicensePlate("12dsdfsdf");
    userVehicleBO.setLifeStyleXML("test");
    userVehicleBO.setMake("Test");
    userVehicleBO.setMileageSource(2);
    userVehicleBO.setModel("Test");
    userVehicleBO.setModelType("Test");
    userVehicleBO.setModelYear("2101");
    userVehicleBO.setOwnerCycle("234");
    userVehicleBO.setOwnerIndicator("213");
    userVehicleBO.setPreferredDealer("test");
    userVehicleBO.setProductVariant("test");
    userVehicleBO.setPurchaseDate(new Date());
    userVehicleBO.setSellingDealer("test");
    userVehicleBO.setSeries("TEst");
    userVehicleBO.setWarrantyStartDate(new Date());
    userVehicleBO.setVhrReadyDate(new Date());
    userVehicleBO.setVersionDescription("test");
    userVehicleBO.setVehicleUpdateDate(new Date());
    userVehicleBO.setVehicleRole("test");
    userVehicleBO.setVehicleRegistrationDate(new Date());
    userVehicleBO.setVehicleName("test");
    userVehicleBO.setVehicleImageId(123);
    userVehicleBO.setTransmissionType("test");
    userVehicleBO.setTcuMileageDate(new Date());
    userVehicleBO.setTcuEnabled("Y");
    userVehicleBO.setSteeringWheelTyp(213);
    userVehicleBO.setSparkPlug(123);

    Assert.assertNotNull(userVehiclePK.getCapUserId());
    Assert.assertNotNull(userVehiclePK.getVin());
    Assert.assertNotNull(userVehiclePK.getTenantId());
    Assert.assertNotNull(userVehicleBO.getUserVehiclePK());
    Assert.assertNotNull(userVehicleBO.getLatestOdometerReading());
    Assert.assertNotNull(userVehicleBO.getSyncVehicleIndicator());
    Assert.assertNotNull(userVehicleBO.getPrimaryVehicleIndicator());
    Assert.assertNotNull(userVehicleBO.getUserProvidedMileage());
    Assert.assertNotNull(userVehicleBO.getAverageDailyMiles());
    Assert.assertNotNull(userVehicleBO.getMileageUpdateDate());
    Assert.assertNotNull(userVehicleBO.getCountryCode());
    Assert.assertNotNull(userVehicleBO.getAccessDate());
    Assert.assertNotNull(userVehicleBO.getAssignedDealer());
    Assert.assertNotNull(userVehicleBO.getColor());
    Assert.assertNotNull(userVehicleBO.getConfigurationId());
    Assert.assertNotNull(userVehicleBO.getCylinders());
    Assert.assertNotNull(userVehicleBO.getDrivetrain());
    Assert.assertNotNull(userVehicleBO.getDrivingConditionId());
    Assert.assertNotNull(userVehicleBO.getEngineDisp());
    Assert.assertNotNull(userVehicleBO.getFuel());
    Assert.assertNotNull(userVehicleBO.getHeadUnitTyp());
    Assert.assertNotNull(userVehicleBO.getLatestMileage());
    Assert.assertNotNull(userVehicleBO.getLatestMileageDate());
    Assert.assertNotNull(userVehicleBO.getLicensePlate());
    Assert.assertNotNull(userVehicleBO.getLifeStyleXML());
    Assert.assertNotNull(userVehicleBO.getMake());
    Assert.assertNotNull(userVehicleBO.getMileageSource());
    Assert.assertNotNull(userVehicleBO.getModel());
    Assert.assertNotNull(userVehicleBO.getModelType());
    Assert.assertNotNull(userVehicleBO.getModelYear());
    Assert.assertNotNull(userVehicleBO.getOwnerCycle());
    Assert.assertNotNull(userVehicleBO.getOwnerIndicator());
    Assert.assertNotNull(userVehicleBO.getPreferredDealer());
    Assert.assertNotNull(userVehicleBO.getProductVariant());
    Assert.assertNotNull(userVehicleBO.getPurchaseDate());
    Assert.assertNotNull(userVehicleBO.getSellingDealer());
    Assert.assertNotNull(userVehicleBO.getSeries());
    Assert.assertNotNull(userVehicleBO.getWarrantyStartDate());
    Assert.assertNotNull(userVehicleBO.getVhrReadyDate());
    Assert.assertNotNull(userVehicleBO.getVersionDescription());
    Assert.assertNotNull(userVehicleBO.getVehicleUpdateDate());
    Assert.assertNotNull(userVehicleBO.getVehicleRole());
    Assert.assertNotNull(userVehicleBO.getVehicleRegistrationDate());
    Assert.assertNotNull(userVehicleBO.getVehicleName());
    Assert.assertNotNull(userVehicleBO.getVehicleImageId());
    Assert.assertNotNull(userVehicleBO.getTransmissionType());
    Assert.assertNotNull(userVehicleBO.getTcuMileageDate());
    Assert.assertNotNull(userVehicleBO.getTcuEnabled());
    Assert.assertNotNull(userVehicleBO.getSteeringWheelTyp());
    Assert.assertNotNull(userVehicleBO.getSparkPlug());
  }
}
