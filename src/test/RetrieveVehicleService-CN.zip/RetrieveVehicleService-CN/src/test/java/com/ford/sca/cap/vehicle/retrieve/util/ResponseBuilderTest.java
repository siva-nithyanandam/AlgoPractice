package com.ford.sca.cap.vehicle.retrieve.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import com.ford.sca.cap.vehicle.retrieve.domain.UserVehicleBO;
import com.ford.sca.cap.vehicle.retrieve.domain.UserVehiclePK;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.CNMobileWebOther;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.NaMobileWebOther;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.transport.UserVehicle;
import java.util.Calendar;
import java.util.Date;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ResponseBuilderTest {


  @InjectMocks
  ResponseBuilder responseBuilderService;

  @Mock
  CacheUtil cacheUtil;

  @Spy
  private NaMobileWebOther naMobileWebOther;

  @Spy
  private CNMobileWebOther CNMobileWebOther;

  @Test
  public void validationResponseCodesSuccessTest() {
    ResponseCodes responseSuccess = ResponseCodes.SUCCESS;
    GenericResponse genericResponseExpected =
        new GenericResponse(responseSuccess.getHttpStatus(), responseSuccess.getResponseMessage());
    GenericResponse genericResponse = responseBuilderService.generateResponse(responseSuccess);
    boolean test1 =
        genericResponse.getHttpStatus().compareTo(genericResponseExpected.getHttpStatus()) == 0;
    boolean test2 =
        genericResponse.getResponseMessage().equals(genericResponseExpected.getResponseMessage());
    assertTrue(test1 && test2);
  }


  @Test
  public void validationResponseCodesFailureTest() {
    ResponseCodes responseFailed = ResponseCodes.CAN_NOT_FIND_IMPL;
    Date time = Calendar.getInstance().getTime();
    GenericResponse genericResponseExpected =
        new GenericResponse(responseFailed.getHttpStatus(), responseFailed.getResponseMessage(),
            responseFailed.getMsgId(), responseFailed.name(), time);
    when(cacheUtil.getErrorMessage(responseFailed.getMsgId())).thenReturn(responseFailed.name());
    GenericResponse genericResponse = responseBuilderService.generateResponse(responseFailed);
    boolean test1 =
        genericResponse.getHttpStatus().compareTo(genericResponseExpected.getHttpStatus()) == 0;
    boolean test2 = genericResponse.getStatus().equals(genericResponseExpected.getStatus());
    boolean test3 = genericResponse.getErrorMsg().equals(genericResponseExpected.getErrorMsg());
    boolean test4 = genericResponse.getErrorMsgId() == genericResponseExpected.getErrorMsgId();
    assertTrue(test1 && test2 && test3 && test4);
  }

  /**
   * When all required info is given, building user vehicle for Mobile NA.
   */
  @Test
  public void test_buildUserVehicle_for_mobile_na() {
    // GIVEN
    UserVehicleBO userVehicleBO = new UserVehicleBO();
    UserVehiclePK userVehiclePK = new UserVehiclePK();
    userVehiclePK.setCapUserId("989dd2d8-907a-40ea-8b9d-00b91902e9ba");
    userVehiclePK.setVin("1FA6P8CF2H5302091");
    userVehicleBO.setUserVehiclePK(userVehiclePK);

    userVehicleBO.setMileageUpdateDate(new Date());
    userVehicleBO.setAverageDailyMiles(10);
    userVehicleBO.setUserProvidedMileage(100);
    userVehicleBO.setPrimaryVehicleIndicator("Sample");
    userVehicleBO.setSyncVehicleIndicator("Sample");
    userVehicleBO.setLatestOdometerReading(70);
    // WHEN
    UserVehicle userVehicle =
        responseBuilderService.buildUserVehicle(userVehicleBO, new ApiParams(), naMobileWebOther);
    // THEN
    assertNotNull(userVehicle);
    assertNotNull(userVehicle.getEstimatedMileage());
  }

  /**
   * When all required info is given, building user vehicle for Mobile China.
   */
  @Test
  public void test_buildUserVehicle_for_mobile_china() {
    // GIVEN
    UserVehicleBO userVehicleBO = new UserVehicleBO();
    UserVehiclePK userVehiclePK = new UserVehiclePK();
    userVehiclePK.setCapUserId("989dd2d8-907a-40ea-8b9d-00b91902e9ba");
    userVehiclePK.setVin("1FA6P8CF2H5302091");
    userVehicleBO.setUserVehiclePK(userVehiclePK);

    userVehicleBO.setMileageUpdateDate(new Date());
    userVehicleBO.setAverageDailyMiles(10);
    userVehicleBO.setUserProvidedMileage(100);
    userVehicleBO.setPrimaryVehicleIndicator("Sample");
    userVehicleBO.setSyncVehicleIndicator("Sample");
    userVehicleBO.setLatestOdometerReading(70);
    // WHEN
    UserVehicle userVehicle =
        responseBuilderService.buildUserVehicle(userVehicleBO, new ApiParams(), CNMobileWebOther);
    // THEN
    assertNotNull(userVehicle);
    assertNull(userVehicle.getEstimatedMileage());
  }

  /**
   * When minimum info is given, building user vehicle.
   */
  @Test
  public void test_buildUserVehicle_1() {
    // GIVEN
    UserVehicleBO userVehicleBO = new UserVehicleBO();
    UserVehiclePK userVehiclePK = new UserVehiclePK();
    userVehiclePK.setCapUserId("989dd2d8-907a-40ea-8b9d-00b91902e9ba");
    userVehiclePK.setVin("1FA6P8CF2H5302091");
    userVehicleBO.setUserVehiclePK(userVehiclePK);

    userVehicleBO.setAverageDailyMiles(10);
    userVehicleBO.setUserProvidedMileage(100);
    // WHEN
    UserVehicle userVehicle =
        responseBuilderService.buildUserVehicle(userVehicleBO, new ApiParams(), naMobileWebOther);
    // THEN
    assertNotNull(userVehicle);
  }

  /**
   * When odometer reading is 0 and average daily miles is not set, building user vehicle.
   */
  @Test
  public void test_buildUserVehicle_2() {
    // GIVEN
    UserVehicleBO userVehicleBO = new UserVehicleBO();
    UserVehiclePK userVehiclePK = new UserVehiclePK();
    userVehiclePK.setCapUserId("989dd2d8-907a-40ea-8b9d-00b91902e9ba");
    userVehiclePK.setVin("1FA6P8CF2H5302091");
    userVehicleBO.setUserVehiclePK(userVehiclePK);

    userVehicleBO.setMileageUpdateDate(new Date());
    // userVehicleBO.setAverageDailyMiles(10);
    userVehicleBO.setUserProvidedMileage(100);
    userVehicleBO.setPrimaryVehicleIndicator("Sample");
    userVehicleBO.setSyncVehicleIndicator("Sample");
    userVehicleBO.setLatestOdometerReading(0);
    // WHEN
    UserVehicle userVehicle =
        responseBuilderService.buildUserVehicle(userVehicleBO, new ApiParams(), naMobileWebOther);
    // THEN
    assertNotNull(userVehicle);
  }

  /**
   * When odometer reading is 0 and user provided mileage is not set, building user vehicle.
   */
  @Test
  public void test_buildUserVehicle_3() {
    // GIVEN
    UserVehicleBO userVehicleBO = new UserVehicleBO();
    UserVehiclePK userVehiclePK = new UserVehiclePK();
    userVehiclePK.setCapUserId("989dd2d8-907a-40ea-8b9d-00b91902e9ba");
    userVehiclePK.setVin("1FA6P8CF2H5302091");
    userVehicleBO.setUserVehiclePK(userVehiclePK);

    userVehicleBO.setMileageUpdateDate(new Date());
    userVehicleBO.setAverageDailyMiles(10);
    userVehicleBO.setPrimaryVehicleIndicator("Sample");
    userVehicleBO.setSyncVehicleIndicator("Sample");
    userVehicleBO.setLatestOdometerReading(0);
    // WHEN
    UserVehicle userVehicle =
        responseBuilderService.buildUserVehicle(userVehicleBO, new ApiParams(), naMobileWebOther);
    // THEN
    assertNotNull(userVehicle);
  }
}
