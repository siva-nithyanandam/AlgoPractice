package com.ford.sca.cap.vehicle.retrieve.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ConstantsTest {
  @Test(expected = InvocationTargetException.class)
  public void privateConstructor()
      throws InstantiationException, IllegalAccessException, IllegalArgumentException,
      InvocationTargetException, NoSuchMethodException, SecurityException {
    Constructor<Constants> c = Constants.class.getDeclaredConstructor();
    c.setAccessible(true);
    Constants con = c.newInstance();
    con.toString();
  }
}
