package com.ford.sca.cap.vehicle.retrieve.util;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class GenericAssisterTest {


  @Test
  public void isNotNumericTest() {

    boolean testNotIntegerValue1 = GenericAssister.isNotNumeric("abcd");
    boolean testNotIntegerValue2 = GenericAssister.isNotNumeric("43.36");
    boolean testNotIntegerValue3 = GenericAssister.isNotNumeric("");
    boolean testNotIntegerValue4 = GenericAssister.isNotNumeric(null);
    boolean testNotIntegerValue5 = GenericAssister.isNotNumeric("40a30");
    boolean testIntegerValue = GenericAssister.isNotNumeric("123");

    assertTrue(
        testNotIntegerValue1 && testNotIntegerValue2 && testNotIntegerValue3 && testNotIntegerValue4
            && testNotIntegerValue5 && !testIntegerValue);

  }

  @Test
  public void isNumericTest() {

    boolean testNotIntegerValue1 = GenericAssister.isNumeric("abcd");
    boolean testNotIntegerValue2 = GenericAssister.isNumeric("43.36");
    boolean testNotIntegerValue3 = GenericAssister.isNumeric("");
    boolean testNotIntegerValue4 = GenericAssister.isNumeric(null);
    boolean testNotIntegerValue5 = GenericAssister.isNumeric("40a30");
    boolean testNotIntegerValue6 = GenericAssister.isNumeric("-");
    boolean testNotIntegerValue7 = GenericAssister.isNumeric("-44a23");
    boolean testNotIntegerValue8 = GenericAssister.isNumeric("-a");
    boolean testIntegerValue1 = GenericAssister.isNumeric("123");
    boolean testIntegerValue2 = GenericAssister.isNumeric("-123");
    boolean testIntegerValue3 = GenericAssister.isNumeric("-1");

    assertTrue(!testNotIntegerValue1 && !testNotIntegerValue2 && !testNotIntegerValue3
        && !testNotIntegerValue4 && !testNotIntegerValue5 && !testNotIntegerValue6
        && !testNotIntegerValue7 && !testNotIntegerValue8
        && testIntegerValue1 && testIntegerValue2 && testIntegerValue3);

  }

  @Test
  public void isEmptyTest() {

    boolean testEmptyValue1 = GenericAssister.isEmptyString(null);
    boolean testEmptyValue2 = GenericAssister.isEmptyString("");
    boolean testEmptyValue3 = GenericAssister.isEmptyString("   ");
    boolean testNotEmptyValue1 = GenericAssister.isEmptyString(" aaa sssd ");
    boolean testNotEmptyValue2 = GenericAssister.isEmptyString("asw");

    assertTrue(testEmptyValue1 && testEmptyValue2 && testEmptyValue3 && !testNotEmptyValue1
        && !testNotEmptyValue2);

  }

  @Test
  public void isNotEmptyTest() {

    boolean testEmptyValue1 = GenericAssister.isNotEmptyString(null);
    boolean testEmptyValue2 = GenericAssister.isNotEmptyString("");
    boolean testEmptyValue3 = GenericAssister.isNotEmptyString("   ");
    boolean testNotEmptyValue1 = GenericAssister.isNotEmptyString(" aaa sssd ");
    boolean testNotEmptyValue2 = GenericAssister.isNotEmptyString("asw");

    assertTrue(!testEmptyValue1 && !testEmptyValue2 && !testEmptyValue3 && testNotEmptyValue1
        && testNotEmptyValue2);

  }

  @Test
  public void isAllStringsNotEmptyTest() {

    boolean testEmptyStrings = GenericAssister.isAllStringsNotEmpty(null, null, "  ");
    boolean testStrings = GenericAssister.isAllStringsNotEmpty("abs", "  ", "sadok");
    boolean testNotEmptyStrings = GenericAssister.isAllStringsNotEmpty("sadok", "chebil", "ford");

    assertTrue(!testEmptyStrings && !testStrings && testNotEmptyStrings);

  }

  @Test
  public void isAnyStringNotEmptyTest() {

    boolean testEmptyStrings = GenericAssister.isAnyStringNotEmpty(null, null, "  ");
    boolean testStrings = GenericAssister.isAnyStringNotEmpty("abs", "  ", "sadok");
    boolean testNotEmptyStrings = GenericAssister.isAnyStringNotEmpty("sadok", "chebil", "ford");

    assertTrue(!testEmptyStrings && testStrings && testNotEmptyStrings);
  }


  @Test
  public void truncateStringTest() {

    boolean testValidString = GenericAssister.truncateString("fordmotor", 4).equals("ford");
    boolean testNull = GenericAssister.truncateString(null, 4) == null;
    boolean testEmpty = GenericAssister.truncateString("", 0).equals("");
    boolean testInvalidString = GenericAssister.truncateString("fordmotor", 19).equals("fordmotor");

    assertTrue(testValidString && testNull && testEmpty && testInvalidString);
  }

  @Test
  public void isCollectionNotEmptyTest() {
    boolean testNullCollection = GenericAssister.isCollectionNotEmpty(null);
    boolean testEmptyCollection = GenericAssister.isCollectionNotEmpty(new ArrayList<>());
    List<Integer> list = new ArrayList<>();
    list.add(1);
    list.add(2);
    list.add(3);
    boolean testNotEmptyCollection = GenericAssister.isCollectionNotEmpty(list);

    assertTrue(!testNullCollection && !testEmptyCollection && testNotEmptyCollection);
  }


}
