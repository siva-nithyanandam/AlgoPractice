package com.ford.sca.cap.vehicle.retrieve.validators;

import static org.mockito.Mockito.when;

import com.ford.sca.cap.vehicle.retrieve.service.MasterRuleEngine;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.CNMobileWebOther;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.NaMobileWebOther;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.Future;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BrandCodeManagerTest {

  @InjectMocks
  private BrandCodeManager brandCodeManager;

  @Spy
  private NaMobileWebOther naMobileWebOther;

  @Spy
  private CNMobileWebOther CNMobileWebOther;

  @Mock
  private ResponseBuilder responseBuilderService;

  /**
   * When a given brand code is empty, ignore it and return success validation.
   */
  @Test
  public void whenBrandCodeEmpty_returnSuccess() {
    ApiParams apiParams = new ApiParams();

    Future<GenericResponse> response =
        brandCodeManager.checkAndConstruct(apiParams, null, null);
    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNull(genericResponse);
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * When a valid brand code is given in the request for NA, return success
   */
  @Test
  public void whenBrandCodeGiven_andThatIsValidForNA() {
    ApiParams apiParams = new ApiParams();
    apiParams.setBrandCode("F");
    Future<GenericResponse> response =
        brandCodeManager.checkAndConstruct(apiParams, null, naMobileWebOther);
    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNull(genericResponse);
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * When a valid brand code is given in the request for CHINA, return success
   */
  @Test
  public void whenBrandCodeGiven_andThatIsValidForChina() {
    ApiParams apiParams = new ApiParams();
    apiParams.setBrandCode("F");
    Future<GenericResponse> response =
        brandCodeManager.checkAndConstruct(apiParams, null, CNMobileWebOther);
    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNull(genericResponse);
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * When a invalid brand code is given in the request for NA, return failure
   */
  @Test
  public void whenBrandCodeGiven_andThatIsInvalidForNA() {
    ApiParams apiParams = new ApiParams();
    apiParams.setBrandCode("A");
    when(responseBuilderService.generateResponse(ResponseCodes.BRAND_CODE_NOT_EXIST))
        .thenReturn(
            new GenericResponse(ResponseCodes.BRAND_CODE_NOT_EXIST.getHttpStatus(), "",
                ResponseCodes.BRAND_CODE_NOT_EXIST.getMsgId(), "", new Date()));
    Future<GenericResponse> response =
        brandCodeManager.checkAndConstruct(apiParams, null, naMobileWebOther);
    verifyFailureBrandCodeValidation(response);
  }

  private void verifyFailureBrandCodeValidation(Future<GenericResponse> response) {
    try {
      GenericResponse genericResponse = response.get();
      Assert.assertNotNull(genericResponse);
      Assert.assertEquals(ResponseCodes.BRAND_CODE_NOT_EXIST.getHttpStatus(),
          genericResponse.getHttpStatus());
      Assert.assertEquals(ResponseCodes.BRAND_CODE_NOT_EXIST.getMsgId(),
          genericResponse.getErrorMsgId());
    } catch (Exception e) {
      Assert.fail();
    }
  }

  /**
   * When a invalid brand code is given in the request for CHINA, return failure
   */
  @Test
  public void whenBrandCodeGiven_andThatIsInvalidForChina() {
    ApiParams apiParams = new ApiParams();
    apiParams.setBrandCode("B");
    when(responseBuilderService.generateResponse(ResponseCodes.BRAND_CODE_NOT_EXIST))
        .thenReturn(
            new GenericResponse(ResponseCodes.BRAND_CODE_NOT_EXIST.getHttpStatus(), "",
                ResponseCodes.BRAND_CODE_NOT_EXIST.getMsgId(), "", new Date()));
    MasterRuleEngine masterRuleEngine = Mockito.mock(MasterRuleEngine.class);
    when(masterRuleEngine.getBrandCodeMap()).thenReturn(new HashMap<>());
    Future<GenericResponse> response =
        brandCodeManager.checkAndConstruct(apiParams, null, masterRuleEngine);
    verifyFailureBrandCodeValidation(response);
  }
}
