package com.ford.sca.cap.vehicle.retrieve.service.statics;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class FlagsTest {

  @Test
  public void test_flags() {
    Assert.assertTrue(Flags.ACTIVE.equals("Y"));
    Assert.assertTrue(Flags.ENABLED.equals("Y"));
  }
}
