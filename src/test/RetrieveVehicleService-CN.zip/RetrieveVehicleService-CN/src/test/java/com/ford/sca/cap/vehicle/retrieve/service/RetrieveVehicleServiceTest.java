package com.ford.sca.cap.vehicle.retrieve.service;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import com.ford.sca.cap.domain.AppCodeBO;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.CNMobileWebOther;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.NaMobileWebOther;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.RuleEngineInterface;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.transport.MaintainVehicleCreateRequest;
import com.ford.sca.cap.vehicle.retrieve.util.CacheUtil;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RetrieveVehicleServiceTest {

  @InjectMocks
  private RetrieveVehicleService retrieveVehicleService;

  @Mock
  private NaMobileWebOther naMobileWebOtherService;

  @Mock
  private CNMobileWebOther CNMobileWebOtherService;

  @Mock
  private CacheUtil cacheUtil;

  @Mock
  private List<RuleEngineInterface> ruleEngineInterfaces;

  @Mock
  private ResponseBuilder responseBuilderService;


  /**
   * Ensure the maintainUserVehicle will fail for inappropriate interface provided
   */


  @Test
  public void createUserVehicleFailure1() {

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId("100581");
    apiParams.setUserId("9999-9999-9999-9999");
    HttpServletRequest request = null;
    MaintainVehicleCreateRequest maintainVehicleCreateRequest = new MaintainVehicleCreateRequest();

    when(cacheUtil.getAppCodeDtls(Integer.valueOf(apiParams.getAppId()))).thenReturn(new AppCodeBO());
    when(responseBuilderService.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR)).thenReturn(
        new GenericResponse(ResponseCodes.INTERNAL_SERVER_ERROR.getHttpStatus(), "aa",
            ResponseCodes.INTERNAL_SERVER_ERROR.getMsgId(), "aa", new Date()));
    GenericResponse response = retrieveVehicleService.retrieveVehicle(request,
        apiParams);
    boolean test = response.getHttpStatus().value() == 500;
    assertTrue(test);
  }

  @Test
  public void createUserVehicleFailure3() {

    ApiParams apiParams = new ApiParams();
    apiParams.setAppId("100581");
    apiParams.setUserId("9999-9999-9999-9999");
    HttpServletRequest request = null;

    when(cacheUtil.getAppCodeDtls(Integer.valueOf(apiParams.getAppId()))).thenReturn(null);
    when(responseBuilderService.generateResponse(ResponseCodes.APP_CODE_NOT_EXISTS_IN_DB))
        .thenReturn(
            new GenericResponse(ResponseCodes.APP_CODE_NOT_EXISTS_IN_DB.getHttpStatus(), "aa",
                ResponseCodes.APP_CODE_NOT_EXISTS_IN_DB.getMsgId(), "aa", new Date()));
    GenericResponse response = retrieveVehicleService.retrieveVehicle(request,
        apiParams);
    assertTrue(response.getHttpStatus() == ResponseCodes.APP_CODE_NOT_EXISTS_IN_DB.getHttpStatus());
  }

  /**
   * Ensure the maintainUserVehicle will return a correct response when validation failed
   */

  @Test
  public void createUserVehicleFailure2() {
    ApiParams apiParams = new ApiParams();
    apiParams.setAppId("100581");
    apiParams.setUserId("9999-9999-9999-9999");
    HttpServletRequest request = null;
    MaintainVehicleCreateRequest maintainVehicleCreateRequest = new MaintainVehicleCreateRequest();

    AppCodeBO appCodeBO = new AppCodeBO();
    appCodeBO.setValidationGrpCode("MOBILE_NA");
    when(cacheUtil.getAppCodeDtls(Integer.valueOf(apiParams.getAppId()))).thenReturn(appCodeBO);

    when(naMobileWebOtherService.isRequestBehalfOfThisImpl(any())).thenReturn(true);
    when(naMobileWebOtherService.getGroupTypes()).thenReturn(new HashSet<String>() {{
      add("MOBILE_NA");
    }});
    GenericResponse errResponse = new GenericResponse(HttpStatus.BAD_REQUEST, "missing whatever",
        "MSG_400", "param is missing", new Date());
    when(naMobileWebOtherService.validate(any(), any())).thenReturn(Optional.of(errResponse));

    GenericResponse response = retrieveVehicleService
        .retrieveVehicle(request, apiParams);

    boolean test1 = response.getStatus().equals("missing whatever");
    boolean test2 = response.getHttpStatus().value() == HttpStatus.BAD_REQUEST.value();
    assertTrue(test1 && test2);

  }

  /**
   * Ensure the maintainUserVehicle will return a correct response when validation success
   */
  @Test
  public void createUserVehicleSuccess() {
    ApiParams apiParams = new ApiParams();
    apiParams.setAppId("100581");
    apiParams.setUserId("9999-9999-9999-9999");
    HttpServletRequest request = null;
    MaintainVehicleCreateRequest maintainVehicleCreateRequest = new MaintainVehicleCreateRequest();

    AppCodeBO appCodeBO = new AppCodeBO();
    appCodeBO.setValidationGrpCode("MOBILE_NA");
    when(cacheUtil.getAppCodeDtls(Integer.valueOf(apiParams.getAppId()))).thenReturn(appCodeBO);

    when(naMobileWebOtherService.isRequestBehalfOfThisImpl(any())).thenReturn(true);
    when(naMobileWebOtherService.getGroupTypes())
        .thenReturn(new HashSet<String>() {{
          add("MOBILE_NA");
        }});
    when(naMobileWebOtherService.validate(any(), any())).thenReturn(Optional.empty());
    when(naMobileWebOtherService.triggerDBProcesses(any(), any())).thenReturn(null);
    doNothing().when(naMobileWebOtherService).triggerPostDBProcesses(any());

    GenericResponse response = retrieveVehicleService
        .retrieveVehicle(request, apiParams);
    assertNull(response);
  }
}
