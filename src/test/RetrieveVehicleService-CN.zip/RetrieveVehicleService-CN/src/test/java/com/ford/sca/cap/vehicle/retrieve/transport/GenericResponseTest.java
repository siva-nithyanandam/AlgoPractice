package com.ford.sca.cap.vehicle.retrieve.transport;

import java.util.Date;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

@RunWith(MockitoJUnitRunner.Silent.class)
public class GenericResponseTest {

  @Spy
  private GenericResponse genericResponse;

  @Test
  public void test_all_the_fields() {

    genericResponse.setResponseMessage("");
    genericResponse.setStatus("");
    genericResponse.setErrorMsg("");
    genericResponse.setErrorMsgId("");
    genericResponse.setErrorTime(new Date());
    genericResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);

    Assert.assertNotNull(genericResponse.getResponseMessage());
    Assert.assertNotNull(genericResponse.getStatus());
    Assert.assertNotNull(genericResponse.getErrorMsg());
    Assert.assertNotNull(genericResponse.getErrorMsgId());
    Assert.assertNotNull(genericResponse.getErrorTime());
    Assert.assertNotNull(genericResponse.getHttpStatus());
  }
}
