package com.ford.sca.cap.vehicle.retrieve.service.statics;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SourceCodeTest {

  @Test
  public void sourceCodeTest() {

    SourceCode SYNC_MY_RIDE = SourceCode.SYNC_MY_RIDE;
    SourceCode MOTOR_CRAFT = SourceCode.MOTOR_CRAFT;
    SourceCode FORD_CREDIT = SourceCode.FORD_CREDIT;
    SourceCode FORD_PASS = SourceCode.FORD_PASS;
    SourceCode LINCOLN_WAY = SourceCode.LINCOLN_WAY;
    SourceCode FORD_GOBIKE = SourceCode.FORD_GOBIKE;

    boolean test1 = SYNC_MY_RIDE.getSourceCd().equals("100392");
    boolean test2 = MOTOR_CRAFT.getSourceCd().equals("100423");
    boolean test3 = FORD_CREDIT.getSourceCd().equals("100424");
    boolean test4 = FORD_PASS.getSourceCd().equals("100504");
    boolean test5 = LINCOLN_WAY.getSourceCd().equals("100530");
    boolean test6 = FORD_GOBIKE.getSourceCd().equals("100532");

    assertTrue(test1 && test2 && test3 && test4 && test5 && test6);

  }

}
