package com.ford.sca.cap.vehicle.retrieve.service.ruleengines;

import com.ford.sca.cap.vehicle.retrieve.domain.UserVehicleBO;
import com.ford.sca.cap.vehicle.retrieve.service.MasterRuleEngine;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.util.LoggerBuilder;
import com.ford.sca.cap.vehicle.retrieve.validators.Validator;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class NaMobileWebOther extends MasterRuleEngine {

  private static final Set<String> GROUP_TYPES = new HashSet<>();
  private static final Locale LOCALE = Locale.US;

  static {
    GROUP_TYPES.add("MOBILE_NA");
    GROUP_TYPES.add("WEB_NA");
    GROUP_TYPES.add("OTHER_NA");
  }

  @Override
  public Set getGroupTypes() {
    return GROUP_TYPES;
  }

  @Override
  public Locale getLocale() {
    return LOCALE;
  }

  @Override
  public List<Validator> getValidators() {
    final List<Validator> validatorsForNA = new ArrayList<>();
    validatorsForNA.add(capUserIdManager);
    validatorsForNA.add(vinCodeManager);
    validatorsForNA.add(brandCodeManager);
    return validatorsForNA;
  }

  @Override
  public Integer calculateEstimatedMileage(final UserVehicleBO userVehicleBO,
      final ApiParams apiParams) {
    Integer estimatedMileage = null;
    LoggerBuilder.printInfo(log, logger -> logger.appId(apiParams.getAppId())
        .capUserId(apiParams.getUserId())
        .message("processing_RetrieveVehiclesServiceImpl_calculateEstimatedMileage"));

    if (null != userVehicleBO.getMileageUpdateDate() && null != userVehicleBO.getAverageDailyMiles()
        && null != userVehicleBO.getUserProvidedMileage()) {
      final long currentTimeInMillis = System.currentTimeMillis();
      final long mileageUpdateTimeInMillis = userVehicleBO.getMileageUpdateDate().getTime();
      final long noOfDays =
          (currentTimeInMillis - mileageUpdateTimeInMillis) / (24 * 60 * 60 * 1000);

      estimatedMileage = (int) (userVehicleBO.getUserProvidedMileage()
          + (noOfDays * userVehicleBO.getAverageDailyMiles()));
    }
    return estimatedMileage;
  }

  //Uncomment and override any of below methods whenever applicable

  /*@Override
  public CriteriaQuery generateQuery(final ApiParams apiParams) {
    return super.generateQuery(apiParams);
  }*/

  /*@Override
  @LogAround
  public GenericResponse triggerDBProcesses(ApiParams apiParams,
      MaintainVehicleUpdateRequest maintainVehicleRequest, RequestMode requestMode,
      HttpServletRequest request) {
    return super.triggerDBProcesses(apiParams, maintainVehicleRequest, requestMode, request);
  }*/

  /*@Override
  public void publishAuditMessage_request(HttpServletRequest request,
      MaintainVehicleUpdateRequest maintainVehicleRequest, ApiParams apiParams) {
    super.publishAuditMessage_request(request, maintainVehicleRequest, apiParams);
  }*/

  /*@Override
  public void publishAuditMessage_response(HttpServletRequest request,
      GenericResponse response, MaintainVehicleUpdateRequest maintainVehicleRequest,
      ApiParams apiParams) {
    super.publishAuditMessage_response(request, response, maintainVehicleRequest, apiParams);
  }*/

  /*@Override
  @LogAround
  public void triggerPostDBProcesses(ApiParams apiParams,
      MaintainVehicleUpdateRequest maintainVehicleRequest, RequestMode requestMode) {
    super.triggerPostDBProcesses(apiParams, maintainVehicleRequest, requestMode);
  }*/

  /*@Override
  public Map<String, String> getBrandCodeMap() {
    return super.getBrandCodeMap();
  }*/
}
