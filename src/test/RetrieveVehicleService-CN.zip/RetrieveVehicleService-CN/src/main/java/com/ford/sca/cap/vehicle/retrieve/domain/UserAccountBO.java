package com.ford.sca.cap.vehicle.retrieve.domain;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

@Entity
@Setter
@Getter
@Table(name = "MCAPP01_USER")
public class UserAccountBO {

  @EmbeddedId
  private UserAccountPK userAccountPK;

  @Column(name = "[CAPC06_COUNTRY_ISO3_C]")
  private String countryCode;

  @Column(name = "[CAPP01_USER_TYP_C]")
  private String consumerType;

  @Column(name = "[CAPP01_USER_COUNTRY_C]")
  private String capUserIDCountry;

  @Nationalized
  @Column(name = "[CAPP01_COMP_N]")
  private String companyName;

  @Nationalized
  @Column(name = "[CAPP01_EMAIL_ADDR_X]")
  private String email;

  @Nationalized
  @Column(name = "[CAPP01_FIRST_N]")
  private String firstName;

  @Nationalized
  @Column(name = "[CAPP01_LAST_N]")
  private String lastName;
}
