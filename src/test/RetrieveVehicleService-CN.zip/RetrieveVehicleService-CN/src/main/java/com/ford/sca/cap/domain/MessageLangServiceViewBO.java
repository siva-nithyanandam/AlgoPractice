package com.ford.sca.cap.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

@Getter
@Setter
@Entity
@Table(name = "MCAPV11_MESSAGE_LANG_SERVICE_VW")
public class MessageLangServiceViewBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[MESSAGE_CODE]")
  private String messageCode;
  
  @Nationalized
  @Column(name = "[MESSAGE_DESC]")
  private String messageDesc;
}
