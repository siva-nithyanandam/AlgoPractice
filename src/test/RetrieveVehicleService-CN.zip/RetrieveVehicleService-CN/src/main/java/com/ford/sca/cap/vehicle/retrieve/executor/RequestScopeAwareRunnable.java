package com.ford.sca.cap.vehicle.retrieve.executor;

import java.util.Map;
import org.slf4j.MDC;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

public class RequestScopeAwareRunnable implements Runnable {

  private final Runnable task;
  private final RequestAttributes context;

  // mappedContextMap is set when new Child() is called
  private final Map<String, String> mappedContextMap = MDC.getCopyOfContextMap();

  /**
   * To construct RequestScopeAwareRunnable.
   * @param task Runnable
   * @param context RequestAttributes
   */
  public RequestScopeAwareRunnable(final Runnable task, final RequestAttributes context) {
    this.task = task;
    this.context = context;
  }

  @Override
  public void run() {
    MDC.setContextMap(mappedContextMap);
    if (context != null) {
      RequestContextHolder.setRequestAttributes(context);
    }
    try {
      task.run();
    } finally {
      RequestContextHolder.resetRequestAttributes();
    }
  }
}
