package com.ford.sca.cap.vehicle.retrieve.transport;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MaintainVehicleCreateRequest extends MaintainVehicleUpdateRequest
    implements Serializable {

  private static final long serialVersionUID = -622904980386711284L;

  private Vehicle vehicle;

}
