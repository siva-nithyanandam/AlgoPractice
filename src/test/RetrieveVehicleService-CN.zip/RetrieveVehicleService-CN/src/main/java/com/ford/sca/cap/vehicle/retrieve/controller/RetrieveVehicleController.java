package com.ford.sca.cap.vehicle.retrieve.controller;

import com.ford.sca.cap.vehicle.retrieve.service.RetrieveVehicleService;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.AuditActivityUtil;
import com.ford.sca.cap.vehicle.retrieve.util.Constants;
import com.ford.sca.cap.vehicle.retrieve.util.GenericAssister;
import com.ford.sca.cap.vehicle.retrieve.util.LogAround;
import com.ford.sca.cap.vehicle.retrieve.util.LoggerBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import com.ford.sca.cap.vehicle.retrieve.util.ScaCapApiResponses;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@Slf4j
@RestController
@RequestMapping(path = "/rv")
@Api("Retrieve Vehicle Service")
public class RetrieveVehicleController {

  @Autowired
  private RetrieveVehicleService retrieveVehicleService;

  @Autowired
  private AuditActivityUtil auditActivityUtil;

  @Autowired
  private ResponseBuilder responseBuilder;

  /**
   * To return an error when invalid url or missing request attributes.
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @return {@link GenericResponse}
   */
  @ApiIgnore
  @GetMapping({"", "/", "/consumerAccounts", "/consumerAccounts/{CAPUserID}",
      "/consumerAccounts/vehicles"})
  public GenericResponse throwRequiredFieldsMissing(final HttpServletRequest request,
      final HttpServletResponse response) {
    auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);
    LoggerBuilder.printError(log, logger -> logger.methodName("throwRequiredFieldsMissing")
        .action(Constants.ACTION_FAILED).message("PreCondition Not Satisfied"));
    response
        .setStatus(ResponseCodes.INVALID_REQUEST_URL.getHttpStatus().value());
    return responseBuilder.generateResponse(ResponseCodes.INVALID_REQUEST_URL);
  }

  /**
   * To return an error when invalid url or missing request attributes.
   *
   * @param vinCode Vin Code
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @return {@link GenericResponse}
   */
  @ApiIgnore
  @GetMapping({"/consumerAccounts/vehicles/{vinCode}"})
  public GenericResponse throwRequiredFieldsMissingForCapUserID(
      @ApiParam("User VIN.") @PathVariable final String vinCode,
      final HttpServletRequest request, final HttpServletResponse response) {
    auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);
    LoggerBuilder.printError(log, logger -> logger
        .methodName("throwRequiredFieldsMissingForCapUserID").action(Constants.ACTION_FAILED)
        .message("PreCondition Not Satisfied"));
    response.setStatus(ResponseCodes.INVALID_REQUEST_URL.getHttpStatus().value());
    return responseBuilder.generateResponse(ResponseCodes.INVALID_REQUEST_URL);
  }

  /**
   * To retrieve vehicle details for user.
   *
   * @param capUserId User ID
   * @param appId App ID
   * @param brandCode Brand Code
   * @param request {@link HttpServletRequest}
   * @param response {@link HttpServletResponse}
   */
  @PreAuthorize("#oauth2.hasScope('vehicle.read')")
  @ScaCapApiResponses
  @ApiOperation(value = "retrieveVehicles", nickname = "retrieveVehicles")
  @GetMapping({"/consumerAccounts/{CAPUserID}/vehicles"})
  @LogAround
  public GenericResponse retrieveVehiclesForUser(
      @ApiParam(value = "capUserId.", required = true)
      @PathVariable("CAPUserID") final String capUserId,
      @ApiParam(value = "appId.", required = true) @RequestParam("AppID") final String appId,
      @ApiParam("brandCode.") @RequestParam(required = false) final String brandCode,
      final HttpServletRequest request, final HttpServletResponse response) {

    return getVehicleDetails(capUserId, appId, null, brandCode, request, response);
  }

  /**
   * To retrieve vehicle details for user and vin code.
   *
   * @param capUserId User ID
   * @param appId App ID
   * @param vinCode Vin code
   * @param brandCode BrandCode
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  @PreAuthorize("#oauth2.hasScope('vehicle.read')")
  @ScaCapApiResponses
  @ApiOperation(value = "retrieveVehicleForVinCode", nickname = "retrieveVehicleForVinCode")
  @GetMapping({"/consumerAccounts/{CAPUserID}/vehicles/{vinCode}"})
  @LogAround
  public GenericResponse retrieveVehicleByVinOrbrandcodeForUser(
      @ApiParam(value = "capUserId.", required = true)
      @PathVariable("CAPUserID") final String capUserId,
      @ApiParam(value = "appId.", required = true) @RequestParam("AppID") final String appId,
      @ApiParam(value = "vinCode.", required = true) @PathVariable final String vinCode,
      @ApiParam("brandCode.") @RequestParam(required = false) final String brandCode,
      final HttpServletRequest request, final HttpServletResponse response) {

    return getVehicleDetails(capUserId, appId, vinCode, brandCode, request, response);
  }

  private GenericResponse getVehicleDetails(final String capUserId, final String appId,
      final String vinCode, final String brandCode, final HttpServletRequest request,
      final HttpServletResponse response) {

    GenericResponse genericResp;
    auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);
    LoggerBuilder.printInfo(log,
        logger -> logger.capUserId(capUserId).appId(appId).vinCode(vinCode).brandCode(brandCode)
            .message("Triggering retrieveVehiclesForUser").httpMethod(RequestMethod.GET.name()));

    //Populate preliminary fields
    final ApiParams apiParams = retrieveVehicleService
        .buildApiParams(appId, capUserId, vinCode, brandCode);

    //Publish audit message for request
    auditActivityUtil.publishAuditMessage_request(request, apiParams);

    //Do the AppID validation first - as it decides the rule engine to start the process
    if (GenericAssister.isEmptyString(appId)) {
      LoggerBuilder.printError(log,
          logger -> logger.capUserId(appId).message("App code not provided"));
      genericResp = responseBuilder.generateResponse(ResponseCodes.APP_CODE_NOT_FOUND_IN_REQ);
    } else if (GenericAssister.isNotNumeric(appId)) {
      LoggerBuilder.printError(log, logger -> logger.capUserId(capUserId)
          .appId(appId).message("AppId code not in number format"));
      genericResp = responseBuilder.generateResponse(ResponseCodes.APP_CODE_NOT_IN_NUMBER_FORMAT);
    } else {
      //Trigger retrieve vehicle process
      genericResp = retrieveVehicleService.retrieveVehicle(request, apiParams);
    }
    //Set HTTP status in the response
    response.setStatus(genericResp.getHttpStatus().value());

    //Publish audit message for response
    auditActivityUtil.publishAuditMessage_response(request, genericResp, apiParams);

    return genericResp;
  }
}
