package com.ford.sca.cap.vehicle.retrieve.validators;

import com.ford.sca.cap.vehicle.retrieve.domain.UserAccountPK;
import com.ford.sca.cap.vehicle.retrieve.repository.UserAccountRepository;
import com.ford.sca.cap.vehicle.retrieve.service.MasterRuleEngine;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.GenericAssister;
import com.ford.sca.cap.vehicle.retrieve.util.LogAround;
import com.ford.sca.cap.vehicle.retrieve.util.LoggerBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.InvalidDataAccessResourceUsageException;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

/**
 * To validate CAP User Id.
 */
@Slf4j
@Service
public class CapUserIdManager implements Validator {

  @Autowired
  private UserAccountRepository userAccountRepository;

  @Autowired
  private ResponseBuilder responseBuilder;

  /**
   * This method validates if the given capUserId is valid or not.
   *
   * @param apiParams Given API Params
   * @param request HTTP request
   * @return Future of {@link GenericResponse}
   */
  @Override
  @LogAround
  public Future<GenericResponse> checkAndConstruct(final ApiParams apiParams,
      final HttpServletRequest request, final MasterRuleEngine ruleEngine) {

    GenericResponse genericResponse = null;
    if (GenericAssister.isEmptyString(apiParams.getUserId())) {
      LoggerBuilder.printError(log, logger -> logger.capUserId(apiParams.getUserId())
          .appId(apiParams.getAppId()).message("CAPUserID not provided"));
      genericResponse =
          responseBuilder.generateResponse(ResponseCodes.CAP_USER_ID_NOT_FOUND_IN_REQ);
    } else {
      try {
        if (!userAccountRepository
            .existsById(new UserAccountPK(apiParams.getUserId(), apiParams.getTenantId()))) {
          LoggerBuilder.printError(log, logger -> logger.capUserId(apiParams.getUserId()).appId(
              apiParams.getAppId()).message(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.name()));
          genericResponse = responseBuilder
              .generateResponse(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP);
        }
      } catch (InvalidDataAccessResourceUsageException invalidDataException) {
        LoggerBuilder.printError(log, logger -> logger.capUserId(apiParams.getUserId())
            .appId(apiParams.getAppId()).message(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP.name())
            .exceptionMessage(invalidDataException.getMessage()).exception(invalidDataException));
        genericResponse =
            responseBuilder.generateResponse(ResponseCodes.CAP_USER_NOT_EXISTS_IN_CAP);
      } catch (Exception ex) {
        LoggerBuilder.printError(log, logger -> logger.capUserId(apiParams.getUserId())
            .appId(apiParams.getAppId()).message(ResponseCodes.INTERNAL_SERVER_ERROR.name())
            .exceptionMessage(ex.getMessage()).exception(ex));
        genericResponse = responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      }
    }
    return new AsyncResult<>(genericResponse);
  }
}
