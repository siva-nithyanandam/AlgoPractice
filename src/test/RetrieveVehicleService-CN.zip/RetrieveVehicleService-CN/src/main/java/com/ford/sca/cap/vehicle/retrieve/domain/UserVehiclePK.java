package com.ford.sca.cap.vehicle.retrieve.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class UserVehiclePK implements Serializable {

  private static final long serialVersionUID = -699186368934844452L;

  @Column(name = "[USERID]")
  private String capUserId;

  @Column(name = "[TENANT_ID]")
  private Integer tenantId;

  @Column(name = "[VIN_CODE]")
  private String vin;

  /**
   * Intentionally empty for JPA purpose.
   */
  public UserVehiclePK() {
    //Intentionally empty for JPA purpose.
  }

  /**
   * To construct primary key for UserVehicleBO.
   * @param capUserId capUserId
   * @param tenantId tenantId
   * @param vinCode vinCode
   */
  public UserVehiclePK(final String capUserId, final Integer tenantId, final String vinCode) {
    this.capUserId = capUserId;
    this.tenantId = tenantId;
    this.vin = vinCode;
  }
}
