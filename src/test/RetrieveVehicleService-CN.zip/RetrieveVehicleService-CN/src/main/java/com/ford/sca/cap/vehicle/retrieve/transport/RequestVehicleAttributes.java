package com.ford.sca.cap.vehicle.retrieve.transport;

import java.util.Date;
import javax.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequestVehicleAttributes {

  @Size(max = 255, message = "255")
  private String productVariant;

  @Size(max = 6, message = "6")
  private String preferredDealer;

  private Integer userProvidedMileage;

  private Date mileageUpdateDate;

  private Integer drivingConditionId;

  private Integer configurationId;

  @Size(max = 1, message = "1")
  private String primaryVehicleIndicator;

  @Size(max = 50, message = "50")
  private String licensePlate;

  private Date vehicleRegistrationDate;

  private Integer vehicleImageId;

  private Integer headUnitTyp;

  private Integer steeringWheelTyp;

  private String lifeStyleXML;

  private String smsMessagesXML;

  @Size(max = 1, message = "1")
  private String syncVehicleIndicator;

  @Size(max = 50, message = "50")
  private String vehicleName;

  private Integer averageDailyMiles;

  private Date vhrReadyDate;

}
