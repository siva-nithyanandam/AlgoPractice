package com.ford.sca.cap.vehicle.retrieve.transport;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RetrieveVehicleSuccessResponse extends GenericResponse {

  private List<UserVehicle> userVehicleList;
}
