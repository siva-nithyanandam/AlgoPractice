package com.ford.sca.cap.vehicle.retrieve.service;

import com.ford.sca.cap.vehicle.retrieve.domain.UserVehicleBO;
import com.ford.sca.cap.vehicle.retrieve.repository.UserVehicleRepository;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.RuleEngineInterface;
import com.ford.sca.cap.vehicle.retrieve.service.statics.BrandCode;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.transport.RetrieveVehicleSuccessResponse;
import com.ford.sca.cap.vehicle.retrieve.transport.UserVehicle;
import com.ford.sca.cap.vehicle.retrieve.util.GenericAssister;
import com.ford.sca.cap.vehicle.retrieve.util.LogAround;
import com.ford.sca.cap.vehicle.retrieve.util.LoggerBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import com.ford.sca.cap.vehicle.retrieve.util.ScaCUtil;
import com.ford.sca.cap.vehicle.retrieve.validators.BrandCodeManager;
import com.ford.sca.cap.vehicle.retrieve.validators.CapUserIdManager;
import com.ford.sca.cap.vehicle.retrieve.validators.Validator;
import com.ford.sca.cap.vehicle.retrieve.validators.VinCodeManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public abstract class MasterRuleEngine implements RuleEngineInterface {

  private static final Map<String, String> BRAND_CODE_MAP = new ConcurrentHashMap<>();

  static {
    BRAND_CODE_MAP.put(BrandCode.FORD.getName(), BrandCode.FORD.getLikePattern());
    BRAND_CODE_MAP.put(BrandCode.FORD.getSymbol(), BrandCode.FORD.getLikePattern());
    BRAND_CODE_MAP.put(BrandCode.FORD.getBrandId(), BrandCode.FORD.getLikePattern());
    BRAND_CODE_MAP.put(BrandCode.LINCOLN.getName(), BrandCode.LINCOLN.getLikePattern());
    BRAND_CODE_MAP.put(BrandCode.LINCOLN.getSymbol(), BrandCode.LINCOLN.getLikePattern());
    BRAND_CODE_MAP.put(BrandCode.LINCOLN.getBrandId(), BrandCode.LINCOLN.getLikePattern());
    BRAND_CODE_MAP.put(BrandCode.MERCURY.getName(), BrandCode.MERCURY.getLikePattern());
    BRAND_CODE_MAP.put(BrandCode.MERCURY.getSymbol(), BrandCode.MERCURY.getLikePattern());
    BRAND_CODE_MAP.put(BrandCode.MERCURY.getBrandId(), BrandCode.MERCURY.getLikePattern());
  }

  @Autowired
  protected CapUserIdManager capUserIdManager;
  @Autowired
  protected BrandCodeManager brandCodeManager;
  @Autowired
  protected VinCodeManager vinCodeManager;
  @Autowired
  protected UserVehicleRepository userVehicleRepository;
  @Autowired
  protected ResponseBuilder responseBuilder;
  @Autowired
  private ScaCUtil scaCUtil;
  @Autowired
  protected EntityManager entityManager;

  /**
   * To get list of required validators for appropriate implementation.
   */
  protected abstract List<Validator> getValidators();

  /**
   * To check given group type matching tenant's group type.
   *
   * @param groupType rule engine type
   * @return TRUE if matching else FALSE
   */
  @Override
  public boolean isRequestBehalfOfThisImpl(final String groupType) {
    return getGroupTypes().contains(groupType);
  }

  /**
   * To get brand code map from master tenant if child doesn't implement.
   */
  @Override
  public Map<String, String> getBrandCodeMap() {
    return BRAND_CODE_MAP;
  }

  /**
   * To invoke all required validator implementations asynchronously.
   */
  @Override
  @LogAround
  public Optional<GenericResponse> validate(final ApiParams apiParams,
      final HttpServletRequest request) {

    final List<Future<GenericResponse>> validationResponses = new ArrayList<>();

    // Trigger each secondary validator's checkAndConstruct()
    getValidators().stream().forEach(validator -> validationResponses
        .add(validator.checkAndConstruct(apiParams, request, this)));

    // Return any of failure validation
    return validationResponses.stream().map(cfResp -> parseValidationResponse(apiParams, cfResp))
        .filter(Objects::nonNull).findAny();
  }

  /**
   * To parse validation response from each validator.
   *
   * @param apiParams API parameters
   * @param cfResp Validation response
   * @return Parsed validation response
   */
  private GenericResponse parseValidationResponse(final ApiParams apiParams,
      final Future<GenericResponse> cfResp) {
    GenericResponse genericResponse;
    try {
      genericResponse = cfResp.get();
    } catch (Exception e) {
      LoggerBuilder.printError(log,
          logger -> logger.exceptionMessage(e.getMessage()).exception(e)
              .capUserId(apiParams.getUserId()).appId(apiParams.getAppId())
              .methodName("parseValidationResponse").message("Exception in one of the validators"));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
    }
    return genericResponse;
  }

  /**
   * To trigger DB related functions.
   *
   * @param apiParams Given API params
   * @param request HttpServletRequest
   * @return GenericResponse/RetrieveVehicleSuccessResponse
   */
  @Override
  @LogAround
  public GenericResponse triggerDBProcesses(final ApiParams apiParams,
      final HttpServletRequest request) {
    GenericResponse response;
    RetrieveVehicleSuccessResponse successResponse;
    List<UserVehicleBO> userVehicleBOList;
    List<UserVehicle> userVehicleList;
    CriteriaQuery criteriaQuery;

    LoggerBuilder.printInfo(log,
        logger -> logger.brandCode(apiParams.getBrandCode()).capUserId(apiParams.getUserId())
            .appId(apiParams.getAppId()).vinCode(apiParams.getVinCode())
            .message("Fetching vehicle details with all not null conditions"));
    try {
      // Fetch vehicle details for given params
      criteriaQuery = generateQuery(apiParams);
      userVehicleBOList = entityManager.createQuery(criteriaQuery).getResultList();
      // Construct response user vehicle details & Get country code if available
      if (GenericAssister.isCollectionNotEmpty(userVehicleBOList)) {
        LoggerBuilder.printInfo(log, logger -> logger.capUserId(apiParams.getUserId())
            .appId(apiParams.getAppId()).message("Success - Fetched vehicle details"));

        userVehicleList = userVehicleBOList.stream()
            .map(userVehicleBO -> responseBuilder.buildUserVehicle(userVehicleBO, apiParams, this))
            .collect(Collectors.toList());

        successResponse = new RetrieveVehicleSuccessResponse();
        successResponse.setStatus(ResponseCodes.SUCCESS.getResponseMessage());
        successResponse.setHttpStatus(ResponseCodes.SUCCESS.getHttpStatus());
        successResponse.setUserVehicleList(userVehicleList);
        response = successResponse;

        // Setting country code for posting to SCA-C
        apiParams.setCountryCode(userVehicleBOList.get(0).getCountryCode());
      } else {
        response = findResponsePerGivenFilters(apiParams);
      }
    } catch (Exception ex) {
      LoggerBuilder.printError(log,
          logger -> logger.capUserId(apiParams.getUserId()).methodName("triggerDBProcesses")
              .message("Exception retrieving userList from DB").exceptionMessage(ex.getMessage())
              .exception(ex));
      response = responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
    }

    return response;
  }

  /**
   * Have to send respective response codes for given filters. Identify and return.
   *
   * @param apiParams {@link ApiParams}
   * @return {@link GenericResponse} - Identified response per given filters.
   */
  private GenericResponse findResponsePerGivenFilters(ApiParams apiParams) {
    GenericResponse response;
    LoggerBuilder.printError(log, logger -> logger.capUserId(apiParams.getUserId())
        .appId(apiParams.getAppId()).message("Failure - Not fetched vehicle details"));

    if (GenericAssister.isAllStringsNotEmpty(apiParams.getVinCode(), apiParams.getBrandCode())) {
      response = responseBuilder.generateResponse(ResponseCodes.NO_DATA_FOR_VIN_AND_BRAND_CODE);
    } else if (GenericAssister.isNotEmptyString(apiParams.getVinCode())) {
      response = responseBuilder.generateResponse(ResponseCodes.NO_DATA_FOR_VIN_CODE);
    } else if (GenericAssister.isNotEmptyString(apiParams.getBrandCode())) {
      response = responseBuilder.generateResponse(ResponseCodes.NO_DATA_FOR_BRAND_CODE);
    } else {
      response = responseBuilder.generateResponse(ResponseCodes.NO_DATA_FOR_USER);
    }
    return response;
  }

  /**
   * To trigger post DB process if any - Typically to any SCA-C program.
   *
   * @param apiParams Given API Params
   */
  @Override
  @LogAround
  public void triggerPostDBProcesses(final ApiParams apiParams) {

    LoggerBuilder.printInfo(log, logger -> logger.methodName("triggerPostDBProcesses")
        .message("Executing post DB process!"));
    // Get copy of MDC context to send to sub-threads
    final Map<String, String> webThreadContext = MDC.getCopyOfContextMap();

    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      LoggerBuilder.printInfo(log, logger -> logger.methodName("triggerPostDBProcesses")
          .message("Triggering ScaCUtil.pushToScaC"));
      scaCUtil.pushToScaC(apiParams);
    });
  }

  /**
   * Generate CriteriaQuery through given params to pull vehicle details.
   *
   * @param apiParams {@link ApiParams}
   * @return {@link CriteriaQuery}
   */
  public CriteriaQuery generateQuery(final ApiParams apiParams) {
    final CriteriaBuilder builder = entityManager.getCriteriaBuilder();
    final CriteriaQuery criteriaQuery = builder.createQuery(UserVehicleBO.class);
    final Root<UserVehicleBO> userVehicleBORoot = criteriaQuery.from(UserVehicleBO.class);

    final List<Predicate> predicates = new ArrayList<>();
    predicates.add(builder.equal(userVehicleBORoot.get("userVehiclePK")
        .get("capUserId"), apiParams.getUserId()));
    predicates.add(builder.equal(userVehicleBORoot.get("userVehiclePK")
        .get("tenantId"), apiParams.getTenantId()));

    if (GenericAssister.isNotEmptyString(apiParams.getVinCode())) {
      predicates.add(builder.equal(userVehicleBORoot.get("userVehiclePK")
          .get("vin"), apiParams.getVinCode()));
    }
    if (GenericAssister.isNotEmptyString(apiParams.getBrandCode())) {
      predicates.add(builder.like(builder.upper(userVehicleBORoot.get("make")),
          getBrandCodeMap().get(apiParams.getBrandCode().toUpperCase(getLocale()))));
    }
    criteriaQuery.where(predicates.toArray(new Predicate[0]));
    return criteriaQuery;
  }

  /**
   * Generate a criteria query for rule engine accordingly.
   * 
   * @param apiParams {@link ApiParams}
   * @return Generated query.
   */
  // public abstract CriteriaQuery generateQuery(final ApiParams apiParams);

  /**
   * To calculate estimated mileage from average and last updated mileage.
   *
   * @param userVehicleBO DB fetched vehicle data
   * @param apiParams API params
   * @return Calculated estimated mileage
   */
  public abstract Integer calculateEstimatedMileage(final UserVehicleBO userVehicleBO,
      final ApiParams apiParams);
}
