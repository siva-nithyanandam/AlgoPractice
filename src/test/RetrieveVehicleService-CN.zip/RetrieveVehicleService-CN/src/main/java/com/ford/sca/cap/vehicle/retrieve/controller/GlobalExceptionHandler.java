package com.ford.sca.cap.vehicle.retrieve.controller;

import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.AuditActivityUtil;
import com.ford.sca.cap.vehicle.retrieve.util.LoggerBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

@ControllerAdvice
@RestController
@Slf4j
public class GlobalExceptionHandler {

  private final String className = this.getClass().getSimpleName();

  @Autowired
  private AuditActivityUtil auditActivityUtil;

  @Autowired
  private ResponseBuilder responseBuilder;

  /**
   * When request body is not valid as defined.
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @param exception Exception
   */
  @ExceptionHandler(MethodArgumentNotValidException.class)
  public GenericResponse handleIllegalMethodArgument(final HttpServletRequest request,
      final HttpServletResponse response, final Exception exception) {
    auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);
    response.setStatus(HttpStatus.EXPECTATION_FAILED.value());
    final GenericResponse genericResponse =
        responseBuilder.generateResponse(ResponseCodes.VALUE_EXCEEDS_MAX_LENGTH);
    LoggerBuilder.printError(log, logger -> logger.className(className)
        .methodName("handleIllegalMethodArgument").exception(exception));

    auditActivityUtil.constructAuditServiceResponseAndPublish(request, response, genericResponse);
    return genericResponse;
  }

  /**
   * When request is not parsable.
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @param exception Exception
   */
  @ExceptionHandler(HttpMessageNotReadableException.class)
  public GenericResponse httpMessageNotReadableException(final HttpServletRequest request,
      final HttpServletResponse response, final Exception exception) {
    auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);
    final GenericResponse genericResponse =
        responseBuilder.generateResponse(ResponseCodes.BINDING_ERROR);
    LoggerBuilder.printError(log, logger -> logger.className(className)
        .methodName("httpMessageNotReadableException").exception(exception));

    auditActivityUtil.constructAuditServiceResponseAndPublish(request, response, genericResponse);

    return genericResponse;
  }

  /**
   * When request and header/path parameters are missing.
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   * @param exception Exception
   */
  @ExceptionHandler(MissingServletRequestParameterException.class)
  public GenericResponse handlemissingServletRequestParameterException(
      final HttpServletRequest request, final HttpServletResponse response,
      final Exception exception) {

    auditActivityUtil.storeRequestHeaderAttributes(request);
    auditActivityUtil.setResponseHeaderAttributes(response);
    response.setStatus(HttpStatus.PRECONDITION_FAILED.value());
    final GenericResponse genericResponse =
        responseBuilder.generateResponse(ResponseCodes.APPID_CAPUSERID_VIN_NOT_AVAILABLE);
    LoggerBuilder.printError(log,
        logger -> logger.className(className)
            .methodName("handlemissingServletRequestParameterException")
            .message(exception.getMessage()).exception(exception));

    auditActivityUtil.constructAuditServiceResponseAndPublish(request, response, genericResponse);
    return genericResponse;
  }
}
