package com.ford.sca.cap.vehicle.retrieve.util;

import com.ford.sca.cap.vehicle.retrieve.domain.UserVehicleBO;
import com.ford.sca.cap.vehicle.retrieve.service.MasterRuleEngine;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.transport.UserVehicle;
import java.util.Calendar;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ResponseBuilder {

  @Autowired
  private CacheUtil cacheUtil;

  /**
   * To generate response to the caller.
   *
   * @param responseCode {@link ResponseCodes}
   * @return {@link GenericResponse}
   */
  public GenericResponse generateResponse(final ResponseCodes responseCode) {
    GenericResponse genericResponse;
    if (responseCode.isSuccess()) {
      genericResponse =
          new GenericResponse(responseCode.getHttpStatus(), responseCode.getResponseMessage());
    } else {
      genericResponse = new GenericResponse(responseCode.getHttpStatus(),
          responseCode.getResponseMessage(), responseCode.getMsgId(),
          cacheUtil.getErrorMessage(responseCode.getMsgId()), Calendar.getInstance().getTime());
    }
    return genericResponse;
  }

  /**
   * To build user vehicle response object from BO.
   *
   * @param userVehicleBO From DB fetched output
   * @param apiParams API Params
   * @return {@link UserVehicle}
   */
  @LogAround
  public UserVehicle buildUserVehicle(final UserVehicleBO userVehicleBO, final ApiParams apiParams,
      final MasterRuleEngine ruleEngine) {
    final UserVehicle userVehicle = new UserVehicle();
    userVehicle.setCapUserId(userVehicleBO.getUserVehiclePK().getCapUserId());
    userVehicle
        .setVin(userVehicleBO.getUserVehiclePK().getVin().toUpperCase(ruleEngine.getLocale()));
    userVehicle.setVehicleName(userVehicleBO.getVehicleName());
    userVehicle.setColor(userVehicleBO.getColor());
    userVehicle.setModel(userVehicleBO.getModel());
    userVehicle.setModelYear(userVehicleBO.getModelYear());
    userVehicle.setModelType(userVehicleBO.getModelType());
    userVehicle.setTcuEnabled(userVehicleBO.getTcuEnabled());
    userVehicle.setMake(userVehicleBO.getMake());
    userVehicle.setFuel(userVehicleBO.getFuel());
    userVehicle.setCylinders(userVehicleBO.getCylinders());
    userVehicle.setTransmissionType(userVehicleBO.getTransmissionType());
    userVehicle.setDrivetrain(userVehicleBO.getDrivetrain());
    userVehicle.setSparkPlug(userVehicleBO.getSparkPlug());
    userVehicle.setSeries(userVehicleBO.getSeries());
    userVehicle.setEngineDisp(userVehicleBO.getEngineDisp());
    userVehicle.setVersionDescription(userVehicleBO.getVersionDescription());
    userVehicle.setProductVariant(userVehicleBO.getProductVariant());
    userVehicle.setPreferredDealer(userVehicleBO.getPreferredDealer());
    userVehicle.setSellingDealer(userVehicleBO.getSellingDealer());
    userVehicle.setDrivingConditionId(userVehicleBO.getDrivingConditionId());
    userVehicle.setConfigurationId(userVehicleBO.getConfigurationId());
    userVehicle.setLicensePlate(userVehicleBO.getLicensePlate());
    userVehicle.setVehicleRegistrationDate(userVehicleBO.getVehicleRegistrationDate());
    userVehicle.setVehicleUpdateDate(userVehicleBO.getVehicleUpdateDate());
    userVehicle.setOwnerCycle(userVehicleBO.getOwnerCycle());
    userVehicle.setOwnerIndicator(userVehicleBO.getOwnerIndicator());
    userVehicle.setVehicleImageId(userVehicleBO.getVehicleImageId());
    userVehicle.setHeadUnitTyp(userVehicleBO.getHeadUnitTyp());
    userVehicle.setSteeringWheelTyp(userVehicleBO.getSteeringWheelTyp());
    userVehicle.setLifeStyleXML(userVehicleBO.getLifeStyleXML());
    userVehicle.setVhrReadyDate(userVehicleBO.getVhrReadyDate());
    userVehicle.setAccessDate(userVehicleBO.getAccessDate());
    userVehicle.setVehicleRole(userVehicleBO.getVehicleRole());
    userVehicle.setAssignedDealer(userVehicleBO.getAssignedDealer());
    userVehicle.setWarrantyStartDate(userVehicleBO.getWarrantyStartDate());
    userVehicle.setPurchaseDate(userVehicleBO.getPurchaseDate());

    setIndicators(userVehicleBO, userVehicle);
    setMileageInfo(userVehicleBO, userVehicle, ruleEngine, apiParams);
    userVehicle.setAppId(apiParams.getAppId());

    // Newly added three attributes
    userVehicle.setVehicleEngineNumber(userVehicleBO.getVehicleEngineNumber());
    userVehicle.setVehicleGovRegDate(userVehicleBO.getVehicleGovRegDate());
    userVehicle.setVehicleGovInspectionDate(userVehicleBO.getVehicleGovInspectionDate());
    userVehicle.setCreateDate(userVehicleBO.getCreateDate());
    userVehicle.setPreferredVehicleFlag(userVehicleBO.getPreferredVehicleFlag());
    return userVehicle;
  }

  /**
   * To set the Indicator related information.
   * 
   * @param userVehicleBO {@link UserVehicleBO}
   * @param userVehicle {@link UserVehicle}
   */
  private void setIndicators(final UserVehicleBO userVehicleBO, final UserVehicle userVehicle) {
    if (userVehicleBO.getPrimaryVehicleIndicator() != null) {
      userVehicle.setPrimaryVehicleIndicator(userVehicleBO.getPrimaryVehicleIndicator().trim());
    }
    if (userVehicleBO.getSyncVehicleIndicator() != null) {
      userVehicle.setSyncVehicleIndicator(userVehicleBO.getSyncVehicleIndicator().trim());
    }
  }

  /**
   * To set the mileage related information.
   * 
   * @param userVehicleBO {@link UserVehicleBO}
   * @param userVehicle {@link UserVehicle}
   * @param ruleEngine {@link MasterRuleEngine}
   * @param apiParams {@link ApiParams}
   */
  private void setMileageInfo(final UserVehicleBO userVehicleBO, final UserVehicle userVehicle,
      final MasterRuleEngine ruleEngine, final ApiParams apiParams) {
    userVehicle.setAverageDailyMiles(userVehicleBO.getAverageDailyMiles());
    userVehicle.setUserProvidedMileage(userVehicleBO.getUserProvidedMileage());
    userVehicle.setMileageUpdateDate(userVehicleBO.getMileageUpdateDate());
    userVehicle.setMileageSource(userVehicleBO.getMileageSource());
    userVehicle.setLatestMileageDate(userVehicleBO.getLatestMileageDate());
    userVehicle.setEstimatedMileage(ruleEngine.calculateEstimatedMileage(userVehicleBO, apiParams));
    if (userVehicleBO.getLatestOdometerReading() != null
        && userVehicleBO.getLatestOdometerReading() > 0) {
      userVehicle.setLatestMileage(userVehicleBO.getLatestOdometerReading());
    } else {
      userVehicle.setLatestMileage(userVehicle.getEstimatedMileage());
    }
  }
}
