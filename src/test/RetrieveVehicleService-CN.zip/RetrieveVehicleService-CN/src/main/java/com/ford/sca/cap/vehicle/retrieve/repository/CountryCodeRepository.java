package com.ford.sca.cap.vehicle.retrieve.repository;

import com.ford.sca.cap.domain.CountryCodeBO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CountryCodeRepository extends JpaRepository<CountryCodeBO, String> {

  /**
   * To find Country code details for given ISO3 country code.
   * @param countryCode ISO3 country code
   * @return {@link CountryCodeBO}
   */
  CountryCodeBO findByIso3CodeCountry(String countryCode);

  /**
   * To find Country code details for given ISO2 country code.
   * @param countryCode ISO2 country code
   * @return {@link CountryCodeBO}
   */
  CountryCodeBO findByIso2CodeCountry(String countryCode);

}
