package com.ford.sca.cap.vehicle.retrieve;

import com.google.common.collect.Lists;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;
import org.springframework.security.oauth2.provider.expression.OAuth2MethodSecurityExpressionHandler;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableCaching
@EnableGlobalMethodSecurity(prePostEnabled = true, proxyTargetClass = true)
@EntityScan("com.ford.sca.cap")
public class RetrieveVehicleServiceLauncher {

  /**
   * To launch this application through SpringBoot.
   * @param args args
   */
  public static void main(final String[] args) {
    SpringApplication.run(RetrieveVehicleServiceLauncher.class, args);
  }

  /**
   * To create OAuth2 header section in the swagger API.
   */
  @Bean
  public Docket newsApi() {
    return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.any())
        .paths(PathSelectors.regex("/rv/consumerAccounts.*")).build()
        .globalOperationParameters(Lists.newArrayList(new ParameterBuilder().name("Authorization")
            .description("OAuth2 bearer token").modelRef(new ModelRef("string"))
            .parameterType("header").defaultValue("bearer ").required(true).build()))
        .apiInfo(apiInfo());
  }

  /**
   * To create API information.
   */
  private ApiInfo apiInfo() {
    return new ApiInfoBuilder()
        .title("Consumer Account Profile (CAP) retrieve vehicle Microservice")
        .description("CAP retrieve vehicle profile microservice API").version("1.0").build();
  }

  /**
   * To create security configurations.
   */
  @Bean
  public GlobalMethodSecurityConfiguration globalMethodSecurityConfiguration() {
    return new GlobalMethodSecurityConfiguration() {
      @Override
      protected MethodSecurityExpressionHandler createExpressionHandler() {
        return new OAuth2MethodSecurityExpressionHandler();
      }
    };
  }
}