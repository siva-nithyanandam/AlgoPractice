package com.ford.sca.cap.vehicle.retrieve.validators;

import com.ford.sca.cap.vehicle.retrieve.service.MasterRuleEngine;
import com.ford.sca.cap.vehicle.retrieve.service.statics.BrandCode;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.GenericAssister;
import com.ford.sca.cap.vehicle.retrieve.util.LogAround;
import com.ford.sca.cap.vehicle.retrieve.util.LoggerBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

/**
 * To manage all BrandCode related processes.
 */
@Slf4j
@Service
public class BrandCodeManager implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;

  /**
   * To validate given BrandCode.
   *
   * @return Null when valid Else NOT NULL
   */
  @Override
  @LogAround
  public Future<GenericResponse> checkAndConstruct(final ApiParams apiParams,
      final HttpServletRequest request, final MasterRuleEngine masterRuleEngine) {

    GenericResponse validationResponse = null;

    if (GenericAssister.isNotEmptyString(apiParams.getBrandCode())) {
      LoggerBuilder.printInfo(log, logger -> logger.capUserId(apiParams.getUserId())
          .appId(apiParams.getAppId()).brandCode(apiParams.getBrandCode())
          .message("Brandcode provided in the request"));

      if (!BrandCode
          .isBrandCodeExist(masterRuleEngine, apiParams.getBrandCode())) {
        LoggerBuilder.printError(log, logger -> logger.capUserId(apiParams.getUserId())
            .appId(apiParams.getAppId()).brandCode(apiParams.getBrandCode())
            .message("Brand code is not valid"));
        validationResponse =
            responseBuilder.generateResponse(ResponseCodes.BRAND_CODE_NOT_EXIST);
      }
    }
    return new AsyncResult<>(validationResponse);
  }
}

