package com.ford.sca.cap.vehicle.retrieve.service;

import com.ford.sca.cap.domain.AppCodeBO;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.CNMobileWebOther;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.NaMobileWebOther;
import com.ford.sca.cap.vehicle.retrieve.service.ruleengines.RuleEngineInterface;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.util.CacheUtil;
import com.ford.sca.cap.vehicle.retrieve.util.LoggerBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseBuilder;
import com.ford.sca.cap.vehicle.retrieve.util.ResponseCodes;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * To manage all user vehicle related activities.
 */
@Slf4j
@Service
public class RetrieveVehicleService {

  private static final String RETRIEVE_VEHICLE_METHOD = "retrieveVehicle";
  private final List<RuleEngineInterface> ruleEngineInterfaces = new ArrayList<>();
  private final ResponseBuilder responseBuilder;
  private final CacheUtil cacheUtil;

  /**
   * Constructor to do dependency injection and adding appropriate service implementations.
   */
  @Autowired
  public RetrieveVehicleService(final CacheUtil cacheUtil, final NaMobileWebOther naMobileWebOther,
      final CNMobileWebOther cnMobileWebOther, final ResponseBuilder responseBuilder) {
    this.cacheUtil = cacheUtil;
    this.responseBuilder = responseBuilder;

    // Add tenant implementations here
    ruleEngineInterfaces.add(naMobileWebOther);
    ruleEngineInterfaces.add(cnMobileWebOther);
  }

  /**
   * TO retrieve vehicle for given inputs.
   *
   * @param request HttpServletRequest
   * @return {@link GenericResponse}
   */
  public GenericResponse retrieveVehicle(final HttpServletRequest request,
      final ApiParams apiParams) {

    //Get group/rule engine type and tenant ID
    final AppCodeBO appCodeDtls = cacheUtil.getAppCodeDtls(Integer.valueOf(apiParams.getAppId()));

    //If appCode details not found, then its an invalid/not exist in the DB
    if (null == appCodeDtls) {
      LoggerBuilder.printError(log, logger -> logger.capUserId(apiParams.getUserId())
          .appId(apiParams.getAppId()).message("App code does not exist in the Database"));
      return responseBuilder.generateResponse(ResponseCodes.APP_CODE_NOT_EXISTS_IN_DB);
    }

    GenericResponse genericResponse;

    // 1. Set tenant code
    apiParams.setTenantId(appCodeDtls.getTenantId());

    // 2. Find appropriate implementation
    final Optional<RuleEngineInterface> serviceImpl = ruleEngineInterfaces.stream()
        .filter(impl -> impl.isRequestBehalfOfThisImpl(appCodeDtls.getValidationGrpCode()))
        .findAny();

    // If service rule engines instance found, proceed with that
    if (serviceImpl.isPresent()) {
      LoggerBuilder.printInfo(log,
          logger -> logger.methodName(RETRIEVE_VEHICLE_METHOD).capUserId(apiParams.getUserId())
              .message("Found service rule engines : " + serviceImpl.get().toString()));

      // 3. Do the validations
      final Optional<GenericResponse> failedValidationResponse =
          serviceImpl.get().validate(apiParams, request);

      if (failedValidationResponse.isPresent()) {
        LoggerBuilder.printError(log,
            logger -> logger.methodName(RETRIEVE_VEHICLE_METHOD).capUserId(apiParams.getUserId())
                .appId(apiParams.getAppId()).message("Validation failed"));
        genericResponse = failedValidationResponse.get();
      } else {
        LoggerBuilder.printInfo(log,
            logger -> logger.methodName(RETRIEVE_VEHICLE_METHOD).capUserId(apiParams.getUserId())
                .message("All the validations are passed"));

        // 4. Do the DB operations
        genericResponse = serviceImpl.get().triggerDBProcesses(apiParams, request);
        LoggerBuilder.printInfo(log,
            logger -> logger.methodName(RETRIEVE_VEHICLE_METHOD).capUserId(apiParams.getUserId())
                .message("Completed DB processes"));

        // 5. Trigger post DB operations if any
        serviceImpl.get().triggerPostDBProcesses(apiParams);
      }
      return genericResponse;
    } else {
      LoggerBuilder.printError(log,
          logger -> logger.methodName(RETRIEVE_VEHICLE_METHOD).capUserId(apiParams.getUserId())
              .appId(apiParams.getAppId())
              .message("Rule engine is not available for given APP Code"));
      return responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
    }
  }

  /**
   * To build ApiParams with required attributes.
   *
   * @param appId - AppID
   * @param capUserId - CAPUserID
   * @param vinCode - VINCode
   * @param brandCode - BrandCode
   * @return {@link ApiParams}
   */
  public ApiParams buildApiParams(final String appId, final String capUserId, final String vinCode,
      final String brandCode) {
    final ApiParams apiParams = new ApiParams();
    apiParams.setAppId(appId);
    apiParams.setUserId(capUserId);
    apiParams.setVinCode(vinCode);
    apiParams.setBrandCode(brandCode);
    apiParams.setRequestTimeStamp(Calendar.getInstance().getTime());
    return apiParams;
  }
}
