package com.ford.sca.cap.vehicle.retrieve.service.statics;

import lombok.Getter;

/**
 * To define list of source codes.
 */
@Getter
public enum SourceCode {
  SYNC_MY_RIDE("100392"),
  MOTOR_CRAFT("100423"),
  FORD_CREDIT("100424"),
  FORD_PASS("100504"),
  LINCOLN_WAY("100530"),
  FORD_GOBIKE("100532"),
  MDM("100547");

  private String sourceCd;

  SourceCode(final String sourceCd) {
    this.sourceCd = sourceCd;
  }
}
