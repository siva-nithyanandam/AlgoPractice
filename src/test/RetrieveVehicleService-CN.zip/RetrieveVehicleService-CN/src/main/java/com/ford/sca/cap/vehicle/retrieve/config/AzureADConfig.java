package com.ford.sca.cap.vehicle.retrieve.config;

import com.ford.cloudnative.activedirectory.oauth2.resource.config.EnableActiveDirectoryOAuth2ResourceServer;
import com.ford.cloudnative.activedirectory.oauth2.resource.config.FordActiveDirectoryOauth2ResourceServerConfiguration;
import com.ford.sca.cap.vehicle.retrieve.exception.CAPRuntimeException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;

@Configuration
@EnableWebSecurity
@EnableActiveDirectoryOAuth2ResourceServer
public class AzureADConfig {

  /**
   * To create resource server configurer adapter.
   */
  @Bean
  public ResourceServerConfigurer resourceServerConfigurer() {
    // Cross-Site Request Forgery--csrf
    return new ResourceServerConfigurerAdapter() {
      @Override
      public void configure(final HttpSecurity http) {
        try {
          http.csrf().disable().authorizeRequests().antMatchers("/**").permitAll();
        } catch (Exception e) {
          throw new CAPRuntimeException("Exception in AzureADConfig - resourceServerConfigurer", e);
        }
      }
    };
  }

  /**
   * To create resource server configurer adapter.
   */
  @Configuration
  public static class Oauth2ResourceConfiguration extends
      FordActiveDirectoryOauth2ResourceServerConfiguration {

    @Override
    public void configure(final HttpSecurity http) {
      try {
        http.csrf().disable().authorizeRequests().antMatchers("/**").permitAll();
      } catch (Exception e) {
        throw new CAPRuntimeException("Exception in AzureADConfig-Oauth2ResourceConfiguration", e);
      }
    }
  }
}