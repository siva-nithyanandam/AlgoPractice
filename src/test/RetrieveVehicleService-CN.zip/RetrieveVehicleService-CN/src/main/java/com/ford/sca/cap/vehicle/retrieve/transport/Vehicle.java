package com.ford.sca.cap.vehicle.retrieve.transport;

import java.io.Serializable;
import javax.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Vehicle implements Serializable {

  private static final long serialVersionUID = -622904980386711284L;

  @Size(max = 17, message = "17")
  private String vin;

  private Integer cylinders;

  @Size(max = 50, message = "50")
  private String engineDisp;

  @Size(max = 40, message = "40")
  private String fuel;

  @Size(max = 50, message = "50")
  private String make;

  @Size(max = 10, message = "10")
  private String modelYear;

  @Size(max = 50, message = "50")
  private String modelName;

  @Size(max = 30, message = "30")
  private String modelSeries;

  @Size(max = 30, message = "30")
  private String drivetrain;

  @Size(max = 30, message = "30")
  private String transmissionTyp;

  @Size(max = 30, message = "30")
  private String modelTyp;

  @Size(max = 100, message = "100")
  private String color;

  @Size(max = 100, message = "100")
  private String versionDescription;

  private Integer sparkPlug;
}
