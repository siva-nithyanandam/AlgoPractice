package com.ford.sca.cap.vehicle.retrieve.service.statics;

import lombok.Getter;

/**
 * To define list of ConsumerType.
 */
@Getter
public enum ConsumerType {

  PERSON("P", "Person"),
  ORGANISATION("O", "Organisation");

  private String type;
  private String desc;

  ConsumerType(final String type, final String desc) {
    this.type = type;
    this.desc = desc;
  }
}
