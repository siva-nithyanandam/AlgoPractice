package com.ford.sca.cap.vehicle.retrieve.repository;

import com.ford.sca.cap.vehicle.retrieve.domain.MarketingProfileBO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MarketingProfileRepository extends JpaRepository<MarketingProfileBO, String> {

}
