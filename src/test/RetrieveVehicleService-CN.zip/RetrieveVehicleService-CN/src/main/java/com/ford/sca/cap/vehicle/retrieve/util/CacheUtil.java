package com.ford.sca.cap.vehicle.retrieve.util;

import com.ford.sca.cap.domain.AppCodeBO;
import com.ford.sca.cap.domain.CountryCodeBO;
import com.ford.sca.cap.domain.MessageLangServiceViewBO;
import com.ford.sca.cap.vehicle.retrieve.repository.AppCodeRepository;
import com.ford.sca.cap.vehicle.retrieve.repository.CountryCodeRepository;
import com.ford.sca.cap.vehicle.retrieve.repository.MessageLangServiceViewRepository;
import com.ford.sca.cap.vehicle.retrieve.service.statics.Flags;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CacheUtil {

  @Autowired
  private AppCodeRepository appCodeRepository;

  @Autowired
  private CountryCodeRepository countryCodeRepository;

  @Autowired
  private MessageLangServiceViewRepository messageLangServiceViewRepository;

  /**
   * This method checks for the AppId.
   *
   * @param appId appId of the caller
   * @return appCode
   */
  @Cacheable(cacheNames = "appCodeInfo", key = "#appId")
  public AppCodeBO getAppCodeDtls(final Integer appId) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("getAppCodeDtls")
        .appId(String.valueOf(appId)));
    return appCodeRepository.findByAppIdAndActiveFlag(appId, Flags.ACTIVE);
  }

  /**
   * The error message will store it "errorMessages" cache (consider as a map), if not available. It
   * will fetch it from redis server, if data available in cache server.
   *
   * @param errorMsgId error message code
   * @return message description as a String
   */
  @Cacheable(cacheNames = "errorMessages", key = "#errorMsgId")
  public String getErrorMessage(final String errorMsgId) {
    String errorDesc = null;
    final String logStartMessage = "Getting Error Message for : " + errorMsgId;
    LoggerBuilder
        .printInfo(log, logger -> logger.methodName("getErrorMessage").message(logStartMessage));
    final Optional<MessageLangServiceViewBO> msgOptional =
        messageLangServiceViewRepository.findById(errorMsgId);
    if (msgOptional.isPresent()) {
      errorDesc = msgOptional.get().getMessageDesc();
    }
    final String logMessage = "Retrieved Error Message Description : " + errorDesc;
    LoggerBuilder
        .printInfo(log, logger -> logger.methodName("getErrorMessage").message(logMessage));
    return errorDesc;
  }

  /**
   * The CountryCodeBO will be store in "countryInfo" cache (consider as a map), if not available.
   * It will fetch it from DB, otherwise data available in cache server.
   *
   * @param countryCode iso3 country code
   * @return CountryCodeBO the whole object is returned
   */
  @Cacheable(cacheNames = "countryInfo", key = "#countryCode")
  public CountryCodeBO getCountryCodeByISO3(final String countryCode) {
    LoggerBuilder.printInfo(log,
        logger -> logger.methodName("getCountryCodeByISO3")
            .message("Getting Country by code: " + countryCode));
    final CountryCodeBO findByIso3CodeCountry = countryCodeRepository
        .findByIso3CodeCountry(countryCode);
    final String logMessage = findByIso3CodeCountry != null
        ? "Retrieved Country : " + findByIso3CodeCountry.getCountryName()
        : "Null Country Retrieved";
    LoggerBuilder
        .printInfo(log, logger -> logger.methodName("getCountryCodeByISO3").message(logMessage));
    return findByIso3CodeCountry;
  }

  /**
   * The CountryCodeBO will be store in "countryInfo" cache (consider as a map), if not available.
   * It will fetch it from DB, otherwise data available in cache server.
   *
   * @param countryCode iso2 country code
   * @return CountryCodeBO the whole object is returned
   */
  @Cacheable(cacheNames = "countryInfo", key = "#countryCode")
  public CountryCodeBO getCountryCodeByISO2(final String countryCode) {
    LoggerBuilder.printInfo(log,
        logger -> logger.methodName("getCountryCodeByISO2")
            .message("Getting Country by code: " + countryCode));
    final CountryCodeBO iso2CodeCountry = countryCodeRepository.findByIso2CodeCountry(countryCode);
    final String logMessage = iso2CodeCountry != null
        ? "Retrieved Country : " + iso2CodeCountry.getCountryName()
        : "Null Country Retrieved";
    LoggerBuilder
        .printInfo(log, logger -> logger.methodName("getCountryCodeByISO2").message(logMessage));
    return iso2CodeCountry;
  }
}
