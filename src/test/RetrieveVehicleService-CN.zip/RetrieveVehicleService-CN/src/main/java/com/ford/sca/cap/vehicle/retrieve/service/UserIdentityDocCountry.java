package com.ford.sca.cap.vehicle.retrieve.service;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * To define list of UserIdentityDocCountry.
 */
public enum UserIdentityDocCountry {
  ARG, BRA, CHL, COL, ECU, VEN;

  private static Map<String, UserIdentityDocCountry> userIdentityDocCountries;

  static {
    userIdentityDocCountries = Arrays.stream(UserIdentityDocCountry.values())
        .collect(Collectors.toMap(country -> country.name(), country -> country));
  }

  /**
   * To check the given country available in {@link UserIdentityDocCountry}.
   *
   * @return TRUE if country is available Else FALSE
   */
  public static boolean isThisCountryAvailable(final String country) {
    if (null != country) {
      return userIdentityDocCountries.containsKey(country);
    }
    return false;
  }

  /**
   * To check the given country is not available in {@link UserIdentityDocCountry}.
   *
   * @return TRUE if country is not available Else FALSE
   */
  public static boolean isThisCountryNotAvailable(final String country) {
    return !isThisCountryAvailable(country);
  }
}
