package com.ford.sca.cap.vehicle.retrieve.transport;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MessageHeaders {

  private Date evenRequestTimeStamp;
  private Integer appId;
  private String eventName;
  private String eventType;
  private String eventInitiatorName;
  private String callingServiceName;
  private String correlationId;
  private String guid;
}
