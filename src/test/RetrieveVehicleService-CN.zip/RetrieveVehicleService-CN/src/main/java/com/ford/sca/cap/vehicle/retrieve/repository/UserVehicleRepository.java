package com.ford.sca.cap.vehicle.retrieve.repository;

import com.ford.sca.cap.vehicle.retrieve.domain.UserVehicleBO;
import com.ford.sca.cap.vehicle.retrieve.domain.UserVehiclePK;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserVehicleRepository extends JpaRepository<UserVehicleBO, UserVehiclePK> {

  /**
   * To find list of user vehicle details for given userId, tenantId, vin and brandCode.
   * @param userVehiclePK contains userId, tenantId, vin
   * @param brandCode Brandcode
   * @return List of {@link UserVehicleBO}
   */
  List<UserVehicleBO> findByUserVehiclePKAndMakeStartingWith(UserVehiclePK userVehiclePK,
      String brandCode);

  /**
   * To find list of user vehicle details for given userId, tenantId and brandCode.
   * @param userId userId
   * @param tenantId tenantId
   * @param brandCode brandCode
   * @return List of {@link UserVehicleBO}
   */
  List<UserVehicleBO> findByUserVehiclePK_CapUserIdAndUserVehiclePK_TenantIdAndMakeStartingWith(
      String userId, Integer tenantId, String brandCode);

  /**
   * To find list of user vehicle details for given userId and tenantId.
   * @param userId userId
   * @param tenantId tenantId
   * @return List of {@link UserVehicleBO}
   */
  List<UserVehicleBO> findByUserVehiclePK_CapUserIdAndUserVehiclePK_TenantId(String userId,
      Integer tenantId);
}
