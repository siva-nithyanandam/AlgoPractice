package com.ford.sca.cap.vehicle.retrieve.service.ruleengines;

import com.ford.sca.cap.vehicle.retrieve.domain.UserVehicleBO;
import com.ford.sca.cap.vehicle.retrieve.service.MasterRuleEngine;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.util.LogAround;
import com.ford.sca.cap.vehicle.retrieve.validators.Validator;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CNMobileWebOther extends MasterRuleEngine {

  private static final Set<String> GROUP_TYPES = new HashSet<>();
  private static final Locale LOCALE = Locale.US;

  static {
    GROUP_TYPES.add("MOBILE_CN");
  }

  @Override
  public Set getGroupTypes() {
    return GROUP_TYPES;
  }

  @Override
  public Locale getLocale() {
    return LOCALE;
  }

  @Override
  protected List<Validator> getValidators() {
    final List<Validator> validatorsForChina = new ArrayList<>();
    validatorsForChina.add(capUserIdManager);
    validatorsForChina.add(vinCodeManager);
    validatorsForChina.add(brandCodeManager);
    return validatorsForChina;
  }

  @Override
  public Integer calculateEstimatedMileage(final UserVehicleBO userVehicleBO,
      final ApiParams apiParams) {
    return null;
  }

  @Override
  @LogAround
  public void triggerPostDBProcesses(final ApiParams apiParams) {
    //Do nothing for China functionality as of now.
  }

  //Uncomment and override any of below methods whenever applicable

  /*@Override
  public CriteriaQuery generateQuery(final ApiParams apiParams) {
    return super.generateQuery(apiParams);
  }*/

  /*@Override
  public void publishAuditMessage_request(HttpServletRequest request,
      MaintainVehicleUpdateRequest maintainVehicleRequest, ApiParams apiParams) {
    super.publishAuditMessage_request(request, maintainVehicleRequest, apiParams);
  }*/

  /*@Override
  public void publishAuditMessage_response(HttpServletRequest request,
      GenericResponse response, MaintainVehicleUpdateRequest maintainVehicleRequest,
      ApiParams apiParams) {
    super.publishAuditMessage_response(request, response, maintainVehicleRequest, apiParams);
  }*/

  /*@Override
  public Map<String, String> getBrandCodeMap() {
    return super.getBrandCodeMap();
  }*/
}
