package com.ford.sca.cap.vehicle.retrieve.repository;

import com.ford.sca.cap.vehicle.retrieve.domain.UserAccountBO;
import com.ford.sca.cap.vehicle.retrieve.domain.UserAccountPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserAccountRepository extends JpaRepository<UserAccountBO, UserAccountPK> {

}
