package com.ford.sca.cap.vehicle.retrieve.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.cap.domain.CountryCodeBO;
import com.ford.sca.cap.vehicle.retrieve.messaging.RabbitMqSender;
import com.ford.sca.cap.vehicle.retrieve.repository.MarketingProfileRepository;
import com.ford.sca.cap.vehicle.retrieve.service.statics.Flags;
import com.ford.sca.cap.vehicle.retrieve.service.statics.MQDetails;
import com.ford.sca.cap.vehicle.retrieve.service.statics.SourceCode;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.MDMRetrieveRequest;
import com.ford.sca.cap.vehicle.retrieve.transport.MessageHeaders;
import java.nio.charset.Charset;
import java.util.Calendar;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ScaCUtil {

  private static final Map<String, String> MDM_CAP_LANGUAGE_CODE_MAP = new ConcurrentHashMap<>();
  private static final String PUBLISH_MSG_METHOD = "publishMessage";

  static {
    MDM_CAP_LANGUAGE_CODE_MAP.put("en-US", "en");
    MDM_CAP_LANGUAGE_CODE_MAP.put("fr-CA", "fr");
    MDM_CAP_LANGUAGE_CODE_MAP.put("es-AR", "es");
    MDM_CAP_LANGUAGE_CODE_MAP.put("pt-BR", "pt_BR");
    MDM_CAP_LANGUAGE_CODE_MAP.put("de-DE", "de");
  }

  @Autowired
  private CacheUtil cacheUtil;

  @Autowired
  private MarketingProfileRepository marketingProfileRepository;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private RabbitMqSender rabbitMqSender;

  /**
   * To post to SCA-C service.
   *
   * @param apiParams contains main request parameters
   */
  @LogAround
  public void pushToScaC(final ApiParams apiParams) {
    MDMRetrieveRequest mdmRetrieveRequest;
    if (!marketingProfileRepository.existsById(apiParams.getUserId())
        && isCountryEnabled(apiParams.getCountryCode())) {
      mdmRetrieveRequest = new MDMRetrieveRequest();
      mdmRetrieveRequest.setGuid(apiParams.getUserId());
      mdmRetrieveRequest.setGuidCountryCode(apiParams.getCountryCode());
      mdmRetrieveRequest.setSourceCode(SourceCode.MDM.getSourceCd());
      publishMessage(mdmRetrieveRequest, apiParams.getAppId());
    }
  }

  /**
   * To publish message to the queue.
   *
   * @param mdmRetrieveRequest {@link MDMRetrieveRequest}
   * @param appID Given AppID
   */
  private void publishMessage(final MDMRetrieveRequest mdmRetrieveRequest, final String appID) {
    try {
      final String jsonInString = objectMapper.writeValueAsString(mdmRetrieveRequest);
      final MessageHeaders messageHeaders = buildMessageHeaders(mdmRetrieveRequest, appID);
      final Message messageObject = buildRabbitMqMarketingProfileMessage(jsonInString,
          messageHeaders);
      rabbitMqSender.send(MQDetails.SCA_C_EVENT, messageObject);
      LoggerBuilder.printInfo(log, logger -> logger.appId(appID)
          .capUserId(mdmRetrieveRequest.getGuid()).methodName(PUBLISH_MSG_METHOD)
          .message("Marketing Profile Message submitted to Rabbit Queue!"));
    } catch (Exception ex) {
      LoggerBuilder.printError(log, logger -> logger.appId(appID)
          .capUserId(mdmRetrieveRequest.getGuid()).methodName(PUBLISH_MSG_METHOD)
          .message("Exception in publishMessage").exception(ex).message(ex.getMessage()));
    }
  }

  /**
   * To build message properties for publishing into queue.
   *
   * @param message Message to be published
   * @param messageHeaders Message headers
   * @return Generated {@link Message} object
   */
  private Message buildRabbitMqMarketingProfileMessage(final String message,
      final MessageHeaders messageHeaders) {
    final MessageProperties messageProperties = new MessageProperties();
    messageProperties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);
    messageProperties.setHeader(Constants.CALLING_SERVICE_NAME, Constants.RETRIEVE_VEHICLE);
    messageProperties.setHeader(Constants.APP_ID, messageHeaders.getAppId());
    messageProperties.setHeader(Constants.GUID, messageHeaders.getGuid());
    messageProperties.setHeader(Constants.EVENT_NAME, messageHeaders.getEventName());
    messageProperties.setHeader(Constants.EVENT_REQUEST_TIMESTAMP,
        messageHeaders.getEvenRequestTimeStamp());
    messageProperties.setHeader(Constants.EVENT_INITIATOR_NAME,
        messageHeaders.getEventInitiatorName());
    messageProperties.setHeader(Constants.EVENT_TYPE, messageHeaders.getEventType());
    messageProperties.setHeader(Constants.TRACE_ID_HEADER_NAME,
        MDC.get(Constants.TRACE_ID_HEADER_NAME));
    messageProperties.setHeader(Constants.SPAN_ID_HEADER_NAME,
        MDC.get(Constants.SPAN_ID_HEADER_NAME));
    messageProperties.setHeader(Constants.CORRELATION_ID_HEADER_NAME,
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME));
    return new Message(message.getBytes(Charset.defaultCharset()), messageProperties);
  }

  /**
   * To build message headers.
   *
   * @param mdmRetrieveRequest {@link MDMRetrieveRequest}
   * @param appID Given AppID
   * @return {@link MessageHeaders}
   */
  private MessageHeaders buildMessageHeaders(final MDMRetrieveRequest mdmRetrieveRequest,
      final String appID) {
    final MessageHeaders messageHeaders = new MessageHeaders();
    messageHeaders.setAppId(Integer.parseInt(appID));
    messageHeaders.setGuid(mdmRetrieveRequest.getGuid());
    messageHeaders.setEventName(Constants.RETRIEVE_MARKETING_PROFILE);
    messageHeaders.setEventInitiatorName(Constants.RETRIEVE_VEHICLE);
    messageHeaders.setEventType(Constants.GET);
    messageHeaders.setEvenRequestTimeStamp(Calendar.getInstance().getTime());
    messageHeaders.setCallingServiceName(Constants.RETRIEVE_VEHICLE);
    return messageHeaders;
  }

  /**
   * To check country is enabled for MDM.
   *
   * @param countryCode Country code of User
   * @return TRUE if MDM enabled for the country Else FALSE
   */
  private boolean isCountryEnabled(final String countryCode) {

    final CountryCodeBO countryCodeBO = getCountryCodeBO(countryCode);
    return countryCodeBO != null && countryCodeBO.getMdmEnabledFlag() != null
        && countryCodeBO.getMdmEnabledFlag().equalsIgnoreCase(Flags.ENABLED);
  }

  /**
   * To get Country code details for given country code.
   * @param countryCode Given country code
   * @return {@link CountryCodeBO}
   */
  private CountryCodeBO getCountryCodeBO(final String countryCode) {
    CountryCodeBO countryCodeBO = null;
    if (countryCode != null) {
      if (countryCode.length() == Constants.ISO2_COUNTRY_LENGTH) {
        countryCodeBO = cacheUtil.getCountryCodeByISO2(countryCode);
      } else if (countryCode.length() == Constants.ISO3_COUNTRY_LENGTH) {
        countryCodeBO = cacheUtil.getCountryCodeByISO3(countryCode);
      }
    }
    return countryCodeBO;
  }
}
