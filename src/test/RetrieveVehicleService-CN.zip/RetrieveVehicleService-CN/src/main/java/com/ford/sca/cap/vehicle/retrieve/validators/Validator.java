package com.ford.sca.cap.vehicle.retrieve.validators;

import com.ford.sca.cap.vehicle.retrieve.service.MasterRuleEngine;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.transport.MaintainVehicleCreateRequest;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import org.springframework.scheduling.annotation.Async;

public interface Validator {

  /**
   * To checkAndConstruct given {@link MaintainVehicleCreateRequest} request by respective
   * validators.
   *
   * @return Null when valid Else NOT NULL
   */
  @Async("capTaskExecutor")
  Future<GenericResponse> checkAndConstruct(ApiParams apiParams,
      HttpServletRequest request, MasterRuleEngine masterRuleEngine);
}
