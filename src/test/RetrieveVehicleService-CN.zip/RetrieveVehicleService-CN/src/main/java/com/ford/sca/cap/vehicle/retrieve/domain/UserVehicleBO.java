package com.ford.sca.cap.vehicle.retrieve.domain;

/*
 * View for User, Vehicle, Vehicle Details (P03, P04, P05)
 */

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

@Getter
@Setter
@Entity
@Table(name = "[MCAPV02_USER_VEHICLE_VW]")
public class UserVehicleBO {

  @EmbeddedId
  private UserVehiclePK userVehiclePK;

  @Nationalized
  @Column(name = "[MAKE]")
  private String make;

  @Column(name = "[COUNTRY CODE]")
  private String countryCode;

  @Column(name = "[MODEL_YEAR]")
  private String modelYear;

  @Nationalized
  @Column(name = "[MODEL_NAME]")
  private String model;

  @Nationalized
  @Column(name = "[FUEL_TYPE]")
  private String fuel;

  @Column(name = "[CYLINDER]")
  private Integer cylinders;

  @Nationalized
  @Column(name = "[TRANSMISSION_TYPE]")
  private String transmissionType;

  @Column(name = "[SPARK_PLUG]")
  private Integer sparkPlug;

  @Nationalized
  @Column(name = "[MODEL_TYPE]")
  private String modelType;

  @Nationalized
  @Column(name = "[DRIVE_TYPE]")
  private String drivetrain;

  @Nationalized
  @Column(name = "[MODEL_SERIES]")
  private String series;

  @Nationalized
  @Column(name = "[ENGINE_DISPLACEMENT]")
  private String engineDisp;

  @Nationalized
  @Column(name = "[VEHICLE_VERSION]")
  private String versionDescription;

  @Column(name = "[AVG_DAILY_MILES]")
  private Integer averageDailyMiles;

  @Column(name = "[USER_MILEAGE]")
  private Integer userProvidedMileage;

  @Column(name = "[USER_MILEAGE_UPDATE_DATE]")
  private Date mileageUpdateDate;

  @Column(name = "[VEHICLE_REG_DATE]")
  private Date vehicleRegistrationDate;

  @Column(name = "[PRIMARY_VEHICLE_FLAG]")
  private String primaryVehicleIndicator;

  @Column(name = "[UPDATED_DATE]")
  private Date vehicleUpdateDate;

  @Column(name = "[DRIVING_CONDITIONS_ID]")
  private Integer drivingConditionId;

  @Column(name = "[CONFIGURATION_ID]")
  private Integer configurationId;

  @Nationalized
  @Column(name = "[VEHICLE_NAME]")
  private String vehicleName;

  @Column(name = "[VEHICLE_IMAGE_ID]")
  private Integer vehicleImageId;

  @Nationalized
  @Column(name = "[VEHICLE_COLOR]")
  private String color;

  @Column(name = "[ACCESS_DATE]")
  private Date accessDate;

  @Column(name = "[HEAD_UNIT_TYPE]")
  private Integer headUnitTyp;

  @Column(name = "[STEERING_WHEEL_TYPE]")
  private Integer steeringWheelTyp;

  @Column(name = "[VHR_READY_DATE]")
  private Date vhrReadyDate;

  @Column(name = "[SYNC_VEHICLE_IND]")
  private String syncVehicleIndicator;

  @Nationalized
  @Column(name = "[PRODUCT_VARIANT]")
  private String productVariant;

  @Nationalized
  @Column(name = "[VEHICLE_LIFE_PREF_XML]")
  private String lifeStyleXML;

  @Nationalized
  @Column(name = "[VEHICLE_LICENSE_PLATE_NAME]")
  private String licensePlate;

  @Column(name = "[PREFERRED_DEALER_CODE]")
  private String preferredDealer;

  @Column(name = "[SELLING_DEALER_CODE]")
  private String sellingDealer;

  @Column(name = "[OWNER_CYCLE_CODE]")
  private String ownerCycle;

  @Nationalized
  @Column(name = "[VEHICLE_ROLE]")
  private String vehicleRole;

  @Column(name = "[OWNER_INDICATOR_FLAG]")
  private String ownerIndicator;

  @Column(name = "[TCU_ENABLED_FLAG]")
  private String tcuEnabled;

  @Column(name = "[TCU_MILEAGE]")
  private Integer tcuMileage;

  @Column(name = "[TCU_MILEAGE_DATE]")
  private Date tcuMileageDate;

  @Column(name = "[MILEAGE_SOURCE]")
  private Integer mileageSource;

  @Column(name = "[LATEST_MILEAGE]")
  private Integer latestMileage;

  @Column(name = "[ASSIGNED_DEALER_CODE]")
  private String assignedDealer;

  @Column(name = "[WARRANTY_START_S]")
  private Date warrantyStartDate;

  @Column(name = "[SALE_S]")
  private Date purchaseDate;

  @Column(name = "[LATEST_MILEAGE_S]")
  private Date latestMileageDate;

  @Column(name = "[LATEST_ODO_READ]")
  private Integer latestOdometerReading;
  
  @Column(name = "VEHICLE_ENGINE_NUMBER")
  private String vehicleEngineNumber;
  
  @Column(name = "PREFERRED_VEHICLE_F")
  private String preferredVehicleFlag;
  
  @Column(name = "[CREATE_S]")
  private Date createDate;
  
  @Temporal(TemporalType.DATE)
  @Column(name = "VEHICLE_GOV_REG_DATE")
  private Date vehicleGovRegDate;
  
  @Temporal(TemporalType.DATE)
  @Column(name = "VEHICLE_GOV_INSPECTION_END_DATE")
  private Date vehicleGovInspectionDate;
}