package com.ford.sca.cap.vehicle.retrieve.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.cap.vehicle.retrieve.messaging.RabbitMqSender;
import com.ford.sca.cap.vehicle.retrieve.service.statics.MQDetails;
import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.AuditServiceRequest;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value = "classpath:git.properties", ignoreResourceNotFound = true)
public class AuditActivityUtil {

  private static final Logger LOG = LoggerFactory.getLogger(AuditActivityUtil.class);

  @Value("${DATA_CENTER}")
  private String dataCenter;

  @Value("${ORG}")
  private String org;

  @Value("${ENVIRONMENT}")
  private String environment;

  @Value("${APP_NAME}")
  private String appName;

  @Value("${git.commit.id.abbrev}")
  private String commitIdAbbrev;

  @Value("${VERSION}")
  private String version;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private RabbitMqSender rabbitMqSender;

  /**
   * To build audit activity for request.
   */
  private AuditServiceRequest createAuditServiceRequest(final HttpServletRequest request,
      final ApiParams apiParams) {
    final String resourceUri = request.getScheme() + Constants.COLON_SLASHES
        + request.getServerName() + Constants.COLON + request.getServerPort()
        + request.getRequestURI() + Constants.QUESTION_MARK + request.getQueryString();

    final AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
    auditServiceRequest.setAppId(apiParams.getAppId());
    auditServiceRequest.setCapUserId(apiParams.getUserId());
    auditServiceRequest.setJsonType(Constants.REQUEST_FIELD_NAME);
    auditServiceRequest.setDataCenter(dataCenter);
    auditServiceRequest.setHttpMethod(request.getMethod());
    auditServiceRequest.setOrg(org);
    auditServiceRequest.setRequestStatus(Constants.REQUEST_STATUS_NEW);
    auditServiceRequest.setServiceId(appName + Constants.HYPHEN + version);
    auditServiceRequest.setEnvironment(environment);
    auditServiceRequest.setTraceId(MDC.getCopyOfContextMap().get(Constants.TRACE_ID_HEADER_NAME));
    auditServiceRequest.setSpanId(MDC.getCopyOfContextMap().get(Constants.SPAN_ID_HEADER_NAME));
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    auditServiceRequest.setCorrelationId(MDC.get(Constants.CORRELATION_ID_HEADER_NAME));
    auditServiceRequest.setVcapRequestId(MDC.get(Constants.VCAP_REQUEST_HEADER_NAME));
    auditServiceRequest.setBuildVersion(MDC.get(Constants.BUILD_VERSION_HEADER_NAME));
    auditServiceRequest.setResourceUri(resourceUri);
    auditServiceRequest.setRequestTimeStamp(apiParams.getRequestTimeStamp());
    return auditServiceRequest;
  }

  /**
   * To build audit activity for response.
   */
  private AuditServiceRequest createAuditServiceResponse(final HttpServletRequest request,
      final GenericResponse response, final ApiParams apiParams) {
    final AuditServiceRequest auditServiceRequest = createAuditServiceRequest(request, apiParams);
    auditServiceRequest.setResponseCode(response.getHttpStatus().toString());
    auditServiceRequest.setJsonType(Constants.RESPONSE_FIELD_NAME);
    try {
      auditServiceRequest.setJsonBody(objectMapper.writeValueAsString(response));
    } catch (JsonProcessingException e) {
      LoggerBuilder.printError(LOG, logger -> logger.message("Failed marshalling GenericResponse")
          .exceptionMessage(e.getMessage()).exception(e));
    }
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    auditServiceRequest.setRequestStatus(response.getStatus());
    return auditServiceRequest;
  }

  /**
   * To publish audit activity request into queue.
   */
  private void publishAuditMessage(final AuditServiceRequest auditServiceRequest) {
    String message;
    try {
      message = objectMapper.writeValueAsString(auditServiceRequest);
      final MessageProperties messageProperties = new MessageProperties();
      messageProperties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);
      final Message messageObject =
          new Message(message.getBytes(StandardCharsets.UTF_8), messageProperties);
      rabbitMqSender.send(MQDetails.AUDIT_ACTIVITY, messageObject);
    } catch (JsonProcessingException e) {
      LoggerBuilder.printError(LOG, logger -> logger.exceptionMessage(e.getMessage()).exception(e)
          .message("Failed marshalling auditServiceRequest"));
    } catch (Exception e) {
      LoggerBuilder.printError(LOG, logger -> logger.message("Failed publishing audit message")
          .exceptionMessage(e.getMessage()).exception(e));
    }
  }

  /**
   * To store, request header attributes in MDC for logging purpose.
   */
  @LogAround
  public void storeRequestHeaderAttributes(final HttpServletRequest request) {
    String correlationID = request.getHeader(Constants.CORRELATION_ID_HEADER_NAME);
    if (GenericAssister.isEmptyString(correlationID)) {
      final Random rand = new Random(System.currentTimeMillis());
      correlationID = Long.toHexString(rand.nextLong());
    }
    MDC.put(Constants.CORRELATION_ID_HEADER_NAME, correlationID);
    MDC.put(Constants.REQUEST_SERVICE_ID, appName + Constants.HYPHEN + version);
    MDC.put(Constants.VCAP_REQUEST_HEADER_NAME,
        request.getHeader(Constants.VCAP_REQUEST_HEADER_NAME));
    MDC.put(Constants.BUILD_VERSION_HEADER_NAME, frameBuildVersionHeaderName());
    MDC.put(Constants.REQUEST_SERVICE_ID, appName + Constants.HYPHEN + version);
    MDC.put(Constants.TRACE_ID_HEADER_NAME, request.getHeader(Constants.TRACE_ID_HEADER_NAME));
  }

  /**
   * To frame project's build version header name by environment variables.
   *
   * @return a string represents build version header name
   */
  private String frameBuildVersionHeaderName() {
    String dataCenterShort = "";
    if (null != dataCenter && dataCenter.length() > 2) {
      dataCenterShort = dataCenter.substring(0, 2);
    }
    return appName + Constants.HYPHEN + Constants.SERVICE_FIELD_NAME + Constants.HYPHEN
        + dataCenterShort + Constants.HYPHEN + environment + Constants.HYPHEN + version
        + Constants.HYPHEN + commitIdAbbrev;
  }

  /**
   * To set response header attributes.
   */
  public void setResponseHeaderAttributes(final HttpServletResponse response) {
    response.setHeader(Constants.TRACE_ID_HEADER_NAME, MDC.get(Constants.TRACE_ID_HEADER_NAME));
    response.setHeader(Constants.CORRELATION_ID_HEADER_NAME,
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME));
    response.setHeader(Constants.BUILD_VERSION_HEADER_NAME,
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME));
  }

  /**
   * To construct the audit service request and publish it for Failure Responses coming from
   * GlobalExceptionHandler.
   */
  public void constructAuditServiceResponseAndPublish(final HttpServletRequest request,
      final HttpServletResponse response, final GenericResponse maintianVehicleFailureResponse) {
    setResponseHeaderAttributes(response);
    final ApiParams apiParams = new ApiParams();
    apiParams.setAppId(request.getParameter("AppID"));
    apiParams.setRequestTimeStamp(Calendar.getInstance().getTime());
    final AuditServiceRequest auditServiceRequest = createAuditServiceRequest(request, apiParams);
    final AuditServiceRequest auditServiceResponse =
        createAuditServiceResponse(request, maintianVehicleFailureResponse, apiParams);
    auditServiceRequest.setResponseCode(maintianVehicleFailureResponse.getHttpStatus().toString());
    auditServiceRequest.setJsonType(Constants.RESPONSE_FIELD_NAME);
    try {
      auditServiceRequest
          .setJsonBody(objectMapper.writeValueAsString(maintianVehicleFailureResponse));
    } catch (JsonProcessingException e) {
      LoggerBuilder.printError(LOG, logger -> logger.message("Failed marshalling GenericResponse")
          .exceptionMessage(e.getMessage()).exception(e));
    }
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    auditServiceRequest.setRequestStatus(maintianVehicleFailureResponse.getStatus());

    // Get copy of MDC context to send to sub-threads
    final Map<String, String> webThreadContext = MDC.getCopyOfContextMap();
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      LoggerBuilder.printInfo(LOG,
          logger -> logger.methodName("constructAuditServiceResponseAndPublish")
              .message("Publishing audit activity for GlobalExceptionHandler response"));
      // publish the audit messages for request and response
      publishAuditMessage(auditServiceRequest);
      publishAuditMessage(auditServiceResponse);
    });

  }

  /**
   * To publish request for audit activity.
   *
   * @param request HttpServletRequest
   * @param apiParams Given ApiParams
   */
  public void publishAuditMessage_request(final HttpServletRequest request,
      final ApiParams apiParams) {
    // Get copy of MDC context to send to sub-threads
    final Map<String, String> webThreadContext = MDC.getCopyOfContextMap();

    final AuditServiceRequest auditServiceRequest = createAuditServiceRequest(request, apiParams);
    // Trigger audit activity publish asynchronously
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      LoggerBuilder.printInfo(LOG, logger -> logger.methodName("publishAuditMessage_request")
          .message("Publishing audit activity for response"));

      publishAuditMessage(auditServiceRequest);
    });
  }

  /**
   * To publish response for audit activity.
   *
   * @param httpServletRequest HttpServletRequest
   * @param response Generated GenericResponse
   * @param apiParams Given API Params
   */
  public void publishAuditMessage_response(final HttpServletRequest httpServletRequest,
      final GenericResponse response, final ApiParams apiParams) {

    // Get copy of MDC context to send to sub-threads
    final Map<String, String> webThreadContext = MDC.getCopyOfContextMap();

    final AuditServiceRequest auditServiceRequest =
        createAuditServiceResponse(httpServletRequest, response, apiParams);

    // Trigger audit activity publish asynchronously
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      LoggerBuilder.printInfo(LOG, logger -> logger.methodName("publishAuditMessage_response")
          .message("Publishing audit activity for response"));
      publishAuditMessage(auditServiceRequest);
    });
  }

}
