package com.ford.sca.cap.vehicle.retrieve.datastore;

public class RequestScopeDataStore {

  //Add your variables to store in request scope
}
