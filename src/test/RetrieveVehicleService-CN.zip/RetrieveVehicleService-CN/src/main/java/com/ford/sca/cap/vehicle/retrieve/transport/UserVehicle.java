package com.ford.sca.cap.vehicle.retrieve.transport;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserVehicle {

  @JsonProperty("appID")
  private String appId;
  private String capUserId;
  private String vin;
  private String vehicleName;
  private String color;
  private String model;
  private String modelYear;
  private String modelType;
  @JsonProperty("tCUEnabled")
  private String tcuEnabled;
  private String make;
  private String fuel;
  private Integer cylinders;
  private String transmissionType;
  private String drivetrain;
  private Integer sparkPlug;
  private String series;
  private String engineDisp;
  private String versionDescription;
  private String productVariant;
  private String preferredDealer;
  private String sellingDealer;
  private Integer averageDailyMiles;
  private Integer estimatedMileage;
  private Integer userProvidedMileage;
  private Date mileageUpdateDate;
  private Integer latestMileage;
  private Integer drivingConditionId;
  private Integer configurationId;
  private String primaryVehicleIndicator;
  private String licensePlate;
  private Date vehicleRegistrationDate;
  private String vehicleEngineNumber;  
  private Date vehicleGovRegDate;  
  private Date vehicleGovInspectionDate;
  private Date vehicleUpdateDate;
  private String ownerCycle;
  private String ownerIndicator;
  private Integer vehicleImageId;
  private Integer headUnitTyp;
  private Integer steeringWheelTyp;
  private String lifeStyleXML;
  private String syncVehicleIndicator;
  private Date vhrReadyDate;
  private Date accessDate;
  private String vehicleRole;
  private String assignedDealer;
  private Date warrantyStartDate;
  private Integer mileageSource;
  private Date purchaseDate;
  private Date latestMileageDate;
  private Date createDate;
  private String preferredVehicleFlag;
}
