package com.ford.sca.cap.vehicle.retrieve.util;

import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * Contains validation response code statics.
 */
@Getter
public enum ResponseCodes {
  SUCCESS(true, HttpStatus.OK, Constants.SUCCESS_TEXT, null),
  INVALID_REQUEST_URL(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT, "MSG-0001"),
  APP_CODE_NOT_FOUND_IN_REQ(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0001"),
  CAP_USER_ID_NOT_FOUND_IN_REQ(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0001"),
  APP_CODE_NOT_IN_NUMBER_FORMAT(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0002"),
  APP_CODE_NOT_EXISTS_IN_DB(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0002"),
  CAP_USER_NOT_EXISTS_IN_CAP(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0003"),
  BRAND_CODE_NOT_EXIST(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT, "MSG-0006"),
  NO_DATA_FOR_VIN_AND_BRAND_CODE(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0111"),
  NO_DATA_FOR_VIN_CODE(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT, "MSG-0005"),
  NO_DATA_FOR_BRAND_CODE(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT, "MSG-0007"),
  NO_DATA_FOR_USER(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT, "MSG-0004"),
  CAN_NOT_FIND_IMPL(false, HttpStatus.UNPROCESSABLE_ENTITY, Constants.FAILURE_TEXT, "MSG-0191"),
  VALUE_EXCEEDS_MAX_LENGTH(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0177"),
  BINDING_ERROR(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT, "MSG-0010"),
  INTERNAL_SERVER_ERROR(false, HttpStatus.INTERNAL_SERVER_ERROR, Constants.FAILURE_TEXT, 
      "MSG-9999"),
  APPID_CAPUSERID_VIN_NOT_AVAILABLE(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0023");

  private boolean isSuccess;
  private HttpStatus httpStatus;
  private String responseMessage;
  private String msgId;

  ResponseCodes(final boolean isSuccess, final HttpStatus httpStatus, final String responseMessage,
      final String msgId) {
    this.isSuccess = isSuccess;
    this.httpStatus = httpStatus;
    this.responseMessage = responseMessage;
    this.msgId = msgId;
  }

}
