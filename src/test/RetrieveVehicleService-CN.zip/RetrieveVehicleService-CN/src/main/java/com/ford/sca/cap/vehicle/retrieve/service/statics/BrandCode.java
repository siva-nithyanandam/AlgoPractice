package com.ford.sca.cap.vehicle.retrieve.service.statics;

import com.ford.sca.cap.vehicle.retrieve.service.MasterRuleEngine;
import com.ford.sca.cap.vehicle.retrieve.util.GenericAssister;
import java.util.Locale;
import java.util.Map;
import lombok.Getter;

/**
 * To define list of Brand codes.
 */
@Getter
public enum BrandCode {

  FORD("100380", "F", "FORD", "F%"),
  LINCOLN("100376", "L", "LINCOLN", "L%"),
  MERCURY("100377", "M", "MERCURY", "M%");

  private String brandId;
  private String symbol;
  private String name;
  private String likePattern;

  BrandCode(final String brandId, final String symbol, final String name,
      final String likePattern) {
    this.brandId = brandId;
    this.symbol = symbol;
    this.name = name;
    this.likePattern = likePattern;
  }

  /**
   * This function check if the brand code match with the make or not.
   *
   * @param brandCode : The brand code received from the request
   * @param make : The make received from the Vehicle Object
   * @param locale : {@link Locale}
   * @author SCHEBIL
   */

  public static boolean checkMatchBrandCodeWithMake(final String brandCode, final String make,
      final Map<String, String> brandCodeMap, final Locale locale) {
    if (GenericAssister.isAllStringsNotEmpty(brandCode, make)) {
      final String brandKey = brandCode.toUpperCase(locale);
      final String makeKey = make.toUpperCase(locale);
      return brandCodeMap.containsKey(brandKey) && brandCodeMap.containsKey(makeKey)
          && brandCodeMap.get(makeKey).equals(brandCodeMap.get(brandKey));
    } else {
      return false;
    }
  }

  /**
   * To check the given brand code exist in the given Map.
   */
  public static boolean isBrandCodeExist(final MasterRuleEngine masterRuleEngine,
      final String brandCode) {
    boolean isBrandCodeExist = false;
    if (GenericAssister.isMapNotEmpty(masterRuleEngine.getBrandCodeMap())
        && masterRuleEngine.getBrandCodeMap()
        .containsKey(brandCode.toUpperCase(masterRuleEngine.getLocale()))) {
      isBrandCodeExist = true;
    }
    return isBrandCodeExist;
  }
}
