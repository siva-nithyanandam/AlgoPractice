package com.ford.sca.cap.vehicle.retrieve.service.ruleengines;

import com.ford.sca.cap.vehicle.retrieve.transport.ApiParams;
import com.ford.sca.cap.vehicle.retrieve.transport.GenericResponse;
import com.ford.sca.cap.vehicle.retrieve.transport.MaintainVehicleCreateRequest;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;

public interface RuleEngineInterface {

  /**
   * To identify appropriate implementation for given request.
   *
   * @return TRUE if the request behalf of that ruleengines Else FALSE
   */
  boolean isRequestBehalfOfThisImpl(String groupType);

  /**
   * To get supported group types for the rule engine.
   */
  Set getGroupTypes();

  /**
   * To get appropriate Locale of the rule engine.
   *
   * @return {@link Locale}
   */
  Locale getLocale();

  /**
   * To checkAndConstruct given {@link MaintainVehicleCreateRequest} request in its identified
   * implementation for appropriate mode.
   *
   * @param apiParams All required API params
   * @param request HttpRequest
   * @return An optional value of {@link GenericResponse}
   */
  Optional<GenericResponse> validate(ApiParams apiParams,
      HttpServletRequest request);

  /**
   * To do the table operation through its identified implementation.
   */
  GenericResponse triggerDBProcesses(ApiParams apiParams,
      HttpServletRequest request);

  /**
   * To trigger any post DB operations if any.
   */
  void triggerPostDBProcesses(ApiParams apiParams);

  /**
   * To get the brand code map data.
   */
  Map<String, String> getBrandCodeMap();

}