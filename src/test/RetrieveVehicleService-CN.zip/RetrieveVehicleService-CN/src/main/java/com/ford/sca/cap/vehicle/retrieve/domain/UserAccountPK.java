package com.ford.sca.cap.vehicle.retrieve.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class UserAccountPK implements Serializable {

  private static final long serialVersionUID = -699186368934844452L;

  @Column(name = "[CAPP01_USER_D]")
  private String userId;

  @Column(name = "[CAPC15_TENANT_D]")
  private Integer tenantId;

  /**
   * Intentionally empty for JPA purpose.
   */
  public UserAccountPK() {
    //Intentionally empty for JPA purpose.
  }

  /**
   * Constructor for UserAccountPK.
   * @param userId UserID
   * @param tenantId TenantID
   */
  public UserAccountPK(final String userId, final Integer tenantId) {
    this.userId = userId;
    this.tenantId = tenantId;
  }
}
