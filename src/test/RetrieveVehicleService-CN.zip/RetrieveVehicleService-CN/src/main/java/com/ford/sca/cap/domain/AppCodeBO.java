package com.ford.sca.cap.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

/**
 * To hold APP Code details.
 */
@Entity
@Setter
@Getter
@Table(name = "MCAPC01_APP_CODE")
public class AppCodeBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CAPC01_APP_C]")
  private Integer appId;

  @Nationalized
  @Column(name = "[CAPC01_APP_X]")
  private String appName;

  @Column(name = "[CAPC01_VALIDATION_GRP_C]")
  private String validationGrpCode;

  @Column(name = "[CAPC01_DSP_PWD_CHGSCR_F]")
  private String pswdChngFlag;

  @Column(name = "[CAPC01_ACTIVE_F]")
  private String activeFlag;

  @Column(name = "[CAPC05_LANG_ISO3_C]")
  private String language;

  @Column(name = "[CAPC15_TENANT_D]")
  private Integer tenantId;
}
