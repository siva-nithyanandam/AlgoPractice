package com.ford.sca.cap.vehicle.retrieve.transport;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApiParams {

  private String userId;
  private String appId;
  private String vinCode;
  private String brandCode;
  private Integer tenantId;
  private String countryCode;
  private Date requestTimeStamp;
}
