package com.ford.sca.cap.vehicle.retrieve.service.statics;

import lombok.Getter;

/**
 * To define queue details.
 */
@Getter
public enum MQDetails {

  AUDIT_ACTIVITY("cap.log.exchange", "cap.log.activity"),
  SCA_C_EVENT("cap.event.mp.exchange", "cap.event.mp.queue");

  private String exchangeNm;
  private String routingKeyNm;

  MQDetails(final String exchangeNm, final String routingKeyNm) {
    this.exchangeNm = exchangeNm;
    this.routingKeyNm = routingKeyNm;
  }
}
