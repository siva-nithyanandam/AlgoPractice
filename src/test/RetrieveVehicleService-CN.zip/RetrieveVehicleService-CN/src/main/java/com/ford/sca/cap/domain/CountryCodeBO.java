package com.ford.sca.cap.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "MCAPC06_COUNTRY")
public class CountryCodeBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CAPC06_COUNTRY_ISO3_C]")
  private String iso3CodeCountry;

  @Column(name = "[CAPC06_COUNTRY_ISO2_C]")
  private String iso2CodeCountry;

  @Column(name = "[CAPC06_MDM_ENABLED_F]")
  private String mdmEnabledFlag;

  @Column(name = "[CAPC06_MDM_EFFECTIVE_S]")
  private Date mdmEffectiveDate;

  @Column(name = "[CAPC06_COUNTRY_N]")
  private String countryName;

  @Column(name = "CAPC06_CREATE_S")
  private Date createDate;

  @Column(name = "CAPC06_CREATE_USER_D")
  private String createUser;

  @Column(name = "CAPC06_CREATE_PROCESS_C")
  private String createProcess;

  @Column(name = "CAPC06_CREATE_APP_C")
  private Integer createAppCode;

  @Column(name = "CAPC06_UPDATE_S")
  private Date updateDate;

  @Column(name = "CAPC06_UPDATE_USER_D")
  private String updateUser;

  @Column(name = "CAPC06_UPDATE_PROCESS_C")
  private String updateProcess;

  @Column(name = "CAPC06_UPDATE_APP_C")
  private Integer updateAppCode;

}