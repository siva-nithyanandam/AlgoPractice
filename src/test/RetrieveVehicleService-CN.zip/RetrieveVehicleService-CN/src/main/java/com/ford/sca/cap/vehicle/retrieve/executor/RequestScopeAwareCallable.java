package com.ford.sca.cap.vehicle.retrieve.executor;

import java.util.Map;
import java.util.concurrent.Callable;
import org.slf4j.MDC;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;


public class RequestScopeAwareCallable<T> implements Callable<T> {

  private final Callable<T> task;
  private final RequestAttributes context;

  // mappedContextMap is set when new Child() is called
  private final Map<String, String> mappedContextMap = MDC.getCopyOfContextMap();

  /**
   * To construct RequestScopeAwareCallable.
   * @param task Callable
   * @param context RequestAttributes
   */
  public RequestScopeAwareCallable(final Callable<T> task, final RequestAttributes context) {
    this.task = task;
    this.context = context;
  }

  @Override
  public T call() throws Exception {
    MDC.setContextMap(mappedContextMap);
    if (context != null) {
      RequestContextHolder.setRequestAttributes(context);
    }

    try {
      return task.call();
    } finally {
      RequestContextHolder.resetRequestAttributes();
    }
  }

}
