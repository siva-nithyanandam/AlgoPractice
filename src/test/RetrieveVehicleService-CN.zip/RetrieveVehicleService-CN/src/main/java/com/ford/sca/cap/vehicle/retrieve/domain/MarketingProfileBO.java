package com.ford.sca.cap.vehicle.retrieve.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "MCAPM01_MARKETING_PROFILE")
public class MarketingProfileBO {

  @Id
  @Column(name = "[CAPM01_USER_D]")
  private String mpUserId;
}