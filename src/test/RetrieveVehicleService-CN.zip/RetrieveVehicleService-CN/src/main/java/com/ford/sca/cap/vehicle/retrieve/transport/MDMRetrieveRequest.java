package com.ford.sca.cap.vehicle.retrieve.transport;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MDMRetrieveRequest {

  private String guid;
  private String guidCountryCode;
  private String sourceCode;
}