package com.ford.sca.cap.vehicle.retrieve.repository;

import com.ford.sca.cap.domain.AppCodeBO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppCodeRepository extends JpaRepository<AppCodeBO, Integer> {

  /**
   * To find AppID details for given appID and activeFlag.
   * @param appId AppID
   * @param activeFlag ActiveFlag
   * @return {@link AppCodeBO}
   */
  AppCodeBO findByAppIdAndActiveFlag(Integer appId, String activeFlag);

}
