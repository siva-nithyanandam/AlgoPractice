package com.ford.sca.cap.vehicle.retrieve.util;

import java.util.Collection;
import java.util.Map;
import java.util.stream.Stream;

public final class GenericAssister {

  private static final char HYPEN_CHAR = '-';

  private GenericAssister() {
    throw new IllegalStateException("Utility class");
  }

  /**
   * To check, a given String is numeric or not.
   *
   * @return true if given string is not an numeric else false
   */
  public static boolean isNotNumeric(final String str) {
    return !isNumeric(str);
  }

  /**
   * To check, a given String is numeric or not.
   *
   * @return true if given string is numeric else false
   */
  public static boolean isNumeric(final String str) {
    boolean isNumeric;
    if (isEmptyString(str)) {
      isNumeric = false;
    } else if (str.charAt(0) == HYPEN_CHAR) {
      isNumeric = isValidPositiveNumber(str.substring(1));
    } else {
      isNumeric = isValidPositiveNumber(str);
    }
    return isNumeric;
  }

  /**
   * To check given string is positive number.
   * @param str String to check
   * @return TRUE if valid positive number Else FALSE
   */
  private static boolean isValidPositiveNumber(final String str) {
    if (isEmptyString(str)) {
      return false;
    } else {
      int index = 0;
      char strChar;
      while (index < str.length()) {
        strChar = str.charAt(index++);
        if (isNotValidNumber(strChar)) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * To check the given char is not a number.
   * @param strChar Given char
   * @return TRUE if not a number Else FALSE
   */
  private static boolean isNotValidNumber(final char strChar) {
    return strChar < '0' || strChar > '9';
  }

  /**
   * To checkAndConstruct given status is not null and not empty.
   *
   * @param str - a status to be checked
   * @return TRUE - If not null and not empty, FALSE - if null or empty
   */
  public static boolean isNotEmptyString(final String str) {
    return !isEmptyString(str);
  }

  /**
   * To checkAndConstruct given status is not null and not empty.
   *
   * @param str - a status to be checked
   * @return TRUE - if null or empty, FALSE - If not null and not empty
   */
  public static boolean isEmptyString(final String str) {
    if (null != str) {
      for (int index = 0; index < str.length(); index++) {
        if (!Character.isWhitespace(str.charAt(index))) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * To checkAndConstruct given status is not null and not empty.
   *
   * @param strs - a status to be checked for each input
   * @return TRUE - If all input strings are not null and not empty, FALSE - if at least one input
   * string is null or empty
   */
  public static boolean isAllStringsNotEmpty(final String... strs) {
    return Stream.of(strs).allMatch(s -> isNotEmptyString(s));
  }

  /**
   * To checkAndConstruct if at least one of the input strings is not null and not empty.
   *
   * @param strs - a status to be checked for each input string
   * @return TRUE - If at least one input string is not null and not empty, FALSE - otherwise
   */
  public static boolean isAnyStringNotEmpty(final String... strs) {
    return Stream.of(strs).anyMatch(s -> isNotEmptyString(s));
  }

  /**
   * To truncate the given status to a given length if status's length > given length.
   *
   * @param str - String to be truncated
   * @param len - Max length to be given for a status
   * @return a truncated status if status's length is greater than given length, Or else given
   * status as is will be returned
   */
  public static String truncateString(final String str, final int len) {
    if (str != null && str.length() > len) {
      return str.substring(0, len);
    } else {
      return str;
    }
  }

  /**
   * To check given collection is not empty.
   *
   * @return TRUE if collection is not empty Else FALSE
   */
  public static boolean isCollectionNotEmpty(final Collection collection) {
    return null != collection && !collection.isEmpty();
  }

  /**
   * To check given Map is not empty.
   *
   * @return TRUE if Map is not empty Else FALSE
   */
  public static boolean isMapNotEmpty(final Map map) {
    return null != map && !map.isEmpty();
  }

}
