package com.ford.sca.cap.vehicle.retrieve.transport;

import javax.validation.Valid;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MaintainVehicleUpdateRequest {

  private String brandCode;
  private String returnOutput;

  @Valid
  private RequestVehicleAttributes vehicleAttributes;
}
