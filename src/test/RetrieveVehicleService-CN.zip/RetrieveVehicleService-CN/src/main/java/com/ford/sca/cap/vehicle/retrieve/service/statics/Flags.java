package com.ford.sca.cap.vehicle.retrieve.service.statics;

public final class Flags {

  public static final String ACTIVE = "Y";
  public static final String ENABLED = "Y";

  private Flags() {
    throw new IllegalStateException("Utility class");
  }
}
