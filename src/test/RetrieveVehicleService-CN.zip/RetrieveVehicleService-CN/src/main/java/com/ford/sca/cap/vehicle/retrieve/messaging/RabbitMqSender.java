package com.ford.sca.cap.vehicle.retrieve.messaging;

import com.ford.sca.cap.vehicle.retrieve.service.statics.MQDetails;
import com.ford.sca.cap.vehicle.retrieve.util.LoggerBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Slf4j
@Component
public class RabbitMqSender {

  private static final String SEND_METHOD = "send";

  @Autowired
  private RabbitTemplate rabbitTemplate;

  /**
   * This method sends a message to the rabbit Queue.
   *
   * @param messageObject is the message object to be sent
   */
  public void send(final MQDetails mqDetails, final Message messageObject) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName(SEND_METHOD)
        .message("Sending to rabbit queue !"));
    if (mqDetails != null && messageObject != null) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName(SEND_METHOD).mqName(mqDetails.name())
          .message("Sending to rabbit queue !"));
      rabbitTemplate.send(mqDetails.getExchangeNm(), mqDetails.getRoutingKeyNm(), messageObject);
      LoggerBuilder.printInfo(log, logger -> logger.methodName(SEND_METHOD).mqName(mqDetails.name())
          .message("Message Sent to rabbit queue!"));
    } else {
      LoggerBuilder.printInfo(log, logger -> logger.methodName(SEND_METHOD)
          .message("Both MQDetails and Message are required!"));
    }
  }
}
