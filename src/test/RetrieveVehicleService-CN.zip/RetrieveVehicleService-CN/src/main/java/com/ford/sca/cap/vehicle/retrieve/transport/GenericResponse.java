package com.ford.sca.cap.vehicle.retrieve.transport;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class GenericResponse {

  //Ignore this field sending back to caller always
  @JsonIgnore
  private HttpStatus httpStatus;

  //Ignore this field sending back to caller when it is null
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String responseMessage;

  //Ignore this field sending back to caller when it is null
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String status;

  //Ignore this field sending back to caller when it is null
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String errorMsgId;

  //Ignore this field sending back to caller when it is null
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String errorMsg;

  //Ignore this field sending back to caller when it is null
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Date errorTime;

  /**
   * Default no-arg constructor to aid specific extending subclasses.
   **/
  public GenericResponse() {
    super();
  }

  /**
   * To generate {@link GenericResponse} for success response.
   *
   * @param httpStatus HttpStatus
   * @param responseMessage Success message
   */
  public GenericResponse(final HttpStatus httpStatus, final String responseMessage) {
    this.httpStatus = httpStatus;
    this.responseMessage = responseMessage;
  }

  /**
   * To generate {@link GenericResponse} for failure response.
   *
   * @param httpStatus HttpStatus
   * @param status Failure message
   * @param errorMsgId Error message ID
   * @param errorMsg Error message
   * @param errorTime When error happened
   */
  public GenericResponse(final HttpStatus httpStatus, final String status, final String errorMsgId,
      final String errorMsg, final Date errorTime) {
    this.httpStatus = httpStatus;
    this.status = status;
    this.errorMsgId = errorMsgId;
    this.errorMsg = errorMsg;
    this.errorTime = errorTime;
  }
}
