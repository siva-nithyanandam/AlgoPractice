package com.ford.sca.cap.vehicle.retrieve.config;

import com.ford.sca.cap.vehicle.retrieve.exception.CAPRuntimeException;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

  @Override
  protected void configure(final HttpSecurity http) {
    try {
      http.csrf().disable().authorizeRequests().anyRequest().permitAll();
    } catch (Exception e) {
      throw new CAPRuntimeException("Exception in SecurityConfig-configure", e);
    }
  }
}