# Service configurations and setup 
Below steps defining required prerequisites, configurations, setup, build and deploy.

## Prerequisites 

- Java 8
- Gradle 5.6
- Install lombok plugin
- Import supported code formatter from project to your IDE(Either Intellij or STS).

## Brief about application security

This application supports ADFS, Azure-AD and PCF-UAA with a minimal change in the 
source code and while building.

#### 1. ADFS - Active Directory Federation Services
This is completely managed by Ford. It primarily supports authentication, not authorization.
But this application extended the functionality to authorization to a certain level.

Each touch point has its own resource created, and mapped to required endpoints. Doing so,
Will be creating new resources when there is a new touch point. But permissions are given
only for required endpoints.

#### 2. Azure AD - Azure Active directory
Using azure's authorization server to authenticate and authorize.

#### 3. PCF UAA - Pivotal cloud foundary User Account and Authentication
Using Pivotal's authorization server to authenticate and authorize.

## Source code changes per different authentication type
a. Since ADFS uses different library for decoding the token and authorization,
it requires different '@PreAuthorize' value.

```@PreAuthorize("hasPermission('aud', 'consentReadResources')")```

This "consentReadResources" is a custom collection and externalized environment
property, and it contains list of resources that allowed to access the endpoint.
Example:
```
consentReadResources:
      - urn:sampleconsenttest:resource:api_consent_write:dev
      - urn:sampleconsenttest:resource:api_consent_read:dev
```

And given token must pre-append by ***"Bearer"***.

b. Wherein AzureAD and PCFUAA requires,

```@PreAuthorize("#oauth2.hasScope('consent.read')")```
 
## Build and Deploy

Since it supports different authentication type, there are few classes overriding 
each other resulting runtime failure. To avoid this, while building based on given authentication
type, it loads only the required libraries and classes for given authentication type.

1. PCF UAA

```bash
$ gradlew clean build -P pcfUAA
```

2. Azure AD

```bash
$ gradlew clean build -P azureAD
```

3. ADFS
```bash
$ gradlew clean build -P adfs
```

For running the application in local also, need to specify this authentication type. 
For ex, Set this property "adfs=adfs" under USER_DIR/.gradle/gradle.property

There is no changes to the deployment with respect to authentication type. All uses
same command to deploy.

```bash
$ cf push -f manifest-{required datacenter and env}.yml
```

## Testing
This project supports two types of automated testing, unit tests and functional tests.
Gradle build is configured such that each type of testing can be run individually and test results are stored in separate
directories.

Use the following command to run the unit tests:
```bash
$ gradle clean test
```
Use the following command to run the functional (user acceptance) tests:
```bash
$ gradle clean functionalTest
```