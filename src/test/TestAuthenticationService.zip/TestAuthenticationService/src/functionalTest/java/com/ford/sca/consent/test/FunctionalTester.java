package com.ford.sca.consent.test;

import com.ford.sca.cap.domain.OAuthTokenRequest;
import com.ford.sca.cap.domain.OauthTokenResponse;
import com.ford.sca.cap.vehicle.retrieve.config.ConfigService;
import com.ford.sca.cap.vehicle.retrieve.transport.RetrieveVehicleSuccessResponse;
import com.ford.sca.consent.test.config.ConfigProperties;
import java.util.HashMap;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

@SpringBootTest
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {ConfigService.class, ConfigProperties.class})
@EnableAutoConfiguration
@EntityScan("com.ford.sca.cap")
public class FunctionalTester {

  private static final String oAuthUrl = "https://oauthdev-cap.apps.pp01.cneast.cf.ford.com.cn/oauth/azureADtoken";
  private static final String rvUrl = "https://rvdev.apps.pp01.cneast.cf.ford.com.cn/rv/consumerAccounts/{capUserId}/vehicles?AppID={appId}";

  @Autowired
  private RestTemplate restTemplate;

  /**
   * To test positive flow of RetrieveVehicle functionality.
   */
  @Sql(scripts = "classpath:positive_flow.sql", executionPhase = ExecutionPhase.BEFORE_TEST_METHOD)
  @Test
  public void positive_flow() {

    //Get OAuth Token
    OAuthTokenRequest oAuthTokenRequest = new OAuthTokenRequest();
    oAuthTokenRequest.setClientId("c3cf3dc3-0bc5-454e-ac38-bde3ecda3269");
    oAuthTokenRequest.setClientSecret("BjebiVzqDZEaEbczzKqGz9RQuqAsmTZkjIMyEXK3VyE=");

    ResponseEntity<OauthTokenResponse> responseEntity = restTemplate
        .postForEntity(oAuthUrl, oAuthTokenRequest,
            OauthTokenResponse.class);

    //Frame request params
    Map<String, String> vars = new HashMap<>();
    vars.put("capUserId", "033830c8-0fc4-4b64-87c7-01e3098e2a75");
    vars.put("appId", "100504");

    HttpHeaders headers = new HttpHeaders();
    headers.set("Authorization", "bearer " + responseEntity.getBody().getAccess_token());
    HttpEntity<String> entity = new HttpEntity<>(headers);

    //Hit the url
    ResponseEntity<RetrieveVehicleSuccessResponse> rvEntity = restTemplate
        .exchange(rvUrl, HttpMethod.GET, entity, RetrieveVehicleSuccessResponse.class, vars);

    //Verify
    Assert.assertNotNull(rvEntity);
    Assert.assertNotNull(rvEntity.getBody());
  }
}
