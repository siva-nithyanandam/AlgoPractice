package com.ford.sca.consent.test.config;

import com.ford.sca.consent.test.exception.ConsentRuntimeException;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.authentication.BearerTokenExtractor;
import org.springframework.security.oauth2.provider.authentication.TokenExtractor;
import org.springframework.security.oauth2.provider.expression.OAuth2MethodSecurityExpressionHandler;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.web.filter.OncePerRequestFilter;

@Configuration
@EnableResourceServer
@EnableGlobalMethodSecurity(prePostEnabled = true, proxyTargetClass = true)
public class PcfUaaConfig {

  @Value("${RESOURCE_SERVER_CLIENT_ID}")
  private String resourceid;

  private final TokenExtractor tokenExtractor = new BearerTokenExtractor();

  /**
   * To create security configurations.
   */
  @Bean
  public GlobalMethodSecurityConfiguration globalMethodSecurityConfiguration() {
    return new GlobalMethodSecurityConfiguration() {
      @Override
      protected MethodSecurityExpressionHandler createExpressionHandler() {
        return new OAuth2MethodSecurityExpressionHandler();
      }
    };
  }

  /**
   * To create resource server configurer adapter.
   */
  @Bean
  public ResourceServerConfigurer resourceServerConfigurerAdapter() {
    return new ResourceServerConfigurerAdapter() {

      @Override
      public void configure(final ResourceServerSecurityConfigurer resources) {
        resources.resourceId(resourceid);
      }

      @Override
      public void configure(final HttpSecurity http) {
        http.addFilterAfter(new OncePerRequestFilter() {
          @Override
          protected void doFilterInternal(final HttpServletRequest request,
              final HttpServletResponse response, final FilterChain filterChain) {

            // We don't want to allow access to a resource with no
            // token so clear
            // the security context in case it is actually an
            // OAuth2Authentication

            if (tokenExtractor.extract(request) == null) {
              SecurityContextHolder.clearContext();
            }
            try {
              filterChain.doFilter(request, response);
            } catch (IOException | ServletException e) {
              throw new ConsentRuntimeException("Exception in PcfUaaConfig - doFilterInternal", e);
            }
          }
        }, AbstractPreAuthenticatedProcessingFilter.class);

        try {
          http.csrf().disable();
          http.authorizeRequests()
              .antMatchers("/configuration/**", "/swagger**", "/v2/**").permitAll();
        } catch (Exception e) {
          throw new ConsentRuntimeException("Exception in PcfUaaConfig - doFilterInternal", e);
        }
      }
    };
  }
}
