package com.ford.sca.consent.test.controller;

import com.ford.sca.consent.test.transport.GenericResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(path = "/api")
@Api("Sample Test authentication")
public class TestAuthenticationController {

  /**
   * Sample get response.
   *
   * @return {@link GenericResponse}
   */
  //For ADFS
  @PreAuthorize("hasPermission('aud', 'consentReadResources')")
  //For PCF-UAA and AzureAD
  //@PreAuthorize("#oauth2.hasScope('consent.read')")
  @ApiOperation(value = "sample", nickname = "sample test get")
  @GetMapping({"/sampleGet"})
  public GenericResponse sampleGetSuccess() {
    final GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    genericResponse.setStatus("Get is Success");
    return genericResponse;
  }

  /**
   * Sample post.
   *
   * @return {@link GenericResponse}
   */
  //For ADFS
  @PreAuthorize("hasPermission('aud', 'consentWriteResources')")
  //For PCF-UAA and AzureAD
  //@PreAuthorize("#oauth2.hasScope('consent.write')")
  @ApiOperation(value = "sample", nickname = "sample test post")
  @PostMapping({"/samplePost"})
  public GenericResponse samplePostSuccess() {
    final GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    genericResponse.setStatus("Post is Success");
    return genericResponse;
  }
}