package com.ford.sca.consent.test;

import com.google.common.collect.Lists;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class,
    DataSourceTransactionManagerAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
@EnableSwagger2
//@EnableCaching
@EntityScan("com.ford.sca.consent")
public class TestAuthenticationServiceLauncher {

  /**
   * To launch this application through SpringBoot.
   *
   * @param args args
   */
  public static void main(final String[] args) {
    SpringApplication.run(TestAuthenticationServiceLauncher.class, args);
  }

  /**
   * To create OAuth2 header section in the swagger API.
   */
  @Bean
  public Docket newsApi() {
    return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.any())
        .paths(PathSelectors.regex("/api.*")).build()
        .globalOperationParameters(Lists.newArrayList(new ParameterBuilder().name("Authorization")
            .description("OAuth2 bearer token").modelRef(new ModelRef("string"))
            .parameterType("header").defaultValue("Bearer ").required(true).build()))
        .apiInfo(apiInfo());
  }

  /**
   * To create API information.
   */
  private ApiInfo apiInfo() {
    return new ApiInfoBuilder()
        .title("Consumer Account Profile (CAP) retrieve vehicle Microservice")
        .description("CAP retrieve vehicle profile microservice API").version("1.0").build();
  }
}