package com.ford.sca.consent.test.config;

import com.ford.cloudnative.activedirectory.oauth2.resource.config.EnableActiveDirectoryOAuth2ResourceServer;
import com.ford.cloudnative.activedirectory.oauth2.resource.config.FordActiveDirectoryOauth2ResourceServerConfiguration;
import com.ford.sca.consent.test.exception.ConsentRuntimeException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.provider.expression.OAuth2MethodSecurityExpressionHandler;

@Configuration
@EnableWebSecurity
@EnableActiveDirectoryOAuth2ResourceServer
public class AzureADConfig {

  /**
   * To create security configurations.
   */
  @Bean
  public GlobalMethodSecurityConfiguration globalMethodSecurityConfiguration() {
    return new GlobalMethodSecurityConfiguration() {
      @Override
      protected MethodSecurityExpressionHandler createExpressionHandler() {
        return new OAuth2MethodSecurityExpressionHandler();
      }
    };
  }

  /**
   * To create resource server configurer adapter.
   */
  @Bean
  public ResourceServerConfigurer resourceServerConfigurer() {
    // Cross-Site Request Forgery--csrf
    return new ResourceServerConfigurerAdapter() {
      @Override
      public void configure(final HttpSecurity http) {
        try {
          http.csrf().disable().authorizeRequests().antMatchers("/**").permitAll();
        } catch (Exception e) {
          throw new ConsentRuntimeException("Exception in AzureADConfig - resourceServerConfigurer",
              e);
        }
      }
    };
  }

  /**
   * To create resource server configurer adapter.
   */
  @Configuration
  public static class Oauth2ResourceConfiguration extends
      FordActiveDirectoryOauth2ResourceServerConfiguration {

    @Override
    public void configure(final HttpSecurity http) {
      try {
        http.csrf().disable().authorizeRequests().antMatchers("/**").permitAll();
      } catch (Exception e) {
        throw new ConsentRuntimeException("Exception in AzureADConfig-Oauth2ResourceConfiguration",
            e);
      }
    }
  }
}