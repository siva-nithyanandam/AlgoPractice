package com.ford.sca.consent.test.exception;

import lombok.Getter;

@Getter
public class ConsentRuntimeException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private final String message;

  /**
   * To construct CAPRuntimeException with message and exception.
   * @param message message
   * @param exception {@link Exception}
   */
  public ConsentRuntimeException(final String message, final Exception exception) {
    super(exception);
    this.message = message;
  }
}
