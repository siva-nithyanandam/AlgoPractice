package com.ford.sca.consent.util;

public class ConsentCacheNames {

  public static final String APP_CODE_INFO = "appCodeInfo";

  public static final String ERROR_MESSAGES = "errorMessages";

  public static final String COUNTRY_INFO = "countryInfo";

  public static final String COUNTRY_LANG_INFO = "countryLangInfo";

  public static final String CONSENT_GROUP_CODE_INFO = "consentGroupCodeInfo";

  public static final String CONSENT_PRIVACY_INFO = "consentPrivacyInfo";
  
  public static final String CONSENT_CODE_INFO = "consentCodeInfo";

  public static final String CONSENT_PRIVACY_INFO_CONSENT_ID = "consentPrivacyInfoByConsentId";

  public static final String CONSENT_PRIVACY_INFO_POU_KEY = "consentPrivacyInfoByPouKey";

  public static final String CONSENT_PRIVACY_INFO_CONSENT_NAME = "consentPrivacyInfoByConsentName";

  public static final String DEVICE_TYPE_INFO = "deviceTypeInfo";

  public static final String DEVICE_TYPE_INFO_ID = "deviceTypeInfoById";

  public static final String PRIVACY_DEVICE_MAPPING_INFO = "privacyDeviceMappingInfo";

  public static final String PRIVACY_STATUS_INFO = "privacyStatusInfo";

  public static final String SUPPRESSION_TERM_INFO = "suppressionTermInfo";

  public static final String APP_CONSENT_RELATION_INFO = "appConsentRelationInfo";

  public static final String CONSENT_EXPIRY_RULE_INFO = "consentExpiryRuleInfo";

  public static final String DERIVED_PREFERENCES_INFO = "derivedPreferencesInfo";
  
  public static final String DEFAULT_PRIVACIES_INFO = "defaultPrivaciesInfo";

  private ConsentCacheNames() {
    throw new IllegalStateException("Utility class");
  }

}
