package com.ford.sca.consent.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

@Entity
@Setter
@Getter
@Table(name = "[MCNPC01_APP_CODE]")
public class AppCodeBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CNPC01_APP_C]")
  private Integer appId;

  @Nationalized
  @Column(name = "[CNPC01_APP_X]")
  private String appName;

  @Column(name = "[CNPC01_ACTIVE_F]")
  private String activeFlag;

}
