package com.ford.sca.consent.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ford.sca.consent.domain.AppCodeGroupBO;
import com.ford.sca.consent.domain.AppCodeGroupPK;

public interface AppCodeGroupRepository extends JpaRepository<AppCodeGroupBO, AppCodeGroupPK> {

  List<AppCodeGroupBO> findByAppCodeGroupPK_requestAppId(Integer appCode);

}
