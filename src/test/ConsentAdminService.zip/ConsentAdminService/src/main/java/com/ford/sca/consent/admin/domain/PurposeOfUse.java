package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[MCAPC16_PURPOSE_OF_USE]", catalog = "SCACAP", schema = "dbo")
public class PurposeOfUse implements Serializable {

	private static final long serialVersionUID = -7770773333215796463L;

	@Id
	@Column(name = "[CAPC16_POU_D]")
	private Integer pouId;

	@Column(name = "[CAPC16_APP_C]")
	private Float appId;

	@Column(name = "[CAPC16_APP_COUNTRY_ISO3_C]")
	private String appCountry;

	@Column(name = "[CAPC16_LL_D]")
	private String llId;

	@Column(name = "[CAPC16_CHNL_LL_EFF_START_S]")
	private Date effectiveLLIDStartDate;

	@Column(name = "[CAPC16_CHNL_LL_EFF_END_S]")
	private Date effectiveLLIDEndDate;

	@Column(name = "[CAPC16_POU_DELETE_S]")
	private Date pouDeleteTimestamp;

	@Column(name = "[CAPC16_CREATE_S]")
	private Date createDate;
	
	@Column(name = "[CAPC16_VALUE_EXCHANGE_X]")
    private String valueExchange;

    @Column(name = "[CAPC16_POU_CATEGORY_D]")
    private Integer pouCategoryID;

    @Column(name = "[CAPC16_POU_CATEGORY_N]")
    private String pouCategoryName;

	public Float getAppId() {
		return appId;
	}

	public void setAppId(Float appId) {
		this.appId = appId;
	}

	public String getAppCountry() {
		return appCountry;
	}

	public void setAppCountry(String appCountry) {
		this.appCountry = appCountry;
	}

	public String getLlId() {
		return llId;
	}

	public void setLlId(String llId) {
		this.llId = llId;
	}

	public Integer getPouId() {
		return pouId;
	}

	public void setPouId(Integer pouId) {
		this.pouId = pouId;
	}

	public Date getEffectiveLLIDStartDate() {
		return effectiveLLIDStartDate;
	}

	public void setEffectiveLLIDStartDate(Date effectiveLLIDStartDate) {
		this.effectiveLLIDStartDate = effectiveLLIDStartDate;
	}

	public Date getEffectiveLLIDEndDate() {
		return effectiveLLIDEndDate;
	}

	public void setEffectiveLLIDEndDate(Date effectiveLLIDEndDate) {
		this.effectiveLLIDEndDate = effectiveLLIDEndDate;
	}

	public Date getPouDeleteTimestamp() {
		return pouDeleteTimestamp;
	}

	public void setPouDeleteTimestamp(Date pouDeleteTimestamp) {
		this.pouDeleteTimestamp = pouDeleteTimestamp;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getValueExchange() {
		return valueExchange;
	}

	public void setValueExchange(String valueExchange) {
		this.valueExchange = valueExchange;
	}

	public Integer getPouCategoryID() {
		return pouCategoryID;
	}

	public void setPouCategoryID(Integer pouCategoryID) {
		this.pouCategoryID = pouCategoryID;
	}

	public String getPouCategoryName() {
		return pouCategoryName;
	}

	public void setPouCategoryName(String pouCategoryName) {
		this.pouCategoryName = pouCategoryName;
	}

}
