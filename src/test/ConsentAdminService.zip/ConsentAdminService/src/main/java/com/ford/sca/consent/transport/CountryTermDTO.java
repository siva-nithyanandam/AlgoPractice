package com.ford.sca.consent.transport;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CountryTermDTO {

  private String countryCode;

  private int term;

}
