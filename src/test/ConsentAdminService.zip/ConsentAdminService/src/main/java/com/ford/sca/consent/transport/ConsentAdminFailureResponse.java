package com.ford.sca.consent.transport;

import java.util.Date;

public class ConsentAdminFailureResponse extends ConsentAdminResponse {

    private static final long serialVersionUID = 1L;

    private String errorMsgId;

    private String errorMsg;

    private Date errorTime;

    private String status;

    @Override
    public String getStatus() {
        return status;
    }

    @Override
    public void setStatus(String status) {
        this.status = status;
    }

    public Date getErrorTime() {
        return errorTime;
    }

    public String getErrorMsgId() {
        return errorMsgId;
    }

    public void setErrorMsgId(String errorMsgId) {
        this.errorMsgId = errorMsgId;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public void setErrorTime(Date errorTime) {
        this.errorTime = errorTime;
    }

    @Override
    public String toString() {
        return "ConsentAdminFailureResponse [status=" + status + "errorMsgId=" + errorMsgId + ", errorMsg=" + errorMsg
                + ", errorTime=" + errorTime + "]";
    }

}
