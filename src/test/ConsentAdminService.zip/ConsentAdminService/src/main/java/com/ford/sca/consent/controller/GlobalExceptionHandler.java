package com.ford.sca.consent.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerMapping;

import com.ford.sca.consent.exception.AppCountryCodeNotExistsException;
import com.ford.sca.consent.exception.AppIdNotExistsException;
import com.ford.sca.consent.exception.ConsentBaseException;
import com.ford.sca.consent.exception.InvalidPouStatusException;
import com.ford.sca.consent.exception.MissingPouFieldsException;
import com.ford.sca.consent.exception.PouIdNotExistsException;
import com.ford.sca.consent.exception.RequiredFieldsException;
import com.ford.sca.consent.transport.AuditServiceRequest;
import com.ford.sca.consent.transport.ConsentAdminFailureResponse;
import com.ford.sca.consent.transport.ConsentAdminResponse;
import com.ford.sca.consent.util.AuditActivityUtil;
import com.ford.sca.consent.util.ConsentAdminServiceConstants;
import com.ford.sca.consent.util.PublishAuditMessageUtil;
import com.ford.sca.consent.util.ResponseBuilder;



@ControllerAdvice
@RestController
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private static String className = GlobalExceptionHandler.class.getSimpleName();

    @Autowired
    private ResponseBuilder responseBuilder;

    @Autowired
    private AuditActivityUtil auditActivityUtil;

    @Autowired
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @ExceptionHandler(RequiredFieldsException.class)
    ConsentAdminResponse reqFieldsMissingException(HttpServletResponse response, HttpServletRequest request) {
        response.setStatus(ConsentAdminServiceConstants.HTTP_412_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG0009_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_412_CODE);
        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_412_CODE));

        return consentAdminFailureResponse;

    }

    @ExceptionHandler(MissingPouFieldsException.class)
    ConsentAdminResponse missingPouFieldsException(HttpServletResponse response, HttpServletRequest request) {
        response.setStatus(ConsentAdminServiceConstants.HTTP_412_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG0009_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_412_CODE);

        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_412_CODE));

        return consentAdminFailureResponse;

    }

    @ExceptionHandler(PouIdNotExistsException.class)
    ConsentAdminResponse InvalidPouIdException(HttpServletResponse response, HttpServletRequest request) {
        response.setStatus(ConsentAdminServiceConstants.HTTP_417_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG0206_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_417_CODE);

        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_417_CODE));

        return consentAdminFailureResponse;

    }

    @ExceptionHandler(com.ford.sca.consent.exception.InvalidDateFormatException.class)
    ConsentAdminResponse InvalidDateFormatException(HttpServletResponse response, HttpServletRequest request) {
        response.setStatus(ConsentAdminServiceConstants.HTTP_412_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG0193_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_412_CODE);

        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_412_CODE));

        return consentAdminFailureResponse;

    }

    @ExceptionHandler(ConsentBaseException.class)
    ConsentAdminResponse startDateAfterEndDateException(HttpServletResponse response, HttpServletRequest request) {
        response.setStatus(ConsentAdminServiceConstants.HTTP_412_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG0199_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_412_CODE);

        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_412_CODE));

        return consentAdminFailureResponse;

    }

    @ExceptionHandler(InvalidPouStatusException.class)
    ConsentAdminResponse invalidPouStatusException(HttpServletResponse response, HttpServletRequest request) {
        response.setStatus(ConsentAdminServiceConstants.HTTP_412_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG0195_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_412_CODE);

        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_412_CODE));

        return consentAdminFailureResponse;

    }

    @ExceptionHandler(AppCountryCodeNotExistsException.class)
    ConsentAdminResponse appCountryCodeNotExistsException(HttpServletResponse response, HttpServletRequest request) {
        response.setStatus(ConsentAdminServiceConstants.HTTP_417_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG0208_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_417_CODE);

        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_417_CODE));

        return consentAdminFailureResponse;

    }

    @ExceptionHandler(AppIdNotExistsException.class)
    ConsentAdminResponse appIdNotProvided(HttpServletResponse response, HttpServletRequest request) {

        return buildResponseAndInvokeAuditService(response, request, ConsentAdminServiceConstants.HTTP_417_CODE,
                ConsentAdminServiceConstants.MSG0002_CODE);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ConsentAdminResponse httpMessageNotReadableException(HttpServletResponse response,
            HttpServletRequest request) {
        response.setStatus(ConsentAdminServiceConstants.HTTP_400_CODE);

        ConsentAdminFailureResponse failureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG0010_CODE);
        this.constructAuditServiceResponseAndPublish(request, response, failureResponse,
                ConsentAdminServiceConstants.HTTP_400_CODE);

        failureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_400_CODE));
        return failureResponse;

    }

    @ExceptionHandler(value = Exception.class)
    ConsentAdminResponse applicationException(HttpServletResponse response, HttpServletRequest request, Exception ex) {

        String methodName = "applicationException";
        auditActivityUtil.setRequestHeader(request);

        response.setStatus(ConsentAdminServiceConstants.HTTP_500_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG9999_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_500_CODE);

        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION, MDC.get(ConsentAdminServiceConstants.SERVICE),
                ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                "UnExpectedExceptionRaised",
                MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), ex.getMessage(), ex);

        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_500_CODE));
        return consentAdminFailureResponse;

    }

    @ExceptionHandler(AccessDeniedException.class)
    public ConsentAdminResponse handleAccessDeniedException(HttpServletResponse response, HttpServletRequest request,
            AccessDeniedException exception) {

        String methodName = "handleAccessDeniedException";
        auditActivityUtil.setRequestHeader(request);
        auditActivityUtil.setHttpServletResponseHeaders(response);
        response.setStatus(ConsentAdminServiceConstants.HTTP_401_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG9997_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_401_CODE);

        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION, MDC.get(ConsentAdminServiceConstants.SERVICE),
                ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                "accessDeniedException", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), exception.getClass().getName(),
                exception.getMessage(), exception);

        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_401_CODE));
        return consentAdminFailureResponse;
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ConsentAdminResponse handleHttpRequestMethodNotSupportedException(HttpServletResponse response,
            HttpServletRequest request, HttpRequestMethodNotSupportedException httpMethodNotSupportedExp) {
        String methodName = "handleHttpRequestMethodNotSupportedException";
        auditActivityUtil.setRequestHeader(request);
        auditActivityUtil.setHttpServletResponseHeaders(response);

        response.setStatus(ConsentAdminServiceConstants.HTTP_405_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG9998_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_405_CODE);

        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION, MDC.get(ConsentAdminServiceConstants.SERVICE),
                ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                "handleAccessDeniedException", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
                httpMethodNotSupportedExp.getClass().getName(), httpMethodNotSupportedExp.getMessage(),
                httpMethodNotSupportedExp);

        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_405_CODE));
        return consentAdminFailureResponse;
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ConsentAdminResponse missingServletRequestParameterException(Exception exception,
            HttpServletResponse response, HttpServletRequest request) {

        String methodName = "handleMissingParams";

        response.setStatus(ConsentAdminServiceConstants.HTTP_412_CODE);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(ConsentAdminServiceConstants.MSG0009_CODE);

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse,
                ConsentAdminServiceConstants.HTTP_412_CODE);

        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION, MDC.get(ConsentAdminServiceConstants.SERVICE),
                ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                "MissingParameter", MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), exception.getMessage(), exception);

        consentAdminFailureResponse.setStatusCode(String.valueOf(ConsentAdminServiceConstants.HTTP_412_CODE));

        return consentAdminFailureResponse;
    }

    private void constructAuditServiceResponseAndPublish(HttpServletRequest request, HttpServletResponse response,
            ConsentAdminFailureResponse consentAdminFailureResponse, int statusCode) {

        AuditServiceRequest auditServiceRequest = (AuditServiceRequest) request
                .getAttribute(ConsentAdminServiceConstants.AUDIT_SERVICE_REQUEST_ATTR_NAME);

        if (auditServiceRequest != null) {

            auditActivityUtil.createAuditServiceFailureResponse(auditServiceRequest, consentAdminFailureResponse,
                    statusCode);
            publishAuditMessageUtil.publishAuditMessage(auditServiceRequest);
        } else {
            String countrycode = null;
            @SuppressWarnings("unchecked")
            Map<String, String> pathVariables = (Map<String, String>) request
                    .getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
            if (null != pathVariables) {
                countrycode = pathVariables.get("appCountryCode");
            }

            auditActivityUtil.setRequestHeader(request);
            auditServiceRequest = auditActivityUtil.createAuditServiceRequest(request, null,
                    request.getParameter("appId"));
            publishAuditMessageUtil.publishAuditMessage(auditServiceRequest);
            publishAuditMessageUtil.publishAuditMessage(
                    auditActivityUtil.createAuditServiceResponse(auditServiceRequest, consentAdminFailureResponse));
        }

        auditActivityUtil.setHttpServletResponseHeaders(response);
    }

    private ConsentAdminFailureResponse buildResponseAndInvokeAuditService(HttpServletResponse response,
            HttpServletRequest request, Integer httpStatusCode, String responseMessageCode) {
        response.setStatus(httpStatusCode);

        ConsentAdminFailureResponse consentAdminFailureResponse = responseBuilder
                .constructResponse(responseMessageCode);

        consentAdminFailureResponse.setStatusCode(String.valueOf(httpStatusCode));

        this.constructAuditServiceResponseAndPublish(request, response, consentAdminFailureResponse, httpStatusCode);
        return consentAdminFailureResponse;
    }

}
