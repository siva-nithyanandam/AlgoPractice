package com.ford.sca.consent.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "audit-info")
@Getter
@Setter
public class AuditInfo {
  private String dataCenter;
  private String org;
  private String env;
  private String appName;
  private String version;
}
