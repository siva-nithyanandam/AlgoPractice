package com.ford.sca.consent.exception;

public class MissingPouFieldsException extends ConsentBaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private final String message;

	public MissingPouFieldsException(String message) {
		super(message);
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
