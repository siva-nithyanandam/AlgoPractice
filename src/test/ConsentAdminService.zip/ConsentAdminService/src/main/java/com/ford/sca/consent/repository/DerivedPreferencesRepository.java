package com.ford.sca.consent.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.domain.DerivedPreferencesBO;

@Repository
public interface DerivedPreferencesRepository extends JpaRepository<DerivedPreferencesBO, Long> {

  List<DerivedPreferencesBO> findByAppIdAndRegionCodeAndRequestIndicatorAndPrivacyPreferenceName(
      Integer appId, String regionCode, String statusCode, String privacyPreference);

}
