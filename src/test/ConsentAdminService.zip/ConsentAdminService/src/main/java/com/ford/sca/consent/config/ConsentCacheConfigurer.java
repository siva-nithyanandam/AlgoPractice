package com.ford.sca.consent.config;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurer;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.cache.interceptor.CacheResolver;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Configuration;
import com.ford.sca.consent.util.LoggerBuilder;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class ConsentCacheConfigurer implements CachingConfigurer {

  @Override
  public CacheManager cacheManager() {
    return null;
  }

  @Override
  public CacheResolver cacheResolver() {
    return null;
  }

  @Override
  public KeyGenerator keyGenerator() {
    return null;
  }

  @Override
  public CacheErrorHandler errorHandler() {

    return new CacheErrorHandler() {
      @Override
      public void handleCacheGetError(RuntimeException exception, Cache cache, Object key) {
        String methodName = "handleCacheGetError";
        LoggerBuilder
            .printWarn(log,
                logger -> logger.methodName(methodName).exception(exception)
                    .message(String.format("Failed due to: %s - Action: %s", exception.getMessage(),
                        "Retrieve From DB!")));
      }

      @Override
      public void handleCachePutError(RuntimeException exception, Cache cache, Object key,
          Object value) {
        String methodName = "handleCachePutError";
        LoggerBuilder.printWarn(log, logger -> logger.methodName(methodName).exception(exception)
            .message(String.format("Failed due to: %s", exception.getMessage())));
      }

      @Override
      public void handleCacheEvictError(RuntimeException exception, Cache cache, Object key) {
        String methodName = "handleCacheEvictError";
        LoggerBuilder.printWarn(log, logger -> logger.methodName(methodName).exception(exception)
            .message(String.format("Failed due to: %s", exception.getMessage())));
      }

      @Override
      public void handleCacheClearError(RuntimeException exception, Cache cache) {
        String methodName = "handleCacheClearError";
        LoggerBuilder.printWarn(log, logger -> logger.methodName(methodName).exception(exception)
            .message(String.format("Failed due to: %s", exception.getMessage())));
      }
    };

  }

}
