package com.ford.sca.consent.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name = "[MCNPC13_PRIVACY_DEVICE_MAPPING]")
public class PrivacyDeviceMappingBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CNPC13_PRIVACY_DEVICE_MAP_D]")
  private Long privacyDeviceMapId;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "[CNPC07_CONSENT_K]", referencedColumnName = "[CNPC07_CONSENT_K]")
  private ConsentPrivacyBO consentPrivacyBo;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "[CNPC03_DEVICE_TYPE_D]", referencedColumnName = "[CNPC03_DEVICE_TYPE_D]")
  private DeviceTypeBO deviceTypeBo;

  @Column(name = "[CNPC13_CONSUMER_TYP_X]")
  private String consumerType;

  @Column(name = "[CNPC02_REGION_C]")
  private String region;

  @Column(name = "[CNPC13_DEVICE_ATTRIBUTE_X]")
  private String deviceValueAttributeName;

}
