package com.ford.sca.consent.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.admin.domain.ConsentView;


@Repository
public interface ConsentUserRepository extends JpaRepository<ConsentView, Integer> {


	List<ConsentView> findByExpiryDateLessThanEqualAndExpiryDateIsNotNullAndConsentStatus(Date currentDate,
			String string);
}
