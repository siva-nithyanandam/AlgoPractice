package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[MCAPC17_POU_GOV_REG_STATUS]", catalog = "SCACAP", schema = "dbo")
public class POURegulationBO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "[CAPC17_POU_D]")
	private Integer pouID;

	@Column(name = "[CAPC17_STATUS_C]")
	private String pouStatus;

	@Column(name = "[CAPC17_COUNTRY_ISO3_C]")
	private String appCountryCode;

	@Column(name = "[CAPC17_CREATE_S]")
	private Date createDate;

	@Column(name = "[CAPC17_CREATE_USER_D]")
	private String createUser;

	@Column(name = "[CAPC17_CREATE_PROCESS_C]")
	private String createProcess;

	@Column(name = "[CAPC17_CREATE_APP_C]")
	private Float createAppCode;

	@Column(name = "[CAPC17_UPDATE_S]")
	private Date updateDate;

	@Column(name = "[CAPC17_UPDATE_USER_D]")
	private String updateUser;

	@Column(name = "[CAPC17_UPDATE_PROCESS_C]")
	private String updateProcess;

	@Column(name = "[CAPC17_UPDATE_APP_C]")
	private Float updateAppCode;

	@Column(name = "[CAPC17_EFF_START_Y]")
	private Date effectiveStartDate;

	@Column(name = "[CAPC17_EFF_END_Y]")
	private Date effectiveEndDate;

	@Column(name = "[CAPC17_POU_COMMENTS_X]")
	private String pouComments;

	public Integer getPouID() {
		return pouID;
	}

	public void setPouID(Integer pouID) {
		this.pouID = pouID;
	}

	public String getPouStatus() {
		return pouStatus;
	}

	public void setPouStatus(String pouStatus) {
		this.pouStatus = pouStatus;
	}

	public String getAppCountryCode() {
		return appCountryCode;
	}

	public void setAppCountryCode(String appCountryCode) {
		this.appCountryCode = appCountryCode;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCreateProcess() {
		return createProcess;
	}

	public void setCreateProcess(String createProcess) {
		this.createProcess = createProcess;
	}

	public Float getCreateAppCode() {
		return createAppCode;
	}

	public void setCreateAppCode(Float createAppCode) {
		this.createAppCode = createAppCode;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateProcess() {
		return updateProcess;
	}

	public void setUpdateProcess(String updateProcess) {
		this.updateProcess = updateProcess;
	}

	public Float getUpdateAppCode() {
		return updateAppCode;
	}

	public void setUpdateAppCode(Float updateAppCode) {
		this.updateAppCode = updateAppCode;
	}

	public Date getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public void setEffectiveStartDate(Date effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	public Date getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public void setEffectiveEndDate(Date effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	public String getPouComments() {
		return pouComments;
	}

	public void setPouComments(String pouComments) {
		this.pouComments = pouComments;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		POURegulationBO other = (POURegulationBO) o;
		return Objects.equals(appCountryCode, other.appCountryCode) && Objects.equals(pouID, other.pouID);
	}

	@Override
	public int hashCode() {
		return Objects.hash(appCountryCode, pouID);
	}
}
