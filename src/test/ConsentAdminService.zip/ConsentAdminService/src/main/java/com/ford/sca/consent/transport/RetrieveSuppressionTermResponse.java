package com.ford.sca.consent.transport;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RetrieveSuppressionTermResponse extends GenericResponse {

  private Long suppressionTermsCount;

  private Map<Long, Integer> suppressionTermMap;

}
