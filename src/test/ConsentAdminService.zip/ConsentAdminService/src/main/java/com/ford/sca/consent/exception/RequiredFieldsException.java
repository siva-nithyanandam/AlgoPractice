package com.ford.sca.consent.exception;

public class RequiredFieldsException extends ConsentBaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8269975693606109132L;
	private final String message;

	public RequiredFieldsException(String message) {
		super(message);
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
