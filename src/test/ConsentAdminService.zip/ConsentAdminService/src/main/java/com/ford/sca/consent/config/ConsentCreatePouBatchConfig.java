package com.ford.sca.consent.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.ford.sca.consent.service.ConsentAdminService;
import com.ford.sca.consent.util.ConsentAdminServiceConstants;


@Configuration
@EnableScheduling
public class ConsentCreatePouBatchConfig {


	private static final Logger LOGGER = LoggerFactory.getLogger(ConsentCreatePouBatchConfig.class);
	private static String className = ConsentCreatePouBatchConfig.class.getSimpleName();

	@Autowired
	private ConsentAdminService consentAdminService;
	
	@Scheduled(cron="${CRON_JOB_SCHEDULER_CONSENTEXPIRY_NEW_POU}")
	public void triggerJobForCheckingNewPouExpiry() {
		String methodName = "triggerJobForCheckingNewPouExpiry";
		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"Starting_triggerJobForCheckingNewPouExpiry", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

		consentAdminService.checkNewPouForExpirationRule();

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"Completed_triggerJobForCheckingNewPouExpiry", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
	}
	


}
