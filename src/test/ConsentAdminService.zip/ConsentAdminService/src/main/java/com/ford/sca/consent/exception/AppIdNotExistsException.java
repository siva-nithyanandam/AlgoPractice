package com.ford.sca.consent.exception;

public class AppIdNotExistsException extends ConsentBaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5581928907348752752L;

	public AppIdNotExistsException(String message) {
		super();
	}

}
