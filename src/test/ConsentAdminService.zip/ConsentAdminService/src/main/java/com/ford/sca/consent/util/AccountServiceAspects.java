package com.ford.sca.consent.util;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class AccountServiceAspects {

  /**
   * To log public method's IN and OUT with time duration.
   *
   * @param proceedingJoinPoint method signature
   * @param annotation annotation
   * @return an object triggered the implementation
   * @throws Throwable Any error
   */
  @Around("@annotation(annotation)")
  public Object logMethod(final ProceedingJoinPoint proceedingJoinPoint, final LogAround annotation)
      throws Throwable {
    final long start = System.currentTimeMillis();
    Object obj;
    try {
      LoggerBuilder.printInfo(proceedingJoinPoint.getSignature().getDeclaringType(), logger ->
          logger.methodName(proceedingJoinPoint.getSignature().getName()).message("Starting..."));
      obj = proceedingJoinPoint.proceed();
    } catch (Exception e) {
      LoggerBuilder.printError(proceedingJoinPoint.getSignature().getDeclaringType(),
          logger -> logger.methodName(proceedingJoinPoint.getSignature().getName()).exception(e)
              .exceptionMessage(e.getMessage()).message("Exception caught throw LogAround"));
      throw e;
    } finally {
      LoggerBuilder.printInfo(proceedingJoinPoint.getSignature().getDeclaringType(), logger ->
          logger.methodName(proceedingJoinPoint.getSignature().getName()).message("Exiting...")
              .responseTime(System.currentTimeMillis() - start));
    }
    return obj;
  }
}
