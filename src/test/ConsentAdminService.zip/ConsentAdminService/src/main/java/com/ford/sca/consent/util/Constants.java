package com.ford.sca.consent.util;

public final class Constants {

  public static final String SUCCESS_TEXT = "SUCCESS";
  public static final String FAILURE_TEXT = "FAILURE";
  public static final String CREATE_FAILED = "Privacy option(s) contains one or more error(s)";
  public static final String SUCCESS = "Success: Resource Retrieved or Updated";
  public static final String RETRIEVE_SUCCESS = "Record(s) Retrieved successfully";
  
  public static final String CREATE_SUCCESS = "Record(s) created successfully";
  public static final String UPDATE_SUCCESS = "Record(s) updated successfully";
  public static final String PARTIAL_SUCCESS = "Partial Success";
  public static final String SUCCESS_CREATE = "Success : Resource Created";
  public static final String SUCCESS_UPDATE = "Success : Resource Updated";
  public static final String MULTI_STATUS =
      "Multi String : Part of the request succeeded but " + "other parts did not.";
  public static final String NOT_FOUND = "Not Found:The requested resource could not be found but "
      + "may be available in the future.(System Generated error)";
  public static final String BAD_REQUEST = "Bad Request:The server cannot or will not process "
      + "the request due to an apparent client error.Header and Input Validation";
  public static final String UNAUTHORIZED = "Unauthorized:User might not have the necessary "
      + "credentials.Indicates an expired or otherwise invalid token.Indicates that a token is "
      + "required but was not submitted";
  public static final String SERVER_ERROR = "Internal Server Error:A generic error message, "
      + "given when an unexpected condition was encountered ";
  public static final String FORBIDDEN =
      "Forbidden: No permission for the resource being " + "requested. (System Generated error)";
  public static final String HTTP_REQUEST_METHOD_NOT_SUPPORTED =
      "Not Supported: HTTP Method " + "not allowed";
  public static final String HTTP_412_API_MSG =
      "Required Field(s) is/are missing:Required fields " + "are not in the request";
  public static final String HTTP_417_API_MSG = "Invalid field(s) is/are entered:Invalid Fields "
      + "are in the request or No data is available to be returned";
  public static final String HTTP_503_API_MSG = "Service Unavailable:Service  is currently "
      + "unavailable (because it is overloaded or down for maintenance)";
  public static final String HTTP_4XX_API_MSG = "Client Side Exception occured"
      + "Either the client service has been moved or unavailable at the moment";
  // Thread statics
  public static final String SERVICE_GROUP_NAME = "AccountServices";
  public static final String REQUEST_SERVICE_ID = "serviceId";
  public static final String CORRELATION_ID_HEADER_NAME = "X-Correlation-ID";
  public static final String VCAP_REQUEST_HEADER_NAME = "X-Vcap-Request-Id";
  public static final String BUILD_VERSION_HEADER_NAME = "X-Build-Version";
  public static final String SPAN_ID_HEADER_NAME = "X-B3-SpanId";
  public static final String TRACE_ID_HEADER_NAME = "X-B3-TraceId";
  public static final String AUTHORIZATION_HEADER_NAME = "Authorization";
  // Messages
  public static final String UNABLE_TO_GET_NOT_NULL_FIELDS = "Unable to get not null fields";
  // Common variables
  public static final String COLON_SLASHES = "://";
  public static final String COLON = ":";
  public static final String QUESTION_MARK = "?";
  public static final String HYPHEN = "-";
  public static final String SERVICE_FIELD_NAME = "service";
  // Notification Constants
  public static final String POST = "POST";
  public static final String PUT = "PUT";
  public static final String ORGANIZATION_INFO = "Unknown";
  public static final String APP_ID = "appId";
  public static final String GUID = "guid";
  public static final String EVENT_INITIATOR_NAME = "eventInitiatorName";
  public static final String EVENT_TYPE = "eventType";
  public static final String EVENT_REQUEST_TIMESTAMP = "evenRequestTimeStamp";
  public static final String EVENT_NAME = "eventName";
  // Request Contstants
  public static final String REQUEST_CORRELATION_ID_HEADER = "X-Correlation-ID";
  // Date Formats Constants
  public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
  public static final String DATE_FORMAT_YYYY_MM_DD_hh_mm_ss_ZULU = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
  public static final String DATE_FORMAT_YYYY_MM_DD_TIME_SEC = "yyyy-MM-dd HH:mm:ss.SSS";
  public static final String DATE_FORMAT_YYYY_MM_DD_TIME = "yyyy-MM-dd HH:mm:ss";
  public static final String MAX_ZULU_DATE_FORMAT_YYYY_MM_DD_TIME = "9999-12-31T00:00:00.000Z";

  // DB Constants
  public static final int COLUMN_LENGTH = 100;

  // Application variables
  public static final String SUPPRESSION_CATEGORY = "Suppression";
  public static final String REQUEST_FIELD_NAME = "Request";
  public static final String RESPONSE_FIELD_NAME = "Response";
  public static final String REQUEST_STATUS_NEW = "New";
  public static final String AUDIT_SERVICE_REQUEST_ATTR_NAME = "auditServiceRequest";
  public static final String REQUEST_STATUS_SUCCESS = "SUCCESS";
  public static final String REQUEST_STATUS_FAILURE = "FAILURE";


  private Constants() {
    throw new IllegalStateException("Utility class");
  }
}
