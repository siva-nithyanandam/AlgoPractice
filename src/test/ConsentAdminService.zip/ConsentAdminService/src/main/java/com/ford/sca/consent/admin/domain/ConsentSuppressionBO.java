package com.ford.sca.consent.admin.domain;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "[MCNPS01_CONSENT_SUPPRESSION]")
public class ConsentSuppressionBO {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "[CNPS01_CONSENT_SUPPRESSION_K]")
  private Long consentSuppressionKey;

  @Column(name = "[CNPS01_SCA_D]")
  private String scaId;

  @Column(name = "[CNPS01_USER_D]")
  private String guid;

  @Column(name = "[CNPC07_CONSENT_K]")
  private Long consentId;

  @Column(name = "[CNPC01_APP_C]")
  private Integer srcCode;

  @Column(name = "[CNPC01_SEC_APP_C]")
  private Integer secondarySrcCode;

  @Column(name = "[CNPC02_COUNTRY_ISO3_C]")
  private String countryCode;

  @Column(name = "[CNPC04_STATUS_C]")
  private String statusCode;

  @Column(name = "[CNPD01_DEVICE_D]")
  private Long deviceId;

  @Column(name = "[CNPC03_DEVICE_TYPE_D]")
  private Long deviceType;

  @Column(name = "[CNPS01_SUPPRESSION_S]")
  private Date receivedTimeStamp;

  @Column(name = "[CNPS01_CREATE_S]")
  private Date createDate;

  @Column(name = "[CNPS01_CREATE_USER_D]")
  private String createUser;

  @Column(name = "[CNPS01_CREATE_PROCESS_C]")
  private String createProcess;

  @Column(name = "[CNPS01_CREATE_APP_C]")
  private Integer createAppCode;

  @Column(name = "[CNPS01_UPDATE_S]")
  private Date updateDate;

  @Column(name = "[CNPS01_UPDATE_USER_D]")
  private String updateUser;

  @Column(name = "[CNPS01_UPDATE_PROCESS_C]")
  private String updateProcess;

  @Column(name = "[CNPS01_UPDATE_APP_C]")
  private Integer updateAppCode;

  @Column(name = "[CNPS01_START_S]")
  private Date startDate;

  @Column(name = "[CNPS01_END_S]")
  private Date endDate;

  @Column(name = "[CNPS01_CAPTURED_S]")
  private Date capturedTimestamp;
  
  
  
  @Override
  public boolean equals(Object o) {
      if (this == o)
          return true;
      if (o == null || getClass() != o.getClass())
          return false;
      ConsentSuppressionBO other = (ConsentSuppressionBO) o;
      return Objects.equals(srcCode, other.srcCode) && Objects.equals(countryCode, other.countryCode)
              && Objects.equals(consentId, other.consentId)&&Objects.equals(deviceId, other.deviceId);
  }

  @Override
  public int hashCode() {
      return Objects.hash(srcCode, countryCode, consentId,deviceId);
  }

}