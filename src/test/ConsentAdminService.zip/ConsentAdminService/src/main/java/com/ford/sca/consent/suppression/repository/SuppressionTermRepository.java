package com.ford.sca.consent.suppression.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.domain.SuppressionTermBO;

@Repository
public interface SuppressionTermRepository extends JpaRepository<SuppressionTermBO, Integer> {

}
