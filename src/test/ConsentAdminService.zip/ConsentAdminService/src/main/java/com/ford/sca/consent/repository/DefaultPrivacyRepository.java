package com.ford.sca.consent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.sca.consent.domain.DefaultPrivacyBO;

@Repository
public interface DefaultPrivacyRepository extends JpaRepository<DefaultPrivacyBO, Long> {

  List<DefaultPrivacyBO> findBySourceNameAndRegionAndPrivacyCategory(
     String sourceName, String region, String privacyCategory);

}