package com.ford.sca.consent.transport;

import java.util.Map;

import com.ford.sca.consent.domain.DeviceTypeBO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RetrieveDeviceTypeIds extends GenericResponse {

  private Long deviceTypeIdsCount;
  private Map<Long, String> deviceTypesMap;
  
}
