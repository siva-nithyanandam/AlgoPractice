package com.ford.sca.consent.util;

public class ConsentMailerConstant {
	public static final String FROM_ADDRESS = "scacapit@ford.com";
	public static final String SPLIT = ",";
	public static final String USER_DIR = "user.dir";
	public static final String FAILURE_REPORT_FILE_NAME = "FailuresReport.xlsx";
	public static final String FAILS_SHEET_NAME = "FailuresReport";
	public static final String DATE_FORMAT_YYYY_MM_DD_hh_mm_ss = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	public static final String EXCEL_FONT = "Arial";
	public static final String EXCEL_HEADER_VALUE = "LOG VALIDATION - FAILURE REPORT";
	public static final String EXCEL_REPORT_HEADER_VALUE = " REPORT GENERATED ON :-	";
	public static final String SIMPLE_DATE_FORMAT_D_M_YY = "d/m/yy";
	public static final String CNPT01_APP_C = "CNPT01_APP_C";
	public static final String CNPC02_COUNTRY_ISO3_C = "CNPC02_COUNTRY_ISO3_C";
	public static final String CNPT01_LL_D = "CNPT01_LL_D";
	public static final String CNPT01_EFF_FROM_S = "CNPT01_EFF_FROM_S";
	public static final String CNPT01_EFF_TO_S = "CNPT01_EFF_TO_S";
	public static final String CNPT01_TRANSACTION_S = "CNPT01_TRANSACTION_S";
	public static final String CNPT01_ERROR_X = "CNPT01_ERROR_X";
	public static final String MAIL_SUBJECT = "Consent recorded error";
	public static final String MAIL_TEXT = "Please find the consent error recorded attachment.";
}
