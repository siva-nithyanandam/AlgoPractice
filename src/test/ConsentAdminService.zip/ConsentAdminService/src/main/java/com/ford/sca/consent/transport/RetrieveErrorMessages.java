package com.ford.sca.consent.transport;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RetrieveErrorMessages extends GenericResponse {

  private Long errorMessageCount;

  private Map<String, String> errorMsgMap;

}
