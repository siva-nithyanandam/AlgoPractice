package com.ford.sca.consent.transport;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ConsentPrivacyByPouKeyResponse extends GenericResponse {

  private Long consentPrivaciesCount;

  private Map<Long, ConsentPrivacyDTO> consentPrivaciesMap;

}
