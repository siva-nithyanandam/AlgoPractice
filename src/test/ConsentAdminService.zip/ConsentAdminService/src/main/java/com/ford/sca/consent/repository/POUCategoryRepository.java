package com.ford.sca.consent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.admin.domain.PouCategoryBO;

@Repository
public interface POUCategoryRepository extends JpaRepository<PouCategoryBO, Long> {

  //public PouCategoryBO findByPouKeyAndCountryCode(Long pouKey, String countryCode);
  public PouCategoryBO findByPouKey(Long pouKey);

}
