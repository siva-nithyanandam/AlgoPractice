package com.ford.sca.consent.transport;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RetrieveCountry { 
    
    private String iso3CodeCountry;    
    
    private String iso2CodeCountry;    
    
    private String region;
        
    private String countryName;

}
