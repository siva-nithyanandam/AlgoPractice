package com.ford.sca.consent.util;

import javax.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

@Component
public class ResponseGenerator {
    public void setResponseHeaders(HttpServletResponse response) {
        response.setHeader(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME,
                MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME));
        response.setHeader(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME,
                MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME));
        response.setHeader(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME));
        response.setHeader(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME,
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    }

}
