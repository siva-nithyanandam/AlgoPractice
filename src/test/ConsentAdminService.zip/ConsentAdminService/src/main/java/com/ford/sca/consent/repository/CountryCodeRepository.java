package com.ford.sca.consent.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.consent.domain.CountryCodeBO;

public interface CountryCodeRepository extends JpaRepository<CountryCodeBO, String> {

  public CountryCodeBO findByIso3CodeCountry(String countryCode);

  public CountryCodeBO findByIso2CodeCountry(String countryCode);

}
