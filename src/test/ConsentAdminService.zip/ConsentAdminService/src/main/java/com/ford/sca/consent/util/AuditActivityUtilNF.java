package com.ford.sca.consent.util;

import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.consent.config.AuditInfo;
import com.ford.sca.consent.messaging.RabbitMqSender;
import com.ford.sca.consent.transport.AuditServiceRequest;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.transport.MQDetails;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@PropertySource(value = "classpath:git.properties", ignoreResourceNotFound = true)
public class AuditActivityUtilNF {

  @Autowired
  private transient AuditInfo auditInfo;

  @Value("${git.commit.id.abbrev}")
  private String commitIdAbbrev;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private RabbitMqSender rabbitMqSender;

  /**
   * To build audit activity for request for exceptions handled by the GlobalHandler.
   */
  public AuditServiceRequest createAuditServiceRequest(HttpServletRequest request, String appId,
      Date requestTimeStamp) {

    final String resourceUri = GenericAssister.constructResourceUri(request);

    AuditServiceRequest auditServiceRequest = new AuditServiceRequest();

    auditServiceRequest.setAppId(appId);
    auditServiceRequest.setRequestTimeStamp(requestTimeStamp);

    setAuditServiceRequest(request, resourceUri, auditServiceRequest);

    // setting the jsonBody skipped
    // is always null for exceptions handled by GolobalExceptionHandler

    return auditServiceRequest;
  }

  private void setAuditServiceRequest(HttpServletRequest request, String resourceUri,
      AuditServiceRequest auditServiceRequest) {
    auditServiceRequest.setJsonType(Constants.REQUEST_FIELD_NAME);
    auditServiceRequest.setDataCenter(auditInfo.getDataCenter());
    auditServiceRequest.setHttpMethod(request.getMethod());
    auditServiceRequest.setOrg(auditInfo.getOrg());
    auditServiceRequest.setRequestStatus(Constants.REQUEST_STATUS_NEW);
    auditServiceRequest
        .setServiceId(auditInfo.getAppName() + Constants.HYPHEN + auditInfo.getVersion());
    auditServiceRequest.setEnvironment(auditInfo.getEnv());
    auditServiceRequest.setTraceId(MDC.getCopyOfContextMap().get(Constants.TRACE_ID_HEADER_NAME));
    auditServiceRequest.setSpanId(MDC.getCopyOfContextMap().get(Constants.SPAN_ID_HEADER_NAME));
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    auditServiceRequest.setCorrelationId(MDC.get(Constants.CORRELATION_ID_HEADER_NAME));
    auditServiceRequest.setVcapRequestId(MDC.get(Constants.VCAP_REQUEST_HEADER_NAME));
    auditServiceRequest.setBuildVersion(MDC.get(Constants.BUILD_VERSION_HEADER_NAME));
    auditServiceRequest.setResourceUri(resourceUri);
  }

  /**
   * Create Audit Service Response using audit service request and generic response.
   *
   * @param auditServiceRequest is audit service request
   * @param genericResponse is generic response
   * @return AuditServiceRequest it is an object of {@link AuditServiceRequest}
   */
  public AuditServiceRequest createAuditServiceResponse(
      final AuditServiceRequest auditServiceRequest, final GenericResponse genericResponse) {
    AuditServiceRequest auditServiceResponse = new AuditServiceRequest();
    BeanUtils.copyProperties(auditServiceRequest, auditServiceResponse);
    auditServiceResponse.setResponseCode(genericResponse.getHttpStatus().toString());
    auditServiceResponse.setJsonType(Constants.RESPONSE_FIELD_NAME);
    try {
      auditServiceResponse.setJsonBody(objectMapper.writeValueAsString(genericResponse));
    } catch (JsonProcessingException e) {
      LoggerBuilder.printError(log, logger -> logger.message("Failed marshalling GenericResponse")
          .exceptionMessage(e.getMessage()).exception(e));
    }
    auditServiceResponse.setTranDateTime(Calendar.getInstance().getTime());
    auditServiceResponse.setRequestStatus(getAuditActivityResponseStatus(genericResponse));
    return auditServiceResponse;
  }

  /**
   * To build audit activity for response.
   */
  @LogAround
  public AuditServiceRequest createAuditServiceResponse(HttpServletRequest httpServletRequest,
      GenericResponse genericResponse, String appId, Date requestTimestamp) {
    AuditServiceRequest auditServiceRequest =
        createAuditServiceRequest(httpServletRequest, appId, requestTimestamp);
    auditServiceRequest.setResponseCode(genericResponse.getHttpStatus().toString());
    auditServiceRequest.setJsonType(Constants.RESPONSE_FIELD_NAME);
    try {
      auditServiceRequest.setJsonBody(objectMapper.writeValueAsString(genericResponse));
    } catch (JsonProcessingException e) {
      LoggerBuilder.printError(log, logger -> logger.message("Failed marshalling GenericResponse")
          .exceptionMessage(e.getMessage()).exception(e));
    }
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    auditServiceRequest.setRequestStatus(getAuditActivityResponseStatus(genericResponse));
    return auditServiceRequest;
  }

  /**
   * To construct the audit service request and publish it for Failure Responses coming from
   * GlobalExceptionHandler.
   */
  public void constructAuditServiceMessagesAndPublish(HttpServletRequest request,
      HttpServletResponse response, GenericResponse exceptionFailureResponse,
      Date requestTimeStamp) {

    setResponseHeaderAttributes(response);

    AuditServiceRequest auditServiceRequest =
        createAuditServiceRequest(request, request.getParameter("appCd"), requestTimeStamp);
    AuditServiceRequest auditServiceResponse =
        createAuditServiceResponse(auditServiceRequest, exceptionFailureResponse);

    // Get copy of MDC context to send to sub-threads
    Map<String, String> webThreadContext = MDC.getCopyOfContextMap();
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);

      // publish the audit message for request
      String methodName = "constructAuditServiceMessagesAndPublish";
      LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
          .message("Publishing audit activity for GlobalExceptionHandler request!"));
      publishAuditMessage(auditServiceRequest);

      // publish the audit message for response
      LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
          .message("Publishing audit activity for GlobalExceptionHandler response!"));
      publishAuditMessage(auditServiceResponse);
    });
  }

  /**
   * To publish request for audit activity.
   *
   * @param request HttpServletRequest
   * @param requestBody Given Object
   * @param appId Given String
   * @param requestTimestamp Given Date
   */
  public void publishAuditMessageMaintain_request(HttpServletRequest request, Object requestBody,
      String appId, Date requestTimestamp) {
    // Get copy of MDC context to send to sub-threads

    Map<String, String> webThreadContext = MDC.getCopyOfContextMap();
    AuditServiceRequest auditServiceRequest =
        createAuditServiceRequest(request, appId, requestTimestamp);
    try {
      auditServiceRequest.setJsonBody(objectMapper.writeValueAsString(requestBody));
    } catch (JsonProcessingException e) {
      LoggerBuilder.printError(log, logger -> logger.message("Failed marshalling GenericResponse")
          .exceptionMessage(e.getMessage()).exception(e));
    }

    // Trigger audit activity publish asynchronously
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      LoggerBuilder.printDebug(log,
          logger -> logger.message("Publishing audit activity for request"));
      publishAuditMessage(auditServiceRequest);
    });
  }

  /**
   * To publish response for audit activity.
   *
   * @param httpServletRequest HttpServletRequest
   * @param response Generated GenericResponse
   * @param appId Given String
   * @param requestTimestamp Given Date
   */
  public void publishAuditMessage_response(HttpServletRequest httpServletRequest,
      GenericResponse response, String appId, Date requestTimestamp) {

    AuditServiceRequest auditServiceResponse =
        createAuditServiceResponse(httpServletRequest, response, appId, requestTimestamp);

    // Get copy of MDC context to send to sub-threads
    Map<String, String> webThreadContext = MDC.getCopyOfContextMap();
    // Trigger audit activity publish asynchronously
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      LoggerBuilder.printDebug(log,
          logger -> logger.message("Publishing audit activity for response"));
      publishAuditMessage(auditServiceResponse);
    });

  }

  /**
   * To publish audit activity request into queue.
   */
  @LogAround
  public void publishAuditMessage(AuditServiceRequest auditServiceRequest) {
    String message;
    try {
      message = objectMapper.writeValueAsString(auditServiceRequest);
      LoggerBuilder.printDebug(log, logger -> logger.methodName("publishAuditMessage")
          .message("auditServiceRequest").request(message));
      MessageProperties messageProperties = new MessageProperties();
      messageProperties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);
      Message messageObject =
          new Message(message.getBytes(StandardCharsets.UTF_8), messageProperties);
      rabbitMqSender.send(MQDetails.AUDIT_ACTIVITY, messageObject);
    } catch (JsonProcessingException e) {
      LoggerBuilder.printError(log,
          logger -> logger.message("Failed marshalling auditServiceRequest")
              .exceptionMessage(e.getMessage()).exception(e));
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.message("Failed publishing audit message")
          .exceptionMessage(e.getMessage()).exception(e));
    }
  }

  /**
   * To store, request header attributes in MDC for logging purpose.
   */
  @LogAround
  public void storeRequestHeaderAttributes(HttpServletRequest request) {
    String correlationID = request.getHeader(Constants.CORRELATION_ID_HEADER_NAME);
    if (StringAssister.isEmptyString(correlationID)) {
      Random rand = new Random(System.currentTimeMillis());
      correlationID = Long.toHexString(rand.nextLong());
    }
    MDC.put(Constants.CORRELATION_ID_HEADER_NAME, correlationID);
    MDC.put(Constants.REQUEST_SERVICE_ID,
        auditInfo.getAppName() + Constants.HYPHEN + auditInfo.getVersion());
    MDC.put(Constants.VCAP_REQUEST_HEADER_NAME,
        request.getHeader(Constants.VCAP_REQUEST_HEADER_NAME));
    MDC.put(Constants.BUILD_VERSION_HEADER_NAME, frameBuildVersionHeaderName());
    MDC.put(Constants.REQUEST_SERVICE_ID,
        auditInfo.getAppName() + Constants.HYPHEN + auditInfo.getVersion());
    MDC.put(Constants.TRACE_ID_HEADER_NAME, request.getHeader(Constants.TRACE_ID_HEADER_NAME));

    MDC.put(Constants.AUTHORIZATION_HEADER_NAME,
        request.getHeader(Constants.AUTHORIZATION_HEADER_NAME));

  }

  /**
   * To frame project's build version header name by environment variables.
   *
   * @return a string represents build version header name
   */
  private String frameBuildVersionHeaderName() {
    String dataCenterShort = "";
    if (null != auditInfo.getDataCenter() && auditInfo.getDataCenter().length() > 2) {
      dataCenterShort = auditInfo.getDataCenter().substring(0, 2);
    }
    return auditInfo.getAppName() + Constants.HYPHEN + Constants.SERVICE_FIELD_NAME
        + Constants.HYPHEN + dataCenterShort + Constants.HYPHEN + auditInfo.getEnv()
        + Constants.HYPHEN + auditInfo.getVersion() + Constants.HYPHEN + commitIdAbbrev;
  }

  /**
   * To set response header attributes.
   */
  public void setResponseHeaderAttributes(HttpServletResponse response) {
    response.setHeader(Constants.TRACE_ID_HEADER_NAME, MDC.get(Constants.TRACE_ID_HEADER_NAME));
    response.setHeader(Constants.CORRELATION_ID_HEADER_NAME,
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME));
    response.setHeader(Constants.BUILD_VERSION_HEADER_NAME,
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME));
  }

  private String getAuditActivityResponseStatus(GenericResponse genericResponse) {
    String requestStatus;
    if (HttpStatus.CREATED.value() == genericResponse.getHttpStatus().value()
        || HttpStatus.OK.value() == genericResponse.getHttpStatus().value()) {
      requestStatus = Constants.REQUEST_STATUS_SUCCESS;
    } else {
      requestStatus = Constants.REQUEST_STATUS_FAILURE;
    }
    return requestStatus;
  }

}
