package com.ford.sca.consent.admin.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "MCNPC06_POU")
@Data
public class PouBO implements Serializable{

  private static final long serialVersionUID = 1L;
  
  @Id
  @Column(name = "[CNPC06_POU_K]")
  private Long pouKey;
  
  
  @Column(name = "[CNPC06_POU_D]")
  private Long pouId;
}



