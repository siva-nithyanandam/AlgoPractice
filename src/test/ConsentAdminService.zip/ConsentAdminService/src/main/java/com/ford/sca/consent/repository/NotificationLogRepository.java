package com.ford.sca.consent.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ford.sca.consent.admin.domain.NotificationLogBO;

public interface NotificationLogRepository extends JpaRepository<NotificationLogBO,Long>{
	List<NotificationLogBO> findByTranscationTimeStampBetween(Date startTime, Date endTime);
}
