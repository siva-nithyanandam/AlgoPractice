package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Nationalized;

import lombok.Data;
import lombok.ToString;


@Entity
@Table(name = "[MCAPN01_CONSENT_MGMT]", catalog = "SCACAP", schema = "dbo")
@Data
@ToString
public class ConsentMgmtBO implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = -3182227120646255610L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "[CAPN01_CONSENT_MGMT_SEQ_R]")
  private Integer consentSeqKey;

  @Column(name = "[CAPN01_LL_D]")
  private String lLId;

  @Column(name = "[CAPN01_CONSENT_STATUS_C]")
  private String consentStatus;

  @Column(name = "[CAPN01_CONSENT_S]")
  private Date consentTimestamp;

  @Column(name = "[CAPN01_CONSENT_ACCEPT_S]")
  private Date capturedTimestamp;

  @Column(name = "[CAPN01_COUNTRY_LANG_C]")
  private String displayedLanguage;

  @Column(name = "[CAPN01_USER_D]")
  private String capUserId;

  @Column(name = "[CAPN01_VIN_C]")
  private String vin;

  @Column(name = "[CAPN01_APP_C]")
  private Float AppID;

  @Column(name = "[CAPN01_PHYSICAL_DEVICE_D]")
  private String physicalDeviceId;
  
  @OneToMany(mappedBy="consentSeqKey", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
  private List<ConsentDeviceBO> consentDeviceList;


  public String getPhysicalDeviceId() {
    return physicalDeviceId;
  }

  public void setPhysicalDeviceId(String physicalDeviceId) {
    this.physicalDeviceId = physicalDeviceId;
  }

  @Column(name = "[CAPN01_APP_COUNTRY_ISO3_C]")
  private String appCountryCode;

  @Nationalized
  @Column(name = "[CAPN01_UI_NAME_VALUE_X]")
  private String requestJson;


  @Column(name = "[CAPN01_CONSENT_CONTEXT_D]")
  private String consentContext;

  @Column(name = "[CAPN01_CREATE_S]")
  private Date createDate;

  @Column(name = "[CAPN01_CREATE_USER_D]")
  private String createUser;

  @Column(name = "[CAPN01_CREATE_PROCESS_C]")
  private String createProcess;

  @Column(name = "[CAPN01_CREATE_APP_C]")
  private Float createAppCode;

  @Column(name = "[CAPN01_UPDATE_S]")
  private Date updateDate;

  @Column(name = "[CAPN01_UPDATE_USER_D]")
  private String updateUser;

  @Column(name = "[CAPN01_UPDATE_PROCESS_C]")
  private String updateProcess;

  @Column(name = "[CAPN01_UPDATE_APP_C]")
  private Float updateAppCode;

  @Column(name = "[CAPN01_GLOBAL_CUST_D]")
  private String scaId;
  

  @Column(name="[CAPN01_CAMPAIGN_D]")
  private String campaignID;
  
  @Column(name="[CAPN01_SMS_SHORT_C]")
  private Integer shortCode;
  
  @Column(name="[CAPN01_EXPIRY_S]")
  private Date expiryDate;
  
  

	


}
