package com.ford.sca.consent.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.consent.messaging.AuditSender;
import com.ford.sca.consent.transport.AuditServiceRequest;

@Component
public class PublishAuditMessageUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(PublishAuditMessageUtil.class);
    private static final String CLASSNAME = PublishAuditMessageUtil.class.getSimpleName();

    @Autowired
    private AuditSender auditSender;

    public void publishAuditMessage(AuditServiceRequest auditServiceRequest) {
        LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
                ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), CLASSNAME, "publishAuditMessage",
                "processing_PublishAuditMessageUtil_publishAuditMessage",
                MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
        try {
            String jsonInString = marshallMaintainServiceAudit(auditServiceRequest);
            auditSender.send(jsonInString);

        } catch (Exception ex) {
            LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
                    MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
                    ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                    MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), CLASSNAME, "publishAuditMessage",
                    "failed_PublishAuditMessageUtil_publishAuditMessage",
                    MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getSimpleName(),
                    ex.getMessage(), ex);

        }
    }

    private String marshallMaintainServiceAudit(AuditServiceRequest auditServiceRequest)
            throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        // from Object to Json String
        return mapper.writeValueAsString(auditServiceRequest);
    }
}
