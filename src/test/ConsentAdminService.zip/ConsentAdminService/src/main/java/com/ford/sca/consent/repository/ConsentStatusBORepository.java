package com.ford.sca.consent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ford.sca.consent.admin.domain.ConsentStatusBO;

public interface ConsentStatusBORepository extends JpaRepository<ConsentStatusBO, String> {

	ConsentStatusBO findByConsentStatus(String consentStatusCode);

}
