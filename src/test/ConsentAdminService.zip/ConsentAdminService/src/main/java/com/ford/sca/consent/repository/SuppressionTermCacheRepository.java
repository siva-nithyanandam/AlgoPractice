package com.ford.sca.consent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.domain.SuppressionTermBO;

@Repository
public interface SuppressionTermCacheRepository extends JpaRepository<SuppressionTermBO, Integer> {

  public SuppressionTermBO findByConsentIdAndCountryCode(Long consentId,
      String countryCode);

}
