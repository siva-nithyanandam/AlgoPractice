package com.ford.sca.consent.transport;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ConsentPrivacyDTO {

  private Long consentId;

  private Long pouKey;

  private String privacyCategory;

  private String privacyName;

  private String privacyDescription;

  private String privacyType;

}
