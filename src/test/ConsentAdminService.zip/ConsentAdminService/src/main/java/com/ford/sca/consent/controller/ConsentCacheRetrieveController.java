package com.ford.sca.consent.controller;

import com.ford.sca.consent.service.ConsentCacheService;
import com.ford.sca.consent.transport.ConsentPrivacyByNameResponse;
import com.ford.sca.consent.transport.ConsentPrivacyByPouKeyResponse;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.util.AuditActivityUtilNF;
import com.ford.sca.consent.util.CacheUtil;
import com.ford.sca.consent.util.GenericAssister;
import com.ford.sca.consent.util.LogAround;
import com.ford.sca.consent.util.LoggerBuilder;
import com.ford.sca.consent.util.ResponseBuilder;
import com.ford.sca.consent.util.ResponseCodes;
import com.ford.sca.consent.util.ScaConsentApiResponses;
import com.ford.sca.consent.util.StringAssister;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/cas/consent-administrations")
@ApiOperation("Admin Service Cache Retrieve Controller")
public class ConsentCacheRetrieveController {

  @Autowired
  private AuditActivityUtilNF auditActivityUtilNf;

  @Autowired
  ResponseBuilder responseBuilder;

  @Autowired
  CacheUtil cacheUtil;

  @Autowired
  ConsentCacheService cacheService;

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadAppCodesCache", nickname = "loadAppCodesCache")
  @PostMapping(value = "/v1/app-codes")
  @LogAround
  public GenericResponse loadAppCodesCache(
      @ApiParam(value = "Load AppIdCache",
          required = true) @RequestParam boolean loadAppIdCacheFromDB,
      @ApiParam(value = "App Id", required = false) @RequestParam Optional<Integer> appId,
      HttpServletRequest request, HttpServletResponse response) {

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    LoggerBuilder.printDebug(log, logger -> logger.methodName("loadAppCodesCache")
        .message(String.format("Loading Cache from DB: %s", loadAppIdCacheFromDB)));

    GenericResponse genericResponse = null;

    if (appId != null && appId.isPresent()) {
      genericResponse = cacheService.retrieveAppCodeCache(appId.get(), loadAppIdCacheFromDB);
    } else {
      genericResponse = cacheService.retrieveAllAppCodes(loadAppIdCacheFromDB);
    }

    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadErrorMessageCache", nickname = "loadErrorMessageCache")
  @PostMapping(value = "/v1/error-msgs")
  @LogAround
  public GenericResponse loadErrorMessageCache(
      @ApiParam(value = "Load ErrorMessageCache",
          required = true) @RequestParam boolean loadErrMsgCacheFromDB,
      @ApiParam(value = "Error MessageId", required = false) @RequestParam Optional<String> msgId,
      HttpServletRequest request, HttpServletResponse response) {

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    LoggerBuilder.printDebug(log, logger -> logger.methodName("loadErrorMessageCache")
        .message(String.format("Loading Cache from DB: %s", loadErrMsgCacheFromDB)));

    GenericResponse genericResponse = null;

    if (msgId != null && msgId.isPresent()) {
      genericResponse = cacheService.retrieveErrorMessageCache(msgId.get(), loadErrMsgCacheFromDB);
    } else {
      genericResponse = cacheService.retrieveAllErrorMessages(loadErrMsgCacheFromDB);
    }

    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadPrivacyStatusCache", nickname = "loadPrivacyStatusCache")
  @PostMapping(value = "/v1/privacy-statuses")
  @LogAround
  public GenericResponse loadPrivacyStatusCache(
      @ApiParam(value = "Load PrivacyStatusCache",
          required = true) @RequestParam boolean loadPrivacyStatusCacheFromDB,
      @ApiParam(value = "Privacy Status",
          required = false) @RequestParam Optional<String> privacyStatus,
      HttpServletRequest request, HttpServletResponse response) {

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    LoggerBuilder.printDebug(log, logger -> logger.methodName("loadPrivacyStatusCache")
        .message(String.format("Loading Cache from DB: %s", loadPrivacyStatusCacheFromDB)));

    GenericResponse genericResponse = null;

    if (privacyStatus != null && privacyStatus.isPresent()) {
      genericResponse = cacheService.retrievePrivacyStatusCache(privacyStatus.get(),
          loadPrivacyStatusCacheFromDB);
    } else {
      genericResponse = cacheService.retrieveAllPrivacyStatuses(loadPrivacyStatusCacheFromDB);
    }

    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadPrivacyDeviceMappingCache", nickname = "loadPrivacyDeviceMappingCache")
  @PostMapping(value = "/v1/privacy-device-mappings")
  @LogAround
  public GenericResponse loadPrivacyDeviceMappingCache(
      @ApiParam(value = "Load PrivacyStatusCache",
          required = true) @RequestParam("loadCacheFromDB") boolean loadCacheFromDB,
      @ApiParam(value = "privacy Name", required = false) @RequestParam(value = "privacyName",
          required = false) String privacyName,
      @ApiParam(value = "Region", required = false) @RequestParam(value = "region",
          required = false) String region,
      @ApiParam(value = "Consumer Type", required = false) @RequestParam(value = "consumerType",
          required = false) String consumerType,
      HttpServletRequest request, HttpServletResponse response) {

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    LoggerBuilder.printDebug(log, logger -> logger.methodName("loadPrivacyDeviceMappingCache")
        .message(String.format("Loading Cache from DB: %s", loadCacheFromDB)));

    GenericResponse genericResponse = null;

    if (StringAssister.isAllStringsNotEmpty(privacyName, region, consumerType)) {
      genericResponse = cacheService.retrievePrivacyDeviceMappingCache(privacyName, region,
          consumerType, loadCacheFromDB);
    } else if (StringAssister.isAllStringsEmpty(privacyName, region, consumerType)) {
      genericResponse = cacheService.retrieveAllPrivacyDeviceMappingsCache(loadCacheFromDB);
    } else {
      genericResponse = responseBuilder.generateResponse(ResponseCodes.REQUIRED_FIELD_EXCEPTION);
    }

    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }


  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadCountryInfoCache", nickname = "loadCountryInfoCache")
  @PostMapping("/v1/cntry-infos")
  public GenericResponse loadCountryInfoCache(
      @ApiParam(value = "Load CountryCache",
          required = true) @RequestParam boolean loadCountryInfoCacheFromDB,
      @ApiParam(value = "Country Code",
          required = false) @RequestParam Optional<String> countryCode,
      HttpServletRequest request, HttpServletResponse response) {

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);
    LoggerBuilder.printInfo(log, logger -> logger.methodName("loadCountryInfoCache"));
    GenericResponse genericResponse = null;

    if (countryCode != null && countryCode.isPresent()) {
      genericResponse =
          cacheService.retrieveCountryCodeCache(countryCode.get(), loadCountryInfoCacheFromDB);
    } else {
      genericResponse = cacheService.retrieveAllCountryCodes(loadCountryInfoCacheFromDB);
    }
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;

  }


  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadCountryLangCache", nickname = "loadCountryLangCache")
  @PostMapping("/v1/cntry-lang-infos")
  public GenericResponse loadCountryLangCache(
      @ApiParam(value = "Load CountryLangCache",
          required = true) @RequestParam boolean loadCntryLangCacheFromDB,
      @ApiParam(value = "CountryLang Code",
          required = false) @RequestParam Optional<String> countryLangCode,
      HttpServletRequest request, HttpServletResponse response) {

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);
    LoggerBuilder.printInfo(log, logger -> logger.methodName("loadCountryLangCache"));
    GenericResponse genericResponse = null;

    if (countryLangCode != null && countryLangCode.isPresent()) {
      genericResponse =
          cacheService.retrieveCountryLangCache(countryLangCode.get(), loadCntryLangCacheFromDB);
    } else {
      genericResponse = cacheService.retrieveAllCountryLangs(loadCntryLangCacheFromDB);
    }
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;

  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadConsentPrivacyCacheByConsentId",
      nickname = "loadConsentPrivacyCacheByConsentId")
  @PostMapping("/v1/consent-id-privacies")
  public GenericResponse loadConsentPrivacyCacheByConsentId(
      @ApiParam(value = "Load ConsentPrivacyCache",
          required = true) @RequestParam boolean loadConsentPrivacyCacheFromDB,
      @ApiParam(value = "Consent Id", required = false) @RequestParam Optional<Long> consentId,
      HttpServletRequest request, HttpServletResponse response) {

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);
    LoggerBuilder.printInfo(log, logger -> logger.methodName("loadConsentPrivacyCacheByConsentId"));
    GenericResponse genericResponse = null;

    if (consentId != null && consentId.isPresent()) {
      genericResponse = cacheService.retrieveConsentPrivacyCacheByConsentId(consentId.get(),
          loadConsentPrivacyCacheFromDB);
    } else {
      genericResponse =
          cacheService.retrieveAllConsentPrivacyDtlsByConsentId(loadConsentPrivacyCacheFromDB);
    }
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;

  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "Load Suppression Term Cache", nickname = "Load Suppression Term Cache")
  @PostMapping(value = "/v1/suppression-term-infos")
  public GenericResponse loadSuppressionTermCache(
      @ApiParam(value = "Load Suppression Term Cache From DB",
          required = true) @RequestParam boolean loadSuppressionTermFromDb,
      @ApiParam(value = "Consent ID", required = false) @RequestParam Optional<Long> consentId,
      @ApiParam(value = "Country Code", required = false) @RequestParam Optional<String> cntryCd,
      HttpServletRequest request, HttpServletResponse response) {
    String methodName = "loadSuppressionTermCache";

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    GenericResponse retrievedSuppressionTerms;
    if (!GenericAssister.isValidArguments(consentId, cntryCd)) {
      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.REQUIRED_FIELD_EXCEPTION);
      response.setStatus(genericResponse.getHttpStatus().value());
      return genericResponse;
    } else if (consentId.isPresent()) {
      retrievedSuppressionTerms = cacheService.retrieveSuppressionTermWithConsentIdAndCountry(
          consentId.get(), cntryCd.get(), loadSuppressionTermFromDb);
    } else {
      retrievedSuppressionTerms =
          cacheService.retrieveAllSuppressionTerms(loadSuppressionTermFromDb);
    }

    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).message("Retrieved Suppression Term Info"));
    response.setStatus(retrievedSuppressionTerms.getHttpStatus().value());
    return retrievedSuppressionTerms;
  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "Load Expiry Rule Cache", nickname = "Load Expiry Rule Cache")
  @PostMapping(value = "/v1/expiry-rules")
  public GenericResponse loadExpiryRuleCache(
      @ApiParam(value = "Load Expiry Rule Cache From DB",
          required = true) @RequestParam boolean loadExpiryRuleFromDb,
      @ApiParam(value = "Consent ID", required = false) @RequestParam Optional<Long> consentId,
      @ApiParam(value = "Country Code", required = false) @RequestParam Optional<String> cntryCd,
      HttpServletRequest request, HttpServletResponse response) {
    String methodName = "loadExpiryRuleCache";

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    GenericResponse retrievedExpiryRules;

    if (!GenericAssister.isValidArguments(consentId, cntryCd)) {
      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.REQUIRED_FIELD_EXCEPTION);
      response.setStatus(genericResponse.getHttpStatus().value());
      return genericResponse;
    } else if (consentId.isPresent()) {
      retrievedExpiryRules = cacheService.retrieveExpiryRulesWithConsentIdAndCountry(
          consentId.get(), cntryCd.get(), loadExpiryRuleFromDb);
    } else {
      retrievedExpiryRules = cacheService.retrieveAllExpiryRules(loadExpiryRuleFromDb);
    }

    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).message("Retrieved Expiry Rule Info"));
    response.setStatus(retrievedExpiryRules.getHttpStatus().value());
    return retrievedExpiryRules;
  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "Load Consent Privacy Info Cache Using Consent Name",
      nickname = "Load Consent Privacy Info Cache Using Consent Name")
  @PostMapping(value = "/v1/consent-name-privacies")
  public GenericResponse loadConsentPrivacyInfoCacheByConsentName(
      @ApiParam(value = "Load Consent Privacy Info Cache From DB",
          required = true) @RequestParam boolean loadConsentPrivacyCacheFromDb,
      @ApiParam(value = "Consent Name",
          required = false) @RequestParam Optional<String> consentName,
      HttpServletRequest request, HttpServletResponse response) {
    String methodName = "loadConsenPrivacyInfoCacheByConsentName";

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    ConsentPrivacyByNameResponse retrievedConsentPrivacies;
    if (consentName.isPresent()) {
      retrievedConsentPrivacies = cacheService.retrieveConsentPrivaciesWithConsentName(
          consentName.get(), loadConsentPrivacyCacheFromDb);
    } else {
      retrievedConsentPrivacies =
          cacheService.retrieveAllConsentPrivaciesWithConsentName(loadConsentPrivacyCacheFromDb);
    }

    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).message("Retrieved Consent Privacy Info"));
    response.setStatus(retrievedConsentPrivacies.getHttpStatus().value());
    return retrievedConsentPrivacies;
  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "Load Consent Privacy Info Cache Using Pou Key",
      nickname = "Load Consent Privacy Info Cache Using Pou Key")
  @PostMapping(value = "/v1/pou-key-privacies")
  public GenericResponse loadConsentPrivacyInfoCacheByPouKey(
      @ApiParam(value = "Load Consent Privacy Info Cache From DB",
          required = true) @RequestParam boolean loadConsentPrivacyCacheFromDb,
      @ApiParam(value = "Pou Key", required = false) @RequestParam Optional<Long> pouKey,
      HttpServletRequest request, HttpServletResponse response) {
    String methodName = "loadConsenPrivacyInfoCacheByPouKey";

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    ConsentPrivacyByPouKeyResponse retrievedConsentPrivacies;
    if (pouKey.isPresent()) {
      retrievedConsentPrivacies = cacheService.retrieveConsentPrivaciesWithPouKey(pouKey.get(),
          loadConsentPrivacyCacheFromDb);
    } else {
      retrievedConsentPrivacies =
          cacheService.retrieveAllConsentPrivaciesWithPouKey(loadConsentPrivacyCacheFromDb);
    }

    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).message("Retrieved Consent Privacy Info"));
    response.setStatus(retrievedConsentPrivacies.getHttpStatus().value());
    return retrievedConsentPrivacies;
  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadDeviceTypeCacheByName", nickname = "loadDeviceTypeCacheByName")
  @PostMapping(value = "/v1/device-type-infos")
  @LogAround
  public GenericResponse loadDeviceTypeCacheForName(
      @ApiParam(value = "Load DeviceTypeCacheByName",
          required = true) @RequestParam boolean loadDeviceTypeCacheFromDB,
      @ApiParam(value = "Device Type", required = false) @RequestParam Optional<String> deviceType,
      HttpServletRequest request, HttpServletResponse response) {
//    String methodName = "loadDeviceTypeCacheByName";

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    GenericResponse genericResponse = null;

    if (deviceType != null && deviceType.isPresent()) {
      genericResponse =
          cacheService.retrieveDeviceTypeCacheByName(deviceType.get(), loadDeviceTypeCacheFromDB);
    } else {
      genericResponse = cacheService.retrieveAllDeviceTypesCacheForName(loadDeviceTypeCacheFromDB);
    }

    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadDeviceTypeCacheById", nickname = "loadDeviceTypeCacheById")
  @PostMapping(value = "/v1/device-type-id-infos")
  @LogAround
  public GenericResponse loadDeviceTypeCacheForId(
      @ApiParam(value = "Load DeviceTypeCacheForId",
          required = true) @RequestParam boolean loadDeviceTypeIdCacheFromDB,
      @ApiParam(value = "Device Type Id",
          required = false) @RequestParam Optional<Long> deviceTypeId,
      HttpServletRequest request, HttpServletResponse response) {
//    String methodName = "loadDeviceTypeCacheForId";

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    GenericResponse genericResponse = null;

    if (deviceTypeId != null && deviceTypeId.isPresent()) {
      genericResponse =
          cacheService.retrieveDeviceTypeCacheById(deviceTypeId.get(), loadDeviceTypeIdCacheFromDB);
    } else {
      genericResponse = cacheService.retrieveAllDeviceTypesCacheForId(loadDeviceTypeIdCacheFromDB);
    }

    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadAppConsentRelationCache", nickname = "loadAppConsentRelationCache")
  @PostMapping(value = "/v1/app-consent-relations")
  @LogAround
  public GenericResponse loadappConsentRelationCache(
      @ApiParam(value = "LoadappConsentRelationFromDB",
          required = true) @RequestParam boolean loadAppConsentRelationFromDB,
      @ApiParam(value = "appCd", required = false) @RequestParam Optional<Integer> appCd,
      @ApiParam(value = "consentCd", required = false) @RequestParam Optional<Long> consentCd,
      HttpServletRequest request, HttpServletResponse response) {
//    String methodName = "loadDeviceTypeCacheForId";

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    GenericResponse genericResponse = null;

    if ((appCd != null && appCd.isPresent()) && (null != consentCd && consentCd.isPresent())) {
      genericResponse = cacheService.retrieveAppConsentRelationCache(appCd, consentCd,
          loadAppConsentRelationFromDB);
    } else if (!appCd.isPresent() && !consentCd.isPresent()) {
      genericResponse =
          cacheService.retrieveAllappConsentRelationCache(loadAppConsentRelationFromDB);
    } else {
      genericResponse = responseBuilder.generateResponse(ResponseCodes.REQUIRED_FIELD_EXCEPTION);
    }
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadDerivedPreferenceCache", nickname = "loadDerivedPreferenceCache")
  @PostMapping(value = "/v1/derived-preferences")
  @LogAround
  public GenericResponse loadDerivedPreferenceCache(
      @ApiParam(value = "LoadDerivedPreferenceFromDB",
          required = true) @RequestParam boolean loadDerivedPreferenceFromDB,
      @ApiParam(value = "appCd", required = false) @RequestParam Optional<Integer> appCd,
      @ApiParam(value = "region", required = false) @RequestParam Optional<String> region,
      @ApiParam(value = "statusCode", required = false) @RequestParam Optional<String> statusCode,
      @ApiParam(value = "consentName", required = false) @RequestParam Optional<String> consentName,
      HttpServletRequest request, HttpServletResponse response) {
//    String methodName = "loadDeviceTypeCacheForId";

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    GenericResponse genericResponse = null;

    if (appCd.isPresent() && region.isPresent() && statusCode.isPresent()
        && consentName.isPresent()) {
      genericResponse = cacheService.retrieveDerivedPreferenceCache(appCd, region, statusCode,
          consentName, loadDerivedPreferenceFromDB);
    } else if (!appCd.isPresent() && !region.isPresent() && !statusCode.isPresent()
        && !consentName.isPresent()) {
      genericResponse = cacheService.retrieveAllDerivedPreferenceCache(loadDerivedPreferenceFromDB);
    } else {
      genericResponse = responseBuilder.generateResponse(ResponseCodes.REQUIRED_FIELD_EXCEPTION);
    }

    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }


  @PreAuthorize("hasPermission('aud', 'consentAdminReadResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "loadDefaultPrivacyCache", nickname = "loadDefaultPrivacyCache")
  @PostMapping(value = "/v1/default-privacies")
  @LogAround
  public GenericResponse loadDefaultPrivacyCache(
      @ApiParam(value = "loadDefaultPrivacyFromDB",
          required = true) @RequestParam boolean loadDefaultPrivacyFromDB,
      @ApiParam(value = "sourceName", required = false) @RequestParam Optional<String> sourceName,
      @ApiParam(value = "region", required = false) @RequestParam Optional<String> region,
      @ApiParam(value = "privacyCategory", required = false) @RequestParam Optional<String> privacyCategory,
      HttpServletRequest request, HttpServletResponse response) {

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);

    GenericResponse genericResponse = null;

    if (sourceName.isPresent() && region.isPresent() && privacyCategory.isPresent()) {
      genericResponse = cacheService
          .retrieveDefaultPrivacyCache(sourceName, region, privacyCategory,
              loadDefaultPrivacyFromDB);
    } else if (!sourceName.isPresent() && !region.isPresent() && !privacyCategory.isPresent()) {
      genericResponse = cacheService.retrieveAllDefaultPrivacyCache(loadDefaultPrivacyFromDB);
    } else {
      genericResponse = responseBuilder.generateResponse(ResponseCodes.REQUIRED_FIELD_EXCEPTION);
    }
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }
}
