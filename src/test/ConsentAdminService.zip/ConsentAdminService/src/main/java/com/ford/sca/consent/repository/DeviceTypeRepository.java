package com.ford.sca.consent.repository;

import com.ford.sca.consent.domain.DeviceTypeBO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DeviceTypeRepository extends JpaRepository<DeviceTypeBO, Long> {

  public DeviceTypeBO findByDeviceType(String deviceType);

  public DeviceTypeBO findByDeviceTypeId(Long deviceTypeId);

}
