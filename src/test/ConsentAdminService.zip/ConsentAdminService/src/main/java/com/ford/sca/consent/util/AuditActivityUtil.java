package com.ford.sca.consent.util;

import java.util.Calendar;
import java.util.List;
import java.util.Random;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import com.ford.sca.consent.transport.AuditServiceRequest;
import com.ford.sca.consent.transport.ConsentAdminRequest;
import com.ford.sca.consent.transport.ConsentAdminResponse;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.transport.POURegulation;


@Component
@PropertySource(value = "classpath:git.properties", ignoreResourceNotFound = true)
public class AuditActivityUtil {

  private String className = this.getClass().getSimpleName();
  private static final Logger LOGGER = LoggerFactory.getLogger(AuditActivityUtil.class);

  @Value("${DATA_CENTER}")
  public String dataCenter;

  @Value("${ORG}")
  public String org;

  @Value("${ENVIRONMENT}")
  public String environment;

  @Value("${APP_NAME}")
  public String appName;

  @Value("${VERSION}")
  public String version;

  @Value("${git.commit.id.abbrev}")
  private String commitIdAbbrev;

  @Autowired
  private MarshallUtil marshallUtil;

  public AuditServiceRequest createAuditServiceRequest(HttpServletRequest request,
      List<POURegulation> pouRegulation) {
    String methodName = "createAuditServiceRequest";
    LOGGER.info(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "processing_AuditActivityUtil_createAuditServiceRequest",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

    String resourceURI =
        request.getScheme() + ConsentAdminServiceConstants.COLON_SLASHES + request.getServerName()
            + ConsentAdminServiceConstants.COLON + request.getServerPort() + request.getRequestURI()
            + ConsentAdminServiceConstants.QUESTION_MARK + request.getQueryString();

    AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
    auditServiceRequest.setJsonType(ConsentAdminServiceConstants.TYPE_REQUEST);
    auditServiceRequest.setDataCenter(dataCenter);
    auditServiceRequest.setHttpMethod(request.getMethod());
    auditServiceRequest.setJsonBody(marshallUtil.marshallCreateRequest(pouRegulation));
    auditServiceRequest.setOrg(org);
    auditServiceRequest.setRequestStatus(ConsentAdminServiceConstants.REQUEST_STATUS_NEW);
    auditServiceRequest.setResourceUri(resourceURI);
    auditServiceRequest.setServiceId(appName + ConsentAdminServiceConstants.HYPHEN + version);
    auditServiceRequest.setEnvironment(environment);
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    String correlationID = setRequestHeader(request);

    auditServiceRequest.setCorrelationId(correlationID);
    auditServiceRequest.setTraceId(MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME));
    auditServiceRequest.setSpanId(MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME));
    auditServiceRequest
        .setVcapRequestId(MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME));
    auditServiceRequest
        .setBuildVersion(MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    LOGGER.debug(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "completed_AuditActivityUtil_createAuditServiceRequest",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    return auditServiceRequest;
  }

  /**
   * 
   * @param request
   * @param tnCRequest
   * @param cAPUserID
   * @param appID
   * @return
   */
  public AuditServiceRequest createAuditServiceRequest(HttpServletRequest request,
      ConsentAdminRequest consentAdminRequest, String appID) {
    String methodName = "createAuditServiceRequest";
    LOGGER.info(ConsentAdminServiceConstants.LOG_INFO + ", capUserID = {} ",
        MDC.get(ConsentAdminServiceConstants.SERVICE),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "processing_" + className + "_" + methodName,
        MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), appID);

    AuditServiceRequest auditServiceRequest =
        setAuditServiceRequest(request, consentAdminRequest, appID);

    LOGGER.debug(ConsentAdminServiceConstants.LOG_INFO + " , auditRequest={}",
        MDC.get(ConsentAdminServiceConstants.SERVICE),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "completed_" + className + "_" + methodName,
        MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
        auditServiceRequest.toString());
    return auditServiceRequest;
  }

  private AuditServiceRequest setAuditServiceRequest(HttpServletRequest request,
      ConsentAdminRequest consentAdminRequest, String appID) {

    AuditServiceRequest auditServiceRequest = new AuditServiceRequest();

    auditServiceRequest.setAppId(appID);
    auditServiceRequest.setJsonType(ConsentAdminServiceConstants.TYPE_REQUEST);
    auditServiceRequest.setHttpMethod(request.getMethod());
    auditServiceRequest.setJsonBody(marshallUtil.marshallCreateRequest(consentAdminRequest));
    auditServiceRequest.setOrg(org);
    auditServiceRequest.setRequestStatus(ConsentAdminServiceConstants.REQUEST_STATUS_NEW);
    auditServiceRequest.setServiceId(appName + ConsentAdminServiceConstants.HYPHEN + version);
    auditServiceRequest.setEnvironment(environment);
    auditServiceRequest.setTraceId(
        MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME));
    auditServiceRequest
        .setSpanId(MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME));
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    auditServiceRequest
        .setCorrelationId(MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME));
    auditServiceRequest.setResourceUri(setRequestURI(request));
    auditServiceRequest
        .setVcapRequestId(MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME));
    auditServiceRequest
        .setBuildVersion(MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    return auditServiceRequest;
  }

  public String setRequestURI(HttpServletRequest request) {

    String resourceURI =
        request.getScheme() + ConsentAdminServiceConstants.COLON_SLASHES + request.getServerName()
            + ConsentAdminServiceConstants.COLON + request.getServerPort() + request.getRequestURI()
            + ConsentAdminServiceConstants.QUESTION_MARK + request.getQueryString();

    return resourceURI;

  }

  public AuditServiceRequest createAuditServiceRequestforConsent(HttpServletRequest request,
      ConsentAdminRequest consentAdminRequest) {
    String methodName = "createAuditServiceRequest";
    LOGGER.info(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "processing_AuditActivityUtil_createAuditServiceRequest",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

    String resourceURI =
        request.getScheme() + ConsentAdminServiceConstants.COLON_SLASHES + request.getServerName()
            + ConsentAdminServiceConstants.COLON + request.getServerPort() + request.getRequestURI()
            + ConsentAdminServiceConstants.QUESTION_MARK + request.getQueryString();

    AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
    auditServiceRequest.setAppId(String.valueOf(ConsentAdminServiceConstants.CAP_APP_CODE));
    auditServiceRequest.setJsonType(ConsentAdminServiceConstants.TYPE_REQUEST);
    auditServiceRequest.setDataCenter(dataCenter);
    auditServiceRequest.setHttpMethod(request.getMethod());
    auditServiceRequest
        .setJsonBody(marshallUtil.marshallCreateRequestforConsent(consentAdminRequest));
    auditServiceRequest.setOrg(org);
    auditServiceRequest.setRequestStatus(ConsentAdminServiceConstants.REQUEST_STATUS_NEW);
    auditServiceRequest.setResourceUri(resourceURI);
    auditServiceRequest.setServiceId(appName + ConsentAdminServiceConstants.HYPHEN + version);
    auditServiceRequest.setEnvironment(environment);
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    String correlationID = setRequestHeader(request);
    auditServiceRequest.setCorrelationId(correlationID);

    auditServiceRequest.setTraceId(MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME));
    auditServiceRequest.setSpanId(MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME));
    auditServiceRequest
        .setVcapRequestId(MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME));
    auditServiceRequest
        .setBuildVersion(MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    LOGGER.debug(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "completed_AuditActivityUtil_createAuditServiceRequest",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    return auditServiceRequest;
  }

  public AuditServiceRequest createAuditServiceResponse(AuditServiceRequest auditServiceRequest,
      ConsentAdminResponse consentAdminResponse) {
    String methodName = "createAuditServiceResponse";
    LOGGER.info(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "processing_AuditActivityUtil_createAuditServiceResponse",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    auditServiceRequest.setResponseCode(String.valueOf(consentAdminResponse.getStatusCode()));
    auditServiceRequest.setJsonType(ConsentAdminServiceConstants.TYPE_RESPONSE);
    auditServiceRequest.setJsonBody(marshallUtil.marshallResponse(consentAdminResponse));
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    auditServiceRequest.setRequestStatus(consentAdminResponse.getStatus());

    LOGGER.debug(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "completed_AuditActivityUtil_createAuditServiceResponse",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    return auditServiceRequest;
  }

  public AuditServiceRequest createAuditServiceResponse(AuditServiceRequest auditServiceRequest,
      GenericResponse genericResponse) {
    String methodName = "createAuditServiceResponse";
    LOGGER.info(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "processing_AuditActivityUtil_createAuditServiceResponse",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    auditServiceRequest.setResponseCode(String.valueOf(genericResponse.getHttpStatus().value()));
    auditServiceRequest.setJsonType(ConsentAdminServiceConstants.TYPE_RESPONSE);
    auditServiceRequest.setJsonBody(marshallUtil.marshallResponse(genericResponse));
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    auditServiceRequest.setRequestStatus(genericResponse.getStatus());

    LOGGER.debug(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "completed_AuditActivityUtil_createAuditServiceResponse",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    return auditServiceRequest;
  }

  public String setRequestHeader(HttpServletRequest request) {
    String methodName = "setRequestHeader";
    LOGGER.info(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "processing_AuditActivityUtil_setRequestHeader",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    String correlationID =
        request.getHeader(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME);
    if (correlationID == null) {
      Random rand = new Random(System.currentTimeMillis());
      correlationID = Long.toHexString(rand.nextLong());
    }
    MDC.put(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME, correlationID);
    MDC.put(ConsentAdminServiceConstants.REQUEST_SERVICE_ID,
        appName + ConsentAdminServiceConstants.HYPHEN + version);
    MDC.put(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME,
        request.getHeader(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME));
    MDC.put(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME, fetchBuildVersion());
    LOGGER.debug(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "completed_AuditActivityUtil_setRequestHeader",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
    return correlationID;
  }

  public AuditServiceRequest createAuditServiceFailureResponse(
      AuditServiceRequest auditServiceRequest, ConsentAdminResponse consentAdminResponse,
      int httpResponseCode) {
    String methodName = "createAuditServiceFailureResponse";
    LOGGER.info(
        ConsentAdminServiceConstants.LOG_INFO + " , consentAdminResponse={} , httpResponseCode={} ",
        MDC.get(ConsentAdminServiceConstants.SERVICE),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "processing_" + className + "_" + methodName,
        MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
        consentAdminResponse.toString(), httpResponseCode);
    auditServiceRequest.setResponseCode(String.valueOf(httpResponseCode));
    auditServiceRequest.setJsonType(ConsentAdminServiceConstants.TYPE_RESPONSE);
    auditServiceRequest.setJsonBody(marshallUtil.marshallResponse(consentAdminResponse));
    auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    auditServiceRequest.setRequestStatus(ConsentAdminServiceConstants.REQUEST_STATUS_FAILURE);
    LOGGER.debug(ConsentAdminServiceConstants.LOG_INFO + "capUserID = {} , appId = {} ",
        MDC.get(ConsentAdminServiceConstants.SERVICE),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "completed_" + className + "_" + methodName,
        MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
        auditServiceRequest.getAppId());
    return auditServiceRequest;

  }

  public void setHttpServletResponseHeaders(HttpServletResponse response) {
    response.setHeader(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME,
        MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME));
    response.setHeader(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME));
    response.setHeader(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME,
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

  }

  private String fetchBuildVersion() {
    String dataCenterShort = "";
    if (null != dataCenter && dataCenter.length() > 2) {
      dataCenterShort = dataCenter.substring(0, 2);
    }
    return appName + ConsentAdminServiceConstants.HYPHEN + ConsentAdminServiceConstants.SERVICE
        + ConsentAdminServiceConstants.HYPHEN + dataCenterShort
        + ConsentAdminServiceConstants.HYPHEN + environment + ConsentAdminServiceConstants.HYPHEN
        + version + ConsentAdminServiceConstants.HYPHEN + commitIdAbbrev;
  }

}
