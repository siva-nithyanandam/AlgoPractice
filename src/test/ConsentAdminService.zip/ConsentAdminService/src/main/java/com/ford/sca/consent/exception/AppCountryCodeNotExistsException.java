package com.ford.sca.consent.exception;

public class AppCountryCodeNotExistsException extends ConsentBaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5581928907348752752L;

	public AppCountryCodeNotExistsException(String message) {
		super();
	}

}
