package com.ford.sca.consent.service;

public interface ConsentAdminService {

	public void updateExpiredConsentStatusBatch();

	public void checkNewPouForExpirationRule();

}
