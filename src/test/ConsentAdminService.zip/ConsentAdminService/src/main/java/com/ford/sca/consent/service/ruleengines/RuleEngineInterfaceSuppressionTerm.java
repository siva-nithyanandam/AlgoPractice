package com.ford.sca.consent.service.ruleengines;

import com.ford.sca.consent.statics.RequestMode;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.transport.SuppressionTermRequest;
import com.ford.sca.consent.transport.ApiParams;
import com.ford.sca.consent.transport.ConsentAdminRequest;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;

public interface RuleEngineInterfaceSuppressionTerm {

  /**
   * To identify appropriate implementation for given request.
   *
   * @return TRUE if the request behalf of that ruleengines Else FALSE
   */
  boolean isRequestBehalfOfThisImpl(String groupType);

  /**
   * To get a set of all supported group types which are grouped in this master rule engine
   * implementation.
   */
  Set<String> getSupportedRegions();

  /**
   * To perform the required validation on consent admin request in its identified
   * implementation.
   *
   * @param apiParams All required API params
   * @param suppressionTermRequest {@link ConsentAdminRequest} - consent admin request
   * @param request HttpRequest
   * @return An optional value of {@link GenericResponse}
   */
  Optional<GenericResponse> validate(ApiParams apiParams,
      SuppressionTermRequest suppressionTermRequest, RequestMode requestMode,
      HttpServletRequest request);

  /**
   * Perform DB operations as per the implementation.
   */
  GenericResponse triggerDBProcesses(ApiParams apiParams,
      SuppressionTermRequest suppressionTermRequest, RequestMode requestMode,
      HttpServletRequest request);

  /**
   * To trigger any post DB operations if any.
   */
  void triggerPostDBProcesses(ApiParams apiParams,
      SuppressionTermRequest suppressionTermRequest, RequestMode requestMode);

}
