package com.ford.sca.consent.validators;

import com.ford.sca.consent.statics.RequestMode;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.transport.SuppressionTermRequest;
import com.ford.sca.consent.transport.ApiParams;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import org.springframework.scheduling.annotation.Async;

public interface ValidatorSuppressionTerm {

  /**
   * To checkAndConstruct given suppression summary service request by respective validators.
   *
   * @return Null when valid Else NOT NULL
   */
  @Async("cpTaskExecutor")
  Future<GenericResponse> checkAndConstruct(ApiParams apiParams,
      SuppressionTermRequest suppressionTermRequest, RequestMode requestMode,
      HttpServletRequest request);
}
