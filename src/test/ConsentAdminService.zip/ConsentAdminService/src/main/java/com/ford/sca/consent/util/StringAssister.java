package com.ford.sca.consent.util;

import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class StringAssister {

  private StringAssister() {
    throw new IllegalStateException("String Utility class");
  }

  /**
   * To checkAndConstruct given status is not null and not empty.
   *
   * @param str - a status to be checked
   * @return TRUE - If not null and not empty, FALSE - if null or empty
   */
  public static boolean isNotEmptyString(final String str) {
    return !isEmptyString(str);
  }

  /**
   * To checkAndConstruct given status is not null and not empty.
   *
   * @param str - a status to be checked
   * @return TRUE - if null or empty, FALSE - If not null and not empty
   */
  public static boolean isEmptyString(final String str) {
    if (null != str) {
      for (int index = 0; index < str.length(); index++) {
        if (!Character.isWhitespace(str.charAt(index))) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * To checkAndConstruct given status is not null and not empty.
   *
   * @param strs - a status to be checked for each input
   * @return TRUE - If all input strings are not null and not empty, FALSE - if at least one input
   *         string is null or empty
   */
  public static boolean isAllStringsNotEmpty(final String... strs) {
    return Stream.of(strs).allMatch(StringAssister::isNotEmptyString);
  }

  /**
   * To checkAndConstruct if at least one of the input strings is not null and not empty.
   *
   * @param strs - a status to be checked for each input string
   * @return TRUE - If at least one input string is not null and not empty, FALSE - otherwise
   */
  public static boolean isAnyStringNotEmpty(final String... strs) {
    return Stream.of(strs).anyMatch(StringAssister::isNotEmptyString);
  }

  /**
   * To checkAndConstruct given status is not null and not empty.
   *
   * @param strs - a status to be checked for each input
   * @return TRUE - If all input strings are null and empty, FALSE - if at least one input string is
   *         valid
   */
  public static boolean isAllStringsEmpty(final String... strs) {
    return Stream.of(strs).allMatch(StringAssister::isEmptyString);
  }

  /**
   * To checkAndConstruct if at least one of the input strings is null or empty.
   *
   * @param strs - a status to be checked for each input string
   * @return TRUE - If at least one input string is null or empty, FALSE - otherwise
   */
  public static boolean isAnyStringEmpty(final String... strs) {
    return Stream.of(strs).anyMatch(StringAssister::isEmptyString);
  }

  /**
   * To truncate the given status to a given length if status's length > given length.
   *
   * @param str - String to be truncated
   * @param len - Max length to be given for a status
   * @return a truncated status if status's length is greater than given length, Or else given
   *         status as is will be returned
   */
  public static String truncateString(final String str, final int len) {
    if (str != null && str.length() > len) {
      return str.substring(0, len);
    } else {
      return str;
    }
  }

}
