package com.ford.sca.consent.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.consent.service.NotifyService;
import com.ford.sca.consent.service.SuppressionTermService;
import com.ford.sca.consent.statics.RequestMode;
import com.ford.sca.consent.transport.ApiParams;
import com.ford.sca.consent.transport.AuditServiceRequest;
import com.ford.sca.consent.transport.ConsentAdminRequest;
import com.ford.sca.consent.transport.ConsentAdminResponse;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.transport.SuppressionTermRequest;
import com.ford.sca.consent.util.AuditActivityUtil;
import com.ford.sca.consent.util.AuditActivityUtilNF;
import com.ford.sca.consent.util.ConsentAdminServiceConstants;
import com.ford.sca.consent.util.ConsentAdminServiceValidator;
import com.ford.sca.consent.util.GenericAssister;
import com.ford.sca.consent.util.LogAround;
import com.ford.sca.consent.util.LoggerBuilder;
import com.ford.sca.consent.util.PublishAuditMessageUtil;
import com.ford.sca.consent.util.ResponseGenerator;
import com.ford.sca.consent.util.ScaConsentApiResponses;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/cas/consent-administrations")
public class ConsentAdminController {

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private SuppressionTermService suppressionTermService;

  @Autowired
  private AuditActivityUtil auditActivityUtil;

  @Autowired
  private AuditActivityUtilNF auditActivityUtilNf;

  @Autowired
  private PublishAuditMessageUtil publishAuditMessageUtil;

  @Autowired
  private ResponseGenerator responseGenerator;

  @Autowired
  private ConsentAdminServiceValidator consentAdminServiceValidator;

  @Autowired
  private NotifyService notifyService;

  private static final Logger LOGGER = LoggerFactory.getLogger(ConsentAdminController.class);
  private static String className = ConsentAdminController.class.getSimpleName();

  @PreAuthorize("hasPermission('aud', 'consentAdminWriteResource')")
  @ApiOperation(value = "Update Regulation Status Request",
      nickname = "Update Regulation Status Request")
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = ConsentAdminServiceConstants.CREATE_SUCCESS,
          response = ConsentAdminResponse.class)})
  @PostMapping("/v1/countries/{country-code}/govt-regulation-privacy-statuses")
  public ConsentAdminResponse maintainPouRegulationStatus(
      @RequestBody ConsentAdminRequest consentAdminRequest,
      @ApiParam(value = "App Country Code", required = true) @PathVariable("country-code") String appCountryCode,
      @ApiParam(value = "Application ID", required = true) @RequestParam String appId,
      HttpServletRequest request, HttpServletResponse response) {
    long start = System.currentTimeMillis();
    long responseTime;
    AuditServiceRequest auditServiceRequest = auditActivityUtil.createAuditServiceRequest(request,
        consentAdminRequest.getPouRegulationList());
    request.setAttribute(ConsentAdminServiceConstants.AUDIT_SERVICE_REQUEST_ATTR_NAME,
        auditServiceRequest);
    publishAuditMessageUtil.publishAuditMessage(auditServiceRequest);
    responseGenerator.setResponseHeaders(response); /// check if we need
    /// this
    String serviceId = auditServiceRequest.getServiceId();
    MDC.put(ConsentAdminServiceConstants.REQUEST_SERVICE_ID, serviceId);
    String methodName = "maintainPouRegulationStatus";
    LOGGER.info(ConsentAdminServiceConstants.LOG_INFO,
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "processing_maintainPouRegulationStatus",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
        consentAdminRequest.getPouRegulationList());

    consentAdminServiceValidator.validateInputField(appCountryCode, appId, consentAdminRequest);
    /*
     * ConsentAdminResponse consentAdminResponse =
     * consentAdminService.createOrUpdateUserPOUData(consentAdminRequest, appCountryCode, appId,
     * response);
     */
    ConsentAdminResponse consentAdminResponse = new ConsentAdminResponse();
    publishAuditMessageUtil.publishAuditMessage(
        auditActivityUtil.createAuditServiceResponse(auditServiceRequest, consentAdminResponse));
    responseTime = (System.currentTimeMillis() - start);
    LOGGER.info(ConsentAdminServiceConstants.LOG_INFO + ", responseTime={}",
        MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
        ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
        MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
        "completed_maintainPouRegulationStatus",
        MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), consentAdminResponse,
        responseTime);

    return consentAdminResponse;

  }

  @PreAuthorize("hasPermission('aud', 'consentAdminWriteResource')")
  @ApiOperation(value = "Trigger climes report request", nickname = "Trigger climes report")
  @ApiResponses(value = {@ApiResponse(code = 200,
      message = ConsentAdminServiceConstants.CREATE_SUCCESS, response = String.class)})
  @GetMapping("/climes/v1/unauthorized-llid-usage-reports")
  public String triggerclimesReport(
      @ApiParam(value = "startDateTime must be entered in UTC time format yyyy-mm-ddThh:mm:ss.sssZ",
          required = true) @RequestParam String startDateTime,
      @ApiParam(value = "endDateTime must be entered in UTC time format yyyy-mm-ddThh:mm:ss.sssZ",
          required = true) @RequestParam String endDateTime,
      @ApiParam(value = "mailTo", required = false) @RequestParam Optional<String> mailTo) {
    notifyService.buildReport(startDateTime, endDateTime, mailTo);
    return "success";
  }


  /**
   * Handles maintain suppression term requests.
   */
  // For ADFS
  @PreAuthorize("hasPermission('aud', 'consentAdminWriteResource')")
  // For PCF-UAA and AzureAD
  // @PreAuthorize("#oauth2.hasScope('consent.write')")
  @ScaConsentApiResponses
  @ApiOperation(value = "Maintain Suppression Term")
  @PostMapping("/v1/suppression-terms")
  @LogAround
  public GenericResponse maintainSuppressionTerm(
      @ApiParam(value = "Request Body with Consent Admin Data.",
          required = true) @RequestBody SuppressionTermRequest suppressionTermRequest,
      @ApiParam(value = "Application ID.", required = true) @RequestParam(value = "app-cd",
          required = true) String appCd,
      @ApiParam(value = "Country Code", required = true) @RequestParam(value = "cntry-cd",
          required = true) final String cntryCd,
      final HttpServletRequest request, final HttpServletResponse response) {

    LoggerBuilder.printInfo(log,
        logger -> logger.methodName("maintainSuppressionTerm").countryCode(cntryCd).appCd(appCd));

    final Date requestTimestamp = Calendar.getInstance().getTime();

    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    auditActivityUtilNf.setResponseHeaderAttributes(response);
    ApiParams apiParams =
        suppressionTermService.constructApiParams(appCd, cntryCd, requestTimestamp);
    logRequest(suppressionTermRequest, request, apiParams);

    auditActivityUtilNf.publishAuditMessageMaintain_request(request, suppressionTermRequest, appCd,
        requestTimestamp);

    GenericResponse genericResponse = null;
    genericResponse = suppressionTermService.maintainSuppressionTerm(apiParams,
        suppressionTermRequest, request, RequestMode.CREATE);

    auditActivityUtilNf.publishAuditMessage_response(request, genericResponse, appCd,
        requestTimestamp);

    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  /**
   * To log the request asynchronously.
   */
  private void logRequest(final Object requestObj, final HttpServletRequest request,
      final ApiParams apiParams) {

    final String resourceUri = GenericAssister.constructResourceUri(request);
    final Map<String, String> webContextMap = MDC.getCopyOfContextMap();
    // Trigger asynchronously
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webContextMap);
      try {
        // Marshall the data
        final String json = objectMapper.writeValueAsString(requestObj);
        LoggerBuilder.printInfo(log, logger -> logger.appCd(apiParams.getAppCd())
            .resourceUri(resourceUri).httpMethod(RequestMethod.POST.name()).json(json));

      } catch (JsonProcessingException e) {
        LoggerBuilder.printError(log, logger -> logger.appCd(apiParams.getAppCd())
            .resourceUri(resourceUri).message("Error while parsing suppression request to json"));
      }
    });
  }

}
