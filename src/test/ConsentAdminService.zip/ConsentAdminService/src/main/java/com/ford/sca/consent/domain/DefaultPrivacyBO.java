package com.ford.sca.consent.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@EqualsAndHashCode
@Table(name = "[MCNPC18_DEFAULT_PREFERENCES]")
public class DefaultPrivacyBO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "[CNPC18_DEF_PREF_SEQ_R]")
    private Long sequenceId;

    @Column(name = "[CNPC18_SOURCE_N]")
    private String sourceName;

    @Column(name = "[CNPC18_REGION_N]")
    private String region;
    
    @Column(name = "[CNPC07_CONSENT_CATG_X]")
    private String privacyCategory;

    @Column(name = "[CNPC07_CONSENT_N]")
    private String consentName;

    @Column(name = "[CNPC18_DEF_PREF_X]")
    private String consentDescription;
    
}
