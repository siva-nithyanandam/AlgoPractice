package com.ford.sca.consent.util;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class GenericAssister {

  private static final char HYPEN_CHAR = '-';

  private static final Locale US_LOCALE = Locale.US;

  private GenericAssister() {
    throw new IllegalStateException("Utility class");
  }

  /**
   * To check, a given String is numeric or not.
   *
   * @return true if given string is not an numeric else false
   */
  public static boolean isNotNumeric(final String str) {
    return !isNumeric(str);
  }

  /**
   * To check, a given String is numeric or not.
   *
   * @return true if given string is numeric else false
   */
  public static boolean isNumeric(final String str) {
    boolean isNumeric;
    if (StringAssister.isEmptyString(str)) {
      isNumeric = false;
    } else if (str.charAt(0) == HYPEN_CHAR) {
      isNumeric = isValidPositiveNumber(str.substring(1));
    } else {
      isNumeric = isValidPositiveNumber(str);
    }
    return isNumeric;
  }

  /**
   * To check given string is positive number.
   * 
   * @param str String to check
   * @return TRUE if valid positive number Else FALSE
   */
  private static boolean isValidPositiveNumber(final String str) {
    if (StringAssister.isEmptyString(str)) {
      return false;
    } else {
      int index = 0;
      char strChar;
      while (index < str.length()) {
        strChar = str.charAt(index++);
        if (isNotValidNumber(strChar)) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * To check the given char is not a number.
   * 
   * @param strChar Given char
   * @return TRUE if not a number Else FALSE
   */
  private static boolean isNotValidNumber(final char strChar) {
    return strChar < '0' || strChar > '9';
  }



  /**
   * TO convert status to date with day as one.
   *
   * @param inputDateStr a status to be passed supported format is yyyy-MM-dd
   * @return a Date - with first day of month
   */
  public static Date convertStringToDateWithDayAsOne(final String inputDateStr) {
    final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", US_LOCALE);
    sdf.setLenient(false);
    Date inputDate = null;
    try {
      inputDate = sdf.parse(inputDateStr.trim());
      final Calendar calendar = Calendar.getInstance();
      calendar.setTime(inputDate);
      calendar.set(Calendar.DAY_OF_MONTH, 1);
      inputDate = calendar.getTime();
    } catch (Exception e) {
      return null;
    }
    return inputDate;
  }

  /**
   * To check given collection is not empty.
   *
   * @return TRUE if collection is not empty Else FALSE
   */
  public static boolean isCollectionNotEmpty(final Collection collection) {
    return null != collection && !collection.isEmpty();
  }

  /**
   * Convert String to Date, given the string date format.
   * 
   * @param inputDate is a string to be converted
   * @param dateFormat is date format for given input string
   * @return Date which is the converted date
   */
  public static Date convertStringToDate(final String inputDate, final String dateFormat) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("convertStringToDate")
        .message("inputDate: " + inputDate + " , dateFormat: " + dateFormat));
    Date parsedDate = null;
    try {
      if (StringAssister.isNotEmptyString(inputDate)) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, US_LOCALE);
        parsedDate = sdf.parse(inputDate);
      }
    } catch (Exception ex) {
      LoggerBuilder.printError(log,
          logger -> logger.methodName("TODOconvertStringToDate").exception(ex));
    }
    return parsedDate;
  }

  /**
   * convert a date to a string given the required date format.
   * 
   * @param inputDate is the date to be converted
   * @param dateFormat is the given date format string
   * @return String is the converted date to a string
   */
  public static String convertDateToString(final Date inputDate, final String dateFormat) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("convertDateToString")
        .message("inputDate: " + inputDate + " , dateFormat: " + dateFormat));
    String stringDate = null;
    try {
      if (inputDate != null) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, US_LOCALE);
        stringDate = sdf.format(inputDate);
      }
    } catch (Exception ex) {
      LoggerBuilder.printError(log,
          logger -> logger.methodName("convertDateToString").exception(ex));
    }
    return stringDate;
  }

  
  /**
   * construct resource uri string needed for audit activity and logging purposes.
   * 
   * @param request is HttpServletRequest
   * @return String is the constructed resource uri
   */
  public static String constructResourceUri(final HttpServletRequest request) {
    return request.getScheme() + Constants.COLON_SLASHES + request.getServerName() + Constants.COLON
        + request.getServerPort() + request.getRequestURI() + Constants.QUESTION_MARK
        + request.getQueryString();
  }
  
  /**
   * Shrinks the given String to only contain the specified number of characters.
   * 
   * @param data the given data string
   * @param columnLength the number of characters to keep
   * @return String is the Shortened String
   */
  public static String getColumnTruncated(String data, int columnLength) {
    if (data != null && data.length() > columnLength) {
      return data.substring(0, columnLength);
    } else {
      return data;
    }
  }
  
  /**
   * Convert String to LocalDateTime, given the string date format.
   * 
   * @param inputDate is a string to be converted
   * @param dateFormat is date format for given input string
   * @return LocalDateTime which is the converted date
   */
  public static LocalDateTime convertStringToLocalDateTime(final String inputDate,
      final String dateFormat) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("convertStringToLocalDateTime")
        .message("inputDate: " + inputDate + " , dateFormat: " + dateFormat));
    LocalDateTime parsedDateTime = null;
    try {
      if (StringAssister.isNotEmptyString(inputDate)) {

        DateTimeFormatter fomatter = DateTimeFormatter.ofPattern(dateFormat, Locale.US);
        parsedDateTime = LocalDateTime.parse(inputDate, fomatter);

      }
    } catch (Exception ex) {
      LoggerBuilder.printError(log,
          logger -> logger.methodName("convertStringToLocalDateTime").exception(ex));
    }
    return parsedDateTime;
  }
  
  /**
   * To check validity of arguments for retrieving suppression term and expiry rule caches.
   * 
   * @param consentId - consentId provided in the request
   * @param cntryCd - country code provided in the request
   * @return boolean - depending on the validity of the inputs
   */
  public static boolean isValidArguments(Optional<Long> consentId, Optional<String> cntryCd) {
    boolean isValid = true;
    if ((consentId.isPresent() && !cntryCd.isPresent())
        || (!consentId.isPresent() && cntryCd.isPresent())) {
      isValid = false;
    }
    return isValid;
  }
}
