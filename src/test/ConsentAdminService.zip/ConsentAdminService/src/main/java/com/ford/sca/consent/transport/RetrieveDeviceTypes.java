package com.ford.sca.consent.transport;

import java.util.Map;

import com.ford.sca.consent.domain.DeviceTypeBO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RetrieveDeviceTypes extends GenericResponse {

  private Long deviceTypesCount;
  private Map<String, DeviceTypeBO> deviceTypesMap;
  
}
