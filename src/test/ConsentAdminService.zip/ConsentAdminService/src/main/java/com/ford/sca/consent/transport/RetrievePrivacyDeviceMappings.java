package com.ford.sca.consent.transport;

import java.util.List;
import java.util.Map;
import com.ford.sca.consent.domain.PrivacyDeviceMappingBO;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RetrievePrivacyDeviceMappings extends GenericResponse {

  private Long privacyDeviceMappingsCount;

  private Map<String, List<PrivacyDeviceMappingBO>> privacyDeviceMappingsMap;

}
