package com.ford.sca.consent.validators;

import com.ford.sca.consent.statics.RequestMode;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.transport.SuppressionTermRequest;
import com.ford.sca.consent.transport.ApiParams;
import com.ford.sca.consent.util.CacheUtil;
import com.ford.sca.consent.util.GenericAssister;
import com.ford.sca.consent.util.LogAround;
import com.ford.sca.consent.util.LoggerBuilder;
import com.ford.sca.consent.util.ResponseBuilder;
import com.ford.sca.consent.util.ResponseCodes;
import com.ford.sca.consent.util.StringAssister;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;


/**
 * To validate appCode.
 */
@Slf4j
@Service
public class AppCodeValidator implements ValidatorSuppressionTerm {

  @Autowired
  private ResponseBuilder responseBuilder;

  @Autowired
  private CacheUtil cacheUtil;



  /**
   * This method validates if the given appCode is valid or not.
   *
   * @param apiParams Given API Params
   * @param suppressionTermRequest a given request
   * @param requestMode request operation mode
   * @return Future of {@link GenericResponse}
   */
  @Override
  @LogAround
  public Future<GenericResponse> checkAndConstruct(final ApiParams apiParams,
      final SuppressionTermRequest suppressionTermRequest, final RequestMode requestMode,
      HttpServletRequest httpRequest) {

    GenericResponse genericResponse = null;
    if (StringAssister.isEmptyString(apiParams.getAppCd())) {
      LoggerBuilder.printError(log, logger -> logger.appCd(apiParams.getAppCd())
          .message(ResponseCodes.APP_ID_IS_REQUIRED.name()));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.APP_ID_IS_REQUIRED);
    } else if (GenericAssister.isNotNumeric(apiParams.getAppCd())) {
      LoggerBuilder.printError(log, logger -> logger.appCd(apiParams.getAppCd())
          .message(ResponseCodes.APP_CODE_NOT_IN_NUMBER_FORMAT.name()));
      genericResponse =
          responseBuilder.generateResponse(ResponseCodes.APP_CODE_NOT_IN_NUMBER_FORMAT);
    } else {
      try {
        if (null == cacheUtil.getAppCodeDtls(Integer.valueOf(apiParams.getAppCd()))) {
          LoggerBuilder.printError(log, logger -> logger.appCd(apiParams.getAppCd())
              .message(ResponseCodes.APP_CODE_NOT_EXISTS_IN_DB.name()));
          genericResponse =
              responseBuilder.generateResponse(ResponseCodes.APP_CODE_NOT_EXISTS_IN_DB);
        }
      } catch (Exception exception) {
        LoggerBuilder.printError(log, logger -> logger.appCd(apiParams.getAppCd())
            .message(ResponseCodes.INTERNAL_SERVER_ERROR.name()).exception(exception));
        genericResponse = responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      }
    }
    return new AsyncResult<>(genericResponse);
  }

}
