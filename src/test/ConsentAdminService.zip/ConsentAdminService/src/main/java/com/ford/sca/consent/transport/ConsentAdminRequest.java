package com.ford.sca.consent.transport;

import java.util.List;

public class ConsentAdminRequest {
    public List<POURegulation> getPouRegulationList() {
        return pouRegulationList;
    }

    public void setPouRegulationList(List<POURegulation> pouRegulationList) {
        this.pouRegulationList = pouRegulationList;
    }

    List<POURegulation> pouRegulationList;
}
