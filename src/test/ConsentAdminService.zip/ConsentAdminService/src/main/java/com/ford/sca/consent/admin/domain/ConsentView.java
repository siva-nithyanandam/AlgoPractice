package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Entity
@Table(name = "[MCAPV15_DISTINCT_CONSENT_USERS_VW]", catalog = "SCACAP", schema = "dbo")
@Data
@ToString
public class ConsentView implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "[CAPN01_CONSENT_MGMT_SEQ_R]")
  private Integer consentSeqKey;
 
  @Column(name = "[CAPN01_LL_D]")
  private String lLId;
 
  @Column(name = "[CAPN01_APP_COUNTRY_ISO3_C]")
  private String appCountryCode;

  @Column(name = "[CAPN01_APP_C]")
  private Float appCode;

  @Column(name = "[CAPN01_USER_D]")
  private String capUserId;

  @Column(name = "[CAPN01_CONSENT_STATUS_C]")
  private String consentStatus;

  @Column(name = "[DT]")
  private Date consentTimestamp;
  
  @Column(name = "[CAPN01_SECONDARY_APP_C]")
  private Float secondaryAppCode;
  
  @Column(name = "[CAPN01_GLOBAL_CUST_D]")
  private String scaId;
  
  @Column(name="[CAPN01_CAMPAIGN_D]")
  private String campaignID;
  
  @Column(name="[CAPN01_SMS_SHORT_C]")
  private Integer shortCode;
  
  @Column(name="[CAPN01_EXPIRY_S]")
  private Date expiryDate;

}
