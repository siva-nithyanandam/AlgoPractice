package com.ford.sca.consent.service;

import com.ford.sca.consent.domain.SuppressionTermBO;
import com.ford.sca.consent.suppression.repository.SuppressionTermRepository;
import com.ford.sca.consent.service.ruleengines.RuleEngineInterfaceSuppressionTerm;
import com.ford.sca.consent.statics.RequestMode;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.transport.SuppressionTermRequest;
import com.ford.sca.consent.transport.ApiParams;
import com.ford.sca.consent.util.CacheUtil;
import com.ford.sca.consent.util.Constants;
import com.ford.sca.consent.util.GenericAssister;
import com.ford.sca.consent.util.LogAround;
import com.ford.sca.consent.util.LoggerBuilder;
import com.ford.sca.consent.util.ResponseBuilder;
import com.ford.sca.consent.util.ResponseCodes;
import com.ford.sca.consent.validators.AppCodeValidator;
import com.ford.sca.consent.validators.SuppressionTermValidator;
import com.ford.sca.consent.validators.SuppressionTypeValidator;
import com.ford.sca.consent.validators.ValidatorSuppressionTerm;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public abstract class MasterRuleEngineSupressionTerm implements RuleEngineInterfaceSuppressionTerm {

  @Autowired
  private ResponseBuilder responseBuilder;

  @Autowired
  protected AppCodeValidator appCodeValidator;

  @Autowired
  protected SuppressionTypeValidator suppressionTypeValidator;


  @Autowired
  protected SuppressionTermValidator suppressionTermValidator;

  @Autowired
  protected SuppressionTermRepository suppressionTermRepository;

  @Autowired
  protected CacheUtil cacheUtil;


  /**
   * To get list of required validators for appropriate implementation.
   *
   */
  protected abstract List<ValidatorSuppressionTerm> getValidators();

  /**
   * To check if there is a rule engine implementation for the given country.
   *
   * @param groupType rule engine type
   * @return TRUE if matching else FALSE
   */
  @Override
  public boolean isRequestBehalfOfThisImpl(String groupType) {
    return getSupportedRegions().contains(groupType);
  }

  /**
   * To invoke all required validator implementations asynchronously.
   */
  @LogAround
  public Optional<GenericResponse> validate(ApiParams apiParams,
      SuppressionTermRequest suppressionTermRequest, RequestMode requestMode,
      HttpServletRequest request) {

    List<Future<GenericResponse>> validationResponses = new ArrayList<>();
    Optional<GenericResponse> validationResponse;

    // Trigger each secondary validator's checkAndConstruct()
    getValidators().stream().forEach(validator -> validationResponses
        .add(validator.checkAndConstruct(apiParams, suppressionTermRequest, requestMode, request)));

    // Return any of failure validation
    validationResponse =
        validationResponses.stream().map(cfResp -> parseValidationResponse(apiParams, cfResp))
            .filter(Objects::nonNull).findAny();

    return validationResponse;
  }

  /**
   * To parse validation response from each validator.
   *
   * @param apiParams API parameters
   * @param cfResp Validation response
   * @return Parsed validation response
   */
  private GenericResponse parseValidationResponse(ApiParams apiParams,
      Future<GenericResponse> cfResp) {
    try {
      return cfResp.get();
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName("checkAndConstruct")
          .message("Exception in one of the validators").exception(e));
      return responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
    }
  }

  /**
   * To trigger DB related activities.
   *
   * @param apiParams Given API params
   * @param suppressionTermRequest - consent admin request
   * @param request HttpServletRequest
   * @return {@link GenericResponse}
   */
  @Override
  @LogAround
  public GenericResponse triggerDBProcesses(ApiParams apiParams,
      SuppressionTermRequest suppressionTermRequest, RequestMode requestMode,
      HttpServletRequest request) {

    GenericResponse genericResponse =
        responseBuilder.generateResponse(ResponseCodes.CREATE_SUCCESS);

    Date cuurentTime = Calendar.getInstance().getTime();

    SuppressionTermBO suppressionTermBo = new SuppressionTermBO();
    suppressionTermBo.setCountryCode(apiParams.getCountryCode());
    suppressionTermBo.setSuppressionTerm(suppressionTermRequest.getTerm());
    suppressionTermBo.setConsentId(suppressionTermRequest.getConsentId());

    suppressionTermBo.setCreateDate(cuurentTime);
    suppressionTermBo.setCreateUser(apiParams.getAppCd());
    String processName = GenericAssister
        .getColumnTruncated(MDC.get(Constants.BUILD_VERSION_HEADER_NAME), Constants.COLUMN_LENGTH);
    suppressionTermBo.setCreateProcess(processName);
    Integer appCode = Integer.parseInt(apiParams.getAppCd());
    suppressionTermBo.setCreateAppCode(appCode);

    suppressionTermBo.setUpdateDate(cuurentTime);
    suppressionTermBo.setUpdateUser(apiParams.getAppCd());
    suppressionTermBo.setUpdateProcess(processName);
    suppressionTermBo.setUpdateAppCode(appCode);

    try {
      suppressionTermRepository.save(suppressionTermBo);
    } catch (Exception ex) {

      LoggerBuilder.printError(log, logger -> logger.methodName("checkAndConstruct")
          .message("Exception while saving records to DB.").exception(ex));
      return responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
    }

    return genericResponse;
  }

  /**
   * To trigger post DB process if any.
   * 
   * @param apiParams - Given API Params
   */
  @Override
  @LogAround
  public void triggerPostDBProcesses(ApiParams apiParams,
      SuppressionTermRequest suppressionTermRequest, RequestMode requestMode) {
    // Get copy of MDC context to send to sub-threads
    Map<String, String> webThreadContext = MDC.getCopyOfContextMap();

    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webThreadContext);
      // TODO

    });
  }

}
