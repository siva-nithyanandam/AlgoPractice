package com.ford.sca.consent.util;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.sca.consent.transport.ConsentAdminFailureResponse;
import com.ford.sca.consent.transport.GenericResponse;


@Component
public class ResponseBuilder {

    private static final Logger LOGGER = LoggerFactory.getLogger(PublishAuditMessageUtil.class);
    private static String className = ResponseBuilder.class.getSimpleName();

    @Autowired
    private CacheUtil cacheUtil;

    public ConsentAdminFailureResponse constructResponse(String errorMsgID) {

        String methodName = "constructResponse";
        LOGGER.info(ConsentAdminServiceConstants.LOG_INFO + ",  errorMsgID={}",
                MDC.get(ConsentAdminServiceConstants.SERVICE), ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                "processing_" + className + "_" + methodName,
                MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), errorMsgID);
        ConsentAdminFailureResponse consentAdminFailureResponse = new ConsentAdminFailureResponse();
        consentAdminFailureResponse.setStatus(ConsentAdminServiceConstants.STATUS_FAILED);
        consentAdminFailureResponse.setErrorMsg(cacheUtil.getErrorMessage(errorMsgID));
        consentAdminFailureResponse.setErrorMsgId(errorMsgID);
        consentAdminFailureResponse.setErrorTime(Calendar.getInstance().getTime());
        return consentAdminFailureResponse;

    }

    /**
     * To generate response to the caller.
     */
    public GenericResponse generateResponse(final ResponseCodes responseCode) {
      GenericResponse genericResponse;
      if (responseCode.isSuccess()) {
        genericResponse = new GenericResponse(responseCode.getHttpStatus(), responseCode.getStatus());
      } else {
        genericResponse = new GenericResponse(responseCode.getHttpStatus(), responseCode.getStatus(),
            responseCode.getMsgId(), cacheUtil.getErrorMessage(responseCode.getMsgId()),
            Calendar.getInstance().getTime());
      }
      return genericResponse;
    }    
    
}
