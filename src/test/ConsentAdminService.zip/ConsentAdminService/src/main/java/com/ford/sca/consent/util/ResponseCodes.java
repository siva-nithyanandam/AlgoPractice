package com.ford.sca.consent.util;

import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * Contains validation response code statics.
 */
@Getter
public enum ResponseCodes {
  CREATE_SUCCESS(true, HttpStatus.CREATED, Constants.CREATE_SUCCESS, null),
  RETRIEVE_SUCCESS(true, HttpStatus.OK, Constants.SUCCESS_TEXT, null),
  UPDATE_SUCCESS(true, HttpStatus.OK, Constants.SUCCESS_TEXT, null),
  PARTIAL_SUCCESS(true, HttpStatus.MULTI_STATUS, Constants.PARTIAL_SUCCESS, null),
  CREATE_FAILED(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG=XXXX"),
  CREATE_FAILED_EXPECTATION(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      null),
  CREATE_FAILED_PRECONDITION(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      null),
  INTERNAL_SERVER_ERROR(false, HttpStatus.INTERNAL_SERVER_ERROR, Constants.FAILURE_TEXT,
      "MSG-9999"),
  UNAUTHORIZED_ERROR(false, HttpStatus.UNAUTHORIZED, Constants.FAILURE_TEXT,
      "MSG-9997"),
  UNSUPPORTED_METHOD_ERROR(false, HttpStatus.METHOD_NOT_ALLOWED, Constants.FAILURE_TEXT,
      "MSG-9998"),
  CAN_NOT_FIND_IMPL(false, HttpStatus.UNPROCESSABLE_ENTITY, Constants.FAILURE_TEXT,
      "MSG-9992"),  
  APP_ID_IS_REQUIRED(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0005"),
  APP_CODE_NOT_IN_NUMBER_FORMAT(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0047"),
  APP_CODE_NOT_EXISTS_IN_DB(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0002"),
  CAP_USER_NOT_EXISTS_IN_CP(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0003"),
  SERVICE_UNAVAILABLE_ERROR(false, HttpStatus.SERVICE_UNAVAILABLE, Constants.FAILURE_TEXT,
      "MSG-9991"),
  UNEXPECTED_BEHAVIOR(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-9992"),
  REQUIRED_FIELD_EXCEPTION(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0009"),
  VALUE_EXCEEDS_MAX_LENGTH(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0177"),
  BINDING_ERROR(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0049"),
  INVALID_FIELD_PROVIDED(false, HttpStatus.BAD_REQUEST, Constants.FAILURE_TEXT,
      "MSG-0010"),
  COUNTRY_CODE_IS_REQUIRED(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0004"),
  INVALID_COUNTRY_CODE(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0042"),
  INVALID_PRIVACY_STATUS(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0048"),
  INVALID_DATE_FORMAT(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0006"),
  INVALID_CONSENT_ID(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "MSG-0306"),
  INVALID_SUPPRESSION_TYPE(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "INVALID_SUPPRESSION_TYPE"),
  SUPPRESSION_TYPE_OR_CONSENTID_IS_REQUIRED(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "SUPPRESSION_TYPE_OR_CONSENTID_IS_REQUIRED"),
  NO_SUPPRESSION_RECORD_FOUND(false, HttpStatus.PRECONDITION_FAILED, Constants.FAILURE_TEXT,
      "NO_SUPPRESSION_RECORD_FOUND"),
  INVALID_SUPPRESSION_TERM(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "INVALID_SUPPRESSION_TERM"),
  INVALID_SUPPRESSION_TERM_FORMAT(false, HttpStatus.EXPECTATION_FAILED, Constants.FAILURE_TEXT,
      "INVALID_SUPPRESSION_TERM_FORMAT")
  ;

  private boolean isSuccess;
  private HttpStatus httpStatus;
  private String status;
  private String msgId;

  ResponseCodes(final boolean isSuccess, final HttpStatus httpStatus, final String status,
      final String msgId) {
    this.isSuccess = isSuccess;
    this.httpStatus = httpStatus;
    this.status = status;
    this.msgId = msgId;
  }
  
}
