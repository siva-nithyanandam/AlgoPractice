package com.ford.sca.consent.service;

import com.ford.sca.consent.config.ConfigProperties;
import com.ford.sca.consent.domain.CountryCodeBO;
import com.ford.sca.consent.service.ruleengines.RuleEngineInterfaceSuppressionTerm;
import com.ford.sca.consent.service.ruleengines.SuppressionTermRuleEngine;
import com.ford.sca.consent.statics.RequestMode;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.transport.SuppressionTermRequest;
import com.ford.sca.consent.transport.ApiParams;
import com.ford.sca.consent.transport.ConsentAdminRequest;
import com.ford.sca.consent.util.CacheUtil;
import com.ford.sca.consent.util.LoggerBuilder;
import com.ford.sca.consent.util.ResponseBuilder;
import com.ford.sca.consent.util.ResponseCodes;
import com.ford.sca.consent.util.StringAssister;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * To manage suppression term related activities.
 */
@Slf4j
@Service
public class SuppressionTermService {

  private static final String SUPPRESSION_TERM_SERVICE = "suppressionTermService";

  private final List<RuleEngineInterfaceSuppressionTerm> ruleEngineInterfaces = new ArrayList<>();
  private final ResponseBuilder responseBuilderService;
  private final CacheUtil cacheUtil;
  private final ConfigProperties configProperties;

  /**
   * Constructor to do dependency injection and adding appropriate service implementations.
   */
  @Autowired
  public SuppressionTermService(final CacheUtil cacheUtil,
      final SuppressionTermRuleEngine genericRuleEngine, final ResponseBuilder responseBuilderService,
      final ConfigProperties configProperties) {
    this.cacheUtil = cacheUtil;
    this.responseBuilderService = responseBuilderService;
    this.configProperties = configProperties;

    // Add tenant implementations here
    ruleEngineInterfaces.add(genericRuleEngine);

  }

  /**
   * To maintain Suppression Term.
   */
  public GenericResponse maintainSuppressionTerm(final ApiParams apiParams,
      final SuppressionTermRequest suppressionTermRequest, final HttpServletRequest request,
      final RequestMode requestMode) {
    GenericResponse genericResponse = null;

    // start the process
    genericResponse = validateCountryCode(apiParams);
    if (genericResponse != null) {
      return genericResponse;
    }

    LoggerBuilder.printInfo(log, logger -> logger.methodName(SUPPRESSION_TERM_SERVICE)
        .appCd(apiParams.getAppCd()).countryCode(apiParams.getCountryCode()));

    genericResponse = executeRuleEngine(apiParams, suppressionTermRequest, request, requestMode);

    return genericResponse;
  }

  /**
   * To validate Country Code.
   * 
   * @param apiParams - parameters included in the request
   * @return {@link GenericResponse}
   */
  private GenericResponse validateCountryCode(final ApiParams apiParams) {
    GenericResponse genericResponse = null;
    if (StringAssister.isEmptyString(apiParams.getCountryCode())) {
      LoggerBuilder.printError(log,
          logger -> logger.message(ResponseCodes.COUNTRY_CODE_IS_REQUIRED.name()));
      genericResponse =
          responseBuilderService.generateResponse(ResponseCodes.COUNTRY_CODE_IS_REQUIRED);
    } else {
      String country = apiParams.getCountryCode();
      final CountryCodeBO countryCodeBo = cacheUtil.getCountryCodeByISO3(country);
      if (null == countryCodeBo) {
        LoggerBuilder.printError(log, logger -> logger.appCd(apiParams.getAppCd())
            .message(ResponseCodes.INVALID_COUNTRY_CODE.name()));
        genericResponse =
            responseBuilderService.generateResponse(ResponseCodes.INVALID_COUNTRY_CODE);
      }
    }
    return genericResponse;
  }

  private GenericResponse executeRuleEngine(final ApiParams apiParams,
      final SuppressionTermRequest suppressionTermRequest, final HttpServletRequest request,
      final RequestMode requestMode) {

    String country = apiParams.getCountryCode();
    final CountryCodeBO countryCodeBo = country.length() == 2
        ? cacheUtil.getCountryCodeByISO2(country) : cacheUtil.getCountryCodeByISO3(country);

    // 1. Find appropriate implementation
    final Optional<RuleEngineInterfaceSuppressionTerm> serviceImpl = ruleEngineInterfaces.stream()
        .filter(impl -> impl.isRequestBehalfOfThisImpl(countryCodeBo.getRegion())).findAny();

    /*
     * If service rule engines instance found, proceed with that otherwise return error
     */
    if (!serviceImpl.isPresent()) {
      LoggerBuilder.printError(log, logger -> logger.methodName(SUPPRESSION_TERM_SERVICE)
          .message(ResponseCodes.CAN_NOT_FIND_IMPL.name()));
      return responseBuilderService.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
    }
    final RuleEngineInterfaceSuppressionTerm selectedServiceImpl = serviceImpl.get();
    LoggerBuilder.printInfo(log, logger -> logger.methodName(SUPPRESSION_TERM_SERVICE)
        .message("Found service ruleengines : " + selectedServiceImpl.toString()));

    // 2. Do the validations
    final Optional<GenericResponse> failedValidationResponse =
        selectedServiceImpl.validate(apiParams, suppressionTermRequest, requestMode, request);
    GenericResponse genericResponse = null;
    if (failedValidationResponse.isPresent()) {
      LoggerBuilder.printError(log, logger -> logger.methodName(SUPPRESSION_TERM_SERVICE)
          .message("Validation generic response is present!"));
      genericResponse = failedValidationResponse.get();
    }

    // 3. DB operations
    genericResponse = checkAndPerformDB(genericResponse, selectedServiceImpl, apiParams,
        suppressionTermRequest, request, requestMode);

    // 4. Post DB operations
    checkAndPerformPostDB(genericResponse, selectedServiceImpl, apiParams, suppressionTermRequest,
        requestMode);

    return genericResponse;

  }

  private GenericResponse checkAndPerformDB(final GenericResponse validationGenericResponse,
      final RuleEngineInterfaceSuppressionTerm selectedServiceImpl, final ApiParams apiParams,
      final SuppressionTermRequest suppressionTermRequest, HttpServletRequest request,
      final RequestMode requestMode) {
    GenericResponse genericResponse = validationGenericResponse;
    if (validationGenericResponse == null) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("checkAndPerformDB")
          .message("Validations are checked and able to proceed with DB Processes!"));
      genericResponse = selectedServiceImpl.triggerDBProcesses(apiParams, suppressionTermRequest,
          requestMode, request);
      LoggerBuilder.printInfo(log,
          logger -> logger.methodName("checkAndPerformDB").message("Completed DB processes"));
    } else {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("checkAndPerformDB")
          .message("Validations are not passed, not able to proceed with DB Processes!"));
    }
    return genericResponse;
  }

  private void checkAndPerformPostDB(final GenericResponse dbGenericResponse,
      final RuleEngineInterfaceSuppressionTerm selectedServiceImpl, final ApiParams apiParams,
      final SuppressionTermRequest suppressionTermRequest, final RequestMode requestMode) {
    final int responseHttpStatus = dbGenericResponse.getHttpStatus().value();
    if (responseHttpStatus == ResponseCodes.CREATE_SUCCESS.getHttpStatus().value()) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("checkAndPerformPostDB")
          .message("Submitting Post DB Processes!"));
      selectedServiceImpl.triggerPostDBProcesses(apiParams, suppressionTermRequest, requestMode);
    } else {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("checkAndPerformPostDB")
          .message("Pre-Conditions for Post DB Processes are failed!"));
    }
  }

  /**
   * This method create api params object.
   *
   * @param appId is App id
   * @param cntryCd is country code
   * @param requestTimestamp is request timestamp
   * @return
   */
  public ApiParams constructApiParams(final String appId, final String cntryCd,
      final Date requestTimestamp) {
    // Populate preliminary fields
    final ApiParams apiParams = new ApiParams();
    apiParams.setAppCd(appId.trim());
    apiParams.setCountryCode(cntryCd);
    apiParams.setRequestTimeStamp(requestTimestamp);
    return apiParams;
  }

}
