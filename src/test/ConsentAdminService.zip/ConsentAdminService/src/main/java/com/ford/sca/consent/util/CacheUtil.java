package com.ford.sca.consent.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import com.ford.sca.consent.domain.AppCodeBO;
import com.ford.sca.consent.domain.AppCodeGroupBO;
import com.ford.sca.consent.domain.AppConsentRelationBO;
import com.ford.sca.consent.domain.ConsentPrivacyBO;
import com.ford.sca.consent.domain.ConsentPrivacyExpiryRuleBO;
import com.ford.sca.consent.domain.CountryCodeBO;
import com.ford.sca.consent.domain.CountryLangBO;
import com.ford.sca.consent.domain.DefaultPrivacyBO;
import com.ford.sca.consent.domain.DerivedPreferencesBO;
import com.ford.sca.consent.domain.DeviceTypeBO;
import com.ford.sca.consent.domain.MessageLangServiceViewBO;
import com.ford.sca.consent.domain.PrivacyDeviceMappingBO;
import com.ford.sca.consent.domain.PrivacyStatusBO;
import com.ford.sca.consent.domain.SuppressionTermBO;
import com.ford.sca.consent.repository.AppCodeGroupRepository;
import com.ford.sca.consent.repository.AppCodeRepository;
import com.ford.sca.consent.repository.AppConsentRelationRepository;
import com.ford.sca.consent.repository.ConsentPrivacyExpiryRuleRepository;
import com.ford.sca.consent.repository.ConsentPrivacyRepository;
import com.ford.sca.consent.repository.CountryCodeRepository;
import com.ford.sca.consent.repository.CountryLangRepository;
import com.ford.sca.consent.repository.DefaultPrivacyRepository;
import com.ford.sca.consent.repository.DerivedPreferencesRepository;
import com.ford.sca.consent.repository.DeviceTypeRepository;
import com.ford.sca.consent.repository.MessageLangServiceViewRepository;
import com.ford.sca.consent.repository.PrivacyDeviceMappingRepository;
import com.ford.sca.consent.repository.PrivacyStatusRepository;
import com.ford.sca.consent.repository.SuppressionTermCacheRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CacheUtil {

  @Autowired
  private AppCodeRepository appCodeRepository;

  @Autowired
  private CountryCodeRepository countryCodeRepository;

  @Autowired
  private CountryLangRepository countryLangRepository;

  @Autowired
  private MessageLangServiceViewRepository messageLangServiceViewRepository;

  @Autowired
  private AppCodeGroupRepository appCodeGroupRepository;

  @Autowired
  private ConsentPrivacyRepository consentPrivacyRepository;

  @Autowired
  private DeviceTypeRepository deviceTypeRepository;

  @Autowired
  private PrivacyDeviceMappingRepository privacyDeviceMappingRepository;

  @Autowired
  private PrivacyStatusRepository privacyStatusRepository;

  @Autowired
  private SuppressionTermCacheRepository suppressionTermCacheRepository;

  @Autowired
  private AppConsentRelationRepository appConsentRelationRepository;

  @Autowired
  private ConsentPrivacyExpiryRuleRepository consentPrivacyExpiryRuleRepository;

  @Autowired
  private DerivedPreferencesRepository derivedPreferencesRepository;
  
  @Autowired
  private DefaultPrivacyRepository defaultPrivacyRepository;

  /**
   * This method checks for the AppId.
   *
   * @param appId appId of the caller
   * @return appCode
   */
  @Cacheable(cacheNames = ConsentCacheNames.APP_CODE_INFO, key = "#appId")
  public AppCodeBO getAppCodeDtls(Integer appId) {
    String methodName = "getAppCodeDtls";
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).appCd(String.valueOf(appId)));
    AppCodeBO appCode = null;
    appCode = appCodeRepository.findByAppId(appId);
    return appCode;
  }

  /**
   * This method checks for the AppId.
   *
   * @param appId appId of the caller
   * @param getFromdb whether to fetch from DB Or Not
   * @return appCode
   */
  @Cacheable(cacheNames = ConsentCacheNames.APP_CODE_INFO, key = "#appId")
  public AppCodeBO getAppCodeDtls(Integer appId, boolean getFromdb) {
    String methodName = "getAppCodeDtls";
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .appCd(String.valueOf(appId)).message(String.format("getFromDb: %s", getFromdb)));
    AppCodeBO appCode = null;
    if (getFromdb) {
      appCode = appCodeRepository.findByAppId(appId);
    }
    return appCode;
  }

  @Cacheable(cacheNames = ConsentCacheNames.APP_CODE_INFO)
  public List<AppCodeBO> getAppCodeList() {
    String methodName = "getActiveAppCodeList";
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).message("Getting All App Code Info"));
    List<AppCodeBO> appCodeBOList = new ArrayList<AppCodeBO>();
    appCodeBOList = appCodeRepository.findAll();
    return appCodeBOList;
  }


  @CacheEvict(cacheNames = ConsentCacheNames.APP_CODE_INFO, key = "#appId")
  public void clearAppCode(Integer appId) {
    // clearing app code
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.APP_CODE_INFO)
  public void clearAllAppCodes() {
    // clearing app codes
  }

  /**
   * The error message will store it "errorMessages" cache (consider as a map), if not available. It
   * will fetch it from redis server, if data available in cache server.
   *
   * @param errorMsgId error message code
   * @return message description as a String
   */
  @Cacheable(cacheNames = ConsentCacheNames.ERROR_MESSAGES, key = "#errorMsgId")
  public String getErrorMessage(String errorMsgId) {
    String methodName = "getErrorMessage";
    String errorDesc = null;
    String logStartMessage = "Getting Error Message for : " + errorMsgId;
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName).message(logStartMessage));
    Optional<MessageLangServiceViewBO> msgOptional =
        messageLangServiceViewRepository.findFirstByMessageCode(errorMsgId);
    if (msgOptional.isPresent()) {
      errorDesc = msgOptional.get().getMessageDesc();
    }
    String logMessage = "Retrieved Error Message Description : " + errorDesc;
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName).message(logMessage));
    return errorDesc;
  }

  /**
   * The error message will store it "errorMessages" cache (consider as a map), if not available. It
   * will fetch it from redis server, if data available in cache server.
   *
   * @param errorMsgId error message code
   * @Param loadErrMsgCacheFromDB fetch from DB Indicator
   * @return message description as a String
   */
  @Cacheable(cacheNames = ConsentCacheNames.ERROR_MESSAGES, key = "#errorMsgId")
  public String getErrorMessage(String errorMsgId, boolean loadErrMsgCacheFromDB) {
    String methodName = "getErrorMessage";
    String errorDesc = null;
    String logStartMessage = "Getting Error Message for : " + errorMsgId;
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName).message(logStartMessage));
    if (loadErrMsgCacheFromDB) {
      Optional<MessageLangServiceViewBO> msgOptional =
          messageLangServiceViewRepository.findById(errorMsgId);
      if (msgOptional.isPresent()) {
        errorDesc = msgOptional.get().getMessageDesc();
      }
    }
    String logMessage = "Retrieved Error Message Description : " + errorDesc;
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName).message(logMessage));
    return errorDesc;
  }

  @Cacheable(cacheNames = ConsentCacheNames.ERROR_MESSAGES)
  public List<MessageLangServiceViewBO> getErrorMessagesList() {
    String methodName = "getErrorMessagesList";
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .message("Fetching All MessageLangServiceViewBO From DB!"));
    List<MessageLangServiceViewBO> msgList = messageLangServiceViewRepository.findAll();
    return msgList;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.ERROR_MESSAGES, key = "#errorMsgId")
  public void clearErrorMessage(String errorMsgId) {
    // clearing Error Message
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.ERROR_MESSAGES)
  public void clearAllErrorMessages() {
    // clearing error-messages
  }

  /**
   * The CountryCodeBO will be store in "countryInfo" cache (consider as a map), if not available.
   * It will fetch it from DB, otherwise data available in cache server.
   *
   * @param countryCode iso3 country code
   * @return CountryCodeBO the whole object is returned
   */
  @Cacheable(cacheNames = ConsentCacheNames.COUNTRY_INFO, key = "#countryCode")
  public CountryCodeBO getCountryCodeByISO3(String countryCode) {
    String methodName = "getCountryCodeByISO3";
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).message("Getting Country by code: " + countryCode));
    CountryCodeBO findByIso3CodeCountry = countryCodeRepository.findByIso3CodeCountry(countryCode);
    String logMessage = findByIso3CodeCountry != null
        ? "Retrieved Country : " + findByIso3CodeCountry.getCountryName()
        : "Null Country Retrieved";
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName).message(logMessage));
    return findByIso3CodeCountry;
  }

  /**
   * Get country code BO.
   *
   * @param countryCode - country code
   * @return {@link CountryCodeBO}
   */
  @Cacheable(cacheNames = ConsentCacheNames.COUNTRY_INFO, key = "#countryCode")
  public CountryCodeBO getCountryCodeByISO2(String countryCode) {

    String methodName = "getCountryCodeISO2";
    CountryCodeBO findByIso2CodeCountry = countryCodeRepository.findByIso2CodeCountry(countryCode);

    String logMessage = findByIso2CodeCountry != null
        ? "Retrieved Country : " + findByIso2CodeCountry.getIso2CodeCountry()
        : "Null Country Retrieved";
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName).message(logMessage));
    return findByIso2CodeCountry;

  }

  @Cacheable(cacheNames = ConsentCacheNames.COUNTRY_INFO)
  public List<CountryCodeBO> retrieveAllCountryCodes() {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("retrieveAllCountryCodes"));
    return countryCodeRepository.findAll();
  }

  @Cacheable(cacheNames = ConsentCacheNames.COUNTRY_INFO, key = "#countryCode")
  public CountryCodeBO retrieveIso3CodeCountry(String countryCode, boolean loadCountryCacheFromDB) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("retrieveIso3CodeCountry")
        .countryCode(String.valueOf(countryCode)));
    CountryCodeBO countryCodeBO = new CountryCodeBO();
    if (loadCountryCacheFromDB) {
      countryCodeBO = countryCodeRepository.findByIso3CodeCountry(countryCode);
    } else {
      countryCodeBO = null;
    }
    return countryCodeBO;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.COUNTRY_INFO, key = "#countryCode")
  public void clearCountryCode(String countryCode) {
    // clearing country code
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.COUNTRY_INFO)
  public void clearAllCountryCodes() {
    // clearing all country codes
  }

  /**
   * get CountryLang By Preferred Language.
   *
   * @param preferredLanguage is preferred Language
   * @return {@link CountryLangBO}
   */
  @Cacheable(cacheNames = ConsentCacheNames.COUNTRY_LANG_INFO, key = "#preferredLanguage")
  public CountryLangBO getCountryLangByPreferredLanguage(String preferredLanguage) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("getCountryLangByPreferredLanguage")
        .message("processing_CacheUtil_getCountryLangByPreferredLangNameAndCountryCode"));
    return countryLangRepository.findByPreferredLanguage(preferredLanguage);
  }

  @Cacheable(cacheNames = ConsentCacheNames.COUNTRY_LANG_INFO)
  public List<CountryLangBO> retrieveAllCountryLangs() {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("retrieveAllCountryLangs"));
    return countryLangRepository.findAll();
  }

  @Cacheable(cacheNames = ConsentCacheNames.COUNTRY_LANG_INFO, key = "#preferredLanguage")
  public CountryLangBO retrieveCountryLangByPreferredLanguage(String preferredLanguage,
      boolean loadCountryLangCacheFromDB) {
    LoggerBuilder.printInfo(log,
        logger -> logger.methodName("retrieveCountryLangByPreferredLanguage")
            .preferredLanguage(String.valueOf(preferredLanguage)));
    CountryLangBO countryLangBO = new CountryLangBO();
    if (loadCountryLangCacheFromDB) {
      countryLangBO = countryLangRepository.findByPreferredLanguage(preferredLanguage);
    } else {
      countryLangBO = null;
    }
    return countryLangBO;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.COUNTRY_LANG_INFO, key = "#preferredLanguage")
  public void clearCountryLang(String preferredLanguage) {
    // clearing country Lang
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.COUNTRY_LANG_INFO)
  public void clearAllCountryLangs() {
    // clearing all country Langs
  }

  /**
   * Get the consent APP code group form the cache.
   *
   * @param appCode is appCode
   * @return
   */
  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_GROUP_CODE_INFO, key = "#appCode")
  public List<AppCodeGroupBO> getAppCodeGroupCache(Integer appCode) {
    LoggerBuilder.printInfo(log,
        logger -> logger.methodName("getAppCodeGroupCache").appCd(String.valueOf(appCode)));
    return appCodeGroupRepository.findByAppCodeGroupPK_requestAppId(appCode);
  }

  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_GROUP_CODE_INFO)
  public List<AppCodeGroupBO> retrieveAllAppCodeGroups() {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("retrieveAllAppCodeGroups"));
    return appCodeGroupRepository.findAll();
  }

  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_GROUP_CODE_INFO, key = "#appCode")
  public List<AppCodeGroupBO> retrieveAppCodeGroupByAppCode(Integer appCode,
      boolean loadConsentGroupCodeInfoCacheFromDB) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("retrieveAppCodeGroupByAppCode")
        .appCd(String.valueOf(appCode)));
    List<AppCodeGroupBO> appCodeGroupBOList = new ArrayList<AppCodeGroupBO>();
    if (loadConsentGroupCodeInfoCacheFromDB) {
      appCodeGroupBOList = appCodeGroupRepository.findByAppCodeGroupPK_requestAppId(appCode);
    } else {
      appCodeGroupBOList = null;
    }
    return appCodeGroupBOList;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.CONSENT_GROUP_CODE_INFO, key = "#appCode")
  public void clearConsentAppCodeGroup(Integer appCode) {
    // clearing Consent AppCode Group
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.CONSENT_GROUP_CODE_INFO)
  public void clearAllConsentAppCodeGroups() {
    // clearing all Consent AppCode Groups
  }


  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO)
  public List<ConsentPrivacyBO> retrieveAllConsentPrivacies() {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("retrieveAllConsentPrivacies"));
    return consentPrivacyRepository.findAll();
  }
  
  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO)
  public void clearCommonConsentPrivacies() {
    // clearing all Consent Privacies
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.CONSENT_CODE_INFO)
  public void clearAllConsentCodes() {
    // clearing all Consent C07 Codes
  }

  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_ID, key = "#consentId")
  public ConsentPrivacyBO retrieveConsentPrivacyByConsentId(Long consentId,
      boolean loadConsentPrivacyCacheFromDB) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("retrieveConsentPrivacyByConsentId")
        .consentId(String.valueOf(consentId)));
    ConsentPrivacyBO consentPrivacyBO = new ConsentPrivacyBO();
    if (loadConsentPrivacyCacheFromDB) {
      consentPrivacyBO = consentPrivacyRepository.findByConsentId(consentId);
    } else {
      consentPrivacyBO = null;
    }
    return consentPrivacyBO;
  }

  /**
   * This method checks for the ConsentCodes.
   *
   * @param consentId is Privacy Option Id
   * @return ConsentPrivacyBO
   */
  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_ID, key = "#consentId")
  public ConsentPrivacyBO getConsentPrivacyDtlsForConsentId(final Long consentId) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("getConsentPrivacyDtls by consent Id")
        .message(String.format("consentId: %d", consentId)));
    return consentPrivacyRepository.findByConsentId(consentId);
  }

  @CacheEvict(cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_ID, key = "#consentId")
  public void clearConsentPrivacyDtlsForConsentId(Long consentId) {
    // clearing Consent Privacy Details For ConsentId
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_ID)
  public void clearAllConsentPrivacyDtlsForConsentId() {
    // clearing all Consent Privacy Details For ConsentId
  }

  /**
   * This method get ConsentPrivacyBO by POU Key.
   *
   * @param pouKey is pou key
   * @return ConsentPrivacyBO
   */
  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_POU_KEY, key = "#pouKey")
  public ConsentPrivacyBO getConsentPrivacyDtlsForPouKey(final Long pouKey) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("getConsentPrivacyDtlsForPouKey")
        .message("Getting consentId for: " + pouKey));
    ConsentPrivacyBO consentBo = consentPrivacyRepository.findByPouKey(pouKey);
    String logMessage = consentBo != null ? "Retrieved consentId : " + consentBo.getConsentId()
        : "Null consentId Retrieved";
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName("getConsentPrivacyDtlsForPouKey").message(logMessage));
    return consentBo;
  }
  
  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_POU_KEY, key = "#pouKey")
  public ConsentPrivacyBO getConsentPrivacyDtlsForPouKey(final Long pouKey, boolean getFromDb) {
    String methodName = "getConsentPrivacyDtlsForPouKey";
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).message(String.format("getFromDb: %s", getFromDb)));
    ConsentPrivacyBO consentBo = null;
    if (getFromDb) {
      consentBo = consentPrivacyRepository.findByPouKey(pouKey);
    }
    return consentBo;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_POU_KEY, key = "#pouKey")
  public void clearConsentPrivacyDtlsForPouKey(Long pouKey) {
    // clearing Consent Privacy Details For pouKey
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_POU_KEY)
  public void clearAllConsentPrivacyDtlsForPouKey() {
    // clearing all Consent Privacy Details For PouKey
  }

  /**
   *
   * @param consentName
   * @return
   */
  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_NAME, key = "#consentName")
  public ConsentPrivacyBO getConsentPrivacyDtlsForName(String consentName) {
    String methodName = "getConsentPrivacyDtlsForName";
    ConsentPrivacyBO consentMappingBo = null;
    try {
      consentMappingBo = consentPrivacyRepository.findByPrivacyName(consentName);
    } catch (Exception exception) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(exception)
          .message(exception.getMessage()));
    }
    return consentMappingBo;
  }
  
  
  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_NAME, key = "#consentName")
  public ConsentPrivacyBO getConsentPrivacyDtlsForName(String consentName, boolean getFromDb) {
    String methodName = "getConsentPrivacyDtlsForName";
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).message(String.format("getFromDb: %s", getFromDb)));
    ConsentPrivacyBO consentMappingBo = null;
    if (getFromDb) {
      consentMappingBo = consentPrivacyRepository.findByPrivacyName(consentName);
    }
    return consentMappingBo;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_NAME,
      key = "#consentName")
  public void clearConsentPrivacyDtlsForName(String consentName) {
    // clearing Consent Privacy Details For name
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_NAME)
  public void clearAllConsentPrivacyDtlsForName() {
    // clearing all Consent Privacy Details For Name
  }

  /**
   *
   * @param deviceType
   * @return
   */
  @Cacheable(cacheNames = ConsentCacheNames.DEVICE_TYPE_INFO, key = "#deviceType")
  public DeviceTypeBO getDeviceTypeDtls(String deviceType, boolean loadFromDB) {
    String methodName = "getDeviceTypeDtls";
    DeviceTypeBO deviceTypeBo = null;
    try {
      if (loadFromDB) {
        deviceTypeBo = deviceTypeRepository.findByDeviceType(deviceType);
      }
    } catch (Exception exception) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(exception)
          .message(exception.getMessage()));
    }
    return deviceTypeBo;
  }

  @Cacheable(cacheNames = ConsentCacheNames.DEVICE_TYPE_INFO)
  public List<DeviceTypeBO> getAllDeviceTypeDtls() {
    String methodName = "getAllDeviceTypeDtls";
    List<DeviceTypeBO> deviceTypelist = null;
    try {
      deviceTypelist = deviceTypeRepository.findAll();
    } catch (Exception exception) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(exception)
          .message(exception.getMessage()));
    }
    return deviceTypelist;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.DEVICE_TYPE_INFO, key = "#deviceType")
  public void clearDeviceType(String deviceType) {
    // clearing device types
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.DEVICE_TYPE_INFO)
  public void clearAllDeviceTypes() {
    // clearing device types
  }

  /**
   * This method returns device type for an id
   *
   * @param deviceId
   * @return device Type
   */
  @Cacheable(cacheNames = ConsentCacheNames.DEVICE_TYPE_INFO_ID, key = "#deviceTypeId")
  public String getDeviceTypeById(Long deviceTypeId, boolean loadFromDB) {
    if (loadFromDB) {
      final DeviceTypeBO deviceMappingBO = deviceTypeRepository.findByDeviceTypeId(deviceTypeId);
      if (null != deviceMappingBO)
        return deviceMappingBO.getDeviceType();
    }
    return null;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.DEVICE_TYPE_INFO_ID, key = "#deviceTypeId")
  public void clearDeviceTypeById(Long deviceTypeId) {
    // clearing device type Ids
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.DEVICE_TYPE_INFO_ID)
  public void clearAllDeviceTypesById() {
    // clearing device type Ids
  }

  /**
   *
   * @param consentName
   * @param region
   * @param consumerType
   * @return
   */
  @Cacheable(cacheNames = ConsentCacheNames.PRIVACY_DEVICE_MAPPING_INFO,
      key = "{#consentName, #region, #consumerType}")
  public List<PrivacyDeviceMappingBO> getPrivacyDeviceMapping(String consentName, String region,
      String consumerType) {
    List<PrivacyDeviceMappingBO> mappings = null;
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName("getPrivacyDeviceMapping")
            .message(String.format(
                "Received Parameters: Consent Name: %s, Region: %s, Consumer Type: %s", consentName,
                region, consumerType)));
    try {
      mappings =
          privacyDeviceMappingRepository.findByConsentPrivacyBoPrivacyNameAndRegionAndConsumerType(
              consentName, region, consumerType);
    } catch (Exception exception) {
      LoggerBuilder.printError(log, logger -> logger.methodName("getPrivacyDeviceMapping")
          .exception(exception).message(exception.getMessage()));
    }
    return mappings;
  }

  @Cacheable(cacheNames = ConsentCacheNames.PRIVACY_DEVICE_MAPPING_INFO,
      key = "{#consentName, #region, #consumerType}")
  public List<PrivacyDeviceMappingBO> getPrivacyDeviceMapping(String consentName, String region,
      String consumerType, boolean loadFromDb) {
    List<PrivacyDeviceMappingBO> mappings = null;
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName("getPrivacyDeviceMapping")
            .message(String.format(
                "Received Parameters: Consent Name: %s, Region: %s, Consumer Type: %s", consentName,
                region, consumerType)));
    try {
      if (loadFromDb) {
        mappings = privacyDeviceMappingRepository
            .findByConsentPrivacyBoPrivacyNameAndRegionAndConsumerType(consentName, region,
                consumerType);
      }
    } catch (Exception exception) {
      LoggerBuilder.printError(log, logger -> logger.methodName("getPrivacyDeviceMapping")
          .exception(exception).message(exception.getMessage()));
    }
    return mappings;
  }

  @Cacheable(cacheNames = ConsentCacheNames.PRIVACY_DEVICE_MAPPING_INFO)
  public List<PrivacyDeviceMappingBO> getAllPrivacyDeviceMappings() {
    List<PrivacyDeviceMappingBO> mappings = null;
    LoggerBuilder.printDebug(log, logger -> logger.methodName("getAllPrivacyDeviceMappings")
        .message("Getting All Entries from DB!"));
    try {
      mappings = privacyDeviceMappingRepository.findAll();
    } catch (Exception exception) {
      LoggerBuilder.printError(log, logger -> logger.methodName("getAllPrivacyDeviceMappings")
          .exception(exception).message(exception.getMessage()));
    }
    return mappings;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.PRIVACY_DEVICE_MAPPING_INFO,
      key = "{#consentName, #region, #consumerType}")
  public void clearPrivacyDeviceMapping(String consentName, String region, String consumerType) {
    // clearing Privacy Device Mapping for provided key
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.PRIVACY_DEVICE_MAPPING_INFO)
  public void clearAllPrivacyDeviceMappings() {
    // clearing All Privacy Device Mappings
  }

  /**
   * This method checks for the PrivacyStatus.
   *
   * @param privacyStatus is Status of Privacy Option
   * @return PrivacyStatusBO
   */
  @Cacheable(cacheNames = ConsentCacheNames.PRIVACY_STATUS_INFO, key = "#privacyStatus")
  public PrivacyStatusBO getPrivacyStatusDtls(final String privacyStatus) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("getPrivacyStatusDtls")
        .message(String.format("PrivacyStatus: %s", privacyStatus)));
    return privacyStatusRepository.findByPrivacyStatus(privacyStatus);
  }

  /**
   * This method checks for the PrivacyStatus.
   *
   * @param privacyStatus is Status of Privacy Option
   * @param PrivacyStatus load from DB indicator
   * @return PrivacyStatusBO
   */
  @Cacheable(cacheNames = ConsentCacheNames.PRIVACY_STATUS_INFO, key = "#privacyStatus")
  public PrivacyStatusBO getPrivacyStatusDtls(final String privacyStatus,
      boolean loadPrivacyStatusFromDB) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("getPrivacyStatusDtls").message(String
        .format("PrivacyStatus: %s, Load from DB: %s", privacyStatus, loadPrivacyStatusFromDB)));
    PrivacyStatusBO privacyStatusBo = null;
    if (loadPrivacyStatusFromDB) {
      privacyStatusBo = privacyStatusRepository.findByPrivacyStatus(privacyStatus);
    }
    return privacyStatusBo;
  }

  /**
   * This method Gets All PrivacyStatus Bos From DB.
   *
   * @return List<PrivacyStatusBO> All Privacy Status Bos
   */
  @Cacheable(cacheNames = ConsentCacheNames.PRIVACY_STATUS_INFO)
  public List<PrivacyStatusBO> getAllPrivacyStatusDtls() {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("getPrivacyStatusDtls")
        .message("Gets All PrivacyStatus From DB!"));
    return privacyStatusRepository.findAll();
  }

  @CacheEvict(cacheNames = ConsentCacheNames.PRIVACY_STATUS_INFO, key = "#privacyStatus")
  public void clearPrivacyStatus(String privacyStatus) {
    // clearing Privacy Status
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.PRIVACY_STATUS_INFO)
  public void clearAllPrivacyStatusDtls() {
    // clearing All Privacy Status Details
  }

  /**
   * This method checks for the SuppressionTerm.
   *
   * @param consentId is Privacy Option Id
   * @param countryCode - country code
   * @return SuppressionTermBO
   */
  @Cacheable(cacheNames = ConsentCacheNames.SUPPRESSION_TERM_INFO,
      key = "{#consentId, #countryCode}")
  public SuppressionTermBO getSuppressionTermDtls(final Long consentId, final String countryCode) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("getSuppressionTermDtls")
        .message(String.format("ConsentId: %s, Country Code: %s", consentId, countryCode)));
    return suppressionTermCacheRepository.findByConsentIdAndCountryCode(consentId, countryCode);
  }
  
  
  /**
   * This method retrieves Suppression Term from DB if getFromDb is true.
   *
   * @param consentId - consenId
   * @param getFromdb whether to fetch from DB Or Not
   * @return {@link SuppressionTermBO}
   */
  @Cacheable(cacheNames = ConsentCacheNames.SUPPRESSION_TERM_INFO,
      key = "{#consentId, #countryCode}")
  public SuppressionTermBO getSuppressionTermDtls(final Long consentId, final String countryCode,
      boolean getFromdb) {
    String methodName = "getSuppressionTermDtls";
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .consentId(String.valueOf(consentId)).message(String.format("getFromDb: %s", getFromdb)));
    SuppressionTermBO suppressionTermBo = null;
    if (getFromdb) {
      suppressionTermBo =
          suppressionTermCacheRepository.findByConsentIdAndCountryCode(consentId, countryCode);
    }
    return suppressionTermBo;
  }
  
  @Cacheable(cacheNames = ConsentCacheNames.SUPPRESSION_TERM_INFO)
  public List<SuppressionTermBO> getAllSuppressionTerms() {
    String methodName = "getAllSuppressions";
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).message("Getting All Suppression Term Info..."));
    return suppressionTermCacheRepository.findAll();
  }

  @CacheEvict(cacheNames = ConsentCacheNames.SUPPRESSION_TERM_INFO,
      key = "{#consentId, #countryCode}")
  public void clearSuppressionTerm(Long consentId, String countryCode) {
    // clearing Suppression Term
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.SUPPRESSION_TERM_INFO)
  public void clearAllSuppressionTerms() {
    // clearing suppression terms
  }

  @Cacheable(cacheNames = ConsentCacheNames.APP_CONSENT_RELATION_INFO, key = "{#appId, #consentId}")
  public AppConsentRelationBO getAppConsentRelationDtls(final Integer appId, final Long consentId,
      final boolean loadFromDB) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("getAppConsentRelationDtls")
        .message(String.format("AppId: %d, and ConsentId: %d", appId, consentId)));
    return appConsentRelationRepository
        .findByAppConsentRelationPK_appIdAndAppConsentRelationPK_consentId(appId, consentId);
  }

  @Cacheable(cacheNames = ConsentCacheNames.APP_CONSENT_RELATION_INFO)
  public List<AppConsentRelationBO> getAllAppConsentRelationDtls() {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("getAllAppConsentRelationDtls"));
    return appConsentRelationRepository.findAll();
  }

  @CacheEvict(cacheNames = ConsentCacheNames.APP_CONSENT_RELATION_INFO,
      key = "{#appId, #consentId}")
  public void clearAppConsentRelationDtls(final Integer appId, final Long consentId) {
    // clearing appId and consent Id relationship
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.APP_CONSENT_RELATION_INFO)
  public void clearAllAppConsentRelationDtls() {
    // clearing appId and consent Id relationship
  }

  /**
   * This method checks for the Expiration.
   *
   * @param consentId is privacy consent Id
   * @param countryCode is country code iso3
   * @return ConsentPrivacyExpiryRuleBO
   */
  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_EXPIRY_RULE_INFO,
      key = "{#consentId, #countryCode}")
  public ConsentPrivacyExpiryRuleBO getConsentExpirationDtls(Long consentId, String countryCode) {
    String methodName = "getConsentExpirationDtls";
    ConsentPrivacyExpiryRuleBO consentExpirationBo = null;
    try {
      consentExpirationBo =
          consentPrivacyExpiryRuleRepository.findByConsentIdAndCountryCode(consentId, countryCode);
    } catch (Exception exception) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(exception)
          .message(exception.getMessage()));
    }
    return consentExpirationBo;
  }
  
  
  /**
   * This method checks for the Expiration.
   *
   * @param consentId is privacy consent Id
   * @param countryCode is country code iso3
   * @param getFromDb fetch from DB if true
   * @return ConsentPrivacyExpiryRuleBO
   */
  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_EXPIRY_RULE_INFO,
      key = "{#consentId, #countryCode}")
  public ConsentPrivacyExpiryRuleBO getConsentExpirationDtls(Long consentId, String countryCode,
      boolean getFromDb) {
    String methodName = "getConsentExpirationDtls";
    ConsentPrivacyExpiryRuleBO consentExpirationBo = null;
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .consentId(String.valueOf(consentId)).message(String.format("getFromDb: %s", getFromDb)));
    if (getFromDb) {
      consentExpirationBo =
          consentPrivacyExpiryRuleRepository.findByConsentIdAndCountryCode(consentId, countryCode);
    }
    return consentExpirationBo;
  }

  @Cacheable(cacheNames = ConsentCacheNames.CONSENT_EXPIRY_RULE_INFO)
  public List<ConsentPrivacyExpiryRuleBO> getAllExpiryRules() {
    String methodName = "getAllExpiryRules";
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName).message("Getting All Expiry Rules Info..."));
    return consentPrivacyExpiryRuleRepository.findAll();
  }
  
  @CacheEvict(cacheNames = ConsentCacheNames.CONSENT_EXPIRY_RULE_INFO,
      key = "{#consentId, #countryCode}")
  public void clearExpiryRule(Long consentId, String countryCode) {
    // clearing Expiry Rule
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.CONSENT_EXPIRY_RULE_INFO)
  public void clearAllExpiryRules() {
    // clearing all expiry rules
  }

  /**
   * This Method gets a list of deriver preferences by appId, region, statusCode, and consentName.
   *
   * @param appId is App Id
   * @param region is the region
   * @param statusCode is the status code
   * @param consentName is the consent Name
   * @param loadFromDb is loadFromDb flag
   * @return
   */
  
  //equavalent methods for your new cachename
  @Cacheable(cacheNames = ConsentCacheNames.DERIVED_PREFERENCES_INFO,
      key = "{#appId,#region,#statusCode,#consentName}")
  public List<DerivedPreferencesBO> getDerivedPreferences(String appId, String region,
      String statusCode, String consentName, boolean loadFromDb) {
    String methodName = "getDerivedPreferences";
    List<DerivedPreferencesBO> derivedPreferences = null;
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName)
            .message(String.format("AppId: %s, region: %s, statusCode: %s, consentName: %s", appId,
                region, statusCode, consentName)));
    if (loadFromDb) {
      derivedPreferences = derivedPreferencesRepository
          .findByAppIdAndRegionCodeAndRequestIndicatorAndPrivacyPreferenceName(
              Integer.valueOf(appId), region, statusCode, consentName);
    }
    return derivedPreferences;
  }

  @Cacheable(cacheNames = ConsentCacheNames.DERIVED_PREFERENCES_INFO)
  public List<DerivedPreferencesBO> getAllDerivedPreferences() {
    String methodName = "getDerivedPreferences";
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName));
    List<DerivedPreferencesBO> derivedPreferences = derivedPreferencesRepository.findAll();

    return derivedPreferences;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.DERIVED_PREFERENCES_INFO,
      key = "{#appId,#region,#statusCode,#consentName}")
  public void clearDerivedPreferences(String appId, String region, String statusCode,
      String consentName) {
    // clearing Derived preferences
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.DERIVED_PREFERENCES_INFO)
  public void clearAllDerivedPreferences() {
    // clearing Derived preferences
  }

  //
  
  @CacheEvict(allEntries = true,
      cacheNames = {ConsentCacheNames.CONSENT_PRIVACY_INFO, ConsentCacheNames.CONSENT_CODE_INFO,
          ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_ID,
          ConsentCacheNames.CONSENT_PRIVACY_INFO_POU_KEY,
          ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_NAME})
  public void clearAllConsentPrivacyCaches() {
    // clearing All Consent Privacy Caches
  }
  
  

//Default Privacy Cache handling begins 
  
  /**
   * This Method gets a list of default privacies by sourceName, region, privacyCategory
   *
   * @param sourceName is CWS/Stewardship
   * @param region is NA/SA/EU
   * @param privacyCategory can be permission/preference/suppression
   * @param loadFromDb is loadFromDb flag
   * @return
   */

  @Cacheable(cacheNames = ConsentCacheNames.DEFAULT_PRIVACIES_INFO,
      key = "{#sourceName,#region,#privacyCategory}")
  public List<DefaultPrivacyBO> getDefaultPrivacies(String sourceName, String region,
      String privacyCategory, boolean loadFromDb) {
    String methodName = "getDefaultPrivacies";
    List<DefaultPrivacyBO> defaultPrivacies = null;
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName(methodName)
            .message(String.format("sourceName: %s, region: %s, privacyCategory: %s", sourceName,region, privacyCategory)));
    if (loadFromDb) {
      defaultPrivacies = defaultPrivacyRepository
          .findBySourceNameAndRegionAndPrivacyCategory(
              sourceName, region, privacyCategory);
    }
    return defaultPrivacies;
  }

  @Cacheable(cacheNames = ConsentCacheNames.DEFAULT_PRIVACIES_INFO)
  public List<DefaultPrivacyBO> getAllDefaultPrivacies() {
    String methodName = "getDefaultPrivacies";
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName));
    List<DefaultPrivacyBO> defaultPrivacies = defaultPrivacyRepository.findAll();
    return defaultPrivacies;
  }

  @CacheEvict(cacheNames = ConsentCacheNames.DEFAULT_PRIVACIES_INFO,
      key = "{#sourceName,#region,#privacyCategory}")
  public void clearDefaultPrivacies(String sourceName, String region, String privacyCategory) {
    // clearing default Privacies
  }

  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.DEFAULT_PRIVACIES_INFO)
  public void clearAllDefaultPrivacies() {
    // clearing default Privacies
  }
  
 // Default Privacy Cache handling ends 
  
  
  
  @CacheEvict(allEntries = true,
      cacheNames = {ConsentCacheNames.APP_CODE_INFO, ConsentCacheNames.ERROR_MESSAGES,
          ConsentCacheNames.COUNTRY_INFO, ConsentCacheNames.COUNTRY_LANG_INFO,
          ConsentCacheNames.CONSENT_GROUP_CODE_INFO, ConsentCacheNames.CONSENT_PRIVACY_INFO,
          ConsentCacheNames.CONSENT_CODE_INFO, ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_ID,
          ConsentCacheNames.CONSENT_PRIVACY_INFO_POU_KEY,
          ConsentCacheNames.CONSENT_PRIVACY_INFO_CONSENT_NAME, ConsentCacheNames.DEVICE_TYPE_INFO,
          ConsentCacheNames.DEVICE_TYPE_INFO_ID, ConsentCacheNames.PRIVACY_DEVICE_MAPPING_INFO,
          ConsentCacheNames.PRIVACY_STATUS_INFO, ConsentCacheNames.SUPPRESSION_TERM_INFO,
          ConsentCacheNames.APP_CONSENT_RELATION_INFO, ConsentCacheNames.CONSENT_EXPIRY_RULE_INFO,
          ConsentCacheNames.DERIVED_PREFERENCES_INFO, ConsentCacheNames.DEFAULT_PRIVACIES_INFO})
  public void clearAllCaches() {
    // clearing All Caches
  }

}
