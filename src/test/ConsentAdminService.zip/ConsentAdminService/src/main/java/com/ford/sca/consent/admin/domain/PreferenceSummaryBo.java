package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "[MCNPF01_CONSENT_PREFERENCE]")
public class PreferenceSummaryBo implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "[CNPF01_CONSENT_PREFERENCE_K]")
  private Long preferenceSummaryKey;

  @Column(name = "[CNPC07_CONSENT_K]")
  private Long consentId;

  @Column(name = "[CNPC01_APP_C]")
  private Integer sourceCode;

  @Column(name = "[CNPC01_SEC_APP_C]")
  private Integer secSourceCode;

  @Column(name = "[CNPC02_COUNTRY_ISO3_C]")
  private String countryCode;

  @Column(name = "[CNPC04_STATUS_C]")
  private String preferenceStatus;

  @Column(name = "[CNPD01_DEVICE_D]")
  private Long deviceId;

  @Column(name = "[CNPC03_DEVICE_TYPE_D]")
  private Long deviceTypeId;

  @Column(name = "[CNPF01_PREFERENCE_S]")
  private Date preferenceTimestamp;

  @Column(name = "[CNPF01_CREATE_S]")
  private Date createDate;

  @Column(name = "[CNPF01_CREATE_USER_D]")
  private String createUser;

  @Column(name = "[CNPF01_CREATE_PROCESS_C]")
  private String createProcess;

  @Column(name = "[CNPF01_CREATE_APP_C]")
  private Integer createAppCode;

  @Column(name = "[CNPF01_UPDATE_S]")
  private Date updateDate;

  @Column(name = "[CNPF01_UPDATE_USER_D]")
  private String updateUser;

  @Column(name = "[CNPF01_UPDATE_PROCESS_C]")
  private String updateProcess;

  @Column(name = "[CNPF01_UPDATE_APP_C]")
  private Integer updateAppCode;

  @Column(name = "[CNPF01_SCA_D]")
  private String scaId;

  @Column(name = "[CNPF01_USER_D]")
  private String guid;

  @Column(name = "[CNPF01_START_S]")
  private Date startDate;

  @Column(name = "[CNPF01_END_S]")
  private Date endDate;

  @Column(name = "[CNPF01_CAPTURED_S]")
  private Date capturedTimestamp;
  
  @Override
  public boolean equals(Object o) {
      if (this == o)
          return true;
      if (o == null || getClass() != o.getClass())
          return false;
      PreferenceSummaryBo other = (PreferenceSummaryBo) o;
      return Objects.equals(sourceCode, other.sourceCode) && Objects.equals(countryCode, other.countryCode)
              && Objects.equals(consentId, other.consentId)&&Objects.equals(deviceId, other.deviceId);
  }

  @Override
  public int hashCode() {
      return Objects.hash(sourceCode, countryCode, consentId,deviceId);
  }


}

