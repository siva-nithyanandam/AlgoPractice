package com.ford.sca.consent.transport;

import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RetrieveAllExpiryRuleResponse extends GenericResponse {

  private Long expiryRulesCount;

  private Map<Long, List<CountryTermDTO>> expiryRulesMap;

}
