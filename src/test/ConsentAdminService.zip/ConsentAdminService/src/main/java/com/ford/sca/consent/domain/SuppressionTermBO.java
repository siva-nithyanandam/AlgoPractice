package com.ford.sca.consent.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "[MCNPC12_SUPPRESSION_TERM]")
public class SuppressionTermBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "[CNPC12_SUPPRESSION_TERM_K]")
  private Integer suppressionTermKey;

  @Column(name = "[CNPC02_COUNTRY_ISO3_C]")
  private String countryCode;

  @Column(name = "[CNPC12_SUPPRESSION_TERM_R]")
  private Integer suppressionTerm;

  @Column(name = "[CNPC07_CONSENT_K]")
  private Long consentId;

  @Column(name = "[CNPC12_CREATE_S]")
  private Date createDate;

  @Column(name = "[CNPC12_CREATE_USER_D]")
  private String createUser;

  @Column(name = "[CNPC12_CREATE_PROCESS_C]")
  private String createProcess;

  @Column(name = "[CNPC12_CREATE_APP_C]")
  private Integer createAppCode;

  @Column(name = "[CNPC12_UPDATE_S]")
  private Date updateDate;

  @Column(name = "[CNPC12_UPDATE_USER_D]")
  private String updateUser;

  @Column(name = "[CNPC12_UPDATE_PROCESS_C]")
  private String updateProcess;

  @Column(name = "[CNPC12_UPDATE_APP_C]")
  private Integer updateAppCode;

}