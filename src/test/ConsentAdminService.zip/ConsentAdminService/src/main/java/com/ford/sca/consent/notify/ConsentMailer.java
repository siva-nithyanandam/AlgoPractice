package com.ford.sca.consent.notify;

import java.io.File;

import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.ford.sca.consent.util.ConsentAdminServiceConstants;
import com.ford.sca.consent.util.ConsentMailerConstant;


@Component
public class ConsentMailer {
	
	@Autowired
	private JavaMailSender sender;

	private static final Logger LOGGER = LoggerFactory.getLogger(ConsentMailer.class);
	private String className = this.getClass().getSimpleName();

	public void sendMessageWithAttachment(String setTo, String subject, String text, String pathToAttachment) {
		String methodName = "sendMessageWithAttachment";
		MimeMessage message = sender.createMimeMessage();

		try {

			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(ConsentMailerConstant.FROM_ADDRESS);
			helper.setTo(setTo.split(ConsentMailerConstant.SPLIT));
			helper.setSubject(subject);
			helper.setText(text, text);

			FileSystemResource file = new FileSystemResource(new File(pathToAttachment));
			helper.addAttachment(file.getFilename(), file);

			sender.send(message);
		} catch (Exception e) {
			LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION, className, methodName,
					ConsentAdminServiceConstants.FAILED_STATUS + className + ConsentAdminServiceConstants.UNDERSCORE + methodName, MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
					MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME), e.getClass().getSimpleName(), e.getMessage(), e);
		}
	}
	
	public void sendMessage(String setTo, String subject, String text) {
		String methodName = "sendMessageWithOutAttachment";
		MimeMessage message = sender.createMimeMessage();
		try {

			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(ConsentMailerConstant.FROM_ADDRESS);
			helper.setTo(setTo.split(ConsentMailerConstant.SPLIT));
			helper.setSubject(subject);
			helper.setText(text);

			sender.send(message);
		} catch (Exception e) {
			LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION, className, methodName,
					ConsentAdminServiceConstants.FAILED_STATUS + className + ConsentAdminServiceConstants.UNDERSCORE + methodName, MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
					MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME), e.getClass().getSimpleName(), e.getMessage(), e);
		}
	} 
}
