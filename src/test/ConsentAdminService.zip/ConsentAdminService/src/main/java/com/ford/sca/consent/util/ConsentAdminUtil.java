package com.ford.sca.consent.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;




public class ConsentAdminUtil {

    private SimpleDateFormat consentEffectiveDateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public SimpleDateFormat getConsentEffectiveDateFormat() {
        return consentEffectiveDateFormat;
    }

    public void setConsentEffectiveDateFormat(SimpleDateFormat consentEffectiveDateFormat) {
        this.consentEffectiveDateFormat = consentEffectiveDateFormat;
    }

    // private static final SimpleDateFormat CONSENT_DATE_FORMAT =new
    // SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    private SimpleDateFormat consentDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

    public SimpleDateFormat getConsentDateFormat() {
        return consentDateFormat;
    }

    public void setConsentDateFormat(SimpleDateFormat consentDateFormat) {
        this.consentDateFormat = consentDateFormat;
    }

    private static ConsentAdminUtil instance = new ConsentAdminUtil();

    public static ConsentAdminUtil getInstance() {
        return instance;
    }

    public static String format(Date d) {
        return getInstance().getConsentEffectiveDateFormat().format(d);
    }

    public static Date today() {
        return Calendar.getInstance(TimeZone.getTimeZone("UTC")).getTime();
    }

    public static Date parseDate(String date) {
        if (date == null) {
            return null;
        }
        try {
            return getInstance().getConsentEffectiveDateFormat().parse(date);
        } catch (ParseException e) {
            return null;
        }

    }

    public static String todayString() {
        return format(today());
    }

    public static boolean isValidDate(String date) {
        try {
            getInstance().getConsentDateFormat().parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public static boolean isActiveFlag(String inputString) {
        boolean outputFlag = false;
        if (!isEmpty(inputString)) {
            outputFlag = inputString.equalsIgnoreCase(ConsentAdminServiceConstants.ACTIVE_FLAG);
        }
        return outputFlag;
    }

    public static boolean isEmpty(String value) {
        return (value == null || value.trim().isEmpty());
    }
    
    public static String convertDateToString(Date date, String dateFormat) {
        String dateString = null;
        if (null != date && !isEmpty(dateFormat)) {
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            dateString = sdf.format(date);
        }
        return dateString;
    }
    
    /**
     * To add expiration days.
     *
     * @return EndDate by adding expiration.
     */
  	public static String addExpirationPeriod(final String inputDate, final int days, final String dateFormat) {
  		
  		String endDate = null;
  		String time="T00:00:00.000Z";
  		if (inputDate != null) {
  			LocalDate date = LocalDate.parse(inputDate, DateTimeFormatter.ofPattern(dateFormat)).plusDays(days);
  			endDate = date+time;
  			  
  		}
  		return endDate;

  	}
  	
  	/**
     * Convert String to Date, given the string date format.
     *
     * @param inputDate is a string to be converted
     * @param dateFormat is date format for given input string
     * @return Date which is the converted date
  	 * @throws ParseException 
     */
	public static Date convertStringToDate(final String inputDate, final String dateFormat) throws ParseException {
		Date parsedDate = null;
		try {
			if (inputDate != null) {
				final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);
				parsedDate = sdf.parse(inputDate);
			}
		} catch (Exception ex) {
		}

		return parsedDate;
	}
}
