package com.ford.sca.consent.transport;

import java.io.Serializable;

public class POURegulation implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer pouID;

    private String pouStatus;

    private String createUser;

    private String effectiveStartDate;

    private String effectiveEndDate;

    public Integer getPouID() {
        return pouID;
    }

    public void setPouID(Integer pouID) {
        this.pouID = pouID;
    }

    public String getPouStatus() {
        return pouStatus;
    }

    public void setPouStatus(String pouStatus) {
        this.pouStatus = pouStatus;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getEffectiveStartDate() {
        return effectiveStartDate;
    }

    public void setEffectiveStartDate(String effectiveStartDate) {
        this.effectiveStartDate = effectiveStartDate;
    }

    public String getEffectiveEndDate() {
        return effectiveEndDate;
    }

    public void setEffectiveEndDate(String effectiveEndDate) {
        this.effectiveEndDate = effectiveEndDate;
    }

}
