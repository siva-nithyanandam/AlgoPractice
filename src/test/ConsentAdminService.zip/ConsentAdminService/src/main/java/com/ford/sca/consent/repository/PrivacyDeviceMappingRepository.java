package com.ford.sca.consent.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.domain.PrivacyDeviceMappingBO;

@Repository
public interface PrivacyDeviceMappingRepository
    extends JpaRepository<PrivacyDeviceMappingBO, Long> {

  public List<PrivacyDeviceMappingBO> findByConsentPrivacyBoPrivacyNameAndRegionAndConsumerType(
      String consentName, String region, String consumerType);

}
