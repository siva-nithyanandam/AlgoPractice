package com.ford.sca.consent.transport;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RetrieveAppCodeGroup {
  private Integer requestAppId;
  private Integer retrieveAppId;
}
