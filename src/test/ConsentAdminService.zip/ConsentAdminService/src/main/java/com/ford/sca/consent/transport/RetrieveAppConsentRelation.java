package com.ford.sca.consent.transport;

import java.util.List;
import java.util.Map;

import com.ford.sca.consent.domain.AppConsentRelationBO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RetrieveAppConsentRelation extends GenericResponse {

  private Long appConsentRelationCount;
  private Map<Integer, List<AppConsentRelationBO>> appIdConsentRelationMap;
  
}
