package com.ford.sca.consent.service.ruleengines;

import com.ford.sca.consent.service.MasterRuleEngineSupressionTerm;
import com.ford.sca.consent.validators.ValidatorSuppressionTerm;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class SuppressionTermRuleEngine extends MasterRuleEngineSupressionTerm {

  private static final Set<String> REGIONS = new HashSet<>();

  static {
    REGIONS.add("NA ");
    REGIONS.add("SA ");
    REGIONS.add("EU ");
  }

  @Override
  public Set<String> getSupportedRegions() {
    return REGIONS;
  }

  @Override
  public List<ValidatorSuppressionTerm> getValidators() {
    List<ValidatorSuppressionTerm> validatorsForSuppressionTerm = new ArrayList<>();
    validatorsForSuppressionTerm.add(appCodeValidator);
    validatorsForSuppressionTerm.add(suppressionTypeValidator);
    validatorsForSuppressionTerm.add(suppressionTermValidator);

    return validatorsForSuppressionTerm;
  }
}
