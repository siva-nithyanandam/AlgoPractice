package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "[MCNPC14_EXPIRY_RULE]")
public class ConsentExpirationBo implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "[CNPC14_EXPIRY_RULE_SEQ_R]")
	private Long consentExpirationId;

	@Column(name = "[CNPC02_COUNTRY_ISO3_C]")
	private String consentCountry;

	@Column(name = "[CNPC07_CONSENT_K]")
	private Long consentId;

	@Column(name = "[CNPC14_EXPIRY_TERM_R]")
	private Integer consentExpirationPeriod;

	@Column(name = "[CNPC14_STATUS_C]")
	private String consentExpirationStatus;
	
	@Column(name = "[CNPC14_CREATE_S]")
	private Timestamp createTime;

	@Column(name = "[CNPC14_CREATE_USER_D]")
	private String createUser;

	@Column(name = "[CNPC14_CREATE_PROCESS_C]")
	private String createProcess;

	@Column(name = "[CNPC14_CREATE_APP_C]")
	private Integer createAppId;

	@Column(name = "[CNPC14_UPDATE_S]")
	private Timestamp updatedTime;

	@Column(name = "[CNPC14_UPDATE_USER_D]")
	private String updateUserId;

	@Column(name = "[CNPC14_UPDATE_PROCESS_C]")
	private String updateProcess;

	@Column(name = "[CNPC14_UPDATE_APP_C]")
	private Integer updateAppId;
	
	
	@Column(name = "[CNPC14_ACTION_F]")
	private String actionFlag;

}
