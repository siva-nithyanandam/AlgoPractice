package com.ford.sca.consent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ford.sca.consent.domain.ConsentPrivacyExpiryRuleBO;

public interface ConsentPrivacyExpiryRuleRepository
    extends JpaRepository<ConsentPrivacyExpiryRuleBO, Long> {

  public ConsentPrivacyExpiryRuleBO findByConsentIdAndCountryCode(Long consentId,
      String countryCode);

}
