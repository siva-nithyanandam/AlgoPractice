package com.ford.sca.consent.transport;

import java.io.Serializable;

public class ConsentAdminResponse implements Serializable {

    /**
    * 
    */
    private static final long serialVersionUID = 1L;
    private String status;
    private String statusCode;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    @Override
    public String toString() {
        return "ConsentAdminResponse [status=" + status + ", statusCode=" + statusCode + "]";
    }

}
