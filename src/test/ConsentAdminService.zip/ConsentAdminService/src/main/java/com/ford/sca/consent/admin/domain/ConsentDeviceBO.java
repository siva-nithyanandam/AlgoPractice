package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "[MCAPN04_CONSENT_DEVICE]", catalog = "SCACAP", schema = "dbo")
public class ConsentDeviceBO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3182227120646255610L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "[CAPN04_CONSENT_DEVICE_SEQ_R]")
	private Integer consentDeviceSeqKey;

	@ManyToOne
	@JoinColumn(name = "[CAPN01_CONSENT_MGMT_SEQ_R]")
	private ConsentMgmtBO consentSeqKey;

	@Column(name = "[CAPN04_DEVICE_TYPE_X]")
	private String deviceType;

	@Column(name = "[CAPN04_DEVICE_VALUE_X]")
	private String deviceValue;

	@Column(name = "[CAPN04_CREATE_S]")
	private Date createDate;

	@Column(name = "[CAPN04_CREATE_USER_D]")
	private String createUser;

	@Column(name = "[CAPN04_CREATE_PROCESS_C]")
	private String createProcess;

	@Column(name = "[CAPN04_CREATE_APP_C]")
	private Float createAppCode;

	@Column(name = "[CAPN04_UPDATE_S]")
	private Date updateDate;

	@Column(name = "[CAPN04_UPDATE_USER_D]")
	private String updateUser;

	@Column(name = "[CAPN04_UPDATE_PROCESS_C]")
	private String updateProcess;

	@Column(name = "[CAPN04_UPDATE_APP_C]")
	private Float updateAppCode;

	public Integer getConsentDeviceSeqKey() {
		return consentDeviceSeqKey;
	}

	public void setConsentDeviceSeqKey(Integer consentDeviceSeqKey) {
		this.consentDeviceSeqKey = consentDeviceSeqKey;
	}

	public ConsentMgmtBO getConsentSeqKey() {
		return consentSeqKey;
	}

	public void setConsentSeqKey(ConsentMgmtBO consentSeqKey) {
		this.consentSeqKey = consentSeqKey;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getDeviceValue() {
		return deviceValue;
	}

	public void setDeviceValue(String deviceValue) {
		this.deviceValue = deviceValue;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCreateProcess() {
		return createProcess;
	}

	public void setCreateProcess(String createProcess) {
		this.createProcess = createProcess;
	}

	public Float getCreateAppCode() {
		return createAppCode;
	}

	public void setCreateAppCode(Float createAppCode) {
		this.createAppCode = createAppCode;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateProcess() {
		return updateProcess;
	}

	public void setUpdateProcess(String updateProcess) {
		this.updateProcess = updateProcess;
	}

	public Float getUpdateAppCode() {
		return updateAppCode;
	}

	public void setUpdateAppCode(Float updateAppCode) {
		this.updateAppCode = updateAppCode;
	}

	@Override
	public String toString() {
		return "ConsentDeviceBO [consentDeviceSeqKey=" + consentDeviceSeqKey + ", consentSeqKey=" + consentSeqKey
				+ ", deviceType=" + deviceType + ", deviceValue=" + deviceValue + ", createDate=" + createDate
				+ ", createUser=" + createUser + ", createProcess=" + createProcess + ", createAppCode=" + createAppCode
				+ ", updateDate=" + updateDate + ", updateUser=" + updateUser + ", updateProcess=" + updateProcess
				+ ", updateAppCode=" + updateAppCode + "]";
	}

}
