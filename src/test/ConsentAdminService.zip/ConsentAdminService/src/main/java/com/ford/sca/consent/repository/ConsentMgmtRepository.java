package com.ford.sca.consent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ford.sca.consent.admin.domain.ConsentMgmtBO;

public interface ConsentMgmtRepository extends JpaRepository<ConsentMgmtBO, Integer> {

}
