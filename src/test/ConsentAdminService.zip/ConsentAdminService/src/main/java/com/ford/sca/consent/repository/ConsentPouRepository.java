package com.ford.sca.consent.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.admin.domain.ConsentPouBO;

@Repository
public interface ConsentPouRepository extends JpaRepository<ConsentPouBO, Long> {

    List<ConsentPouBO> findDistinctCapUserIdByAppCountryCode(String appCountry);
    List<ConsentPouBO> findByCapUserIDAndPouIDOrderByCreateDateDesc(String appCountry,Integer pouId);
	List<ConsentPouBO> findByExpiryDateLessThanEqualAndExpiryDateIsNotNullOrderByCreateDateDesc(Date currentDate);
	

	/*List<ConsentPouBO> findByCapUserIDAndScaIdAndSourceAppIDAndAppCountryCodeAndLLIdAndExpiryDateGreaterThanEqualAndExpiryDateIsNotNull(
			String capUserId, String scaId, Float appCode, String appCountryCode, String llId, Date currentDate);*/
	
}
