package com.ford.sca.consent.transport;


import java.util.List;
import java.util.Map;

import com.ford.sca.consent.domain.DefaultPrivacyBO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RetrieveDefaultPrivacy extends GenericResponse {

  private Long defaultPrivaciesCount;
  private List<DefaultPrivacyBO> defaultPrivacyList;
  
}

