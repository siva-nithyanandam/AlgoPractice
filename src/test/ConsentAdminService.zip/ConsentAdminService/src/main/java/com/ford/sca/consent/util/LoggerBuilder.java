package com.ford.sca.consent.util;

import java.lang.reflect.Field;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

@Setter
@Accessors(fluent = true)
public final class LoggerBuilder {

  // Application statics
  private String serviceGroup = Constants.SERVICE_GROUP_NAME;

  // Thread statics
  private String serviceId;
  private String correlationId;
  private String vcapRequestId;
  private String buildVersion;
  private String traceId;

  // Variables - Strictly no primitives
  private String className;
  private String methodName;
  private String action;
  private String appCd;
  private String message;
  private String exceptionMessage;
  private Exception exception;
  private Long responseTime;
  private String request;
  private String mqName;
  private String json;
  private String httpMethod;
  private String resourceUri;
  private String guid;
  private String scaId;
  private String countryCode;
  private String cacheName;
  private String cacheKeyName;
  private String preferredLanguage;
  private String consentId;


  private LoggerBuilder(final String serviceId, final String correlationId,
      final String vcapRequestId, final String buildVersion, final String traceId) {
    this.serviceId = serviceId;
    this.correlationId = correlationId;
    this.vcapRequestId = vcapRequestId;
    this.buildVersion = buildVersion;
    this.traceId = traceId;
  }

  /**
   * To log in INFO mode for given class and consumer.
   *
   * @param declaringType class name of the caller
   * @param consumer required LoggerBuilder statements
   */
  public static void printInfo(final Class declaringType, final Consumer<LoggerBuilder> consumer) {
    final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
    CompletableFuture.runAsync(() -> {
      final Logger logger = LoggerFactory.getLogger(declaringType);
      consumer.accept(loggerBuilder);
      loggerBuilder.info(logger);
    });
  }

  /**
   * To log in INFO mode for given logger and consumer.
   *
   * @param logger logger instance to log
   * @param consumer required LoggerBuilder statements
   */
  public static void printInfo(final Logger logger, final Consumer<LoggerBuilder> consumer) {
    final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
    CompletableFuture.runAsync(() -> {
      consumer.accept(loggerBuilder);
      loggerBuilder.info(logger);
    });
  }

  /**
   * To log in TRACE mode for given logger and consumer.
   *
   * @param logger logger instance to log
   * @param consumer required LoggerBuilder statements
   */
  public static void printTrace(final Logger logger, final Consumer<LoggerBuilder> consumer) {
    final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
    CompletableFuture.runAsync(() -> {
      consumer.accept(loggerBuilder);
      loggerBuilder.trace(logger);
    });
  }

  /**
   * To log in DEBUG mode for given logger and consumer.
   *
   * @param logger logger instance to log
   * @param consumer required LoggerBuilder statements
   */
  public static void printDebug(final Logger logger, final Consumer<LoggerBuilder> consumer) {
    final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
    CompletableFuture.runAsync(() -> {
      consumer.accept(loggerBuilder);
      loggerBuilder.debug(logger);
    });
  }

  /**
   * To log in WARNING mode for given logger and consumer.
   *
   * @param logger logger instance to log
   * @param consumer required LoggerBuilder statements
   */
  public static void printWarn(final Logger logger, final Consumer<LoggerBuilder> consumer) {
    final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
    CompletableFuture.runAsync(() -> {
      consumer.accept(loggerBuilder);
      loggerBuilder.warn(logger);
    });
  }

  /**
   * To log in ERROR mode for given class and consumer.
   *
   * @param declaringType class name of the caller
   * @param consumer required LoggerBuilder statements
   */
  public static void printError(final Class declaringType, final Consumer<LoggerBuilder> consumer) {
    final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
    CompletableFuture.runAsync(() -> {
      final Logger logger = LoggerFactory.getLogger(declaringType);
      consumer.accept(loggerBuilder);
      loggerBuilder.error(logger);
    });
  }

  /**
   * To log in ERROR mode for given logger and consumer.
   *
   * @param logger logger instance to log
   * @param consumer required LoggerBuilder statements
   */
  public static void printError(final Logger logger, final Consumer<LoggerBuilder> consumer) {
    final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
    CompletableFuture.runAsync(() -> {
      consumer.accept(loggerBuilder);
      loggerBuilder.error(logger);
    });
  }

  /**
   * To log in INFO mode.
   */
  private void info(final Logger logger) {
    if (null != logger) {
      this.className = logger.getName();
      try {
        logger.info(getNotNullFields());
      } catch (IllegalAccessException e) {
        logger.info(Constants.UNABLE_TO_GET_NOT_NULL_FIELDS, e);
      }
    }
  }

  /**
   * To log in DEBUG mode.
   */
  private void debug(final Logger logger) {
    if (null != logger) {
      this.className = logger.getName();
      try {
        logger.debug(getNotNullFields());
      } catch (IllegalAccessException e) {
        logger.debug(Constants.UNABLE_TO_GET_NOT_NULL_FIELDS, e);
      }
    }
  }

  /**
   * To log in TRACE mode.
   */
  private void trace(final Logger logger) {
    if (null != logger) {
      this.className = logger.getName();
      try {
        logger.trace(getNotNullFields());
      } catch (IllegalAccessException e) {
        logger.trace(Constants.UNABLE_TO_GET_NOT_NULL_FIELDS, e);
      }
    }
  }

  /**
   * To log in WARN mode.
   */
  private void warn(final Logger logger) {
    if (null != logger) {
      this.className = logger.getName();
      try {
        logger.warn(getNotNullFields());
      } catch (IllegalAccessException e) {
        logger.warn(Constants.UNABLE_TO_GET_NOT_NULL_FIELDS, e);
      }
    }
  }

  /**
   * To log in ERROR mode.
   */
  private void error(final Logger logger) {
    if (null != logger) {
      this.className = logger.getName();
      try {
        logger.error(getNotNullFields());
      } catch (IllegalAccessException e) {
        logger.error(Constants.UNABLE_TO_GET_NOT_NULL_FIELDS, e);
      }
    }
  }

  /**
   * To get not null fields of this class.
   */
  private String getNotNullFields() throws IllegalAccessException {
    final StringBuilder stringBuilder = new StringBuilder();
    for (final Field f : getClass().getDeclaredFields()) {
      if (f.get(this) != null) {
        stringBuilder.append(f.getName()).append('=').append(f.get(this)).append(',');
      }
    }
    return stringBuilder.toString();
  }
}
