package com.ford.sca.consent.domain;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name = "[MCNPC11_APP_CODE_MAPPING]")
public class AppCodeGroupBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @EmbeddedId
  private AppCodeGroupPK appCodeGroupPK;

}
