package com.ford.sca.consent.exception;

public class ConsentBaseException extends RuntimeException {

	private static final long serialVersionUID = 9191381998484218993L;

	public ConsentBaseException() {
		super();
	}

	public ConsentBaseException(String message) {
		super(message);
	}

	public ConsentBaseException(Throwable cause) {
		super(cause);
	}

	public ConsentBaseException(String message, Throwable cause) {
		super(message, cause);
	}

	public ConsentBaseException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	@Override
	public synchronized Throwable fillInStackTrace() {

		return this;
	}

}