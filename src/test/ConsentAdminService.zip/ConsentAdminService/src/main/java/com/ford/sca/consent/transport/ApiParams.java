package com.ford.sca.consent.transport;

import java.util.Date;
import com.ford.sca.consent.statics.RequestMode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApiParams {
  private String appCd;
  private String countryCode;
  private Date requestTimeStamp;
  private RequestMode requestMode;

}
