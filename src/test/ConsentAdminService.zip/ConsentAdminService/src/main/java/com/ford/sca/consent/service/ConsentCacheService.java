package com.ford.sca.consent.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ford.sca.consent.domain.AppCodeBO;
import com.ford.sca.consent.domain.MessageLangServiceViewBO;
import com.ford.sca.consent.domain.PrivacyDeviceMappingBO;
import com.ford.sca.consent.domain.PrivacyStatusBO;
import com.ford.sca.consent.domain.ConsentPrivacyBO;
import com.ford.sca.consent.domain.ConsentPrivacyExpiryRuleBO;
import com.ford.sca.consent.domain.SuppressionTermBO;
import com.ford.sca.consent.transport.ConsentPrivacyByNameResponse;
import com.ford.sca.consent.transport.ConsentPrivacyByPouKeyResponse;
import com.ford.sca.consent.transport.ConsentPrivacyDTO;
import com.ford.sca.consent.transport.CountryTermDTO;
import com.ford.sca.consent.domain.AppConsentRelationBO;
import com.ford.sca.consent.domain.DerivedPreferencesBO;
import com.ford.sca.consent.domain.DeviceTypeBO;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.transport.RetrieveAllExpiryRuleResponse;
import com.ford.sca.consent.transport.RetrieveAllSuppressionTermResponse;
import com.ford.sca.consent.transport.RetrieveAppCodes;
import com.ford.sca.consent.transport.RetrieveErrorMessages;
import com.ford.sca.consent.transport.RetrievePrivacyDeviceMappings;
import com.ford.sca.consent.transport.RetrievePrivacyStatuses;
import com.ford.sca.consent.domain.CountryCodeBO;
import com.ford.sca.consent.domain.CountryLangBO;
import com.ford.sca.consent.domain.DefaultPrivacyBO;
import com.ford.sca.consent.transport.RetrieveConsentPrivaciesInfo;
import com.ford.sca.consent.transport.RetrieveConsentPrivacy;
import com.ford.sca.consent.transport.RetrieveCountriesInfo;
import com.ford.sca.consent.transport.RetrieveCountry;
import com.ford.sca.consent.transport.RetrieveCountryLangCodes;
import com.ford.sca.consent.transport.RetrieveDefaultPrivacy;
import com.ford.sca.consent.transport.RetrieveExpiryRuleResponse;
import com.ford.sca.consent.transport.RetrieveSuppressionTermResponse;
import com.ford.sca.consent.transport.RetrieveAppConsentRelation;
import com.ford.sca.consent.transport.RetrieveDerivedPreferences;
import com.ford.sca.consent.transport.RetrieveDeviceTypeIds;
import com.ford.sca.consent.transport.RetrieveDeviceTypes;
import com.ford.sca.consent.util.CacheUtil;
import com.ford.sca.consent.util.GenericAssister;
import com.ford.sca.consent.util.LogAround;
import com.ford.sca.consent.util.LoggerBuilder;
import com.ford.sca.consent.util.ResponseBuilder;
import com.ford.sca.consent.util.ResponseCodes;
import com.ford.sca.consent.util.StringAssister;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ConsentCacheService {

  @Autowired
  private CacheUtil cacheUtil;

  @Autowired
  private ResponseBuilder responseBuilder;

  @LogAround
  public RetrieveAppCodes retrieveAppCodeCache(Integer appId, boolean loadAppIdCacheFromDB) {

    RetrieveAppCodes retrieveAppCodes = new RetrieveAppCodes();
    Long appIdCounts = 0L;
    try {
      if (loadAppIdCacheFromDB) {
        cacheUtil.clearAppCode(appId);
      }

      Map<Integer, String> appCodeMap = new HashMap<Integer, String>();
      AppCodeBO appCodeBO2 = cacheUtil.getAppCodeDtls(appId, loadAppIdCacheFromDB);
      if (appCodeBO2 != null) {
        appIdCounts = 1L;
        appCodeMap.put(appCodeBO2.getAppId(), appCodeBO2.getAppName());
        retrieveAppCodes.setAppCodeMap(appCodeMap);
      }

      retrieveAppCodes.setAppCodesCount(appIdCounts);
      retrieveAppCodes.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveAppCodes.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log,
          logger -> logger.methodName("retrieveAppCodeCache").exception(e));
      appIdCounts = (long) 0;
      retrieveAppCodes.setAppCodesCount(appIdCounts);
      retrieveAppCodes.setAppCodeMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveAppCodes);

    }
    return retrieveAppCodes;
  }

  @LogAround
  public RetrieveAppCodes retrieveAllAppCodes(boolean loadAppIdCacheFromDB) {
    String methodName = "retrieveAllAppCodes";

    RetrieveAppCodes retrieveAppCodes = new RetrieveAppCodes();
    Map<Integer, String> appCodeMap = new HashMap<Integer, String>();
    List<AppCodeBO> appCodeBOList = new ArrayList<AppCodeBO>();
    AppCodeBO appCodeBO = new AppCodeBO();
    Long appIdCounts = 0L;
    try {

      if (loadAppIdCacheFromDB) {
        cacheUtil.clearAllAppCodes();
      }

      appCodeBOList = cacheUtil.getAppCodeList();
      if (GenericAssister.isCollectionNotEmpty(appCodeBOList)) {
        for (AppCodeBO appCBO : appCodeBOList) {
          appIdCounts++;
          if (appCBO != null) {
            appCodeBO = cacheUtil.getAppCodeDtls(appCBO.getAppId(), loadAppIdCacheFromDB);
            if (appCodeBO != null) {
              appCodeMap.put(appCodeBO.getAppId(), appCodeBO.getAppName());
            }
          }
        }
        retrieveAppCodes.setAppCodesCount(appIdCounts);
        retrieveAppCodes.setAppCodeMap(appCodeMap);
      }

      retrieveAppCodes.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveAppCodes.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());


    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      appCodeBOList = null;
      appIdCounts = (long) 0;
      retrieveAppCodes.setAppCodesCount(appIdCounts);
      retrieveAppCodes.setAppCodeMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveAppCodes);

    }
    return retrieveAppCodes;
  }

  @LogAround
  public GenericResponse retrieveErrorMessageCache(String errorMsgId,
      boolean loadErrMsgCacheFromDB) {
    RetrieveErrorMessages retrieveErrorMessages = new RetrieveErrorMessages();
    Long errorMsgCounts = 0L;
    try {
      if (loadErrMsgCacheFromDB) {
        cacheUtil.clearErrorMessage(errorMsgId);
      }

      Map<String, String> errorMessageMap = new HashMap<String, String>();
      String msgDesc = cacheUtil.getErrorMessage(errorMsgId, loadErrMsgCacheFromDB);

      if (StringAssister.isNotEmptyString(msgDesc)) {
        errorMsgCounts = 1L;
        errorMessageMap.put(errorMsgId, msgDesc);
        retrieveErrorMessages.setErrorMsgMap(errorMessageMap);
      }

      retrieveErrorMessages.setErrorMessageCount(errorMsgCounts);
      retrieveErrorMessages.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveErrorMessages.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());

    } catch (Exception e) {
      LoggerBuilder.printError(log,
          logger -> logger.methodName("retrieveErrorMessageCache").exception(e));
      errorMsgCounts = (long) 0;
      retrieveErrorMessages.setErrorMessageCount(errorMsgCounts);
      retrieveErrorMessages.setErrorMsgMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveErrorMessages);
    }

    return retrieveErrorMessages;
  }

  @LogAround
  public GenericResponse retrieveAllErrorMessages(boolean loadErrMsgCacheFromDB) {

    RetrieveErrorMessages retrieveErrorMessages = new RetrieveErrorMessages();
    Long errorMsgCounts = 0L;
    Map<String, String> errorMessageMap = new HashMap<String, String>();
    try {
      if (loadErrMsgCacheFromDB) {
        cacheUtil.clearAllErrorMessages();
      }
      List<MessageLangServiceViewBO> msgList = cacheUtil.getErrorMessagesList();
      if (GenericAssister.isCollectionNotEmpty(msgList)) {
        for (MessageLangServiceViewBO msgViewBo : msgList) {
          errorMsgCounts++;
          if (null != msgViewBo) {
            String msgDesc =
                cacheUtil.getErrorMessage(msgViewBo.getMessageCode(), loadErrMsgCacheFromDB);
            if (StringAssister.isNotEmptyString(msgDesc)) {
              errorMessageMap.put(msgViewBo.getMessageCode(), msgDesc);
            }
          }

        }
        retrieveErrorMessages.setErrorMessageCount(errorMsgCounts);
        retrieveErrorMessages.setErrorMsgMap(errorMessageMap);
      }

      retrieveErrorMessages.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveErrorMessages.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());

    } catch (Exception e) {
      LoggerBuilder.printError(log,
          logger -> logger.methodName("retrieveAllErrorMessages").exception(e));
      errorMsgCounts = (long) 0;
      retrieveErrorMessages.setErrorMessageCount(errorMsgCounts);
      retrieveErrorMessages.setErrorMsgMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveErrorMessages);

    }
    return retrieveErrorMessages;

  }

  @LogAround
  public GenericResponse retrievePrivacyStatusCache(String privacyStatus,
      boolean loadprivacyStatusCacheFromDB) {
    RetrievePrivacyStatuses retrievePrivacyStatuses = new RetrievePrivacyStatuses();
    Long privacyStatusCounts = 0L;
    try {
      if (loadprivacyStatusCacheFromDB) {
        cacheUtil.clearPrivacyStatus(privacyStatus);
      }

      Map<String, PrivacyStatusBO> privacyStatuseMap = new HashMap<String, PrivacyStatusBO>();
      PrivacyStatusBO privacyStatusBo =
          cacheUtil.getPrivacyStatusDtls(privacyStatus, loadprivacyStatusCacheFromDB);

      if (privacyStatusBo != null) {
        privacyStatusCounts = 1L;
        privacyStatuseMap.put(privacyStatus, privacyStatusBo);
        retrievePrivacyStatuses.setPrivacyStatusMap(privacyStatuseMap);
      }

      retrievePrivacyStatuses.setPrivacyStatusCount(privacyStatusCounts);
      retrievePrivacyStatuses.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrievePrivacyStatuses.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());

    } catch (Exception e) {
      LoggerBuilder.printError(log,
          logger -> logger.methodName("retrievePrivacyStatusCache").exception(e));
      privacyStatusCounts = (long) 0;
      retrievePrivacyStatuses.setPrivacyStatusCount(privacyStatusCounts);
      retrievePrivacyStatuses.setPrivacyStatusMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrievePrivacyStatuses);
    }

    return retrievePrivacyStatuses;
  }

  @LogAround
  public GenericResponse retrieveAllPrivacyStatuses(boolean loadPrivacyStatusFromDB) {

    RetrievePrivacyStatuses retrievePrivacyStatuses = new RetrievePrivacyStatuses();
    Long privacyStatusCounts = 0L;
    Map<String, PrivacyStatusBO> privacyStatusMap = new HashMap<String, PrivacyStatusBO>();
    try {
      if (loadPrivacyStatusFromDB) {
        cacheUtil.clearAllPrivacyStatusDtls();
      }
      List<PrivacyStatusBO> prvStsList = cacheUtil.getAllPrivacyStatusDtls();
      if (GenericAssister.isCollectionNotEmpty(prvStsList)) {
        for (PrivacyStatusBO prvSts : prvStsList) {
          privacyStatusCounts++;
          if (null != prvSts) {
            PrivacyStatusBO privacyStatusBO =
                cacheUtil.getPrivacyStatusDtls(prvSts.getPrivacyStatus(), loadPrivacyStatusFromDB);
            if (privacyStatusBO != null) {
              privacyStatusMap.put(prvSts.getPrivacyStatus(), privacyStatusBO);
            }
          }

        }
        retrievePrivacyStatuses.setPrivacyStatusCount(privacyStatusCounts);
        retrievePrivacyStatuses.setPrivacyStatusMap(privacyStatusMap);
      }

      retrievePrivacyStatuses.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrievePrivacyStatuses.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());

    } catch (Exception e) {
      LoggerBuilder.printError(log,
          logger -> logger.methodName("retrieveAllPrivacyStatuses").exception(e));
      privacyStatusCounts = (long) 0;
      retrievePrivacyStatuses.setPrivacyStatusCount(privacyStatusCounts);
      retrievePrivacyStatuses.setPrivacyStatusMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrievePrivacyStatuses);

    }
    return retrievePrivacyStatuses;

  }

  public GenericResponse retrievePrivacyDeviceMappingCache(String privacyName, String region,
      String consumerType, boolean loadCacheFromDB) {

    RetrievePrivacyDeviceMappings retrievePrivacyDeviceMappings =
        new RetrievePrivacyDeviceMappings();
    Long privacyDeviceMappingCounts = 0L;
    Map<String, List<PrivacyDeviceMappingBO>> privacyDeviceMappingsMap =
        new HashMap<String, List<PrivacyDeviceMappingBO>>();

    try {
      if (loadCacheFromDB) {
        cacheUtil.clearPrivacyDeviceMapping(privacyName, region, consumerType);
      }


      List<PrivacyDeviceMappingBO> privacyDeviceMappingsList =
          cacheUtil.getPrivacyDeviceMapping(privacyName, region, consumerType, loadCacheFromDB);
      if (GenericAssister.isCollectionNotEmpty(privacyDeviceMappingsList)) {
        privacyDeviceMappingCounts = 1L;
        String key = constructPrivacyDeviceMappingKey(privacyName, region, consumerType);
        privacyDeviceMappingsMap.put(key, privacyDeviceMappingsList);
        retrievePrivacyDeviceMappings.setPrivacyDeviceMappingsMap(privacyDeviceMappingsMap);
      }

      retrievePrivacyDeviceMappings.setPrivacyDeviceMappingsCount(privacyDeviceMappingCounts);
      retrievePrivacyDeviceMappings.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrievePrivacyDeviceMappings.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());

    } catch (Exception e) {
      LoggerBuilder.printError(log,
          logger -> logger.methodName("retrievePrivacyDeviceMappingCache").exception(e));
      privacyDeviceMappingCounts = (long) 0;
      retrievePrivacyDeviceMappings.setPrivacyDeviceMappingsCount(privacyDeviceMappingCounts);
      retrievePrivacyDeviceMappings.setPrivacyDeviceMappingsMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrievePrivacyDeviceMappings);

    }
    return retrievePrivacyDeviceMappings;



  }

  public GenericResponse retrieveAllPrivacyDeviceMappingsCache(boolean loadCacheFromDB) {

    RetrievePrivacyDeviceMappings retrievePrivacyDeviceMappings =
        new RetrievePrivacyDeviceMappings();
    Long privacyDeviceMappingCounts = 0L;
    Map<String, List<PrivacyDeviceMappingBO>> privacyDeviceMappingsMap =
        new HashMap<String, List<PrivacyDeviceMappingBO>>();
    try {
      if (loadCacheFromDB) {
        cacheUtil.clearAllPrivacyDeviceMappings();
      }
      List<PrivacyDeviceMappingBO> prvDeviceMappinsList = cacheUtil.getAllPrivacyDeviceMappings();
      if (GenericAssister.isCollectionNotEmpty(prvDeviceMappinsList)) {
        for (PrivacyDeviceMappingBO prvDeviceMapBo : prvDeviceMappinsList) {
          if (null != prvDeviceMapBo) {

            /*
             * String privacyName =
             * StringAssister.isEmptyString(prvDeviceMapBo.getConsentPrivacyBo().getPrivacyName()) ?
             * null : prvDeviceMapBo.getConsentPrivacyBo().getPrivacyName().replaceAll("\\s", "");
             * String region = StringAssister.isEmptyString(prvDeviceMapBo.getRegion()) ? null :
             * prvDeviceMapBo.getRegion().replaceAll("\\s", ""); String consumerType =
             * StringAssister.isEmptyString(prvDeviceMapBo.getConsumerType()) ? null :
             * prvDeviceMapBo.getConsumerType().replaceAll("\\s", "");
             */

            String privacyName = prvDeviceMapBo.getConsentPrivacyBo().getPrivacyName();
            String region = prvDeviceMapBo.getRegion();
            String consumerType = prvDeviceMapBo.getConsumerType();

            String key = constructPrivacyDeviceMappingKey(privacyName, region, consumerType);
            List<PrivacyDeviceMappingBO> values = privacyDeviceMappingsMap.get(key);
            if (!GenericAssister.isCollectionNotEmpty(values)) {
              List<PrivacyDeviceMappingBO> privacyDeviceMappingsList = cacheUtil
                  .getPrivacyDeviceMapping(privacyName, region, consumerType, loadCacheFromDB);
              if (GenericAssister.isCollectionNotEmpty(privacyDeviceMappingsList)) {
                privacyDeviceMappingCounts++;
                privacyDeviceMappingsMap.put(key, privacyDeviceMappingsList);
              }
            }
          }

        }
        retrievePrivacyDeviceMappings.setPrivacyDeviceMappingsCount(privacyDeviceMappingCounts);
        retrievePrivacyDeviceMappings.setPrivacyDeviceMappingsMap(privacyDeviceMappingsMap);
      }

      retrievePrivacyDeviceMappings.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrievePrivacyDeviceMappings.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());

    } catch (Exception e) {
      LoggerBuilder.printError(log,
          logger -> logger.methodName("retrieveAllPrivacyDeviceMappingsCache").exception(e));
      privacyDeviceMappingCounts = (long) 0;
      retrievePrivacyDeviceMappings.setPrivacyDeviceMappingsCount(privacyDeviceMappingCounts);
      retrievePrivacyDeviceMappings.setPrivacyDeviceMappingsMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrievePrivacyDeviceMappings);

    }
    return retrievePrivacyDeviceMappings;

  }

  private String constructPrivacyDeviceMappingKey(String privacyName, String region,
      String consumerType) {
    return String.format("(%s,%s,%s)", privacyName, region, consumerType);
  }

  @LogAround
  public RetrieveCountriesInfo retrieveCountryCodeCache(String countryCode,
      boolean loadCountryCacheFromDB) {
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName("retrieveCountryCodeCache").countryCode(countryCode));

    if (loadCountryCacheFromDB) {
      cacheUtil.clearCountryCode(countryCode);
    }

    CountryCodeBO countryCBO = new CountryCodeBO();
    RetrieveCountriesInfo retrieveCountryCodes = new RetrieveCountriesInfo();
    Long countryCodeCounts = null;
    List<CountryCodeBO> countryCodeBOList = cacheUtil.retrieveAllCountryCodes();
    List<CountryCodeBO> countryCodeCacheList = new ArrayList<CountryCodeBO>();
    if (countryCodeBOList != null && !countryCodeBOList.isEmpty()) {
      for (CountryCodeBO cntryCBO : countryCodeBOList) {
        if (cntryCBO != null) {
          countryCBO = cacheUtil.retrieveIso3CodeCountry(cntryCBO.getIso3CodeCountry(),
              loadCountryCacheFromDB);
          if (countryCBO != null) {
            countryCodeCacheList.add(countryCBO);
          }
        }
      }
    }
    countryCodeCounts = (long) countryCodeCacheList.size();
    if (countryCodeCounts != null) {
      retrieveCountryCodes.setCountryCounts(countryCodeCounts);
    }
    CountryCodeBO countryCodeBO =
        cacheUtil.retrieveIso3CodeCountry(countryCode.toUpperCase(), loadCountryCacheFromDB);
    List<RetrieveCountry> retrieveCountryList = new ArrayList<RetrieveCountry>();
    if (countryCodeBO != null) {
      RetrieveCountry retrieveCountry = new RetrieveCountry();
      retrieveCountry.setCountryName(countryCodeBO.getCountryName());
      retrieveCountry.setIso2CodeCountry(countryCodeBO.getIso2CodeCountry());
      retrieveCountry.setIso3CodeCountry(countryCodeBO.getIso3CodeCountry());
      retrieveCountry.setRegion(countryCodeBO.getRegion());
      retrieveCountryList.add(retrieveCountry);
    }
    retrieveCountryCodes.setRetrieveCountryList(retrieveCountryList);
    retrieveCountryCodes.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrieveCountryCodes.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrieveCountryCodes;
  }

  @LogAround
  public RetrieveCountriesInfo retrieveAllCountryCodes(boolean loadCountryCacheFromDB) {

    LoggerBuilder.printDebug(log, logger -> logger.methodName("retrieveAllCountryCodes"));

    if (loadCountryCacheFromDB) {
      cacheUtil.clearAllCountryCodes();
    }

    RetrieveCountriesInfo retrieveCountryCodes = new RetrieveCountriesInfo();
    List<RetrieveCountry> retrieveCountryList = new ArrayList<RetrieveCountry>();
    Long countryCodeCounts = null;
    CountryCodeBO countryCodeBO = new CountryCodeBO();
    List<CountryCodeBO> countryCodeBOList = new ArrayList<CountryCodeBO>();
    List<CountryCodeBO> countryCodeCacheList = new ArrayList<CountryCodeBO>();
    try {
      countryCodeBOList = cacheUtil.retrieveAllCountryCodes();
      if ((countryCodeBOList != null) && !(countryCodeBOList.isEmpty())) {
        for (CountryCodeBO countryCBO : countryCodeBOList) {
          if (countryCBO != null) {
            countryCodeBO = cacheUtil.retrieveIso3CodeCountry(countryCBO.getIso3CodeCountry(),
                loadCountryCacheFromDB);
            if (countryCodeBO != null) {
              countryCodeCacheList.add(countryCodeBO);
              RetrieveCountry retrieveCountry = new RetrieveCountry();
              retrieveCountry.setCountryName(countryCodeBO.getCountryName());
              retrieveCountry.setIso2CodeCountry(countryCodeBO.getIso2CodeCountry());
              retrieveCountry.setIso3CodeCountry(countryCodeBO.getIso3CodeCountry());
              retrieveCountry.setRegion(countryCodeBO.getRegion());
              retrieveCountryList.add(retrieveCountry);
            }
          }
        }
        countryCodeCounts = (long) countryCodeCacheList.size();
        retrieveCountryCodes.setCountryCounts(countryCodeCounts);
        retrieveCountryCodes.setRetrieveCountryList(retrieveCountryList);
      }
    } catch (Exception e) {
      retrieveCountryList = null;
      countryCodeCounts = (long) 0;
      retrieveCountryCodes.setCountryCounts(countryCodeCounts);
      retrieveCountryCodes.setRetrieveCountryList(retrieveCountryList);
    }
    retrieveCountryCodes.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrieveCountryCodes.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrieveCountryCodes;
  }

  @LogAround
  public RetrieveCountryLangCodes retrieveCountryLangCache(String preferredLanguage,
      boolean loadCountryLangCacheFromDB) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("retrieveCountryLangCache")
        .preferredLanguage(preferredLanguage));

    if (loadCountryLangCacheFromDB) {
      cacheUtil.clearCountryLang(preferredLanguage);
    }

    RetrieveCountryLangCodes retrieveCountryLangCodes = new RetrieveCountryLangCodes();
    Long countryLangCounts = null;
    CountryLangBO cntryLgBO = new CountryLangBO();
    List<CountryLangBO> countryLangBOList = cacheUtil.retrieveAllCountryLangs();
    List<CountryLangBO> countryLangCacheList = new ArrayList<CountryLangBO>();
    if (countryLangBOList != null && !countryLangBOList.isEmpty()) {
      for (CountryLangBO clBO : countryLangBOList) {
        if (clBO != null) {
          cntryLgBO = cacheUtil.retrieveCountryLangByPreferredLanguage(clBO.getPreferredLanguage(),
              loadCountryLangCacheFromDB);
          if (cntryLgBO != null) {
            countryLangCacheList.add(cntryLgBO);
          }
        }
      }
    }
    countryLangCounts = (long) countryLangCacheList.size();
    if (countryLangCounts != null) {
      retrieveCountryLangCodes.setCountryLangCount(countryLangCounts);
    }
    Map<String, String> countryLangMap = new HashMap<String, String>();
    CountryLangBO countryLangBO = cacheUtil
        .retrieveCountryLangByPreferredLanguage(preferredLanguage, loadCountryLangCacheFromDB);
    if (countryLangBO != null) {
      countryLangMap.put(countryLangBO.getPreferredLanguage(),
          countryLangBO.getPreferredLanguageName());
      retrieveCountryLangCodes.setCountryLangMap(countryLangMap);
    }
    retrieveCountryLangCodes.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrieveCountryLangCodes.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrieveCountryLangCodes;
  }

  @LogAround
  public RetrieveCountryLangCodes retrieveAllCountryLangs(boolean loadCountryLangCacheFromDB) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("retrieveAllCountryLangs"));

    if (loadCountryLangCacheFromDB) {
      cacheUtil.clearAllCountryLangs();
    }

    RetrieveCountryLangCodes retrieveCountryLangCodes = new RetrieveCountryLangCodes();
    Long countryLangCounts = null;
    CountryLangBO cntryLgBO = new CountryLangBO();
    List<CountryLangBO> countryLangBOList = new ArrayList<CountryLangBO>();
    List<CountryLangBO> countryLangCacheList = new ArrayList<CountryLangBO>();
    Map<String, String> countryLangMap = new HashMap<String, String>();
    try {
      countryLangBOList = cacheUtil.retrieveAllCountryLangs();
      if (countryLangBOList != null && !(countryLangBOList.isEmpty())) {
        for (CountryLangBO clBO : countryLangBOList) {
          if (clBO != null) {
            cntryLgBO = cacheUtil.retrieveCountryLangByPreferredLanguage(
                clBO.getPreferredLanguage(), loadCountryLangCacheFromDB);
            if (cntryLgBO != null) {
              countryLangCacheList.add(cntryLgBO);
              countryLangMap.put(cntryLgBO.getPreferredLanguage(),
                  cntryLgBO.getPreferredLanguageName());
            }
          }
        }
        countryLangCounts = (long) countryLangCacheList.size();
        retrieveCountryLangCodes.setCountryLangCount(countryLangCounts);
        retrieveCountryLangCodes.setCountryLangMap(countryLangMap);
      }
    } catch (Exception e) {
      countryLangBOList = null;
      countryLangCounts = (long) 0;
      retrieveCountryLangCodes.setCountryLangCount(countryLangCounts);
      retrieveCountryLangCodes.setCountryLangMap(null);
    }
    retrieveCountryLangCodes.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrieveCountryLangCodes.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrieveCountryLangCodes;
  }

  @LogAround
  public RetrieveConsentPrivaciesInfo retrieveConsentPrivacyCacheByConsentId(Long consentId,
      boolean loadConsentPrivacyCacheFromDB) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("retrieveConsentPrivacyCache")
        .consentId(String.valueOf(consentId)));

    if (loadConsentPrivacyCacheFromDB) {
      cacheUtil.clearConsentPrivacyDtlsForConsentId(consentId);
    }

    RetrieveConsentPrivaciesInfo retrieveConsentPrivacies = new RetrieveConsentPrivaciesInfo();
    List<RetrieveConsentPrivacy> consentPrivaciesList = new ArrayList<>();
    Long consentPrivaciesCount = null;
    List<ConsentPrivacyBO> consentPrivacyBOList = new ArrayList<ConsentPrivacyBO>();
    ConsentPrivacyBO consentPrivacyBO = new ConsentPrivacyBO();
    List<ConsentPrivacyBO> consentPrivacyBOCacheList = new ArrayList<ConsentPrivacyBO>();
    // Get all consent privacies

    try {
      consentPrivacyBOList = cacheUtil.retrieveAllConsentPrivacies();
      if (consentPrivacyBOList != null && !consentPrivacyBOList.isEmpty()) {
        // loop it and retrieve from cache or db based on boolean variable and add it to cache list
        for (ConsentPrivacyBO consentPrvyBO : consentPrivacyBOList) {
          if (consentPrvyBO != null) {
            consentPrivacyBO = cacheUtil.retrieveConsentPrivacyByConsentId(
                consentPrvyBO.getConsentId(), loadConsentPrivacyCacheFromDB);
            if (consentPrivacyBO != null) {
              consentPrivacyBOCacheList.add(consentPrivacyBO);
            }
          }
        }
      }

      consentPrivaciesCount = (long) consentPrivacyBOCacheList.size();
      if (consentPrivaciesCount != null) {
        retrieveConsentPrivacies.setConsentPrivacyCounts(consentPrivaciesCount);
      }

      ConsentPrivacyBO consentPrcyBO =
          cacheUtil.retrieveConsentPrivacyByConsentId(consentId, loadConsentPrivacyCacheFromDB);
      RetrieveConsentPrivacy retrieveConsentPrivacy = new RetrieveConsentPrivacy();
      if (consentPrcyBO != null) {
        retrieveConsentPrivacy.setConsentId(consentPrcyBO.getConsentId());
        retrieveConsentPrivacy.setConsentSystemName(consentPrcyBO.getConsentSystemName());
        retrieveConsentPrivacy.setPouKey(consentPrcyBO.getPouKey());
        retrieveConsentPrivacy.setPrivacyCategory(consentPrcyBO.getPrivacyCategory());
        retrieveConsentPrivacy.setPrivacyDescription(consentPrcyBO.getPrivacyDescription());
        retrieveConsentPrivacy.setPrivacyName(consentPrcyBO.getPrivacyName());
        retrieveConsentPrivacy.setPrivacyType(consentPrcyBO.getPrivacyType());
      }
      consentPrivaciesList.add(retrieveConsentPrivacy);
      retrieveConsentPrivacies.setConsentPrivaciesList(consentPrivaciesList);

    }

    catch (Exception e) {
      consentPrivaciesCount = (long) 0;
      retrieveConsentPrivacies.setConsentPrivacyCounts(consentPrivaciesCount);
      retrieveConsentPrivacies.setConsentPrivaciesList(consentPrivaciesList);

    }

    retrieveConsentPrivacies.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrieveConsentPrivacies.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());

    return retrieveConsentPrivacies;
  }

  @LogAround
  public RetrieveConsentPrivaciesInfo retrieveAllConsentPrivacyDtlsByConsentId(
      boolean loadConsentPrivacyCacheFromDB) {
    LoggerBuilder.printDebug(log, logger -> logger.methodName("retrieveAllConsentPrivacies"));

    if (loadConsentPrivacyCacheFromDB) {
      cacheUtil.clearAllConsentPrivacyDtlsForConsentId();
    }

    RetrieveConsentPrivaciesInfo retrieveConsentPrivacies = new RetrieveConsentPrivaciesInfo();
    List<RetrieveConsentPrivacy> consentPrivaciesList = new ArrayList<>();
    Long consentPrivaciesCount = null;
    List<ConsentPrivacyBO> consentPrivacyBOList = new ArrayList<ConsentPrivacyBO>();
    ConsentPrivacyBO consentPrivacyBO = new ConsentPrivacyBO();
    List<ConsentPrivacyBO> consentPrivacyBOCacheList = new ArrayList<ConsentPrivacyBO>();
    // Get all consent privacies

    try {
      consentPrivacyBOList = cacheUtil.retrieveAllConsentPrivacies();
      if (consentPrivacyBOList != null && !consentPrivacyBOList.isEmpty()) {
        // loop it and retrieve from cache or db based on boolean variable and add it to cache list
        for (ConsentPrivacyBO consentPrvyBO : consentPrivacyBOList) {
          if (consentPrvyBO != null) {
            consentPrivacyBO = cacheUtil.retrieveConsentPrivacyByConsentId(
                consentPrvyBO.getConsentId(), loadConsentPrivacyCacheFromDB);
            if (consentPrivacyBO != null) {
              consentPrivacyBOCacheList.add(consentPrivacyBO);
              // set the values to response object
              RetrieveConsentPrivacy retrieveConsentPrivacy = new RetrieveConsentPrivacy();
              retrieveConsentPrivacy.setConsentId(consentPrivacyBO.getConsentId());
              retrieveConsentPrivacy.setConsentSystemName(consentPrivacyBO.getConsentSystemName());
              retrieveConsentPrivacy.setPouKey(consentPrivacyBO.getPouKey());
              retrieveConsentPrivacy.setPrivacyCategory(consentPrivacyBO.getPrivacyCategory());
              retrieveConsentPrivacy
                  .setPrivacyDescription(consentPrivacyBO.getPrivacyDescription());
              retrieveConsentPrivacy.setPrivacyName(consentPrivacyBO.getPrivacyName());
              retrieveConsentPrivacy.setPrivacyType(consentPrivacyBO.getPrivacyType());
              consentPrivaciesList.add(retrieveConsentPrivacy);
            }
          }
        }
        // set the count to size of cache list
        consentPrivaciesCount = (long) consentPrivacyBOCacheList.size();
        retrieveConsentPrivacies.setConsentPrivacyCounts(consentPrivaciesCount);
        retrieveConsentPrivacies.setConsentPrivaciesList(consentPrivaciesList);
      }

    } catch (Exception e) {
      consentPrivacyBOList = null;
      consentPrivaciesCount = (long) 0;
      retrieveConsentPrivacies.setConsentPrivacyCounts(consentPrivaciesCount);
      retrieveConsentPrivacies.setConsentPrivaciesList(consentPrivaciesList);
    }
    retrieveConsentPrivacies.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrieveConsentPrivacies.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrieveConsentPrivacies;
  }

  @LogAround
  public RetrieveSuppressionTermResponse retrieveSuppressionTermWithConsentIdAndCountry(
      Long consentId, String cntryCd, boolean loadSuppressionTermCacheFromDb) {
    String methodName = "retrieveSuppressionTermWithConsentIdAndCountry";

    RetrieveSuppressionTermResponse retrievedSuppressionTerms =
        new RetrieveSuppressionTermResponse();
    List<SuppressionTermBO> suppressionTermBOCacheList = new ArrayList<>();
    List<SuppressionTermBO> suppressionTermBOList = new ArrayList<>();
    Long suppressionTermsCount = null;
    try {
      if (loadSuppressionTermCacheFromDb) {
        cacheUtil.clearSuppressionTerm(consentId, cntryCd);
      }
      suppressionTermBOList = cacheUtil.getAllSuppressionTerms();
      if (GenericAssister.isCollectionNotEmpty(suppressionTermBOList)) {
        SuppressionTermBO suppressionTermBO = new SuppressionTermBO();
        for (SuppressionTermBO suppTermBo : suppressionTermBOList) {
          suppressionTermBO = cacheUtil.getSuppressionTermDtls(suppTermBo.getConsentId(),
              suppTermBo.getCountryCode(), loadSuppressionTermCacheFromDb);
          if (null != suppressionTermBO) {
            suppressionTermBOCacheList.add(suppressionTermBO);
          }
        }
      }
      suppressionTermsCount = Long.valueOf(suppressionTermBOCacheList.size());
      if (suppressionTermsCount != null) {
        retrievedSuppressionTerms.setSuppressionTermsCount(suppressionTermsCount);
      }
      Map<Long, Integer> suppressionTermsMap = new HashMap<>();
      SuppressionTermBO suppressionTermBOForGivenConsentId =
          cacheUtil.getSuppressionTermDtls(consentId, cntryCd);
      if (null != suppressionTermBOForGivenConsentId) {
        suppressionTermsMap.put(consentId, suppressionTermBOForGivenConsentId.getSuppressionTerm());
        retrievedSuppressionTerms.setSuppressionTermMap(suppressionTermsMap);
      } else {
        retrievedSuppressionTerms.setSuppressionTermMap(null);
      }
    } catch (Exception e) {
      suppressionTermsCount = 0L;
      retrievedSuppressionTerms.setSuppressionTermsCount(suppressionTermsCount);
      retrievedSuppressionTerms.setSuppressionTermMap(null);
    }
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .message("Retrieved Suppression Term Info For Consent ID: " + consentId));

    retrievedSuppressionTerms.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrievedSuppressionTerms.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrievedSuppressionTerms;
  }

  @LogAround
  public RetrieveAllSuppressionTermResponse retrieveAllSuppressionTerms(
      boolean loadSuppressionTermCacheFromDb) {
    String methodName = "retrieveAllSuppressionTerms";

    RetrieveAllSuppressionTermResponse retrievedSuppressionTerms =
        new RetrieveAllSuppressionTermResponse();
    Long suppressionTermCounts = null;
    Map<Long, List<CountryTermDTO>> suppressionTermMap = new HashMap<>();
    List<SuppressionTermBO> suppressionTermBOList = new ArrayList<>();
    SuppressionTermBO suppressionTermBO = new SuppressionTermBO();
    List<SuppressionTermBO> suppressionTermCacheList = new ArrayList<>();
    try {
      // Load from DB Logic
      if (loadSuppressionTermCacheFromDb) {
        cacheUtil.clearAllSuppressionTerms();
      }

      suppressionTermBOList = cacheUtil.getAllSuppressionTerms();
      if (suppressionTermBOList != null && !suppressionTermBOList.isEmpty()) {
        for (SuppressionTermBO suppressionTBO : suppressionTermBOList) {
          if (suppressionTBO != null) {

            suppressionTermBO = cacheUtil.getSuppressionTermDtls(suppressionTBO.getConsentId(),
                suppressionTBO.getCountryCode(), loadSuppressionTermCacheFromDb);

            if (null != suppressionTermBO) {
              suppressionTermCacheList.add(suppressionTermBO);

              // Same consentId can have different terms in different countries
              CountryTermDTO countryTermDto = new CountryTermDTO();
              countryTermDto.setCountryCode(suppressionTermBO.getCountryCode());
              countryTermDto.setTerm(suppressionTermBO.getSuppressionTerm());
              if (suppressionTermMap.containsKey(suppressionTermBO.getConsentId())) {
                suppressionTermMap.get(suppressionTermBO.getConsentId()).add(countryTermDto);
              } else {
                List<CountryTermDTO> countryTermList = new ArrayList<>();
                countryTermList.add(countryTermDto);
                suppressionTermMap.put(suppressionTermBO.getConsentId(), countryTermList);
              }
            }
          }
        }
        suppressionTermCounts = (long) suppressionTermCacheList.size();
        retrievedSuppressionTerms.setSuppressionTermsCount(suppressionTermCounts);
        retrievedSuppressionTerms.setSuppressionTermMap(suppressionTermMap);
      }
    } catch (Exception e) {
      suppressionTermBOList = null;
      suppressionTermCounts = (long) 0;
      retrievedSuppressionTerms.setSuppressionTermsCount(suppressionTermCounts);
      retrievedSuppressionTerms.setSuppressionTermMap(null);
    }
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .message("Retrieved All Suppression Term Info." + retrievedSuppressionTerms));
    retrievedSuppressionTerms.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrievedSuppressionTerms.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrievedSuppressionTerms;
  }

  @LogAround
  public RetrieveExpiryRuleResponse retrieveExpiryRulesWithConsentIdAndCountry(Long consentId,
      String cntryCd, boolean loadExpiryRulesCacheFromDb) {
    String methodName = "retrieveExpiryRulesWithConsentIdAndCountry";

    RetrieveExpiryRuleResponse retrievedExpiryRules = new RetrieveExpiryRuleResponse();
    List<ConsentPrivacyExpiryRuleBO> expiryRulesCacheList = new ArrayList<>();
    List<ConsentPrivacyExpiryRuleBO> expiryRulesBOList = new ArrayList<>();
    Long expiryRulesCount = null;
    try {
      if (loadExpiryRulesCacheFromDb) {
        cacheUtil.clearExpiryRule(consentId, cntryCd);
      }
      expiryRulesBOList = cacheUtil.getAllExpiryRules();
      if (GenericAssister.isCollectionNotEmpty(expiryRulesBOList)) {
        ConsentPrivacyExpiryRuleBO expiryRuleBo = new ConsentPrivacyExpiryRuleBO();
        for (ConsentPrivacyExpiryRuleBO expRuleBo : expiryRulesBOList) {
          expiryRuleBo = cacheUtil.getConsentExpirationDtls(expRuleBo.getConsentId(),
              expRuleBo.getCountryCode(), loadExpiryRulesCacheFromDb);
          if (null != expiryRuleBo) {
            expiryRulesCacheList.add(expiryRuleBo);
          }
        }
      }
      expiryRulesCount = Long.valueOf(expiryRulesCacheList.size());
      if (expiryRulesCount != null) {
        retrievedExpiryRules.setExpiryRulesCount(expiryRulesCount);
      }
      Map<Long, Integer> expiryRulesMap = new HashMap<>();
      ConsentPrivacyExpiryRuleBO expiryRuleBOForGivenConsentId =
          cacheUtil.getConsentExpirationDtls(consentId, cntryCd);
      if (null != expiryRuleBOForGivenConsentId) {
        expiryRulesMap.put(consentId, expiryRuleBOForGivenConsentId.getExpiryTerm());
        retrievedExpiryRules.setExpiryRulesMap(expiryRulesMap);
      } else {
        retrievedExpiryRules.setExpiryRulesMap(null);
      }
    } catch (Exception e) {
      expiryRulesCount = 0L;
      retrievedExpiryRules.setExpiryRulesCount(expiryRulesCount);
      retrievedExpiryRules.setExpiryRulesMap(null);
    }
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .message("Retrieved Expiry Rules Info For Consent ID: " + consentId));

    retrievedExpiryRules.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrievedExpiryRules.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrievedExpiryRules;
  }

  @LogAround
  public RetrieveAllExpiryRuleResponse retrieveAllExpiryRules(boolean loadExpiryRulesCacheFromDb) {
    String methodName = "retrieveAllSuppressionTerms";

    RetrieveAllExpiryRuleResponse retrievedExpiryRules = new RetrieveAllExpiryRuleResponse();
    Long expiryRuleCounts = null;
    Map<Long, List<CountryTermDTO>> expiryRuleMap = new HashMap<>();
    List<ConsentPrivacyExpiryRuleBO> expiryRulesBOList = new ArrayList<>();
    ConsentPrivacyExpiryRuleBO expiryRuleBO = new ConsentPrivacyExpiryRuleBO();
    List<ConsentPrivacyExpiryRuleBO> expiryRulesCacheList = new ArrayList<>();
    try {
      // Load from DB Logic
      if (loadExpiryRulesCacheFromDb) {
        cacheUtil.clearAllExpiryRules();
      }

      expiryRulesBOList = cacheUtil.getAllExpiryRules();
      if (expiryRulesBOList != null && !expiryRulesBOList.isEmpty()) {
        for (ConsentPrivacyExpiryRuleBO expiryRBO : expiryRulesBOList) {
          if (expiryRBO != null) {

            expiryRuleBO = cacheUtil.getConsentExpirationDtls(expiryRBO.getConsentId(),
                expiryRBO.getCountryCode(), loadExpiryRulesCacheFromDb);
            if (expiryRuleBO != null) {

              // Same consentId can have different terms in different countries
              CountryTermDTO countryTermDto = new CountryTermDTO();
              countryTermDto.setCountryCode(expiryRuleBO.getCountryCode());
              countryTermDto.setTerm(expiryRuleBO.getExpiryTerm());
              if (expiryRuleMap.containsKey(expiryRuleBO.getConsentId())) {
                expiryRuleMap.get(expiryRuleBO.getConsentId()).add(countryTermDto);
              } else {
                List<CountryTermDTO> countryTermDtoList = new ArrayList<>();
                countryTermDtoList.add(countryTermDto);
                expiryRuleMap.put(expiryRuleBO.getConsentId(), countryTermDtoList);
              }

            }
          }
        }
        expiryRuleCounts = (long) expiryRulesCacheList.size();
        retrievedExpiryRules.setExpiryRulesCount(expiryRuleCounts);
        retrievedExpiryRules.setExpiryRulesMap(expiryRuleMap);
      }
    } catch (Exception e) {
      expiryRulesBOList = null;
      expiryRuleCounts = (long) 0;
      retrievedExpiryRules.setExpiryRulesCount(expiryRuleCounts);
      retrievedExpiryRules.setExpiryRulesMap(null);
    }

    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .message("Retrieved All Expiry Rule Info." + retrievedExpiryRules));
    retrievedExpiryRules.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrievedExpiryRules.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrievedExpiryRules;
  }

  @LogAround
  public ConsentPrivacyByNameResponse retrieveConsentPrivaciesWithConsentName(String consentName,
      boolean loadConsentPrivaciesCacheFromDb) {
    String methodName = "retrieveConsentPrivaciesWithConsentName";

    ConsentPrivacyByNameResponse retrievedConsentPrivacies = new ConsentPrivacyByNameResponse();
    List<ConsentPrivacyBO> consentPrivaciesCacheList = new ArrayList<>();
    List<ConsentPrivacyBO> consentPrivaciesBOList = new ArrayList<>();
    Long consentPrivaciesCount = null;
    try {
      if (loadConsentPrivaciesCacheFromDb) {
        cacheUtil.clearConsentPrivacyDtlsForName(consentName);
      }
      consentPrivaciesBOList = cacheUtil.retrieveAllConsentPrivacies();
      if (GenericAssister.isCollectionNotEmpty(consentPrivaciesBOList)) {
        ConsentPrivacyBO consentPrivacyBo = null;
        for (ConsentPrivacyBO consentPBo : consentPrivaciesBOList) {
          if (consentPBo != null && StringAssister.isNotEmptyString(consentPBo.getPrivacyName())) {
            consentPrivacyBo = cacheUtil.getConsentPrivacyDtlsForName(consentPBo.getPrivacyName(),
                loadConsentPrivaciesCacheFromDb);
            if (null != consentPrivacyBo) {
              consentPrivaciesCacheList.add(consentPrivacyBo);
            }
          }
        }
      }
      consentPrivaciesCount = Long.valueOf(consentPrivaciesCacheList.size());
      if (consentPrivaciesCount != null) {
        retrievedConsentPrivacies.setConsentPrivaciesCount(consentPrivaciesCount);
      }
      Map<String, ConsentPrivacyDTO> consentPrivaciesMap = new HashMap<>();
      ConsentPrivacyBO consentPrivacyBOForGivenConsentName =
          cacheUtil.getConsentPrivacyDtlsForName(consentName, loadConsentPrivaciesCacheFromDb);
      if (null != consentPrivacyBOForGivenConsentName) {

        ConsentPrivacyDTO privacyBo = new ConsentPrivacyDTO();
        BeanUtils.copyProperties(consentPrivacyBOForGivenConsentName, privacyBo);
        consentPrivaciesMap.put(consentName, privacyBo);
        retrievedConsentPrivacies.setConsentPrivaciesMap(consentPrivaciesMap);
      } else {
        retrievedConsentPrivacies.setConsentPrivaciesMap(null);
      }
    } catch (Exception e) {
      consentPrivaciesCount = 0L;
      retrievedConsentPrivacies.setConsentPrivaciesCount(consentPrivaciesCount);
      retrievedConsentPrivacies.setConsentPrivaciesMap(null);
    }
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .message("Retrieved Consent Privacy Info For Consent Name: " + consentName));

    retrievedConsentPrivacies.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrievedConsentPrivacies.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrievedConsentPrivacies;
  }

  @LogAround
  public ConsentPrivacyByNameResponse retrieveAllConsentPrivaciesWithConsentName(
      boolean loadConsentPrivaciesCacheFromDb) {
    String methodName = "retrieveAllConsentPrivaciesWithConsentName";

    ConsentPrivacyByNameResponse retrievedconsentPrivacies = new ConsentPrivacyByNameResponse();
    Long consentPrivaciesCounts = null;
    Map<String, ConsentPrivacyDTO> consentPrivacyMap = new HashMap<>();
    List<ConsentPrivacyBO> consentPrivacyBOList = new ArrayList<>();
    ConsentPrivacyBO consentPrivacyBO = null;
    List<ConsentPrivacyBO> consentPrivacyCacheList = new ArrayList<>();
    try {
      // Load from DB Logic
      if (loadConsentPrivaciesCacheFromDb) {
        cacheUtil.clearAllConsentPrivacyDtlsForName();
      }

      consentPrivacyBOList = cacheUtil.retrieveAllConsentPrivacies();
      if (consentPrivacyBOList != null && !consentPrivacyBOList.isEmpty()) {
        for (ConsentPrivacyBO consentPBO : consentPrivacyBOList) {
          if (consentPBO != null && StringAssister.isNotEmptyString(consentPBO.getPrivacyName())) {
            consentPrivacyBO = cacheUtil.getConsentPrivacyDtlsForName(consentPBO.getPrivacyName(),
                loadConsentPrivaciesCacheFromDb);
            if (consentPrivacyBO != null) {
              consentPrivacyCacheList.add(consentPrivacyBO);
              ConsentPrivacyDTO privacyBo = new ConsentPrivacyDTO();
              BeanUtils.copyProperties(consentPrivacyBO, privacyBo);
              consentPrivacyMap.put(consentPrivacyBO.getPrivacyName(), privacyBo);
            }
          }
        }
        consentPrivaciesCounts = (long) consentPrivacyCacheList.size();
        retrievedconsentPrivacies.setConsentPrivaciesCount(consentPrivaciesCounts);
        retrievedconsentPrivacies.setConsentPrivaciesMap(consentPrivacyMap);
      }
    } catch (Exception e) {
      consentPrivacyBOList = null;
      consentPrivaciesCounts = (long) 0;
      retrievedconsentPrivacies.setConsentPrivaciesCount(consentPrivaciesCounts);
      retrievedconsentPrivacies.setConsentPrivaciesMap(null);
    }
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .message("Retrieved All Consent Privaciy Info." + retrievedconsentPrivacies));
    retrievedconsentPrivacies.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrievedconsentPrivacies.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrievedconsentPrivacies;
  }

  @LogAround
  public ConsentPrivacyByPouKeyResponse retrieveConsentPrivaciesWithPouKey(Long pouKey,
      boolean loadConsentPrivaciesCacheFromDb) {
    String methodName = "retrieveConsentPrivaciesWithPouKey";

    ConsentPrivacyByPouKeyResponse retrievedConsentPrivacies = new ConsentPrivacyByPouKeyResponse();
    List<ConsentPrivacyBO> consentPrivaciesCacheList = new ArrayList<>();
    List<ConsentPrivacyBO> consentPrivaciesBOList = new ArrayList<>();
    Long consentPrivaciesCount = null;
    try {
      if (loadConsentPrivaciesCacheFromDb) {
        cacheUtil.clearConsentPrivacyDtlsForPouKey(pouKey);
      }
      consentPrivaciesBOList = cacheUtil.retrieveAllConsentPrivacies();
      if (GenericAssister.isCollectionNotEmpty(consentPrivaciesBOList)) {
        ConsentPrivacyBO consentPrivacyBo = new ConsentPrivacyBO();
        for (ConsentPrivacyBO consentPBo : consentPrivaciesBOList) {

          if (null != consentPBo.getPouKey()) {
            consentPrivacyBo = cacheUtil.getConsentPrivacyDtlsForPouKey(consentPBo.getPouKey(),
                loadConsentPrivaciesCacheFromDb);
            if (null != consentPrivacyBo) {
              consentPrivaciesCacheList.add(consentPrivacyBo);
            }
          }

        }
      }
      consentPrivaciesCount = Long.valueOf(consentPrivaciesCacheList.size());
      if (consentPrivaciesCount != null) {
        retrievedConsentPrivacies.setConsentPrivaciesCount(consentPrivaciesCount);
      }
      Map<Long, ConsentPrivacyDTO> consentPrivaciesMap = new HashMap<>();
      ConsentPrivacyBO consentPrivacyBOForGivenPouKey =
          cacheUtil.getConsentPrivacyDtlsForPouKey(pouKey, loadConsentPrivaciesCacheFromDb);
      if (null != consentPrivacyBOForGivenPouKey) {

        ConsentPrivacyDTO privacyBo = new ConsentPrivacyDTO();
        BeanUtils.copyProperties(consentPrivacyBOForGivenPouKey, privacyBo);
        consentPrivaciesMap.put(pouKey, privacyBo);
        retrievedConsentPrivacies.setConsentPrivaciesMap(consentPrivaciesMap);
      } else {
        retrievedConsentPrivacies.setConsentPrivaciesMap(null);
      }
    } catch (Exception e) {
      consentPrivaciesCount = 0L;
      retrievedConsentPrivacies.setConsentPrivaciesCount(consentPrivaciesCount);
      retrievedConsentPrivacies.setConsentPrivaciesMap(null);
    }
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .message("Retrieved Consent Privacy Info For Consent Name: " + pouKey));

    retrievedConsentPrivacies.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrievedConsentPrivacies.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrievedConsentPrivacies;
  }

  @LogAround
  public ConsentPrivacyByPouKeyResponse retrieveAllConsentPrivaciesWithPouKey(
      boolean loadConsentPrivaciesCacheFromDb) {
    String methodName = "retrieveAllConsentPrivaciesWithPouKey";

    ConsentPrivacyByPouKeyResponse retrievedconsentPrivacies = new ConsentPrivacyByPouKeyResponse();
    Long consentPrivaciesCounts = null;
    Map<Long, ConsentPrivacyDTO> consentPrivacyMap = new HashMap<>();
    List<ConsentPrivacyBO> consentPrivacyBOList = new ArrayList<>();
    ConsentPrivacyBO consentPrivacyBO = new ConsentPrivacyBO();
    List<ConsentPrivacyBO> consentPrivacyCacheList = new ArrayList<>();
    try {
      // Load from DB Logic
      if (loadConsentPrivaciesCacheFromDb) {
        cacheUtil.clearAllConsentPrivacyDtlsForPouKey();
      }

      consentPrivacyBOList = cacheUtil.retrieveAllConsentPrivacies();
      System.out.println("Size: " + consentPrivacyBOList.size());
      if (consentPrivacyBOList != null && !consentPrivacyBOList.isEmpty()) {
        for (ConsentPrivacyBO consentPBO : consentPrivacyBOList) {
          if (consentPBO != null) {

            // Disregarding records with null pouKey
            if (null != consentPBO.getPouKey()) {
              consentPrivacyBO = cacheUtil.getConsentPrivacyDtlsForPouKey(consentPBO.getPouKey(),
                  loadConsentPrivaciesCacheFromDb);
              if (consentPrivacyBO != null) {
                consentPrivacyCacheList.add(consentPrivacyBO);

                ConsentPrivacyDTO privacyBo = new ConsentPrivacyDTO();
                BeanUtils.copyProperties(consentPrivacyBO, privacyBo);
                consentPrivacyMap.put(consentPrivacyBO.getPouKey(), privacyBo);
              }
            }

          }
        }
        consentPrivaciesCounts = (long) consentPrivacyCacheList.size();
        retrievedconsentPrivacies.setConsentPrivaciesCount(consentPrivaciesCounts);
        retrievedconsentPrivacies.setConsentPrivaciesMap(consentPrivacyMap);
      }
    } catch (Exception e) {
      consentPrivacyBOList = null;
      consentPrivaciesCounts = (long) 0;
      retrievedconsentPrivacies.setConsentPrivaciesCount(consentPrivaciesCounts);
      retrievedconsentPrivacies.setConsentPrivaciesMap(null);
    }
    LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
        .message("Retrieved All Consent Privaciy Info." + retrievedconsentPrivacies));
    retrievedconsentPrivacies.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
    retrievedconsentPrivacies.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    return retrievedconsentPrivacies;
  }

  @LogAround
  public RetrieveDeviceTypes retrieveDeviceTypeCacheByName(String deviceType, boolean loadFromDB) {

    String methodName = "retrieveDeviceTypeCacheByName";
    Long deviceTypeCount = 0L;
    RetrieveDeviceTypes retrieveDeviceTypes = new RetrieveDeviceTypes();
    Map<String, DeviceTypeBO> deviceTypeMap = new HashMap<>();
    DeviceTypeBO deviceTypeBO = null;
    try {

      if (loadFromDB) {
        cacheUtil.clearDeviceType(deviceType);
      }

      deviceTypeBO = cacheUtil.getDeviceTypeDtls(deviceType, loadFromDB);

      if (deviceTypeBO != null) {
        deviceTypeCount = 1L;
        deviceTypeMap.put(deviceTypeBO.getDeviceType(), deviceTypeBO);
      }
      retrieveDeviceTypes.setDeviceTypesCount(deviceTypeCount);
      retrieveDeviceTypes.setDeviceTypesMap(deviceTypeMap);
      retrieveDeviceTypes.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveDeviceTypes.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      deviceTypeCount = (long) 0;
      retrieveDeviceTypes.setDeviceTypesCount(deviceTypeCount);
      retrieveDeviceTypes.setDeviceTypesMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveDeviceTypes);

    }
    return retrieveDeviceTypes;
  }

  @LogAround
  public RetrieveDeviceTypes retrieveAllDeviceTypesCacheForName(boolean loadFromDB) {

    String methodName = "retrieveAllDeviceTypesCacheByName";
    Long deviceTypeCount = 0L;
    RetrieveDeviceTypes retrieveDeviceTypes = new RetrieveDeviceTypes();
    Map<String, DeviceTypeBO> deviceTypeMap = new HashMap<>();
    List<DeviceTypeBO> deviceTypeBOList = null;
    try {
      if (loadFromDB) {
        cacheUtil.clearAllDeviceTypes();
      }
      deviceTypeBOList = cacheUtil.getAllDeviceTypeDtls();
      if (null != deviceTypeBOList && deviceTypeBOList.size() > 0) {
        deviceTypeCount = (long) deviceTypeBOList.size();
        deviceTypeBOList.parallelStream().forEach(deviceTypeBO -> {
          DeviceTypeBO deviceTypeBo =
              cacheUtil.getDeviceTypeDtls(deviceTypeBO.getDeviceType(), loadFromDB);
          if (null != deviceTypeBo) {
            deviceTypeMap.put(deviceTypeBO.getDeviceType(), deviceTypeBO);
          }
        });
      }
      retrieveDeviceTypes.setDeviceTypesCount(deviceTypeCount);
      retrieveDeviceTypes.setDeviceTypesMap(deviceTypeMap);
      retrieveDeviceTypes.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveDeviceTypes.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      deviceTypeCount = (long) 0;
      retrieveDeviceTypes.setDeviceTypesCount(deviceTypeCount);
      retrieveDeviceTypes.setDeviceTypesMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveDeviceTypes);

    }
    return retrieveDeviceTypes;
  }

  @LogAround
  public RetrieveDeviceTypeIds retrieveDeviceTypeCacheById(Long deviceTypeId, boolean loadFromDB) {

    String methodName = "retrieveDeviceTypeCacheById";
    Long deviceTypeCount = 0L;
    RetrieveDeviceTypeIds retrieveDeviceTypeIds = new RetrieveDeviceTypeIds();
    Map<Long, String> deviceTypeMap = new HashMap<>();
    String deviceType = null;
    try {

      if (loadFromDB) {
        cacheUtil.clearDeviceTypeById(deviceTypeId);
      }

      deviceType = cacheUtil.getDeviceTypeById(deviceTypeId, loadFromDB);

      if (null != deviceType) {
        deviceTypeCount = 1L;
        deviceTypeMap.put(deviceTypeId, deviceType);
      }
      retrieveDeviceTypeIds.setDeviceTypeIdsCount(deviceTypeCount);
      retrieveDeviceTypeIds.setDeviceTypesMap(deviceTypeMap);
      retrieveDeviceTypeIds.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveDeviceTypeIds.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      deviceTypeCount = (long) 0;
      retrieveDeviceTypeIds.setDeviceTypeIdsCount(deviceTypeCount);
      retrieveDeviceTypeIds.setDeviceTypesMap(null);
      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveDeviceTypeIds);

    }
    return retrieveDeviceTypeIds;
  }

  @LogAround
  public RetrieveDeviceTypeIds retrieveAllDeviceTypesCacheForId(boolean loadFromDB) {

    String methodName = "retrieveAllDeviceTypesCacheForId";
    Long deviceTypeCount = 0L;
    RetrieveDeviceTypeIds retrieveDeviceTypeIds = new RetrieveDeviceTypeIds();
    Map<Long, String> deviceTypeMap = new HashMap<>();
    List<DeviceTypeBO> deviceTypeBOList = null;
    try {

      if (loadFromDB) {
        cacheUtil.clearAllDeviceTypesById();
      }

      deviceTypeBOList = cacheUtil.getAllDeviceTypeDtls();

      if (null != deviceTypeBOList && deviceTypeBOList.size() > 0) {
        deviceTypeCount = (long) deviceTypeBOList.size();
        // retrieveDeviceTypeIds.setDeviceTypeIdsCount(deviceTypeCount);
        deviceTypeBOList.parallelStream().forEach(deviceTypeBO -> {
          String deviceType =
              cacheUtil.getDeviceTypeById(deviceTypeBO.getDeviceTypeId(), loadFromDB);
          if (null != deviceType) {
            deviceTypeMap.put(deviceTypeBO.getDeviceTypeId(), deviceType);
          }
        });
        // retrieveDeviceTypeIds.setDeviceTypesMap(deviceTypeMap);
      }
      retrieveDeviceTypeIds.setDeviceTypeIdsCount(deviceTypeCount);
      retrieveDeviceTypeIds.setDeviceTypesMap(deviceTypeMap);
      retrieveDeviceTypeIds.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveDeviceTypeIds.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      deviceTypeCount = (long) 0;
      retrieveDeviceTypeIds.setDeviceTypeIdsCount(deviceTypeCount);
      retrieveDeviceTypeIds.setDeviceTypesMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveDeviceTypeIds);

    }
    return retrieveDeviceTypeIds;
  }

  @LogAround
  public RetrieveAppConsentRelation retrieveAppConsentRelationCache(Optional<Integer> appId,
      Optional<Long> consentId, boolean loadFromDB) {

    String methodName = "retrieveAppConsentRelationCache";
    Long appConsentRelationCount = 0L;
    RetrieveAppConsentRelation retrieveAppConsentRelation = new RetrieveAppConsentRelation();
    Map<Integer, List<AppConsentRelationBO>> appConsentRelationMap = null;
    List<AppConsentRelationBO> appConsentRelationDtlList = null;
    try {
      if (loadFromDB) {
        cacheUtil.clearAppConsentRelationDtls(appId.get(), consentId.get());
      }
      AppConsentRelationBO appConsentRelationBO =
          cacheUtil.getAppConsentRelationDtls(appId.get(), consentId.get(), loadFromDB);
      if (null != appConsentRelationBO) {
        appConsentRelationMap = new HashMap<>();
        appConsentRelationDtlList = new ArrayList<>();
        appConsentRelationDtlList.add(appConsentRelationBO);
        appConsentRelationCount = (long) 1;
        appConsentRelationMap.put(appId.get(), appConsentRelationDtlList);
      }

      retrieveAppConsentRelation.setAppConsentRelationCount(appConsentRelationCount);
      retrieveAppConsentRelation.setAppIdConsentRelationMap(appConsentRelationMap);
      retrieveAppConsentRelation.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveAppConsentRelation.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      appConsentRelationCount = (long) 0;
      retrieveAppConsentRelation.setAppConsentRelationCount(appConsentRelationCount);
      retrieveAppConsentRelation.setAppIdConsentRelationMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveAppConsentRelation);

    }
    return retrieveAppConsentRelation;
  }

  @LogAround
  public RetrieveAppConsentRelation retrieveAllappConsentRelationCache(boolean loadFromDB) {

    String methodName = "retrieveAllappConsentRelationCache";
    Long appConsentRelationCount = 0L;
    RetrieveAppConsentRelation retrieveAppConsentRelation = new RetrieveAppConsentRelation();
    Map<Integer, List<AppConsentRelationBO>> appConsentRelationMap = new HashMap<>();
    List<AppConsentRelationBO> appConsentRelationList = null;
    try {

      if (loadFromDB) {
        cacheUtil.clearAllAppConsentRelationDtls();
      }

      appConsentRelationList = cacheUtil.getAllAppConsentRelationDtls();

      if (null != appConsentRelationList && appConsentRelationList.size() > 0) {
        appConsentRelationCount = (long) appConsentRelationList.size();
        appConsentRelationList.parallelStream().forEach(appConsentRelationBO -> {
          AppConsentRelationBO appConsentRelation = cacheUtil.getAppConsentRelationDtls(
              appConsentRelationBO.getAppConsentRelationPK().getAppId(),
              appConsentRelationBO.getAppConsentRelationPK().getConsentId(), loadFromDB);
          if (null != appConsentRelation) {
            if (appConsentRelationMap
                .containsKey(appConsentRelation.getAppConsentRelationPK().getAppId())) {
              List<AppConsentRelationBO> appConsentRelationDtlList = appConsentRelationMap
                  .get(appConsentRelation.getAppConsentRelationPK().getAppId());
              appConsentRelationDtlList.add(appConsentRelation);
              appConsentRelationMap.put(appConsentRelation.getAppConsentRelationPK().getAppId(),
                  appConsentRelationDtlList);
            } else {
              List<AppConsentRelationBO> appConsentRelationDtlList = new ArrayList<>();
              appConsentRelationDtlList.add(appConsentRelation);
              appConsentRelationMap.put(appConsentRelation.getAppConsentRelationPK().getAppId(),
                  appConsentRelationDtlList);
            }
          }
        });
        retrieveAppConsentRelation.setAppIdConsentRelationMap(appConsentRelationMap);
      }
      retrieveAppConsentRelation.setAppConsentRelationCount(appConsentRelationCount);
      retrieveAppConsentRelation.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveAppConsentRelation.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      appConsentRelationCount = (long) 0;
      retrieveAppConsentRelation.setAppConsentRelationCount(appConsentRelationCount);
      retrieveAppConsentRelation.setAppIdConsentRelationMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveAppConsentRelation);

    }
    return retrieveAppConsentRelation;
  }

  @LogAround
  public RetrieveDerivedPreferences retrieveAllDerivedPreferenceCache(boolean loadFromDB) {

    String methodName = "retrieveAllDerivedPreferenceCache";
    Long derivedPreferenceCount = 0L;
    RetrieveDerivedPreferences retrieveDerivedPreferences = new RetrieveDerivedPreferences();
    Map<Object, List<DerivedPreferencesBO>> derivedPreferenceMap = new HashMap<>();
    List<DerivedPreferencesBO> derivedPreferencesList = null;
    List<DerivedPreferencesBO> derivedPreferencesListFromCache = new ArrayList<>();
    try {

      if (loadFromDB) {
        cacheUtil.clearAllDerivedPreferences();
      }

      derivedPreferencesList = cacheUtil.getAllDerivedPreferences();

      if (null != derivedPreferencesList && derivedPreferencesList.size() > 0) {
        derivedPreferenceCount = (long) derivedPreferencesList.size();
        retrieveDerivedPreferences.setDerivedPreferenceCount(derivedPreferenceCount);
        derivedPreferencesList.parallelStream().forEach(derivedPreferenceBO -> {
          List<DerivedPreferencesBO> derivedPreferenceList =
              cacheUtil.getDerivedPreferences(String.valueOf(derivedPreferenceBO.getAppId()),
                  derivedPreferenceBO.getRegionCode(), derivedPreferenceBO.getRequestIndicator(),
                  derivedPreferenceBO.getPrivacyPreferenceName(), loadFromDB);
          if (derivedPreferenceList != null) {
            derivedPreferencesListFromCache.addAll(derivedPreferenceList);
          }
        });
        derivedPreferenceMap = derivedPreferencesListFromCache.parallelStream()
            .collect(Collectors.groupingBy(DerivedPreferencesBO::getAppId));

        retrieveDerivedPreferences.setDerivedPreferenceMap(derivedPreferenceMap);
      }

      retrieveDerivedPreferences.setDerivedPreferenceCount(derivedPreferenceCount);
      retrieveDerivedPreferences.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveDerivedPreferences.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      derivedPreferenceCount = (long) 0;
      retrieveDerivedPreferences.setDerivedPreferenceCount(derivedPreferenceCount);
      retrieveDerivedPreferences.setDerivedPreferenceMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveDerivedPreferences);

    }
    return retrieveDerivedPreferences;
  }

  @LogAround
  public RetrieveDerivedPreferences retrieveDerivedPreferenceCache(Optional<Integer> appId,
      Optional<String> region, Optional<String> statusCode, Optional<String> consentName,
      boolean loadFromDB) {

    String methodName = "retrieveDerivedPreferenceCache";
    Long derivedPreferenceCount = 0L;
    RetrieveDerivedPreferences retrieveDerivedPreferences = new RetrieveDerivedPreferences();
    Map<Object, List<DerivedPreferencesBO>> derivedPreferenceMap = new HashMap<>();
    try {

      if (loadFromDB) {
        cacheUtil.clearDerivedPreferences(String.valueOf(appId.get()), region.get(),
            statusCode.get(), consentName.get());
      }
      List<DerivedPreferencesBO> derivedPreferenceList =
          cacheUtil.getDerivedPreferences(String.valueOf(appId.get()), region.get(),
              statusCode.get(), consentName.get(), loadFromDB);
      if (null != derivedPreferenceList && derivedPreferenceList.size() > 0) {
        derivedPreferenceCount = (long) derivedPreferenceList.size();
        derivedPreferenceMap = derivedPreferenceList.parallelStream()
            .collect(Collectors.groupingBy(DerivedPreferencesBO::getAppId));
      }
      retrieveDerivedPreferences.setDerivedPreferenceCount(derivedPreferenceCount);
      retrieveDerivedPreferences.setDerivedPreferenceMap(derivedPreferenceMap);
      retrieveDerivedPreferences.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveDerivedPreferences.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      derivedPreferenceCount = (long) 0;
      retrieveDerivedPreferences.setDerivedPreferenceCount(derivedPreferenceCount);
      retrieveDerivedPreferences.setDerivedPreferenceMap(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveDerivedPreferences);

    }
    return retrieveDerivedPreferences;
  }

  
  @LogAround
  public RetrieveDefaultPrivacy retrieveDefaultPrivacyCache(Optional<String> sourceName,
      Optional<String> region, Optional<String> privacyCategory, boolean loadFromDB) {

    String methodName = "retrieveDefaultPrivacyCache";
    Long defualtPrivaciesCount = 0L;
    RetrieveDefaultPrivacy retrieveDefaultPrivacy = new RetrieveDefaultPrivacy();
    List<DefaultPrivacyBO> defaultPrivacyList = null;
    try {

      if (loadFromDB) {
        cacheUtil.clearDefaultPrivacies(String.valueOf(sourceName.get()), region.get(),
            privacyCategory.get());
      }
       defaultPrivacyList =
          cacheUtil.getDefaultPrivacies(String.valueOf(sourceName.get()), region.get(),
              privacyCategory.get(), loadFromDB);
      if (null != defaultPrivacyList && defaultPrivacyList.size() > 0) {
        defualtPrivaciesCount = (long) defaultPrivacyList.size();
      }
      retrieveDefaultPrivacy.setDefaultPrivaciesCount(defualtPrivaciesCount);
      retrieveDefaultPrivacy.setDefaultPrivacyList(defaultPrivacyList);
      retrieveDefaultPrivacy.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveDefaultPrivacy.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      defualtPrivaciesCount = (long) 0;
      retrieveDefaultPrivacy.setDefaultPrivaciesCount(defualtPrivaciesCount);
      retrieveDefaultPrivacy.setDefaultPrivacyList(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveDefaultPrivacy);

    }
    return retrieveDefaultPrivacy;
  }
  
  @LogAround
  public RetrieveDefaultPrivacy retrieveAllDefaultPrivacyCache(boolean loadFromDB) {

    String methodName = "retrieveAllDefaultPrivacyCache";
    Long defaultPrivaciesCount = 0L;
    RetrieveDefaultPrivacy retrieveDefaultPrivacy = new RetrieveDefaultPrivacy();
    List<DefaultPrivacyBO> defaultPrivacyList = null;
    Set<DefaultPrivacyBO> defaultPrivacyListFromCache = new HashSet<DefaultPrivacyBO>();

    try {

      if (loadFromDB) {
        cacheUtil.clearAllDefaultPrivacies();
      }

      defaultPrivacyList = cacheUtil.getAllDefaultPrivacies();

      if (GenericAssister.isCollectionNotEmpty(defaultPrivacyList)) {
        defaultPrivaciesCount = (long) defaultPrivacyList.size();
        // retrieveDefaultPrivacy.setDefaultPrivaciesCount(defaultPrivaciesCount);
        defaultPrivacyList.parallelStream().forEach(defaultPrivacyBO -> {
          List<DefaultPrivacyBO> defaultPrivaciesList =
              cacheUtil.getDefaultPrivacies(defaultPrivacyBO.getSourceName(),
                  defaultPrivacyBO.getRegion(), defaultPrivacyBO.getPrivacyCategory(), loadFromDB);
          if (GenericAssister.isCollectionNotEmpty(defaultPrivaciesList)) {
            defaultPrivacyListFromCache.addAll(defaultPrivaciesList);
          }
        });
      }

      if (GenericAssister.isCollectionNotEmpty(defaultPrivacyListFromCache)) {
        retrieveDefaultPrivacy.setDefaultPrivacyList(
            defaultPrivacyListFromCache.stream().collect(Collectors.toList()));

        retrieveDefaultPrivacy.setDefaultPrivaciesCount(
            Long.valueOf(retrieveDefaultPrivacy.getDefaultPrivacyList().size()));

      }

      // retrieveDefaultPrivacy.setDefaultPrivaciesCount(defaultPrivaciesCount);
      retrieveDefaultPrivacy.setHttpStatus(ResponseCodes.RETRIEVE_SUCCESS.getHttpStatus());
      retrieveDefaultPrivacy.setStatus(ResponseCodes.RETRIEVE_SUCCESS.getStatus());
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger -> logger.methodName(methodName).exception(e));
      defaultPrivaciesCount = 0L;
      retrieveDefaultPrivacy.setDefaultPrivaciesCount(defaultPrivaciesCount);
      retrieveDefaultPrivacy.setDefaultPrivacyList(null);

      GenericResponse genericResponse =
          responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR);
      BeanUtils.copyProperties(genericResponse, retrieveDefaultPrivacy);

    }
    return retrieveDefaultPrivacy;
  }

  @LogAround
  public void clearAllConsentPrivacyCaches() {
    cacheUtil.clearAllConsentPrivacyCaches();
  }

}
