package com.ford.sca.consent.datastore;

public class RequestScopeDataStore {

  //Add your variables to store in request scope
}
