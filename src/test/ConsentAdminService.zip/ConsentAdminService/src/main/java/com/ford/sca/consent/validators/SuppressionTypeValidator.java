package com.ford.sca.consent.validators;

import com.ford.sca.consent.domain.ConsentPrivacyBO;
import com.ford.sca.consent.statics.RequestMode;
import com.ford.sca.consent.transport.GenericResponse;
import com.ford.sca.consent.transport.SuppressionTermRequest;
import com.ford.sca.consent.transport.ApiParams;
import com.ford.sca.consent.util.CacheUtil;
import com.ford.sca.consent.util.LogAround;
import com.ford.sca.consent.util.LoggerBuilder;
import com.ford.sca.consent.util.ResponseBuilder;
import com.ford.sca.consent.util.ResponseCodes;
import com.ford.sca.consent.util.StringAssister;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

/**
 * To validate appCode.
 */
@Slf4j
@Service
public class SuppressionTypeValidator implements ValidatorSuppressionTerm {

  @Autowired
  private ResponseBuilder responseBuilder;

  @Autowired
  private CacheUtil cacheUtil;

  /**
   * This method validates if the given suppressionType or consentId is valid or not.
   *
   * @param apiParams Given API Params
   * @param suppressionTermRequest a given request
   * @param requestMode request operation mode
   * @return Future of {@link GenericResponse}
   */
  @Override
  @LogAround
  public Future<GenericResponse> checkAndConstruct(final ApiParams apiParams,
      final SuppressionTermRequest suppressionTermRequest, final RequestMode requestMode,
      HttpServletRequest httpRequest) {

    GenericResponse genericResponse = null;
    String suppressionType = suppressionTermRequest.getSuppressionType();
    Long consentId = suppressionTermRequest.getConsentId();

    if (StringAssister.isNotEmptyString(suppressionType) || null != consentId) {
      genericResponse = StringAssister.isNotEmptyString(suppressionType)
          ? checkSuppressionWithType(suppressionType, suppressionTermRequest)
          : checkSuppressionConsentId(consentId);
    } else {
      LoggerBuilder.printError(log,
          logger -> logger.message(ResponseCodes.SUPPRESSION_TYPE_OR_CONSENTID_IS_REQUIRED.name()));
      genericResponse =
          responseBuilder.generateResponse(ResponseCodes.SUPPRESSION_TYPE_OR_CONSENTID_IS_REQUIRED);
    }
    return new AsyncResult<>(genericResponse);
  }

  private GenericResponse checkSuppressionWithType(String suppressionType,
      SuppressionTermRequest suppressionTermRequest) {
    ConsentPrivacyBO consetPrivacy = cacheUtil.getConsentPrivacyDtlsForName(suppressionType);
    GenericResponse genericResponse = null;
    if (null == consetPrivacy) {

      LoggerBuilder.printError(log,
          logger -> logger.message(ResponseCodes.INVALID_SUPPRESSION_TYPE.name()));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_SUPPRESSION_TYPE);
    } else {
      suppressionTermRequest.setConsentId(consetPrivacy.getConsentId());
    }
    return genericResponse;
  }

  private GenericResponse checkSuppressionConsentId(Long consentId) {
    ConsentPrivacyBO consetPrivacy = cacheUtil.getConsentPrivacyDtlsForConsentId(consentId);

    GenericResponse genericResponse = null;
    if (null == consetPrivacy) {
      LoggerBuilder.printError(log,
          logger -> logger.message(ResponseCodes.INVALID_CONSENT_ID.name()));
      genericResponse = responseBuilder.generateResponse(ResponseCodes.INVALID_CONSENT_ID);
    }
    return genericResponse;
  }
}
