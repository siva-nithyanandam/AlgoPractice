package com.ford.sca.consent.statics;

public final class Flags {
  public static final String ACTIVE = "Y";
  public static final String IN_ACTIVE = "N";
}
