package com.ford.sca.consent.transport;

import java.io.Serializable;
import java.util.Date;

public class MessageHeaders implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private Float appId;
    private String eventInitiatorName;
    private String eventType;
    private String eventName;
    private Date eventRequestStamp;

    private String correlationID;
    private String guid;

    @Override
    public String toString() {
        return "MessageHeaders [appId=" + appId + ", eventInitiatorName=" + eventInitiatorName + ", eventType="
                + eventType + ", eventName=" + eventName + ", eventRequestStamp=" + eventRequestStamp
                + ", correlationID=" + correlationID + ", guid=" + guid + "]";
    }

    public Float getAppId() {
        return appId;
    }

    public void setAppId(Float appId) {
        this.appId = appId;
    }

    public String getEventInitiatorName() {
        return eventInitiatorName;
    }

    public void setEventInitiatorName(String eventInitiatorName) {
        this.eventInitiatorName = eventInitiatorName;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public Date getEventRequestStamp() {
        return eventRequestStamp;
    }

    public void setEventRequestStamp(Date eventRequestStamp) {
        this.eventRequestStamp = eventRequestStamp;
    }

    public String getCorrelationID() {
        return correlationID;
    }

    public void setCorrelationID(String correlationID) {
        this.correlationID = correlationID;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

}
