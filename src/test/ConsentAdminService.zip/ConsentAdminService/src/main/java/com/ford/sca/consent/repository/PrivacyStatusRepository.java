package com.ford.sca.consent.repository;

import com.ford.sca.consent.domain.PrivacyStatusBO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface PrivacyStatusRepository extends JpaRepository<PrivacyStatusBO, String> {

  public PrivacyStatusBO findByPrivacyStatus(String privacyStatus);

}
