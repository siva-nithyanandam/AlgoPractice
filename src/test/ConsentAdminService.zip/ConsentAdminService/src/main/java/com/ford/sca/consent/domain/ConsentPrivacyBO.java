package com.ford.sca.consent.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name = "[MCNPC07_CONSENT]")
public class ConsentPrivacyBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CNPC07_CONSENT_K]")
  private Long consentId;

  @Column(name = "[CNPC06_POU_K]")
  private Long pouKey;

  @Column(name = "[CNPC07_CONSENT_CATG_X]")
  private String privacyCategory;

  @Column(name = "[CNPC07_CONSENT_N]")
  private String privacyName;

  @Column(name = "[CNPC07_CONSENT_X]")
  private String privacyDescription;

  @Column(name = "[CNPC07_CONSENT_TYPE_C]")
  private String privacyType;

  @Column(name = "[CNPC07_SYSTEM_N]")
  private String consentSystemName;

}
