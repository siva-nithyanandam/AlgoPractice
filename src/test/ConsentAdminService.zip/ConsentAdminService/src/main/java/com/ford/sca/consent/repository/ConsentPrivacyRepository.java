package com.ford.sca.consent.repository;

import com.ford.sca.consent.domain.ConsentPrivacyBO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConsentPrivacyRepository extends JpaRepository<ConsentPrivacyBO, Long> {

  public ConsentPrivacyBO findByConsentId(Long consentId);

  public ConsentPrivacyBO findByPouKey(Long pouKey);

  public ConsentPrivacyBO findByPrivacyName(String name);

}
