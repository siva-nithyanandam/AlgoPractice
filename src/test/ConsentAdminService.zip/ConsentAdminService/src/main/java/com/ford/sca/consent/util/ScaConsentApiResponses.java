package com.ford.sca.consent.util;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@ApiResponses(value = {
    @ApiResponse(code = 201, message = Constants.SUCCESS_CREATE, response = String.class),
    @ApiResponse(code = 200, message = Constants.SUCCESS),
    @ApiResponse(code = 207, message = Constants.MULTI_STATUS),
    @ApiResponse(code = 400, message = Constants.BAD_REQUEST),
    @ApiResponse(code = 401, message = Constants.UNAUTHORIZED),
    @ApiResponse(code = 403, message = Constants.FORBIDDEN),
    @ApiResponse(code = 404, message = Constants.NOT_FOUND),
    @ApiResponse(code = 405, message = Constants.HTTP_REQUEST_METHOD_NOT_SUPPORTED),
    @ApiResponse(code = 412, message = Constants.HTTP_412_API_MSG),
    @ApiResponse(code = 417, message = Constants.HTTP_417_API_MSG),
    @ApiResponse(code = 500, message = Constants.SERVER_ERROR),
    @ApiResponse(code = 503, message = Constants.HTTP_503_API_MSG)})
public @interface ScaConsentApiResponses {

}