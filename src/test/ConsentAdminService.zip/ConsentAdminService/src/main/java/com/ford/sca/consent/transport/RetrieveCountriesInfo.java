package com.ford.sca.consent.transport;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RetrieveCountriesInfo extends GenericResponse {

  private Long countryCounts;

  private List<RetrieveCountry> retrieveCountryList;


}
