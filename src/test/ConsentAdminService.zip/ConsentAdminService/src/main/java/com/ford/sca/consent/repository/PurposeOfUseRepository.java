package com.ford.sca.consent.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ford.sca.consent.admin.domain.PurposeOfUse;

public interface PurposeOfUseRepository extends JpaRepository<PurposeOfUse, Integer> {

	List<PurposeOfUse> findByPouId(Integer pouId);

	List<PurposeOfUse> findByPouIdInAndAppCountryInOrderByCreateDateDesc(Set<Integer> pouIds, Set<String> countryCodes);
}
