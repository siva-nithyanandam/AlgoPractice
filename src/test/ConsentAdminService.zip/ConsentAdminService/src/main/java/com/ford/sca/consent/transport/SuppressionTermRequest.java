package com.ford.sca.consent.transport;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SuppressionTermRequest{

  private static final long serialVersionUID = 1L;
  
  private String suppressionType;
  private Long consentId; 
  private Integer term;

}
