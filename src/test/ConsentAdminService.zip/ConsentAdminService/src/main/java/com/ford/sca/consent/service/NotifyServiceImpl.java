package com.ford.sca.consent.service;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.ford.sca.consent.admin.domain.NotificationLogBO;
import com.ford.sca.consent.notify.ConsentMailer;
import com.ford.sca.consent.repository.NotificationLogRepository;
import com.ford.sca.consent.util.ConsentAdminServiceConstants;
import com.ford.sca.consent.util.ConsentAdminUtil;
import com.ford.sca.consent.util.ConsentMailerConstant;


@Service
public class NotifyServiceImpl implements NotifyService {

	private static final Logger LOGGER = LoggerFactory.getLogger(NotifyServiceImpl.class);
	private String className = this.getClass().getSimpleName();

	@Value("${CRON_TIME_ZONE}")
	public String cronTimeZone;

	@Value("${ENVIRONMENT}")
	public String environment="";
	
	@Value("${MAIL_TO}")
	public Optional<String> mailTo;

	@Autowired
	ConsentMailer consentMailer;
	
	@Autowired
	NotificationLogRepository notificationLogRepository;
	
	
	@Scheduled(cron = "${CLIMES_BATCH_CRON_EVENT}", zone = "${CRON_TIME_ZONE}")
	public void triggerClimesBatchScheduled(){
		Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();
        calendar.add(Calendar.DATE, -1);
        Date yesterdayDate = calendar.getTime();
        String todayDateString = ConsentAdminUtil.convertDateToString(currentDate, ConsentMailerConstant.DATE_FORMAT_YYYY_MM_DD_hh_mm_ss);
        String yesterdayDateString =
        		ConsentAdminUtil.convertDateToString(yesterdayDate, ConsentMailerConstant.DATE_FORMAT_YYYY_MM_DD_hh_mm_ss);
		buildReport(yesterdayDateString, todayDateString, mailTo);
	}

	@Override
	public void buildReport(String startDate, String endDate, Optional<String> mailTo) {
		String methodName = "buildReport";
		LOGGER.debug(ConsentAdminServiceConstants.LOG_INFO + " cronTimeZone = {} ", className, methodName,
				ConsentAdminServiceConstants.COMPLETED_STATUS + className + ConsentAdminServiceConstants.UNDERSCORE
						+ methodName,
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME), cronTimeZone);
		DateFormat dateFormat = new SimpleDateFormat(ConsentMailerConstant.DATE_FORMAT_YYYY_MM_DD_hh_mm_ss);
		List<NotificationLogBO> notificationLogBOList = null;
		try {
			notificationLogBOList = generateExcelAndPrepareListToUpdate(dateFormat.parse(startDate),
					dateFormat.parse(endDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (notificationLogBOList != null && !notificationLogBOList.isEmpty()) {
		String currentWorkingDir = System.getProperty(ConsentMailerConstant.USER_DIR);
		String path = currentWorkingDir + "/" + environment + ConsentAdminServiceConstants.HYPHEN
				+ ConsentMailerConstant.FAILURE_REPORT_FILE_NAME;
		consentMailer.sendMessageWithAttachment(mailTo.get(), ConsentMailerConstant.MAIL_SUBJECT,
				ConsentMailerConstant.MAIL_TEXT, path);
		
			notificationLogBOList.forEach(notificationLog -> notificationLog.setNotifyStaus(true));
			notificationLogRepository.saveAll(notificationLogBOList);
		}
		
	}

	@Override
	public List<NotificationLogBO> generateExcelAndPrepareListToUpdate(Date startTime, Date endTime) {
		
		String methodName = "generateExcel";
		List<NotificationLogBO> notificationLogBOList = null;
		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ConsentMailerConstant.FAILS_SHEET_NAME);
			sheet.autoSizeColumn(12);

			LOGGER.info(ConsentAdminServiceConstants.LOG_INFO + " yesterday date is = {}, today date is = {} ", "","",className, methodName,
					ConsentAdminServiceConstants.PROCESSING_STATUS + className + ConsentAdminServiceConstants.UNDERSCORE + methodName,
					MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
					MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME), startTime, endTime);

			CellStyle headerCellStyle = createExcelDesign(workbook, sheet);
			createExcelRowHeaders(sheet, headerCellStyle);
			notificationLogBOList = notificationLogRepository.findByTranscationTimeStampBetween(startTime, endTime);
			if (notificationLogBOList != null && notificationLogBOList.size() > 0) {
				int rowCount = 5;
				for (NotificationLogBO notificationLogBO : notificationLogBOList) {
					Row userRow = sheet.createRow(rowCount);
					userRow.createCell(0).setCellValue(notificationLogBO.getAppCode());
					userRow.createCell(1).setCellValue(notificationLogBO.getCountryCode());
					userRow.createCell(2).setCellValue(notificationLogBO.getLLId());
					
					Cell cell3 = userRow.createCell(3);
					cell3.setCellStyle(getDateFormatCellStyle(workbook));
					cell3.setCellValue(notificationLogBO.getEffectiveFromTimeStamp());
					
					
					Cell cell4 = userRow.createCell(4);
					cell4.setCellStyle(getDateFormatCellStyle(workbook));
					cell4.setCellValue(notificationLogBO.getEffectiveToTimeStamp());
					
					Cell cell5 = userRow.createCell(5);
					cell5.setCellStyle(getDateFormatCellStyle(workbook));
					cell5.setCellValue(notificationLogBO.getTranscationTimeStamp());
					
					userRow.createCell(6).setCellValue(notificationLogBO.getErrorMsg());
					rowCount++;
				}
				getAutoSizeColumn(sheet);
				FileOutputStream fileOut = new FileOutputStream(environment + ConsentAdminServiceConstants.HYPHEN
						+ ConsentMailerConstant.FAILURE_REPORT_FILE_NAME);
				workbook.write(fileOut);
				fileOut.close();

				workbook.close();
			}

		}catch (Exception e) {
			e.printStackTrace();
		}
		return notificationLogBOList;
		
	}
	
	private CellStyle getDateFormatCellStyle(XSSFWorkbook workbook){
		CellStyle cellStyle = workbook.createCellStyle();
		CreationHelper createHelper = workbook.getCreationHelper();
		cellStyle.setDataFormat(
				createHelper.createDataFormat().getFormat(ConsentMailerConstant.DATE_FORMAT_YYYY_MM_DD_hh_mm_ss));
		return cellStyle;
	}
	
	private void getAutoSizeColumn(XSSFSheet sheet) {
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);
		sheet.autoSizeColumn(6);
	}

	private void createExcelRowHeaders(XSSFSheet sheet, CellStyle headerCellStyle) {

		Row header = sheet.createRow(4);
		header.createCell(0).setCellValue(ConsentMailerConstant.CNPT01_APP_C);
		header.getCell(0).setCellStyle(headerCellStyle);
		header.createCell(1).setCellValue(ConsentMailerConstant.CNPC02_COUNTRY_ISO3_C);
		header.getCell(1).setCellStyle(headerCellStyle);
		header.createCell(2).setCellValue(ConsentMailerConstant.CNPT01_LL_D);
		header.getCell(2).setCellStyle(headerCellStyle);
		header.createCell(3).setCellValue(ConsentMailerConstant.CNPT01_EFF_FROM_S);
		header.getCell(3).setCellStyle(headerCellStyle);
		header.createCell(4).setCellValue(ConsentMailerConstant.CNPT01_EFF_TO_S);
		header.getCell(4).setCellStyle(headerCellStyle);
		header.createCell(5).setCellValue(ConsentMailerConstant.CNPT01_TRANSACTION_S);
		header.getCell(5).setCellStyle(headerCellStyle);
		header.createCell(6).setCellValue(ConsentMailerConstant.CNPT01_ERROR_X);
		header.getCell(6).setCellStyle(headerCellStyle);
	}

	private CellStyle createExcelDesign(XSSFWorkbook workbook, XSSFSheet sheet) {
		XSSFFont headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 12);

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);
		headerFont.setFontName(ConsentMailerConstant.EXCEL_FONT);
		headerCellStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.LAVENDER.getIndex());
		headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
		headerCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
		headerCellStyle.setFont(headerFont);

		sheet.addMergedRegion(new CellRangeAddress(0, 2, 0, 2));

		XSSFRow headerrow = sheet.createRow(0);
		XSSFCell cell1 = headerrow.createCell(0);
		cell1.setCellValue(
				environment + ConsentAdminServiceConstants.HYPHEN + ConsentMailerConstant.EXCEL_HEADER_VALUE);
		cell1.setCellStyle(headerCellStyle);

		XSSFRow Dateheader = sheet.createRow(3);
		sheet.addMergedRegion(new CellRangeAddress(3, 3, 0, 1));
		XSSFCell cell2 = Dateheader.createCell(0);
		cell2.setCellValue(ConsentMailerConstant.EXCEL_REPORT_HEADER_VALUE);
		cell1.setCellStyle(headerCellStyle);

		CellStyle cellStyle1 = workbook.createCellStyle();
		CreationHelper createHelper = workbook.getCreationHelper();
		cellStyle1.setDataFormat(
				createHelper.createDataFormat().getFormat(ConsentMailerConstant.SIMPLE_DATE_FORMAT_D_M_YY));
		XSSFCell cell5 = Dateheader.createCell(2);
		cell5.setCellValue(new Date());
		cell5.setCellStyle(cellStyle1);

		headerFont.setFontHeightInPoints((short) 10);
		headerFont.setColor(IndexedColors.BLACK.getIndex());
		headerCellStyle.setFont(headerFont);
		return headerCellStyle;
	}
	
	public static void main(String args[]){
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(ConsentMailerConstant.DATE_FORMAT_YYYY_MM_DD_hh_mm_ss);
		try {
			System.out.println(dateFormat.parse("2019-05-21T19:00:00.000Z"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
