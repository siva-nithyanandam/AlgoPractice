package com.ford.sca.consent.transport;

import java.util.List;
import java.util.Map;

import com.ford.sca.consent.domain.DerivedPreferencesBO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RetrieveDerivedPreferences extends GenericResponse {

  private Long derivedPreferenceCount;
  private Map<Object, List<DerivedPreferencesBO>> derivedPreferenceMap;
  
}
