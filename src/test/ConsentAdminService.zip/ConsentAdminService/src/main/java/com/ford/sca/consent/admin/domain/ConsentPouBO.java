package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "[MCAPN02_USER_POU]", catalog = "SCACAP", schema = "dbo")
@Data
public class ConsentPouBO implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "[CAPN02_USER_POU_SEQ_R]")
    private Long consentPouSeqKey;

    @Column(name = "[CAPN02_USER_D]")
    private String capUserID;

    @Column(name = "[CAPN02_APP_C]")
    private Float sourceAppID;
    @Column(name = "[CAPN02_POU_D]")
    private Integer pouID;

    @Column(name = "[CAPN02_POU_STATUS_C]")
    private String pouStatus;

    @Column(name = "[CAPN02_POU_S]")
    private Date pouDate;

    @Column(name = "[CAPN02_APP_COUNTRY_ISO3_C]")
    private String appCountryCode;

    @Column(name = "[CAPN02_CREATE_S]")
    private Date createDate;

    @Column(name = "[CAPN02_CREATE_USER_D]")
    private String createUser;

    @Column(name = "[CAPN02_CREATE_PROCESS_C]")
    private String createProcess;

    @Column(name = "[CAPN02_CREATE_APP_C]")
    private Float createAppCode;

    @Column(name = "[CAPN02_UPDATE_S]")
    private Date updateDate;

    @Column(name = "[CAPN02_UPDATE_USER_D]")
    private String updateUser;

    @Column(name = "[CAPN02_UPDATE_PROCESS_C]")
    private String updateProcess;

    @Column(name = "[CAPN02_UPDATE_APP_C]")
    private Float updateAppCode;

    @Column(name = "[CAPN02_LL_D]")
    private String llId;

    @Column(name = "[CAPN02_CONSENT_S]")
    private Date consentTimeStampDate;

    @Column(name = "[CAPN02_LLID_APP_C]")
    private Float llidAppCode;

  /*  @Column(name = "[CAPN02_POU_SHRT_DESC_X]")
    private String pouDescription;*/
    
    @Column(name = "[CAPN02_VALUE_EXCHANGE_X]")
    private String valueExchange;

    @Column(name = "[CAPN02_POU_CATEGORY_D]")
    private Integer pouCategoryID;

    @Column(name = "[CAPN02_POU_CATEGORY_N]")
    private String pouCategoryName;
    
    @Column(name ="[CAPN02_SECONDARY_APP_C]")
    private Float secondaryAppID;
    
    @Column(name="[CAPN02_EXPIRY_S]")
    private Date expiryDate; 
    
    @Column(name = "CAPN02_GLOBAL_CUST_D")
    private String scaId;
    
    @Column(name="[CAPN02_CAMPAIGN_D]")
    private String campaignID;
    
    @Column(name="[CAPN02_SMS_SHORT_C]")
    private Integer shortCode;

    @OneToMany(mappedBy = "consentPouBO", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<UserPouDeviceBO> userPouDevices = new ArrayList<>();

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ConsentPouBO other = (ConsentPouBO) o;
        return Objects.equals(sourceAppID, other.sourceAppID) && Objects.equals(appCountryCode, other.appCountryCode)
                && Objects.equals(pouID, other.pouID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sourceAppID, appCountryCode, pouID);
    }

}
