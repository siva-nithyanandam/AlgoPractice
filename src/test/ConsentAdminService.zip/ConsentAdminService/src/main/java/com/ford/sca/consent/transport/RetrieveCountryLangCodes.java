package com.ford.sca.consent.transport;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RetrieveCountryLangCodes extends GenericResponse {

  private Long countryLangCount;

  private Map<String, String> countryLangMap;

}
