package com.ford.sca.consent.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name = "[MCNPC17_APP_CONSENT]")
public class AppConsentRelationBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @EmbeddedId
  private AppConsentRelationPK appConsentRelationPK;

  @Column(name = "[CNPC17_ACTIVE_F]")
  private String activeFlag;

}
