package com.ford.sca.consent.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.ford.sca.consent.repository.ConsentExpirationRepository;
import com.ford.sca.consent.repository.ConsentMgmtRepository;
import com.ford.sca.consent.repository.ConsentPermissionRepository;
import com.ford.sca.consent.repository.ConsentPouRepository;
import com.ford.sca.consent.repository.ConsentPrivacyRepository;
import com.ford.sca.consent.repository.ConsentSuppressionRepository;
import com.ford.sca.consent.repository.ConsentUserRepository;
import com.ford.sca.consent.repository.CountryCodeRepository;
import com.ford.sca.consent.repository.POURegulationRepository;
import com.ford.sca.consent.repository.PouRepository;
import com.ford.sca.consent.repository.PreferenceSummaryRepository;
import com.ford.sca.consent.repository.PurposeOfUseRepository;
import com.ford.sca.consent.util.CacheUtil;
import com.ford.sca.consent.util.ConsentAdminServiceConstants;
import com.ford.sca.consent.util.ConsentAdminUtil;
import com.ford.sca.consent.admin.domain.ConsentExpirationBo;
import com.ford.sca.consent.admin.domain.ConsentPermissionBO;
import com.ford.sca.consent.admin.domain.PouBO;
import com.ford.sca.consent.admin.domain.PreferenceSummaryBo;
import com.ford.sca.consent.admin.domain.PurposeOfUse;
import com.ford.sca.consent.domain.ConsentPrivacyBO;



@Component("ConsentAdminService")
public class ConsentAdminServiceImpl implements ConsentAdminService {
	

	@Autowired
	public ConsentPouRepository consentPouN02Repository;

	@Autowired
	public POURegulationRepository pouRegulationRepository;

	@Autowired
	public CountryCodeRepository countryCodeRepository;

	@Autowired
	public PurposeOfUseRepository purposeOfUseRepository;
	
	@Autowired
	public ConsentUserRepository consentUserViewRepository;

	@Autowired
	public ConsentMgmtRepository consentMgmtRepository;
	
	@Autowired
	public ConsentPrivacyRepository consentPrivacyRepository;
	
	@Autowired
	public ConsentExpirationRepository  consentExpirationRepository;
	
	@Autowired
	public PreferenceSummaryRepository preferenceSummaryRepository;
	
	@Autowired
	public ConsentPermissionRepository consentPermissionRepository;
	
	@Autowired
	public ConsentSuppressionRepository  consentSuppressionRepository;
	
	@Autowired
	public PouRepository pouRepository;
	@Autowired
	public CacheUtil cacheUtil;
	
	@Value("${CCPA_POU}")
	public String ccpaPouId;
	
	public List<PurposeOfUse> purposeOfUse = new LinkedList<>();
	


	private static final Logger LOGGER = LoggerFactory.getLogger(ConsentAdminServiceImpl.class);
	private static String className = ConsentAdminServiceImpl.class.getSimpleName();
	
	private String[] actionFlag={"I","U"};



	@Override
	public void updateExpiredConsentStatusBatch() {

		processExpiredPOUData();
		
	}
	
	@Override
	public void checkNewPouForExpirationRule() {

		processNewPouForExpiry();
		
	}
	
	
	private void processNewPouForExpiry() {
		String methodName = "processNewPouForExpiry";
		List<ConsentExpirationBo> consentInsertPouList;
		List<ConsentExpirationBo> consentUpdatePouList;
		List<ConsentExpirationBo> consentDeletePouList;
		
		consentInsertPouList=consentExpirationRepository.findByActionFlag("I");
		consentUpdatePouList=consentExpirationRepository.findByActionFlag("U");
		consentDeletePouList=consentExpirationRepository.findByActionFlag("D");
		if(!consentInsertPouList.isEmpty()) {
			consentInsertPouList.forEach(addedPou->updateEndDateAddedExpiryPou(addedPou));
		}
		
		if(!consentUpdatePouList.isEmpty()) {
			consentUpdatePouList.forEach(addedPou->updateEndDateAddedExpiryPou(addedPou));
		}
		
		if(!consentDeletePouList.isEmpty()) {
			consentDeletePouList.forEach(addedPou->updateEndDateAddedExpiryPou(addedPou));
		}
		
	}
	
	/**
	 * This Method will get the expired Permission data from P01 and updates the pou
	 * status if applicable. 
	 *
	 */
	private void updateEndDateAddedExpiryPou(ConsentExpirationBo consentExpirationBo) {

		List<ConsentPermissionBO> addedPouExpirationList=consentPermissionRepository.findByConsentKeyAndCountryCode(consentExpirationBo.getConsentId(),consentExpirationBo.getConsentCountry());
        
		List<ConsentPermissionBO> updatedPous = new ArrayList<>();
		addedPouExpirationList = removeMultiplePouRecords(addedPouExpirationList);

		if (!addedPouExpirationList.isEmpty()) {
			addedPouExpirationList.forEach(consentPermissionBO -> {						
				ConsentPermissionBO consentPermission=new ConsentPermissionBO();
				consentPermission.setConsentKey(consentPermissionBO.getConsentKey());				
				consentPermission.setConsentLlKey(consentPermissionBO.getConsentLlKey());
				consentPermission.setUpdateAppCode(consentPermissionBO.getUpdateAppCode());
				consentPermission.setSrcCode(consentPermissionBO.getSrcCode());
				consentPermission.setSecondarySrcCode(consentPermissionBO.getSecondarySrcCode());
				consentPermission.setCountryCode(consentPermissionBO.getCountryCode());
				consentPermission.setStatusCode(getStatus(consentPermissionBO.getStatusCode(),
						getEndDate(consentPermissionBO.getReceivedTimeStamp(),
								consentExpirationBo),
						consentExpirationBo));
				consentPermission.setDeviceId(consentPermissionBO.getDeviceId());
				consentPermission.setDeviceType(consentPermissionBO.getDeviceType());
				consentPermission.setReceivedTimeStamp(consentPermissionBO.getReceivedTimeStamp());
				consentPermission.setCreateDate(Calendar.getInstance().getTime());
				consentPermission.setCreateUser(String.valueOf(consentPermissionBO.getSrcCode()));
				consentPermission.setCreateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
				consentPermission.setCreateAppCode(consentPermissionBO.getSrcCode());
				consentPermission.setUpdateDate(Calendar.getInstance().getTime());
				consentPermission.setUpdateUser(String.valueOf(consentPermissionBO.getSrcCode()));
				consentPermission.setUpdateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
				consentPermission.setScaId(consentPermissionBO.getScaId());
				consentPermission.setGuid(consentPermissionBO.getGuid());
				consentPermission.setStartDate(consentPermissionBO.getStartDate());
				consentPermission.setEndDate(getEndDate(consentPermissionBO.getReceivedTimeStamp(),consentExpirationBo));
				consentPermission.setCapturedTimeStamp(consentPermissionBO.getCapturedTimeStamp());			
				updatedPous.add(consentPermission);

			});

		}
		if (!updatedPous.isEmpty())
			consentPermissionRepository.saveAll(updatedPous);
		if(Arrays.asList(actionFlag).contains(consentExpirationBo.getActionFlag())) {
		consentExpirationBo.setActionFlag(null);
		}else {
			consentExpirationBo.setActionFlag("A");
		}
		consentExpirationRepository.save(consentExpirationBo);
		
}
	

	
	private  Date getEndDate(Date receivedTimeStamp,ConsentExpirationBo consentExpirationBo)  {
		Date endDate = null;
		try {
			if(Arrays.asList(actionFlag).contains(consentExpirationBo.getActionFlag())) {
		 endDate=ConsentAdminUtil.convertStringToDate(ConsentAdminUtil.addExpirationPeriod(
				ConsentAdminUtil.convertDateToString(receivedTimeStamp,
						ConsentAdminServiceConstants.DATE_FORMAT_YYYY_MM_DD_HR_MIN_SEC),
				consentExpirationBo.getConsentExpirationPeriod(),
				ConsentAdminServiceConstants.DATE_FORMAT_YYYY_MM_DD_HR_MIN_SEC), ConsentAdminServiceConstants.DATE_FORMAT_YYYY_MM_DD_HR_MIN_SEC);
			}
			
		}catch (Exception e) {
			
		}
		return endDate;
	}
	
	
	
	private String getStatus(String statusCode,Date endDate,ConsentExpirationBo consentExpirationBo) {
		String statusCodeValue=null;
		try {
			
		        SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
		        if(Arrays.asList(actionFlag).contains(consentExpirationBo.getActionFlag())) {
				Date endDateFormated = sdformat.parse(ConsentAdminUtil.convertDateToString(endDate,
						ConsentAdminServiceConstants.DATE_FORMAT_YYYY_MM_DD_HR_MIN_SEC));
				Date currentDateFormated = sdformat.parse(ConsentAdminUtil.convertDateToString(Calendar.getInstance().getTime(),
						ConsentAdminServiceConstants.DATE_FORMAT_YYYY_MM_DD_HR_MIN_SEC));
				if(endDateFormated.compareTo(currentDateFormated)>0) {
					statusCodeValue=statusCode;
				}
				if(endDateFormated.compareTo(currentDateFormated)<=0) {
					
					statusCodeValue=consentExpirationBo.getConsentExpirationStatus();
					
				}
		        }else {
		        	statusCodeValue=statusCode;
		        }
				
				
		}catch (Exception e) {
			// TODO: handle exception
		}
		return statusCodeValue;
		
	}
	
	

	/**
	 * This Method will get the expired Permission data from P01 and updates the pou
	 * status if applicable. 
	 *
	 */
	private void processExpiredPOUData() {

		String todayStr = ConsentAdminUtil.todayString();
		Date currentDate = ConsentAdminUtil.parseDate(todayStr);
		Date infinateDate=ConsentAdminUtil.parseDate(ConsentAdminServiceConstants.INFINATE_DATE);
		String methodName = "processExpiredPOUData";

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"processing_processExpiredPOUData", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

		
		List<ConsentPermissionBO> permissionExpired=consentPermissionRepository.findByEndDateAndEndDateNotNullOrderByCreateDateDesc(currentDate);
        List<ConsentPermissionBO> infinatePous=consentPermissionRepository.findByEndDateAndEndDateNotNullOrderByCreateDateDesc(infinateDate);
        permissionExpired.addAll(infinatePous);
        permissionExpired = removeMultiplePouRecords(permissionExpired);
		
		List<ConsentPermissionBO> expirationDefinedPous=new  ArrayList<>();
		
		if (!permissionExpired.isEmpty()) {
			permissionExpired.forEach(consentPermissionBO -> {
				ConsentExpirationBo consentExpirationBo = consentExpirationRepository
						.findByConsentIdAndConsentCountry(consentPermissionBO.getConsentKey(),consentPermissionBO.getCountryCode());
				if (null != consentExpirationBo) {
					Optional<ConsentPrivacyBO> consnetCode= consentPrivacyRepository.findById(consentPermissionBO.getConsentKey());
					Long pouKey=consnetCode.get().getPouKey();
					Optional<PouBO> pou=null;
					if(pouKey!=null)
					{
						pou=pouRepository.findById(pouKey);
					}
					if(pou.get().getPouId()!=Integer.parseInt(ccpaPouId))
					{
					String defaultStatus = consentExpirationBo.getConsentExpirationStatus();
					
					if(!defaultStatus.equalsIgnoreCase(consentPermissionBO.getStatusCode())){
					consentPermissionBO.setStatusCode(defaultStatus);

					expirationDefinedPous.add(consentPermissionBO);
					}
					}else{
						if(consentPermissionBO.getStatusCode().equalsIgnoreCase(ConsentAdminServiceConstants.CCPA_STATUS_N)){
							consentPermissionBO.setStatusCode(ConsentAdminServiceConstants.CCPA_STATUS_Y);
							
							consentPermissionBO.setEndDate(infinateDate);
							expirationDefinedPous.add(consentPermissionBO);
						}
					}
				}
			});
		}

		List<ConsentPermissionBO> updatedPous = new ArrayList<>();
		

		if (!expirationDefinedPous.isEmpty()) {
			expirationDefinedPous.forEach(consentPermissionBO -> {						
				ConsentPermissionBO consentPermission=new ConsentPermissionBO();
				consentPermission.setConsentKey(consentPermissionBO.getConsentKey());				
				consentPermission.setConsentLlKey(consentPermissionBO.getConsentLlKey());
				consentPermission.setUpdateAppCode(consentPermissionBO.getUpdateAppCode());
				consentPermission.setSrcCode(consentPermissionBO.getSrcCode());
				consentPermission.setSecondarySrcCode(consentPermissionBO.getSecondarySrcCode());
				consentPermission.setCountryCode(consentPermissionBO.getCountryCode());
				consentPermission.setStatusCode(consentPermissionBO.getStatusCode());
				consentPermission.setDeviceId(consentPermissionBO.getDeviceId());
				consentPermission.setDeviceType(consentPermissionBO.getDeviceType());
				consentPermission.setReceivedTimeStamp(consentPermissionBO.getReceivedTimeStamp());
				consentPermission.setCreateDate(Calendar.getInstance().getTime());
				consentPermission.setCreateUser(String.valueOf(consentPermissionBO.getSrcCode()));
				consentPermission.setCreateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
				consentPermission.setCreateAppCode(consentPermissionBO.getSrcCode());
				consentPermission.setUpdateDate(Calendar.getInstance().getTime());
				consentPermission.setUpdateUser(String.valueOf(consentPermissionBO.getSrcCode()));
				consentPermission.setUpdateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
				consentPermission.setScaId(consentPermissionBO.getScaId());
				consentPermission.setGuid(consentPermissionBO.getGuid());
				consentPermission.setStartDate(consentPermissionBO.getStartDate());
				consentPermission.setEndDate(consentPermissionBO.getEndDate());
				consentPermission.setCapturedTimeStamp(consentPermissionBO.getCapturedTimeStamp());			
				updatedPous.add(consentPermission);

			});

		}
		if (!updatedPous.isEmpty())
			consentPermissionRepository.saveAll(updatedPous);

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"Calling_processExpiredPreferenceData", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
		
		processExpiredPreferenceData();

		//updateConsnetStatus();

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"Completed_processExpiredPOUData", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

	}
	
	

	/**
	 * This Method will get the expired Preference data from N02 and updates the pou
	 * status if applicable. 
	 *
	 */
	
	private void processExpiredPreferenceData() {
		String todayStr = ConsentAdminUtil.todayString();
		Date currentDate = ConsentAdminUtil.parseDate(todayStr);
		String methodName = "processExpiredPreference Data";

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"processExpiredPreferenceData", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

		List<PreferenceSummaryBo> preferenceExpired = preferenceSummaryRepository
				.findByEndDateAndEndDateNotNullOrderByCreateDateDesc(currentDate);
		preferenceExpired = removePreferenceDuplicated(preferenceExpired);

		List<PreferenceSummaryBo> expirationDefinedPreferences = new ArrayList<>();

		if (!preferenceExpired.isEmpty()) {
			preferenceExpired.forEach(consentPreferenceBo -> {
				ConsentExpirationBo consentExpirationBo = consentExpirationRepository
						.findByConsentIdAndConsentCountry(consentPreferenceBo.getConsentId(),consentPreferenceBo.getCountryCode());
				if (null != consentExpirationBo) {
					String defaultStatus = consentExpirationBo.getConsentExpirationStatus();
					if(!defaultStatus.equalsIgnoreCase(consentPreferenceBo.getPreferenceStatus()))
					{
					consentPreferenceBo.setPreferenceStatus(defaultStatus);
					expirationDefinedPreferences.add(consentPreferenceBo);
					}
				}
			});
		}

		List<PreferenceSummaryBo> updatedPous = new ArrayList<>();

		if (!expirationDefinedPreferences.isEmpty()) {
			expirationDefinedPreferences.forEach(consentPreferenceBo -> {
				PreferenceSummaryBo preferenceSummaryBo = new PreferenceSummaryBo();
				preferenceSummaryBo.setConsentId(consentPreferenceBo.getConsentId());
				preferenceSummaryBo.setUpdateAppCode(consentPreferenceBo.getUpdateAppCode());
				preferenceSummaryBo.setSourceCode(consentPreferenceBo.getSourceCode());
				preferenceSummaryBo.setSecSourceCode(consentPreferenceBo.getSecSourceCode());
				preferenceSummaryBo.setCountryCode(consentPreferenceBo.getCountryCode());
				preferenceSummaryBo.setPreferenceStatus(consentPreferenceBo.getPreferenceStatus());
				preferenceSummaryBo.setDeviceId(consentPreferenceBo.getDeviceId());
				preferenceSummaryBo.setDeviceTypeId(consentPreferenceBo.getDeviceTypeId());
				preferenceSummaryBo.setCreateDate(Calendar.getInstance().getTime());
				preferenceSummaryBo.setCreateUser(String.valueOf(consentPreferenceBo.getSourceCode()));
				preferenceSummaryBo.setCreateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
				preferenceSummaryBo.setCreateAppCode(consentPreferenceBo.getSourceCode());
				preferenceSummaryBo.setUpdateDate(Calendar.getInstance().getTime());
				preferenceSummaryBo.setUpdateUser(String.valueOf(consentPreferenceBo.getSourceCode()));
				preferenceSummaryBo.setUpdateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
				preferenceSummaryBo.setScaId(consentPreferenceBo.getScaId());
				preferenceSummaryBo.setGuid(consentPreferenceBo.getGuid());
				preferenceSummaryBo.setStartDate(consentPreferenceBo.getStartDate());
				preferenceSummaryBo.setEndDate(consentPreferenceBo.getEndDate());
				preferenceSummaryBo.setPreferenceTimestamp(consentPreferenceBo.getPreferenceTimestamp());
				updatedPous.add(preferenceSummaryBo);

			});

		}

		if (!updatedPous.isEmpty())
			preferenceSummaryRepository.saveAll(updatedPous);

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"Calling_processExpiredSupressionData", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
		
		//processExpiredSuppressionData();

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"Completed_processExpiredPersmission", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

	}

	/*private void processExpiredSuppressionData() {
		String todayStr = ConsentAdminUtil.todayString();
		Date currentDate = ConsentAdminUtil.parseDate(todayStr);
		String methodName = "processExpiredSuppressionData Data";

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"processExpiredPreferenceData", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
		
		List<ConsentSuppressionBO> suppressionsExpired = consentSuppressionRepository
				.findByEndDateAndEndDateNotNullOrderByCreateDateDesc(currentDate);
		suppressionsExpired = removeSuppressionDuplicated(suppressionsExpired);

		List<ConsentSuppressionBO> expirationDefinedSuppressions = new ArrayList<>();

		if (!suppressionsExpired.isEmpty()) {
			suppressionsExpired.forEach(consentSuppressionBo -> {
				ConsentExpirationBo consentExpirationBo = consentExpirationRepository
						.findByConsentId(consentSuppressionBo.getConsentId());
				if (null != consentExpirationBo) {
					String defaultStatus = consentExpirationBo.getConsentExpirationStatus();
					consentSuppressionBo.setStatusCode(defaultStatus);

					expirationDefinedSuppressions.add(consentSuppressionBo);
				}
			});
		}

		List<ConsentSuppressionBO> updatedPous = new ArrayList<>();

		if (!expirationDefinedSuppressions.isEmpty()) {
			expirationDefinedSuppressions.forEach(consentSuppression -> {
				ConsentSuppressionBO consentSuppressionBo = new ConsentSuppressionBO();
				consentSuppressionBo.setConsentId(consentSuppression.getConsentId());
				consentSuppressionBo.setUpdateAppCode(consentSuppression.getUpdateAppCode());
				consentSuppressionBo.setSrcCode(consentSuppression.getSrcCode());
				consentSuppressionBo.setSecondarySrcCode(consentSuppression.getSecondarySrcCode());
				consentSuppressionBo.setCountryCode(consentSuppression.getCountryCode());
				consentSuppressionBo.setStatusCode(consentSuppression.getStatusCode());
				consentSuppressionBo.setDeviceId(consentSuppression.getDeviceId());
				consentSuppressionBo.setDeviceType(consentSuppression.getDeviceType());
				consentSuppressionBo.setCreateDate(Calendar.getInstance().getTime());
				consentSuppressionBo.setCreateUser(String.valueOf(consentSuppression.getSrcCode()));
				consentSuppressionBo.setCreateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
				consentSuppressionBo.setCreateAppCode(consentSuppression.getSrcCode());
				consentSuppressionBo.setUpdateDate(Calendar.getInstance().getTime());
				consentSuppressionBo.setUpdateUser(String.valueOf(consentSuppression.getSrcCode()));
				consentSuppressionBo.setUpdateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
				consentSuppressionBo.setScaId(consentSuppression.getScaId());
				consentSuppressionBo.setGuid(consentSuppression.getGuid());
				consentSuppressionBo.setStartDate(consentSuppression.getStartDate());
				consentSuppressionBo.setEndDate(consentSuppression.getEndDate());
				consentSuppressionBo.setReceivedTimeStamp(consentSuppression.getReceivedTimeStamp());
				consentSuppressionBo.setCapturedTimestamp(consentSuppression.getCapturedTimestamp());
				updatedPous.add(consentSuppressionBo);

			});

		}

		if (!updatedPous.isEmpty())
			consentSuppressionRepository.saveAll(updatedPous);



		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"Completed_processExpiredSuppressionData", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
		
		
	}

*/

/*	private List<ConsentSuppressionBO> removeSuppressionDuplicated(List<ConsentSuppressionBO> suppressionsExpired) {
		List<ConsentSuppressionBO> newUserPouList = new ArrayList<>();
	    //userPouList.sort(Comparator.comparing(ConsentPouBO::getCreateDate).reversed());
	    Set<ConsentSuppressionBO> newConsentPOUSet = new HashSet<>(suppressionsExpired);
	    newUserPouList.addAll(newConsentPOUSet);
	    return newUserPouList;
	}
*/


	private List<PreferenceSummaryBo> removePreferenceDuplicated(List<PreferenceSummaryBo> preferenceExpired) {
		List<PreferenceSummaryBo> newUserPouList = new ArrayList<>();
	    //userPouList.sort(Comparator.comparing(ConsentPouBO::getCreateDate).reversed());
	    Set<PreferenceSummaryBo> newConsentPOUSet = new HashSet<>(preferenceExpired);
	    newUserPouList.addAll(newConsentPOUSet);
	    return newUserPouList;
	}



	/*private void updateConsnetStatus() {

		String todayStr = ConsentAdminUtil.todayString();
		Date currentDate = ConsentAdminUtil.parseDate(todayStr);
		String methodName = "updateConsnetStatus";
		List<ConsentMgmtBO> updatedConsentList = new ArrayList<>();

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"processing_updateConsnetStatus", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

		// Fetching the expired Consents from N01
		List<ConsentView> expiredConsents = consentUserViewRepository
				.findByExpiryDateLessThanEqualAndExpiryDateIsNotNullAndConsentStatus(currentDate,
						ConsentAdminServiceConstants.CONSNET_OPTIN_1);

		expiredConsents.forEach(consentView -> {

			// Checking If active POU for the Expired Consent
			List<ConsentPouBO> activePous = consentPouN02Repository
					.findByCapUserIDAndScaIdAndSourceAppIDAndAppCountryCodeAndLLIdAndExpiryDateGreaterThanEqualAndExpiryDateIsNotNull(
							consentView.getCapUserId(), consentView.getScaId(), consentView.getAppCode(),
							consentView.getAppCountryCode(), consentView.getLLId(), currentDate);
			if (activePous.isEmpty()) {

				// if there is no active POU update the N01 consent status to 0
				Optional<ConsentMgmtBO> consentMgmtBO = consentMgmtRepository.findById(consentView.getConsentSeqKey());

				if (consentMgmtBO.isPresent()) {
					ConsentMgmtBO consentMgmtBOUpdate = consentMgmtBO.get();
					consentMgmtBOUpdate.setConsentSeqKey(null);
					consentMgmtBOUpdate.setConsentStatus(ConsentAdminServiceConstants.CONSNET_OPTOUT_0);
					consentMgmtBOUpdate.setCreateDate(Calendar.getInstance().getTime());
					consentMgmtBOUpdate.setUpdateDate(Calendar.getInstance().getTime());
					consentMgmtBOUpdate.setCreateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
					consentMgmtBOUpdate.setUpdateProcess(ConsentAdminServiceConstants.CAP_PROCESS);

					List<ConsentDeviceBO> consentDeviceBOList = consentMgmtBOUpdate.getConsentDeviceList();
					List<ConsentDeviceBO> updatedConsentDeviceBOList = new ArrayList<>();
					if (null != consentDeviceBOList && !consentDeviceBOList.isEmpty()) {
						consentDeviceBOList.forEach(consentDeviceBO -> {
							consentDeviceBO.setConsentDeviceSeqKey(null);
							consentDeviceBO.setCreateDate(Calendar.getInstance().getTime());
							consentDeviceBO.setUpdateDate(Calendar.getInstance().getTime());
							consentDeviceBO.setCreateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
							consentDeviceBO.setUpdateProcess(ConsentAdminServiceConstants.CAP_PROCESS);
							updatedConsentDeviceBOList.add(consentDeviceBO);
						});

					}

					consentMgmtBOUpdate.setConsentDeviceList(updatedConsentDeviceBOList);

					updatedConsentList.add(consentMgmtBOUpdate);

				}

			}

		});

		if (!updatedConsentList.isEmpty()) {
			consentMgmtRepository.saveAll(updatedConsentList);
		}

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"Completed_updateConsnetStatus", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
	}
*/
	public List<ConsentPermissionBO> removeMultiplePouRecords(List<ConsentPermissionBO> userPouList) {
	    List<ConsentPermissionBO> newUserPouList = new ArrayList<>();
	    userPouList.sort(Comparator.comparing(ConsentPermissionBO::getCreateDate).reversed());
	    Set<ConsentPermissionBO> newConsentPOUSet = new HashSet<>(userPouList);
	    newUserPouList.addAll(newConsentPOUSet);
	    return newUserPouList;
	  }

}
