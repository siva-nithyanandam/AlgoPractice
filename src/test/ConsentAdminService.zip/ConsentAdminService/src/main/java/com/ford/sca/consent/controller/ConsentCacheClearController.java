package com.ford.sca.consent.controller;

import com.ford.sca.consent.service.ConsentCacheService;
import com.ford.sca.consent.util.AuditActivityUtilNF;
import com.ford.sca.consent.util.CacheUtil;
import com.ford.sca.consent.util.ConsentCacheNames;
import com.ford.sca.consent.util.LogAround;
import com.ford.sca.consent.util.LoggerBuilder;
import com.ford.sca.consent.util.ResponseBuilder;
import com.ford.sca.consent.util.ScaConsentApiResponses;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/cas/consent-administrations")
@ApiOperation("Admin Service Cache Clear Controller")
public class ConsentCacheClearController {

  @Autowired
  private AuditActivityUtilNF auditActivityUtilNf;

  @Autowired
  ResponseBuilder responseBuilder;

  @Autowired
  CacheUtil cacheUtil;

  @Autowired
  CacheManager cacheManager;

  @Autowired
  ConsentCacheService consentCacheService;

  /**
   * This Endpoint clears appCodeInfo Cache for specific appId.
   *
   * @param appId    is Application Id
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAppCodeInfoCache", nickname = "clearAppCodeInfoCache")
  @DeleteMapping(value = "/v1/app-codes/{app-cd}")
  @LogAround
  public void clearAppCodeInfoCache(
      @ApiParam(value = "Application ID.", required = true) @PathVariable("app-cd") Integer appId,
      HttpServletRequest request, HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAppCode(appId);
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAppCodeInfoCache")
        .message(String.format("cleard App Code Info Cache for appId: %d", appId)));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in appCodeInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllAppCodeInfoCache", nickname = "clearAllAppCodeInfoCache")
  @DeleteMapping(value = "/v1/app-codes")
  @LogAround
  public void clearAllAppCodeInfoCache(HttpServletRequest request, HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllAppCodes();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllAppCodeInfoCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in errorMessages Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllErrorMessagesCache", nickname = "clearAllErrorMessagesCache")
  @DeleteMapping(value = "/v1/error-msgs")
  @LogAround
  public void clearAllErrorMessagesCache(HttpServletRequest request, HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllErrorMessages();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllErrorMessagesCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in countryInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllCountryInfoCache", nickname = "clearAllCountryInfoCache")
  @DeleteMapping(value = "/v1/cntry-infos")
  @LogAround
  public void clearAllCountryInfoCache(HttpServletRequest request, HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllCountryCodes();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllCountryInfoCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in countryLangInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllCountryLangInfoCache", nickname = "clearAllCountryLangInfoCache")
  @DeleteMapping(value = "/v1/cntry-lang-infos")
  @LogAround
  public void clearAllCountryLangInfoCache(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllCountryLangs();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllCountryLangInfoCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in consentGroupCodeInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllConsentGroupCodeInfoCache",
      nickname = "clearAllConsentGroupCodeInfoCache")
  @DeleteMapping(value = "/v1/grp-cd-infos")
  @LogAround
  @CacheEvict(allEntries = true, cacheNames = ConsentCacheNames.CONSENT_GROUP_CODE_INFO)
  public void clearAllConsentGroupCodeInfoCache(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllConsentGroupCodeInfoCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in consentPrivacyInfo Caches.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllConsentPrivacyInfoCaches",
      nickname = "clearAllConsentPrivacyInfoCaches")
  @DeleteMapping(value = "/v1/privacy-infos")
  @LogAround
  public void clearAllConsentPrivacyInfoCaches(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    consentCacheService.clearAllConsentPrivacyCaches();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllConsentPrivacyInfoCaches")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in deviceTypeInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllDeviceTypeInfoCache", nickname = "clearAllDeviceTypeInfoCache")
  @DeleteMapping(value = "/v1/device-type-infos")
  @LogAround
  public void clearAllDeviceTypeInfoCache(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllDeviceTypes();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllDeviceTypeInfoCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in deviceTypeInfoById Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllDeviceTypeInfoByIdCache",
      nickname = "clearAllDeviceTypeInfoByIdCache")
  @DeleteMapping(value = "/v1/device-type-id-infos")
  @LogAround
  public void clearAllDeviceTypeInfoByIdCache(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllDeviceTypesById();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllDeviceTypeInfoByIdCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in privacyDeviceMappingInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllPrivacyDeviceMappingInfoCache",
      nickname = "clearAllPrivacyDeviceMappingInfoCache")
  @DeleteMapping(value = "/v1/privacy-device-mappings")
  @LogAround
  public void clearAllPrivacyDeviceMappingInfoCache(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllPrivacyDeviceMappings();
    LoggerBuilder.printDebug(log,
        logger -> logger.methodName("clearAllPrivacyDeviceMappingInfoCache")
            .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in privacyStatusInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllPrivacyStatusInfoCache",
      nickname = "clearAllPrivacyStatusInfoCache")
  @DeleteMapping(value = "/v1/privacy-statuses")
  @LogAround
  public void clearAllPrivacyStatusInfoCache(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllPrivacyStatusDtls();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllPrivacyStatusInfoCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in suppressionTermInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllSuppressionTermInfoCache",
      nickname = "clearAllSuppressionTermInfoCache")
  @DeleteMapping(value = "/v1/suppression-term-infos")
  @LogAround
  public void clearAllSuppressionTermInfoCache(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllSuppressionTerms();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllSuppressionTermInfoCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in appConsentRelationInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllAppConsentRelationInfoCache",
      nickname = "clearAllAppConsentRelationInfoCache")
  @DeleteMapping(value = "/v1/app-consent-relations")
  @LogAround
  public void clearAllAppConsentRelationInfoCache(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllAppConsentRelationDtls();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllAppConsentRelationInfoCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in consentExpiryRuleInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllConsentExpiryRuleInfoCache",
      nickname = "clearAllConsentExpiryRuleInfoCache")
  @DeleteMapping(value = "/v1/expiry-rules")
  @LogAround
  public void clearAllConsentExpiryRuleInfoCache(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllExpiryRules();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllConsentExpiryRuleInfoCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }

  /**
   * This Endpoint clears all entries in derivedPreferencesInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllDerivedPreferencesInfoCache",
      nickname = "clearAllDerivedPreferencesInfoCache")
  @DeleteMapping(value = "/v1/derived-preferences")
  @LogAround
  public void clearAllDerivedPreferencesInfoCache(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllDerivedPreferences();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllDerivedPreferencesInfoCache")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }


  /**
   * This Endpoint clears all entries in defaultPrivacyInfo Cache.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "clearAllDefaultPrivacies",
      nickname = "clearAllDefaultPrivacies")
  @DeleteMapping(value = "/v1/default-privacies")
  @LogAround
  public void clearAllDefaultPrivacies(HttpServletRequest request,
      HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllDefaultPrivacies();
    LoggerBuilder.printDebug(log, logger -> logger.methodName("clearAllDefaultPrivacies")
        .message("All Entries in this Cache Cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }


  /**
   * This Endpoint Clears all caches entries.
   *
   * @param request  is http request
   * @param response is http response
   */
  @PreAuthorize("hasPermission('aud', 'consentAdminDeleteResource')")
  @ScaConsentApiResponses
  @ApiOperation(value = "Clear all cache", nickname = "Clear all cache")
  @DeleteMapping(value = "/v1/all")
  @LogAround
  public void clearAllCache(HttpServletRequest request, HttpServletResponse response) {
    auditActivityUtilNf.storeRequestHeaderAttributes(request);
    cacheUtil.clearAllCaches();
    LoggerBuilder.printDebug(log, logger -> logger.message("All Cache cleared!"));
    auditActivityUtilNf.setResponseHeaderAttributes(response);
  }


}
