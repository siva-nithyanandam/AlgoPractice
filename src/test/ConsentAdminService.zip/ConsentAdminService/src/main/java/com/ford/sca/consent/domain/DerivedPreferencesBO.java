package com.ford.sca.consent.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "[MCNPC15_PRIVACY_PREF_RULE]")
public class DerivedPreferencesBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CNPC15_PRIVACY_PREF_K]")
  private Long privacyPreferenceId;

  @Column(name = "[CNPC02_REGION_C]")
  private String regionCode;

  @Column(name = "[CNPC15_APP_C]")
  private Integer appId;

  @Column(name = "[CNPC15_PRIVACY_PREF_N]")
  private String privacyPreferenceName;

  @Column(name = "[CNPC07_CONSENT_K]")
  private Long consentId;

  @Column(name = "[CNPC15_REQ_INDICATOR_F]")
  private String requestIndicator;

  @Column(name = "[CNPC15_RESP_INDICATOR_F]")
  private String responseIndicator;

}
