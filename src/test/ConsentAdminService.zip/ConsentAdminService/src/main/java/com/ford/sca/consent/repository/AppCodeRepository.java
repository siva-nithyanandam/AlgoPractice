package com.ford.sca.consent.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.consent.domain.AppCodeBO;


public interface AppCodeRepository extends JpaRepository<AppCodeBO, Integer> {

    AppCodeBO findByAppIdAndActiveFlag(Integer appId, String activeFlag);
    AppCodeBO findByAppId(Integer appId);
}
