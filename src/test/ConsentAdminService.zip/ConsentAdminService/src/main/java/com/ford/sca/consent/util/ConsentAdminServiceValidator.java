package com.ford.sca.consent.util;

import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import com.ford.sca.consent.domain.AppCodeBO;
import com.ford.sca.consent.exception.AppCountryCodeNotExistsException;
import com.ford.sca.consent.exception.AppIdNotExistsException;
import com.ford.sca.consent.exception.ConsentBaseException;
import com.ford.sca.consent.exception.InvalidDateFormatException;
import com.ford.sca.consent.exception.InvalidPouStatusException;
import com.ford.sca.consent.exception.MissingPouFieldsException;
import com.ford.sca.consent.exception.RequiredFieldsException;
// import com.ford.sca.consent.service.ConsentAdminService;
import com.ford.sca.consent.transport.ConsentAdminRequest;
import com.ford.sca.consent.transport.POURegulation;


@Component
public class ConsentAdminServiceValidator {

  // @Autowired
  // private ConsentAdminService consentAdminService;

  @Autowired
  private CacheUtil cacheUtil;

  private static final Logger LOGGER = LoggerFactory.getLogger(ConsentAdminServiceValidator.class);
  private static String className = ConsentAdminServiceValidator.class.getSimpleName();

  public void validateInputField(String appCountryCode, String appId,
      ConsentAdminRequest consentAdminRequest) {
    validateAppCode(appId);
    validateCountryCode(appCountryCode);
    validatePouIsPresent(consentAdminRequest.getPouRegulationList());
    validateEffectiveDates(consentAdminRequest.getPouRegulationList());
  }

  private void validateCountryCode(String appCountryCode) {
    String methodName = "validateCountryCode";
    final String missingCountryCode = "CountryCode is missing";
    if (appCountryCode == null) {
      LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
          MDC.get(ConsentAdminServiceConstants.SERVICE),
          ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
          MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
          ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
          MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
          MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
          MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
          MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
          cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0009_CODE));
      throw new RequiredFieldsException(missingCountryCode);
    }

    /*
     * if (!consentAdminService.isAppCountryCodeValid(appCountryCode)) {
     * LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
     * MDC.get(ConsentAdminServiceConstants.SERVICE),
     * ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
     * MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
     * "ErrorInAppCountryCodeValidation",
     * MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
     * MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
     * MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
     * MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
     * cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0208_CODE)); throw new
     * AppCountryCodeNotExistsException("AppCountry Code  does not Exist in CAP"); }
     */

  }

  private void validateAppCode(String appId) {
    String methodName = "validateAppCode";
    Integer appIdVal = null;
    if (appId.isEmpty()) {
      LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
          MDC.get(ConsentAdminServiceConstants.SERVICE),
          ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
          MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
          ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
          MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
          MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
          MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
          MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
          cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0009_CODE));
      throw new RequiredFieldsException("APP ID is not provided");
    } else {
      try {
        appIdVal = Integer.parseInt(appId);
      } catch (NumberFormatException e) {
        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
            MDC.get(ConsentAdminServiceConstants.SERVICE),
            ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
            MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
            ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), e.getMessage());

        throw new AppIdNotExistsException("APP ID is not in number format");
      }
    }

    AppCodeBO appCode = retrieveAppCode(appIdVal);
    if (appCode == null || !ConsentAdminUtil.isActiveFlag(appCode.getActiveFlag())) {
      LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
          MDC.get(ConsentAdminServiceConstants.SERVICE),
          ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
          MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
          ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
          MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
          MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
          MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
          MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
          AppIdNotExistsException.class.getSimpleName(),
          cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0002_CODE));
      throw new AppIdNotExistsException("APP ID  does not Exist or is Inactive in CAP");
    }
  }

  private void validatePouIsPresent(List<POURegulation> pouRegulationlist) {
    String methodName = "validatePouIsPresent";
    final String missingPOUs = "POU Missing";
    if (pouRegulationlist == null || CollectionUtils.isEmpty(pouRegulationlist)) {
      LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
          MDC.get(ConsentAdminServiceConstants.SERVICE),
          ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
          MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
          ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
          MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
          MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
          MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
          MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
          AppCountryCodeNotExistsException.class.getSimpleName(),
          cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0009_CODE));
      throw new MissingPouFieldsException(missingPOUs);
    }
    for (POURegulation pouRegulation : pouRegulationlist) {
      if (pouRegulation.getPouID() == null) {
        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
            MDC.get(ConsentAdminServiceConstants.SERVICE),
            ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
            MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
            ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
            AppCountryCodeNotExistsException.class.getSimpleName(),
            cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0009_CODE));
        throw new MissingPouFieldsException(missingPOUs);
      }

      if (pouRegulation.getPouStatus() == null) {
        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
            MDC.get(ConsentAdminServiceConstants.SERVICE),
            ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
            MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
            ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
            AppCountryCodeNotExistsException.class.getSimpleName(),
            cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0009_CODE));
        throw new MissingPouFieldsException(missingPOUs);
      }

      if (!"G".equalsIgnoreCase(pouRegulation.getPouStatus())
          && !"H".equalsIgnoreCase(pouRegulation.getPouStatus())) {
        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
            MDC.get(ConsentAdminServiceConstants.SERVICE),
            ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
            MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
            "ErrorInPouStatusValidation",
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
            cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0195_CODE));
        throw new InvalidPouStatusException("Pou status must be G or H");
      } else {
        if (cacheUtil.getPrivacyStatusDtls(pouRegulation.getPouStatus()) == null) {
          LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
              MDC.get(ConsentAdminServiceConstants.SERVICE),
              ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
              MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className,
              methodName, "ErrorInPouStatusValidation",
              MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
              MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
              MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
              MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
              cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0195_CODE));
          throw new InvalidPouStatusException("Consent Status is not in CAP");

        }
      }
      /*
       * if (!consentAdminService.isPouIDValid(pouRegulation.getPouID())) {
       * LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
       * MDC.get(ConsentAdminServiceConstants.SERVICE),
       * ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
       * MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
       * "ErrorInPouIdValidation",
       * MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
       * MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
       * MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
       * MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
       * cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0206_CODE)); throw new
       * PouIdNotExistsException("PouID does not Exist in CAP"); }
       */
    }

  }

  private AppCodeBO retrieveAppCode(Integer appId) {
    String methodName = "retrieveAppCode";
    AppCodeBO appCode = null;
    try {
      appCode = cacheUtil.getAppCodeDtls(appId);
    } catch (Exception e) {
      LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
          MDC.get(ConsentAdminServiceConstants.SERVICE),
          ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
          MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
          "App Code is not found",
          MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
          MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
          MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
          MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), e.getMessage());
      throw new ConsentBaseException("Database Error Retrieving AppCode", e);
    }
    return appCode;
  }

  public void validateEffectiveDates(List<POURegulation> pouRegulationlist) {

    String methodName = "validateEffectiveDates";
    final String missingEffectiveDates = "Effective Dates is missing";
    final String invalidEffectiveStartDate = "Invalid Effective Start Date";
    final String invalidEffectiveEndDate = "Invalid Effective End Date";

    for (POURegulation pouRegulation : pouRegulationlist) {
      if (pouRegulation.getEffectiveStartDate() == null) {
        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
            MDC.get(ConsentAdminServiceConstants.SERVICE),
            ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
            MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
            ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
            AppCountryCodeNotExistsException.class.getSimpleName(),
            cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0009_CODE));
        throw new RequiredFieldsException(missingEffectiveDates);
      }

      if (!ConsentAdminUtil.isValidDate(pouRegulation.getEffectiveStartDate())) {
        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
            MDC.get(ConsentAdminServiceConstants.SERVICE),
            ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
            MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
            ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
            AppCountryCodeNotExistsException.class.getSimpleName(),
            cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0193_CODE));
        throw new InvalidDateFormatException(invalidEffectiveStartDate);
      }
      if (pouRegulation.getEffectiveEndDate() != null
          && !ConsentAdminUtil.isValidDate(pouRegulation.getEffectiveEndDate())) {
        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
            MDC.get(ConsentAdminServiceConstants.SERVICE),
            ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
            MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
            ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
            AppCountryCodeNotExistsException.class.getSimpleName(),
            cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0193_CODE));
        throw new InvalidDateFormatException(invalidEffectiveEndDate);
      }

      Date effStartDate = ConsentAdminUtil.parseDate(pouRegulation.getEffectiveStartDate());

      if (pouRegulation.getEffectiveEndDate() != null
          && effStartDate.after(ConsentAdminUtil.parseDate(pouRegulation.getEffectiveEndDate()))) {
        LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
            MDC.get(ConsentAdminServiceConstants.SERVICE),
            ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
            MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
            ConsentAdminServiceConstants.APP_ID_VALIDATION_ERROR,
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.getCopyOfContextMap().get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
            MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME),
            AppCountryCodeNotExistsException.class.getSimpleName(),
            cacheUtil.getErrorMessage(ConsentAdminServiceConstants.MSG0199_CODE));
        throw new ConsentBaseException(
            "Invalid effective end date. Effective end date cannot be before effective start date.");
      }

    }

  }

}
