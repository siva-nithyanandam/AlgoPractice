package com.ford.sca.consent.util;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.consent.transport.ConsentAdminRequest;
import com.ford.sca.consent.transport.ConsentAdminResponse;
import com.ford.sca.consent.transport.POURegulation;

@Component
public class MarshallUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(MarshallUtil.class);

    private static String className = MarshallUtil.class.getSimpleName();

    public String marshallCreateRequest(List<POURegulation> pouRegulationRequest) {
        String methodName = "marshallCreateRequest";
        LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
                ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                ConsentAdminServiceConstants.PROCESSING_STATUS,
                MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

        String jsonInString = null;
        ObjectMapper mapper = new ObjectMapper();
        // from Object to Json String
        try {
            jsonInString = mapper.writeValueAsString(pouRegulationRequest);
        } catch (Exception ex) {
            LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
                    MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
                    ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                    MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                    ConsentAdminServiceConstants.FAILED_STATUS,
                    MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getSimpleName(),
                    ex.getMessage(), ex);
        }
        return jsonInString;
    }

    public String marshallCreateRequest(ConsentAdminRequest consentAdminRequest) {
        String methodName = "marshallCreateRequest";
        LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
                ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                ConsentAdminServiceConstants.PROCESSING_STATUS,
                MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

        String jsonInString = null;
        ObjectMapper mapper = new ObjectMapper();
        // from Object to Json String
        try {
            jsonInString = mapper.writeValueAsString(consentAdminRequest);
        } catch (Exception ex) {
            LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
                    MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
                    ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                    MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                    ConsentAdminServiceConstants.FAILED_STATUS,
                    MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getSimpleName(),
                    ex.getMessage(), ex);
        }
        return jsonInString;
    }

    public String marshallCreateRequestforConsent(ConsentAdminRequest consentRequest) {
        String methodName = "marshallCreateRequestforConsent";
        LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
                ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                ConsentAdminServiceConstants.PROCESSING_STATUS,
                MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

        String jsonInString = null;
        ObjectMapper mapper = new ObjectMapper();
        // from Object to Json String
        try {
            jsonInString = mapper.writeValueAsString(consentRequest);
        } catch (Exception ex) {
            LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
                    MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
                    ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                    MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                    ConsentAdminServiceConstants.FAILED_STATUS,
                    MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getSimpleName(),
                    ex.getMessage(), ex);
        }
        return jsonInString;
    }

    public String marshallResponse(Object responseObj) {
        String methodName = "marshallResponse";
        LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
                ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
        String jsonInString = null;
        ObjectMapper mapper = new ObjectMapper();
        // from Object to Json String
        try {
            jsonInString = mapper.writeValueAsString(responseObj);
        } catch (Exception ex) {
            LOGGER.error(ConsentAdminServiceConstants.LOG_EXCEPTION,
                    MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
                    ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
                    MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
                    MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getSimpleName(),
                    ex.getMessage(), ex);
        }
        return jsonInString;
    }

}
