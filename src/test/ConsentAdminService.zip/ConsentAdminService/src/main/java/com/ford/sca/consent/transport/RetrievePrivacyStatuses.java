package com.ford.sca.consent.transport;

import java.util.Map;
import com.ford.sca.consent.domain.PrivacyStatusBO;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RetrievePrivacyStatuses extends GenericResponse {

  private Long privacyStatusCount;

  private Map<String, PrivacyStatusBO> privacyStatusMap;

}
