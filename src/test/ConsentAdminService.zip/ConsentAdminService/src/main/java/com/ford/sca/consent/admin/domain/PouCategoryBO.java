package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "MCNPC06_POU")
@Getter
@Setter
public class PouCategoryBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CNPC06_POU_K]")
  private Long pouKey;

  @Column(name = "[CNPC06_POU_D]")
  private Long pouId;

  @Column(name = "[CNPC06_DATA_CATG_D]")
  private String dataCategoryId;

  //@Column(name = "[CNPC02_COUNTRY_ISO3_C]")
  //private String countryCode;
}
