package com.ford.sca.consent.domain;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "[MCNPC14_EXPIRY_RULE]")
public class ConsentPrivacyExpiryRuleBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CNPC14_EXPIRY_RULE_SEQ_R]")
  private Long expiryRuleId;

  @Column(name = "[CNPC02_COUNTRY_ISO3_C]")
  private String countryCode;

  @Column(name = "[CNPC07_CONSENT_K]")
  private Long consentId;

  @Column(name = "[CNPC14_EXPIRY_TERM_R]")
  private Integer expiryTerm;

  @Column(name = "[CNPC14_STATUS_C]")
  private String privacyStatus;

  @Column(name = "[CNPC14_ACTION_F]")
  private String actionFlag;

}
