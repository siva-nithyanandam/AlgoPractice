package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "MCNPT01_NOTIFICATION_LOG", catalog = "SCACP", schema = "dbo")
public class NotificationLogBO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "[CNPT01_NOTIFICATION_SEQ_R]")
	private Long notificationSeq;
	
	@Column(name = "[CNPT01_APP_C]")
	private Integer appCode;
	
	@Column(name = "[CNPC02_COUNTRY_ISO3_C]")
	private String countryCode;
	
	@Column(name = "[CNPT01_LL_D]")
	private String lLId;
	
	@Column(name = "[CNPT01_EFF_FROM_S]")
	private Date effectiveFromTimeStamp;
	
	@Column(name = "[CNPT01_EFF_TO_S]")
	private Date effectiveToTimeStamp;
	
	@Column(name = "[CNPT01_SERVICE_N]")
	private String serviceName;
	
	@Column(name = "[CNPT01_TRANSACTION_S]")
	private Date transcationTimeStamp;
	
	@Column(name = "[CNPT01_RESOURCE_URI_X]")
	private String resourceUri;
	
	@Column(name = "[CNPT01_JSON_X]")
	private String requestBody;
	
	@Column(name = "[CNPT01_STATUS_C]")
	private boolean notifyStaus;
	
	@Column(name = "[CNPT01_ERROR_X]")
	private String errorMsg;
	
	@Column(name = "[CNPT01_TRACE_D]")
	private String traceId;
	
	@Column(name = "[CNPT01_CREATE_S]")
	private Date createDate;
	
	@Column(name = "[CNPT01_CREATE_USER_D]")
	private String createUser;
	
	@Column(name = "[CNPT01_CREATE_PROCESS_C]")
	private String createProcess;
	
	@Column(name = "[CNPT01_CREATE_APP_C]")
	private Integer createAppCode;
}
