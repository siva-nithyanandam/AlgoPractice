package com.ford.sca.consent.util;

public class ConsentAdminServiceConstants {

    public static final String NO_USERS_FOUND_IN_USER_POU_TABLE = "No Users Found in POU Table for the Country Code";
    public static final String NO_RECORDS_INSERTED_IN_USER_POU = "No Records Inserted in user POU Table";
    public static final String LOG_INFO = "serviceId={}, serviceGroup={}, correlationID={}, className={}, methodName={}, action={}, spanId={} , traceId={}, vcap_request_id={}, build_version={},request{}";
    public static final String LOG_EXCEPTION = "serviceId={}, serviceGroup={}, correlationID={}, className={}, methodName={}, action={}, spanId={} , traceId={}, vcap_request_id={}, build_version={},exceptionType={}, exceptionMessage={}, exception = {}";
    public static final String TRACE_ID_HEADER_NAME = "X-B3-TraceId";
    public static final String SPAN_ID_HEADER_NAME = "X-B3-SpanId";
    public static final String CORRELATION_ID_HEADER_NAME = "X-Correlation-ID";
    public static final String VCAP_REQUEST_HEADER_NAME = "X-Vcap-Request-Id";
    public static final String BUILD_VERSION_HEADER_NAME = "X-Build-Version";
    public static final String REQUEST_STATUS_SUCCESS = "SUCCESS";
    public static final String REQUEST_STATUS_FAILURE = "FAILURE";
    public static final String REQUEST_SERVICE_ID = "SERVICE_ID";
    public static final String AUDIT_SERVICE_REQUEST_ATTR_NAME = "auditServiceRequest";
    public static final String SPAN_ID_EVENT_HEADER = "spanId";
    public static final String SERVICE_GROUP_NAME = "ConsentAdminService";
    public static final String COLON_SLASHES = "://";
    public static final String COLON = ":";
    public static final String QUESTION_MARK = "?";
    public static final String HYPHEN = "-";
    public static final String TYPE_REQUEST = "Request";
    public static final String TYPE_RESPONSE = "Response";
    public static final String REQUEST_STATUS_NEW = "New";
    public static final String SERVICE = "service";
    public static final String LOG_EXCHANGE_NAME = "consent.log.exchange";
    public static final String LOG_ACTIVITY_ROUTING_KEY_NAME = "consent.log.activity";
    public static final String APP_ID = "appId";
    public static final String CALLING_SERVICE_NAME = "callingServiceName";
    public static final String EVENT_NAME_MP = "Maintain Marketing Profile";
    public static final String EVENT_TYPE = "eventType";
    public static final String EVENT_NAME = "eventName";
    public static final String EVENT_INITIATOR_NAME = "eventInitiatorName";
    public static final String USER_POU_FAILURE = "failed to insert in MCAPN02 Table";
    public static final String CREATE_SUCCESS = "Record Created Successfully";

    public static final String PROCESSING_STATUS = "processing";
    public static final String COMPLETED_STATUS = "completed";
    public static final String FAILED_STATUS = "failed";
    public static final String CONSNET_OPTIN_Y="Y";
    public static final String CONSNET_OPTIN_1="1";
    public static final String CONSNET_OPTOUT_0="0";
    public static final String CONSNET_OPTOUT_N="N";
    public static final String DATE_FORMAT = "yyyy-MM-dd";

    

    public static final String EVENT_REQUEST_TIMESTAMP = "evenRequestTimeStamp";
    public static final String QUEUE_NAME = "consent.event.mp.queue";
    public static final int HTTP_201_CODE = 201;
    public static final int HTTP_417_CODE = 417;
    public static final int HTTP_412_CODE = 412;
    public static final int HTTP_500_CODE = 500;
    public static final int HTTP_400_CODE = 400;
    public static final int HTTP_401_CODE = 401;
    public static final int HTTP_405_CODE = 405;
    public static final Float CAP_APP_CODE = 100547f;
    public static final String CAP_USER = "100547";
    public static final String CAP_PROCESS = "Consent Admin Service";

    public static final String MSG0010_CODE = "MSG-0010";

    public static final String MSG0001_CODE = "MSG-0001";

    public static final String MSG0002_CODE = "MSG-0002";
    public static final String MSG0009_CODE = "MSG-0009";

    public static final String MSG0159_CODE = "MSG-0159";
    public static final String MSG0042_CODE = "MSG-0042";
    public static final String MSG0045_CODE = "MSG-0045";
    public static final String MSG0116_CODE = "MSG-0116";
    public static final String MSG0129_CODE = "MSG-0129";
    public static final String MSG0025_CODE = "MSG-0025";

    public static final String MSG0033_CODE = "MSG-0033";
    public static final String MSG0156_CODE = "MSG-0156";
    public static final String MSG0157_CODE = "MSG-0157";
    public static final String MSG0158_CODE = "MSG-0158";
    public static final String MSG0163_CODE = "MSG-0163";
    public static final String MSG0170_CODE = "MSG-0170";
    public static final String MSG0171_CODE = "MSG-0171";
    public static final String MSG0172_CODE = "MSG-0172";
    public static final String MSG0190_CODE = "MSG-0190";
    public static final String MSG9998_CODE = "MSG-9998";
    public static final String MSG9997_CODE = "MSG-9997";

    public static final String MSG0193_CODE = "MSG-0193";
    public static final String MSG0194_CODE = "MSG-0194";
    public static final String MSG0195_CODE = "MSG-0195";
    public static final String MSG0197_CODE = "MSG-0197";
    public static final String MSG0199_CODE = "MSG-0199";
    public static final String MSG0208_CODE = "MSG-0208";
    public static final String MSG0206_CODE = "MSG-0206";

    public static final String MSG9999_CODE = "MSG-9999";
    public static final String INFINATE_DATE="9999-12-31";
    public static final String CCPA_STATUS_N="0";
    public static final String CCPA_STATUS_Y="1";
    

    public static final String APP_ID_VALIDATION_ERROR = "Error In AppID Validation";

    public static final String STATUS_FAILED = "FAILURE";

    public static final String ACTIVE_FLAG = "Y";
    
    public static final String UNDERSCORE = "_";
    
    public static final String DATE_FORMAT_YYYY_MM_DD_HR_MIN_SEC = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    public static final String OPTIN = "1";
    public static final String OPTOUT = "0";

    private ConsentAdminServiceConstants() {
        // empty constructor
    }

}
