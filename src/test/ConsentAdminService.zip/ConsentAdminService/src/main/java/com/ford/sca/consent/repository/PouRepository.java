package com.ford.sca.consent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.admin.domain.PouBO;

@Repository
public interface PouRepository extends JpaRepository<PouBO, Long> {

	PouBO findByPouId(Long pouId);

	PouBO findByPouKey(Long pouKey);

}