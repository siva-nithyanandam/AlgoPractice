package com.ford.sca.consent.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.ford.sca.consent.service.ConsentAdminService;
import com.ford.sca.consent.util.ConsentAdminServiceConstants;


@Configuration
@EnableScheduling
public class ConsentRegulationStatusBatchConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConsentRegulationStatusBatchConfig.class);
	private static String className = ConsentRegulationStatusBatchConfig.class.getSimpleName();

	@Autowired
	private ConsentAdminService consentAdminService;
	
	@Scheduled(cron="${CRON_JOB_SCHEDULER_CONSENTEXPIRY}")
	public void triggerScheduledJobForCheckingConsnetExpiry() {
		String methodName = "triggerScheduledJobForCheckingConsnetExpiry";
		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"Starting_triggerScheduledJobForCheckingConsnetExpiry", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));

		consentAdminService.updateExpiredConsentStatusBatch();

		LOGGER.info(ConsentAdminServiceConstants.LOG_INFO, MDC.get(ConsentAdminServiceConstants.REQUEST_SERVICE_ID),
				ConsentAdminServiceConstants.SERVICE_GROUP_NAME,
				MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME), className, methodName,
				"Completed_triggerScheduledJobForCheckingConsnetExpiry", MDC.get(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME),
				MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME));
	}
	
}
