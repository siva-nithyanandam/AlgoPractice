package com.ford.sca.consent.transport;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RetrieveConsentPrivaciesInfo extends GenericResponse {
  
  private Long consentPrivacyCounts;
  
  private List<RetrieveConsentPrivacy> consentPrivaciesList;

}
