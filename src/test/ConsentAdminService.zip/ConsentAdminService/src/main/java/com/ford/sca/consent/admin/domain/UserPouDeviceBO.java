package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Nationalized;

import lombok.Data;

@Entity
@Table(name = "[MCAPN03_USER_POU_DEVICE]", catalog = "SCACAP", schema = "dbo")
@Data
public class UserPouDeviceBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "[CAPN03_USER_POU_DEVICE_SEQ_R]")
  private Long userPouDeviceSeq;

  @ManyToOne
  @JoinColumn(name = "[CAPN02_USER_POU_SEQ_R]")
  private ConsentPouBO consentPouBO;

  @Column(name = "[CAPN03_DEVICE_TYPE_X]")
  @Nationalized
  private String deviceType;

  @Column(name = "[CAPN03_DEVICE_VALUE_X]")
  @Nationalized
  private String deviceValue;

  @Column(name = "[CAPN03_CREATE_S]")
  private Date createDate;

  @Column(name = "[CAPN03_CREATE_USER_D]")
  private String createUser;

  @Column(name = "[CAPN03_CREATE_PROCESS_C]")
  private String createProcess;

  @Column(name = "[CAPN03_CREATE_APP_C]")
  private Float createAppCode;

  @Column(name = "[CAPN03_UPDATE_S]")
  private Date updateDate;

  @Column(name = "[CAPN03_UPDATE_USER_D]")
  private String updateUser;

  @Column(name = "[CAPN03_UPDATE_PROCESS_C]")
  private String updateProcess;

  @Column(name = "[CAPN03_UPDATE_APP_C]")
  private Float updateAppCode;

  @Override
  public String toString() {
    return "UserPouDeviceBO [userPouDeviceSeq=" + userPouDeviceSeq + ", deviceType=" + deviceType
        + ", deviceValue=" + deviceValue + "]";
  }

}
