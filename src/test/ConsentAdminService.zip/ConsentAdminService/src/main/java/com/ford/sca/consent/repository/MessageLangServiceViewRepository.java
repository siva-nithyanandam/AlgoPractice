package com.ford.sca.consent.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.consent.domain.MessageLangServiceViewBO;

public interface MessageLangServiceViewRepository extends JpaRepository<MessageLangServiceViewBO, String> {

  Optional<MessageLangServiceViewBO> findFirstByMessageCode(String errorMsgId);
}
