package com.ford.sca.consent.repository;

import com.ford.sca.consent.domain.CountryLangBO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CountryLangRepository extends JpaRepository<CountryLangBO, String> {

  CountryLangBO findByPreferredLanguage(String preferredLanguage);

}
