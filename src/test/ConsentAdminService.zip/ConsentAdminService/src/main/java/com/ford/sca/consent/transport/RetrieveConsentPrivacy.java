package com.ford.sca.consent.transport;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RetrieveConsentPrivacy {
  
  private Long consentId;

  private Long pouKey;

  private String privacyCategory;

  private String privacyName;

  private String privacyDescription;

  private String privacyType;

  private String consentSystemName;


}
