package com.ford.sca.consent.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ford.sca.consent.admin.domain.POURegulationBO;

public interface POURegulationRepository extends JpaRepository<POURegulationBO, Integer> {

    List<POURegulationBO> findByPouIDAndAppCountryCode(String pouId, String countryCode);

    List<POURegulationBO> findByEffectiveStartDate(Date effectiveStartDate);

}
