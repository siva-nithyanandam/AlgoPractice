package com.ford.sca.consent.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import com.ford.sca.consent.admin.domain.NotificationLogBO;


public interface NotifyService {
	
	public void buildReport(String startDate, String endDate, Optional<String> mailTo);

	public List<NotificationLogBO> generateExcelAndPrepareListToUpdate(Date startDate, Date endDate);

}
