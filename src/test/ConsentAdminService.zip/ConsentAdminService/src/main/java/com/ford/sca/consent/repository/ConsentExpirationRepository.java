package com.ford.sca.consent.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import com.ford.sca.consent.admin.domain.ConsentExpirationBo;

@Transactional
public interface ConsentExpirationRepository extends JpaRepository<ConsentExpirationBo, Long>{

	public ConsentExpirationBo findByConsentIdAndConsentCountry(Long consentId, String countryCode);
	public List<ConsentExpirationBo> findByActionFlag(String actionFlag);
	
	@Modifying
	  @Query("update ConsentExpirationBo u set u.actionFlag = ?1 where "
	      + "u.consentExpirationId = ?2")
	public void updateActionFlag(String actionFlag,Long consentExpirationId);
	

}
