package com.ford.sca.consent.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.admin.domain.ConsentPermissionBO;


@Repository
public interface ConsentPermissionRepository extends JpaRepository<ConsentPermissionBO, Long> {

	List<ConsentPermissionBO> findByEndDateAndEndDateNotNullOrderByCreateDateDesc(Date currentDate);
	List<ConsentPermissionBO> findByConsentKeyAndCountryCode(Long consentKey,String countryCode);
	
	
}
