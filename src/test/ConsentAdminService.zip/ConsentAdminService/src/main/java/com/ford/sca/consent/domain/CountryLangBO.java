package com.ford.sca.consent.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

@Entity
@Setter
@Getter
@Table(name = "[MCNPC05_COUNTRY_LANG]")
public class CountryLangBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CNPC05_COUNTRY_LANG_C]")
  private String preferredLanguage;

  @Column(name = "[CNPC02_COUNTRY_ISO2_C]")
  private String countryISOCode;

  @Column(name = "[CNPC05_LANG_ISO2_C]")
  private String languageISOCode;

  @Nationalized
  @Column(name = "[CNPC05_COUNTRY_LANG_N]")
  private String preferredLanguageName;

}
