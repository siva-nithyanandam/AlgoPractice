package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "MCNPP01_CONSENT_PERMISSION")
@Getter
@Setter
@ToString
public class ConsentPermissionBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "[CNPP01_CONSENT_PERMISSION_K]")
  private Long consentPermissionKey;

  @Column(name = "[CNPN01_CONSENT_LL_K]")
  private Long consentLlKey;

  @Column(name = "[CNPC07_CONSENT_K]")
  private Long consentKey;

  @Column(name = "[CNPC01_APP_C]")
  private Integer srcCode;

  @Column(name = "[CNPC01_SEC_APP_C]")
  private Integer secondarySrcCode;

  @Column(name = "[CNPC02_COUNTRY_ISO3_C]")
  private String countryCode;

  @Column(name = "[CNPC04_STATUS_C]")
  private String statusCode;

  @Column(name = "[CNPD01_DEVICE_D]")
  private Long deviceId;

  @Column(name = "[CNPC03_DEVICE_TYPE_D]")
  private Long deviceType;

  @Column(name = "[CNPP01_PERMISSION_S]")
  private Date receivedTimeStamp;

  @Column(name = "[CNPP01_CREATE_S]")
  private Date createDate;

  @Column(name = "[CNPP01_CREATE_USER_D]")
  private String createUser;

  @Column(name = "[CNPP01_CREATE_PROCESS_C]")
  private String createProcess;

  @Column(name = "[CNPP01_CREATE_APP_C]")
  private Integer createAppCode;

  @Column(name = "[CNPP01_UPDATE_S]")
  private Date updateDate;

  @Column(name = "[CNPP01_UPDATE_USER_D]")
  private String updateUser;

  @Column(name = "[CNPP01_UPDATE_PROCESS_C]")
  private String updateProcess;

  @Column(name = "[CNPP01_UPDATE_APP_C]")
  private Integer updateAppCode;

  @Column(name = "CNPP01_SCA_D")
  private String scaId;

  @Column(name = "CNPP01_USER_D")
  private String guid;

  @Column(name = "CNPP01_START_S")
  private Date startDate;

  @Column(name = "CNPP01_END_S")
  private Date endDate;

  @Column(name = "CNPP01_CAPTURED_S")
  private Date capturedTimeStamp;
  
  @Override
  public boolean equals(Object o) {
      if (this == o)
          return true;
      if (o == null || getClass() != o.getClass())
          return false;
      ConsentPermissionBO other = (ConsentPermissionBO) o;
      return Objects.equals(srcCode, other.srcCode) && Objects.equals(countryCode, other.countryCode)
              && Objects.equals(consentKey, other.consentKey)&&Objects.equals(deviceId, other.deviceId);
  }

  @Override
  public int hashCode() {
      return Objects.hash(srcCode, countryCode, consentKey,deviceId);
  }

}
