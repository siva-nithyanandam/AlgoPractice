package com.ford.sca.consent.statics;

public enum RequestMode {
  CREATE, UPDATE;
}
