package com.ford.sca.consent.transport;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RetrieveAppCodeGroupsInfo extends GenericResponse {

  private Long appCodeGroupCounts;

  private List<RetrieveAppCodeGroup> retrieveAppCodeGroupList;


}
