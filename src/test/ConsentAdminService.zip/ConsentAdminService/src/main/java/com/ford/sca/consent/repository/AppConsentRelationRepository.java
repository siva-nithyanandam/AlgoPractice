package com.ford.sca.consent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.sca.consent.domain.AppConsentRelationBO;
import com.ford.sca.consent.domain.AppConsentRelationPK;

@Repository
public interface AppConsentRelationRepository
    extends JpaRepository<AppConsentRelationBO, AppConsentRelationPK> {

  public AppConsentRelationBO findByAppConsentRelationPK_appIdAndAppConsentRelationPK_consentId(
      Integer appId, Long consentId);

}
