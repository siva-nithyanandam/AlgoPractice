package com.ford.sca.consent.admin.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MCAPC19_CONSENT_STATUS", catalog = "SCACAP", schema = "dbo")
public class ConsentStatusBO implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[CAPC19_CONSENT_STATUS_C]")
  private String consentStatus;

  @Column(name = "[CAPC19_CONSENT_STATUS_X]")
  private String consentStatusDescription;

  @Column(name = "[CAPC19_CREATE_S]")
  private Date createTimestamp;

  @Column(name = "[CAPC19_CREATE_USER_D]")
  private String createUser;

  @Column(name = "[CAPC19_CREATE_PROCESS_C]")
  private String createProcess;

  @Column(name = "[CAPC19_CREATE_APP_C]")
  private Float appID;

  @Column(name = "[CAPC19_UPDATE_S]")
  private Date updateTimeStamp;

  @Column(name = "[CAPC19_UPDATE_USER_D]")
  private String updateUser;

  @Column(name = "[CAPC19_UPDATE_PROCESS_C]")
  private String updateProcess;

  @Column(name = "[CAPC19_UPDATE_APP_C]")
  private Float updateAppID;

  public String getConsentStatus() {
    return consentStatus;
  }

  public void setConsentStatus(String consentStatus) {
    this.consentStatus = consentStatus;
  }

  public String getConsentStatusDescription() {
    return consentStatusDescription;
  }

  public void setConsentStatusDescription(String consentStatusDescription) {
    this.consentStatusDescription = consentStatusDescription;
  }

  public Date getCreateTimestamp() {
    return createTimestamp;
  }

  public void setCreateTimestamp(Date createTimestamp) {
    this.createTimestamp = createTimestamp;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public String getCreateProcess() {
    return createProcess;
  }

  public void setCreateProcess(String createProcess) {
    this.createProcess = createProcess;
  }



  public Date getUpdateTimeStamp() {
    return updateTimeStamp;
  }

  public void setUpdateTimeStamp(Date updateTimeStamp) {
    this.updateTimeStamp = updateTimeStamp;
  }

  public String getUpdateUser() {
    return updateUser;
  }

  public void setUpdateUser(String updateUser) {
    this.updateUser = updateUser;
  }

  public String getUpdateProcess() {
    return updateProcess;
  }

  public void setUpdateProcess(String updateProcess) {
    this.updateProcess = updateProcess;
  }

  public Float getAppID() {
    return appID;
  }

  public void setAppID(Float appID) {
    this.appID = appID;
  }



}
