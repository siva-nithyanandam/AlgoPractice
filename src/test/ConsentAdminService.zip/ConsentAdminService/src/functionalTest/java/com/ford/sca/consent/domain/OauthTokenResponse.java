package com.ford.sca.consent.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OauthTokenResponse {

  private String access_token;
  private String token_type;
  private Integer expires_in;
  private String ext_expires_in;
  private String expires_on;
  private String not_before;
  private String scope;
  private String jti;
}
