package com.ford.sca.consent.util;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

@RunWith(MockitoJUnitRunner.class)
public class ResponseBuilderTest {

	@Mock
	private CacheUtil cacheUtil;

	@InjectMocks
	private ResponseBuilder responseBuilder;

	@Test
	public void testConstructResponse() {
		MDC.setContextMap(new HashMap<>());
		responseBuilder.constructResponse("MSG-0001");
	}

}
