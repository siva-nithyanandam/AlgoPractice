package com.ford.sca.consent.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;
import org.springframework.test.util.ReflectionTestUtils;

import com.ford.sca.consent.transport.AuditServiceRequest;
import com.ford.sca.consent.transport.ConsentAdminRequest;
import com.ford.sca.consent.transport.ConsentAdminResponse;
import com.ford.sca.consent.transport.POURegulation;

@RunWith(MockitoJUnitRunner.class)
public class AuditActivityUtilTest {

	@InjectMocks
	private AuditActivityUtil auditActivityUtil = new AuditActivityUtil();

	@Mock
	private HttpServletRequest request;

	@Mock
	private HttpServletResponse response;

	@Mock
	private MarshallUtil marshallUtil;

	@Test
	public void createAuditServiceRequest() {
		// assertNotNull(auditActivityUtil.createAuditServiceRequest(request, new
		// RuleEngineRequest()));
	}

	@Mock
	AuditServiceRequest auditServiceRequest;

	@Mock
	ConsentAdminResponse consentAdminResponse;

	@Test
	public void createAuditServiceRequestforConsent() {
		assertNotNull(auditActivityUtil.createAuditServiceRequestforConsent(request, new ConsentAdminRequest()));
	}

	@Test
	public void createAuditServiceResponse() {
		// assertNotNull(auditActivityUtil.createAuditServiceResponse(auditServiceRequest,
		// new ArrayList<>()));
	}

	@Test
	public void populateMDCParameters_whenCorrelationID() {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		when(request.getHeader(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME)).thenReturn("123");
		when(request.getHeader(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME)).thenReturn("headerName");
		auditActivityUtil.setRequestHeader(request);
		assertEquals("123", MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME));
		assertEquals("headerName", MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME));
	}

	@Test
	public void populateMDCParameters_whenNullCorrelationID() {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		when(request.getHeader(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME)).thenReturn(null);
		when(request.getHeader(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME)).thenReturn("headerName");
		auditActivityUtil.setRequestHeader(request);
		assertNotNull(MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME));
		assertEquals("headerName", MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME));
	}

	@Test
	public void populateMDCParameters_whenNoCorrelationIDAndLongDataCenterName() {
		ReflectionTestUtils.setField(auditActivityUtil, "dataCenter", "datCenterName");
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		when(request.getHeader(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME)).thenReturn("");
		when(request.getHeader(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME)).thenReturn("headerName");
		auditActivityUtil.setRequestHeader(request);
		assertNotNull(MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME));
		assertEquals("headerName", MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME));
		assertTrue(MDC.get(ConsentAdminServiceConstants.BUILD_VERSION_HEADER_NAME).contains("-da-"));
	}

	@Test
	public void populateMDCParameters_whenNoCorrelationIDAndShortDataCenterName() {
		ReflectionTestUtils.setField(auditActivityUtil, "dataCenter", "Y");
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		when(request.getHeader(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME)).thenReturn("");
		when(request.getHeader(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME)).thenReturn("headerName");
		auditActivityUtil.setRequestHeader(request);
		assertNotNull(MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME));
		assertEquals("headerName", MDC.get(ConsentAdminServiceConstants.VCAP_REQUEST_HEADER_NAME));

	}

	@Test
	public void testCreateAuditServiceResponse() {
		auditActivityUtil.createAuditServiceResponse(auditServiceRequest, consentAdminResponse);
	}

	@Test
	public void testCreateAuditServiceRequest() {
		List<POURegulation> pouRegulationList = new ArrayList<>();
		POURegulation pouRegulation = new POURegulation();
		pouRegulation.setPouID(1002);
		pouRegulationList.add(pouRegulation);
		assertNotNull(auditActivityUtil.createAuditServiceRequest(request, pouRegulationList));
	}

	@Test
	public void testCreateAuditRequest() {
		ConsentAdminRequest consentAdminRequest = new ConsentAdminRequest();
		assertNotNull(auditActivityUtil.createAuditServiceRequest(request, consentAdminRequest, "100504"));
	}

	@Test
	public void testCreateAuditServiceFailureResponse() {
		assertNotNull(
				auditActivityUtil.createAuditServiceFailureResponse(auditServiceRequest, consentAdminResponse, 417));
	}

	@Test
	public void testHttpServletResponseHeaders() {
		auditActivityUtil.setHttpServletResponseHeaders(response);
	}

}
