package com.ford.sca.consent.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;

import com.ford.sca.consent.transport.AuditServiceRequest;
import com.ford.sca.consent.transport.ConsentAdminFailureResponse;
import com.ford.sca.consent.util.AuditActivityUtil;
import com.ford.sca.consent.util.PublishAuditMessageUtil;
import com.ford.sca.consent.util.ResponseBuilder;



@RunWith(MockitoJUnitRunner.class)
public class GlobalExceptionHandlerTest {

	@InjectMocks
	GlobalExceptionHandler globalExceptionHandler;

	@Mock
	private ResponseBuilder responseBuilder;

	@Mock
	private AuditActivityUtil auditActivityUtil;

	@Mock
	private PublishAuditMessageUtil publishAuditMessageUtil;

	@Mock
	private HttpServletRequest request;

	@Mock
	private HttpServletResponse response;

	@Mock
	private ConsentAdminFailureResponse consentAdminFailureResponse;

	@Mock
	AuditServiceRequest auditServiceRequest;
	
	@Before
	public void setUp() {
	}

	@Test
	public void testReqFieldsMissingException() {

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.reqFieldsMissingException(response, request);
	}

	@Test
	public void testMissingPouFieldsException() {

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.missingPouFieldsException(response, request);
	}

	@Test
	public void testInvalidPouIdException() {

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.InvalidPouIdException(response, request);
	}

	@Test
	public void testInvalidDateFormatException() {

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.InvalidDateFormatException(response, request);
	}

	@Test
	public void testStartDateAfterEndDateException() {

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.startDateAfterEndDateException(response, request);
	}

	@Test
	public void testInvalidPouStatusException() {

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.invalidPouStatusException(response, request);
	}

	@Test
	public void testAppCountryCodeNotExistsException() {

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.appCountryCodeNotExistsException(response, request);
	}

	@Test
	public void testHttpMessageNotReadableException() {

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.httpMessageNotReadableException(response, request);
	}

	@Test
	public void testApplicationException() {
		MDC.setContextMap(new HashMap<>());

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.applicationException(response, request, new Exception(Mockito.anyString()));
	}

	@Test
	public void testHandleAccessDeniedException() {

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.handleAccessDeniedException(response, request,
				new AccessDeniedException(Mockito.anyString()));
	}

	@Test
	public void testHandleHttpRequestMethodNotSupportedException() {

		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.handleHttpRequestMethodNotSupportedException(response, request,
				new HttpRequestMethodNotSupportedException("method not supported"));
	}

	@Test
	public void testMissingServletRequestParameterException() {
		MDC.setContextMap(new HashMap<>());
		Mockito.when(responseBuilder.constructResponse(Mockito.anyString())).thenReturn(consentAdminFailureResponse);
		globalExceptionHandler.missingServletRequestParameterException(new Exception(Mockito.anyString()), response,
				request);
	}
}
