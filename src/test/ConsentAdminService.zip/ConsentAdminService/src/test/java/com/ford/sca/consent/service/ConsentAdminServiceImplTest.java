/*package com.ford.sca.cap.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

import com.ford.sca.cap.domain.ConsentPouBO;
import com.ford.sca.cap.domain.CountryCodeBO;
import com.ford.sca.cap.domain.POURegulationBO;
import com.ford.sca.cap.domain.PurposeOfUse;
import com.ford.sca.cap.domain.UserPouDeviceBO;
import com.ford.sca.cap.repository.ConsentPouRepository;
import com.ford.sca.cap.repository.CountryCodeRepository;
import com.ford.sca.cap.repository.POURegulationRepository;
import com.ford.sca.cap.repository.PurposeOfUseRepository;
import com.ford.sca.cap.transport.ConsentAdminRequest;
import com.ford.sca.cap.transport.POURegulation;
import com.ford.sca.cap.util.ConsentAdminUtil;
@RunWith(MockitoJUnitRunner.Silent.class)
public class  ConsentAdminServiceImplTest {

    @Mock
    public ConsentPouRepository consentPouN02Repository;

    @Mock
    public POURegulationRepository pouRegulationRepository;

    @Mock
    public CountryCodeRepository countryCodeRepository;

    @Mock
    public PurposeOfUseRepository purposeOfUseRepository;

    @Mock
    ConsentAdminRequest consentAdminRequest;

    @Mock
    @Autowired
    POURegulation pou;

    @Mock
    List<POURegulation> list;

    @Mock
    List<ConsentPouBO> boList;

    @Mock
    List<PurposeOfUse> pouList;

    @Mock
    ConsentPouBO pouBO;

    @Mock
    private HttpServletResponse response;

    @Mock
    CountryCodeBO countryBO;
    
 
    @Mock
    List<POURegulationBO> pouRegBOList;


    @InjectMocks
    ConsentAdminServiceImpl service;
    
    
    @Mock
    POURegulationBO pouRegBO;
    
    @Mock
    Map<String,List<POURegulationBO>> pouRegmap;
    
    List<POURegulationBO> pouRegList;
    
    @Mock
    ConsentAdminUtil consentAdminUtil;
    
    List<UserPouDeviceBO> userDeviceList=new ArrayList();

    @Before 
    public void setUp(){
        list = new ArrayList();
        boList = new ArrayList();
        
        UserPouDeviceBO userPouDevice = new UserPouDeviceBO();
        userPouDevice.setDeviceType("phone");
        userPouDevice.setDeviceValue("123456789");
        userDeviceList.add(userPouDevice);

        pou.setEffectiveStartDate("2019-04-11T00:00:00.000Z");
        list.add(pou);
        //pouBO.setCapUserID("test");
        pouBO.setCapUserID("1234454365363y6363636");
        pouBO.setPouID(1001);
        pouBO.setUserPouDevices(userDeviceList);
        ConsentPouBO pouBO1=new ConsentPouBO();
       // pouBO1.setCapUserID("test");
        pouBO1.setCapUserID("1234454365363y6363636");
        pouBO1.setPouID(1001);
        pouBO1.setUserPouDevices(userDeviceList);
        boList.add(pouBO);
        boList.add(pouBO1);

        pouList = new ArrayList();
        pouList.add(new PurposeOfUse());
        
        pouRegBOList = new ArrayList();
        pouRegBO.setAppCountryCode("USA");
        pouRegBO.setPouID(1001);
        pouRegBOList.add(pouRegBO);
        
        
        pouRegList=new ArrayList();
        POURegulationBO  pouRegulationBO=new POURegulationBO();
        pouRegulationBO.setAppCountryCode("USA");
        pouRegulationBO.setPouID(1001);
        pouRegulationBO.setCreateAppCode(Float.parseFloat("100504"));
        pouRegulationBO.setEffectiveStartDate(consentAdminUtil.parseDate("2019-05-02T00:00:00.000Z"));
        pouRegulationBO.setCreateUser(null);
        POURegulationBO  pouRegulationBO1=new POURegulationBO();
        pouRegulationBO1.setAppCountryCode("USA");
        pouRegulationBO1.setPouID(1002);
        pouRegulationBO1.setCreateAppCode(Float.parseFloat("100504"));
        pouRegulationBO1.setEffectiveStartDate(consentAdminUtil.parseDate("2019-05-01T00:00:00.000Z"));
        pouRegulationBO1.setCreateUser("test");
        pouRegList.add(pouRegulationBO);
        pouRegList.add(pouRegulationBO1);
        
    }

    @Test
    public void testCreateOrUpdatePOURegulationData()	{
        Mockito.when(pouRegulationRepository.saveAll(Mockito.anyList())).thenReturn(null);
        service.createOrUpdatePOURegulationData("USA", "100504", list,response);
    }

    @Test
    public void testCreateOrUpdateUserPOUData()	{
        Mockito.when(consentPouN02Repository.saveAll(Mockito.anyList())).thenReturn(null);
        Mockito.when(service.findAllUserIdsByCountryCode("USA")).thenReturn(boList);
        Mockito.when(pou.getEffectiveStartDate()).thenReturn("2019-05-02T00:00:00.000Z");
        service.createOrUpdateUserPOUData(list, "USA", "100504", response);
    }
    
    @Test
    public void testCreateOrUpdateUserPOUDataBeforDate() {
        Mockito.when(consentPouN02Repository.saveAll(Mockito.anyList())).thenReturn(null);
        Mockito.when(service.findAllUserIdsByCountryCode("USA")).thenReturn(boList);
        Mockito.when(pou.getEffectiveStartDate()).thenReturn("2019-05-01T00:00:00.000Z");
        service.createOrUpdateUserPOUData(list, "USA", "100504", response);
    }

    @Test
    public void testIsAppCountryCodeValid() {
        Mockito.when(countryCodeRepository.findByIso3CodeCountry(Mockito.anyString())).thenReturn(countryBO);
        service.isAppCountryCodeValid("USA");
    }

    @Test
    public void testIsAppCountryCodeEmpty() {
        Mockito.when(countryCodeRepository.findByIso3CodeCountry(Mockito.anyString())).thenReturn(null);
        service.isAppCountryCodeValid("UA");
    }
    @Test
    public void isPouIDValid() {
        Mockito.when(purposeOfUseRepository.findByPouId(1001)).thenReturn(pouList);
        service.isPouIDValid(1001);
    }
    
    @Test
    public void isPouIDEmpty() {
        List<PurposeOfUse> pouList1 = new ArrayList();
        Mockito.when(purposeOfUseRepository.findByPouId(Mockito.anyInt())).thenReturn(pouList1);
        service.isPouIDValid(1001);
    }
    
    @Test
    public void isPouIDNull() {
        Mockito.when(purposeOfUseRepository.findByPouId(Mockito.anyInt())).thenReturn(null);
        service.isPouIDValid(1001);
    }

    @Test
    public void testCreateOrUpdateUserPOUData2() {
        Mockito.when(countryCodeRepository.findByIso3CodeCountry(Mockito.anyString())).thenReturn(null);
        Mockito.when(service.findAllUserIdsByCountryCode("USA")).thenReturn(boList);
        Mockito.when(pouRegulationRepository.saveAll(Mockito.anyList())).thenReturn(null);
        Mockito.when(service.findAllUserIdsByCapUserIdAndPouId(Mockito.anyString(),Mockito.anyInt())).thenReturn(boList);
        service.groupPOUIdByCountryCode(pouRegList);
        service.processPOUDataByCurrentDate();
        ReflectionTestUtils.invokeMethod(service, "addDevicesToUserPouBO", new Object[]{Float.parseFloat("100504"),new ConsentPouBO(),userDeviceList});
        service.createOrUpdateUserPOUData(pouRegList, "USA");
        
    }
    
    
    @Test
    public void testCreateOrUpdateUserPOUData3() {
        Mockito.when(countryCodeRepository.findByIso3CodeCountry(Mockito.anyString())).thenReturn(null);
        Mockito.when(service.findAllUserIdsByCountryCode("USA")).thenReturn(boList);
        Mockito.when(pouRegulationRepository.saveAll(Mockito.anyList())).thenReturn(null);
        Mockito.when(service.findAllUserIdsByCapUserIdAndPouId(Mockito.anyString(),Mockito.anyInt())).thenReturn(null);
        service.createOrUpdateUserPOUData(pouRegList, "USA");
    }
    
    @Test
    public void testCreateOrUpdateUserPOUData4() {
        Mockito.when(countryCodeRepository.findByIso3CodeCountry(Mockito.anyString())).thenReturn(null);
        Mockito.when(service.findAllUserIdsByCountryCode("USA")).thenReturn(boList);
        Mockito.when(pouRegulationRepository.saveAll(Mockito.anyList())).thenReturn(null);
        ConsentPouBO consentPouBO=null;
        List<ConsentPouBO> consentList=new ArrayList();
        consentList.add(consentPouBO);
        Mockito.when(service.findAllUserIdsByCapUserIdAndPouId(Mockito.anyString(),Mockito.anyInt())).thenReturn(consentList);
        service.createOrUpdateUserPOUData(pouRegList, "USA");
    }
    
    
    @Test
    public void testCreateOrUpdateUserPOUData3() {
        Mockito.when(countryCodeRepository.findByIso3CodeCountry(Mockito.anyString())).thenReturn(null);
        Mockito.when(service.findAllUserIdsByCountryCode("USA")).thenReturn(boList);
       // Mockito.when(pou.getEffectiveStartDate()).thenReturn("2019-04-11T00:00:00.000Z");
        Mockito.when(pouRegulationRepository.saveAll(Mockito.anyList())).thenReturn(null);
        service.groupPOUIdByCountryCode(pouRegList);
        service.processPOUDataByCurrentDate();
        service.createOrUpdateUserPOUData(pouRegList, "USA");
    }
    
    
    @Test
    public void testFindAllUserIdsByCapUserIdAndPouId() {  
        
        Mockito.when(consentPouN02Repository.saveAll(Mockito.anyList())).thenReturn(boList);
        Mockito.when(service.findAllUserIdsByCountryCode("USA")).thenReturn(boList);
        service.findAllUserIdsByCapUserIdAndPouId(Mockito.anyString(), Mockito.anyInt());
        
        service.createOrUpdateUserPOUData(list, "USA", "100504", response);
    }
    

}
*/