package com.ford.sca.consent.messaging;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.UnsupportedEncodingException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import com.ford.sca.consent.transport.MessageHeaders;
@RunWith(MockitoJUnitRunner.class)
public class SenderTest {
	@InjectMocks
	private Sender sender=new Sender();
	 @Mock
	    private RabbitTemplate rabbitTemplate;
	 @Mock
	 private MessageHeaders messageHeaders;
	  @Before
	    public void setUp() {
	        MockitoAnnotations.initMocks(this);
	        Mockito.doNothing().when(rabbitTemplate).send(any(String.class), any(Message.class));
	        messageHeaders.setAppId(100547f);
	        messageHeaders.setEventInitiatorName("Climes Rule engine");
	        messageHeaders.setEventName("ClimesRuleEngine");
	    }
	  @Test
	    public void sendTest() throws UnsupportedEncodingException {
	        String requestJson = "Dummy Json String";
	        sender.send(requestJson,messageHeaders);
	        verify(rabbitTemplate, times(1)).send(any(String.class), any(Message.class));
	    }

}
