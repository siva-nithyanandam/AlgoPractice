package com.ford.sca.consent.messaging;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import com.ford.sca.consent.messaging.RabbitMqSender;
import com.ford.sca.consent.transport.MQDetails;
import java.nio.charset.Charset;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class RabbitMqSenderTest {

  @InjectMocks
  private RabbitMqSender rabbitMqSender;

  @Mock
  private RabbitTemplate rabbitTemplate;

  @Test
  public void test_rabbitSender_send_success() {
    //GIVEN
    String requestJson = "Dummy Json String";
    Message message = new Message(requestJson.getBytes(Charset.defaultCharset()), new MessageProperties());
    doNothing().when(rabbitTemplate).send(Mockito.any(), Mockito.any(), Mockito.any());
    //WHEN
    rabbitMqSender.send(MQDetails.SCA_C_EVENT, message);
    //THEN
    verify(rabbitTemplate, times(1)).send(Mockito.any(), Mockito.any(), Mockito.any());
  }

  @Test
  public void test_rabbitSender_send_failure1() {
    //GIVEN
    doNothing().when(rabbitTemplate).send(Mockito.any(), Mockito.any(), Mockito.any());
    //WHEN
    rabbitMqSender.send(MQDetails.SCA_C_EVENT, null);
    //THEN
    verify(rabbitTemplate, times(0)).send(Mockito.any(), Mockito.any(), Mockito.any());
  }

  @Test
  public void test_rabbitSender_send_failure2() {
    //GIVEN
    doNothing().when(rabbitTemplate).send(Mockito.any(), Mockito.any(), Mockito.any());
    //WHEN
    rabbitMqSender.send(null, null);
    //THEN
    verify(rabbitTemplate, times(0)).send(Mockito.any(), Mockito.any(), Mockito.any());
  }
}
