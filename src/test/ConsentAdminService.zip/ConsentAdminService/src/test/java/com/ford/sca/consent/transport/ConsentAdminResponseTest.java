package com.ford.sca.consent.transport;

import org.junit.Test;
import org.meanbean.test.BeanTester;

public class ConsentAdminResponseTest {

  @Test
  public void getterAndSetterCorrectness() {
    new BeanTester().testBean(ConsentAdminResponse.class);
  }



}
