package com.ford.sca.consent.domain;

import org.junit.Test;
import org.meanbean.test.BeanTester;
import com.ford.sca.consent.admin.domain.ConsentPouBO;

public class ConsentPOUBOTest {
  @Test
  public void getterAndSetterCorrectness() {
    new BeanTester().testBean(ConsentPouBO.class);
  }
}
