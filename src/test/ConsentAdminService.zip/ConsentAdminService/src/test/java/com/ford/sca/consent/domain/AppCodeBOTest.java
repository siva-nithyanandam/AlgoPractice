package com.ford.sca.consent.domain;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AppCodeBOTest {

  @Spy
  private AppCodeBO appCodeBO;

  @Test
  public void test_all_the_fields() {
    appCodeBO.setAppId(100432);
    appCodeBO.setAppName("Test");

    Assert.assertNotNull(appCodeBO.getAppId());
    Assert.assertNotNull(appCodeBO.getAppName());
  }
}
