package com.ford.sca.consent.domain;

import org.junit.Test;
import org.meanbean.test.BeanTester;

public class CountryCodeBOTest {
  @Test
  public void getterAndSetterCorrectness() {
    new BeanTester().testBean(CountryCodeBO.class);
  }


}
