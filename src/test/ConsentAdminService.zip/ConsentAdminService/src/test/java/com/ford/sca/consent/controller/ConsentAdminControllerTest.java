/*package com.ford.sca.cap.controller;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;

import com.ford.sca.cap.service.ConsentAdminService;
import com.ford.sca.cap.transport.AuditServiceRequest;
import com.ford.sca.cap.transport.ConsentAdminRequest;
import com.ford.sca.cap.transport.ConsentAdminResponse;
import com.ford.sca.cap.transport.POURegulation;
import com.ford.sca.cap.util.AuditActivityUtil;
import com.ford.sca.cap.util.ConsentAdminServiceValidator;
import com.ford.sca.cap.util.MarshallUtil;
import com.ford.sca.cap.util.PublishAuditMessageUtil;
import com.ford.sca.cap.util.ResponseGenerator;

@RunWith(MockitoJUnitRunner.class)
public class ConsentAdminControllerTest {
	private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	@InjectMocks
	ConsentAdminController consentAdminController;
	
	@Mock
	HttpServletRequest request;
	
	@Mock
	HttpServletResponse response;
	
	@Mock
	AuditServiceRequest auditServiceRequest;
	
	@Mock
	ConsentAdminRequest consentAdminRequest;
	
	@Mock
	POURegulation pouRegulation;
	
	@Mock
	List<POURegulation> pouRegulationList;
	
	@Mock
	private AuditActivityUtil auditActivityUtil;
	
	@Mock
	private MarshallUtil marshallUtil;
	
	@Mock
	private ConsentAdminService consentAdminService;
	
	@Mock
	private ConsentAdminServiceValidator consentAdminServiceValidator;
	
	@Mock
	  private PublishAuditMessageUtil publishAuditMessageUtil;
	
	@Mock
	 private ResponseGenerator responseGenerator;
	 
	@Mock
	private ConsentAdminResponse consentAdminResponse;
	
	@Before
    public void setUp(){
		pouRegulationList=new ArrayList();
		pouRegulationList.add(new POURegulation());
		consentAdminRequest=new ConsentAdminRequest();
		consentAdminRequest.setPouRegulationList(pouRegulationList);
	}

	@Test
	public void testCreateOrUpdateUserPou(){
		Mockito.when(auditActivityUtil.createAuditServiceRequest(request, pouRegulationList)).thenReturn(auditServiceRequest);
		Mockito.when(consentAdminService.createOrUpdateUserPOUData(consentAdminRequest, "USA", "100504", response)).thenReturn(consentAdminResponse);
		consentAdminController.createOrUpdateUserPou(consentAdminRequest,"USA","100504", request, response);
	}
}
*/