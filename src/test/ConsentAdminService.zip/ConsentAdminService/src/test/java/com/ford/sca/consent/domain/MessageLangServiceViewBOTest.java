package com.ford.sca.consent.domain;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MessageLangServiceViewBOTest {

  @Spy
  private MessageLangServiceViewBO messageLangServiceViewBO;

  @Test
  public void test_all_the_fields() {
    messageLangServiceViewBO.setMessageDesc("test");
    messageLangServiceViewBO.setMessageCode("test");
    Assert.assertNotNull(messageLangServiceViewBO.getMessageDesc());
    Assert.assertNotNull(messageLangServiceViewBO.getMessageCode());
  }
}
