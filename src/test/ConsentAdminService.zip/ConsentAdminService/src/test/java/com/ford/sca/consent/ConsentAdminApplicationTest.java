package com.ford.sca.consent;

import static org.junit.Assert.assertNotNull;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.ford.sca.consent.ConsentAdminApplication;

public class ConsentAdminApplicationTest {

  @Spy
  ConsentAdminApplication consentAdminApplicationTest;

  @Test
  public void testNewsApi() {
    Assert.assertNotNull(consentAdminApplicationTest.newsApi());
  }

  @Test
  public void testGlobalMethodSecurityConfiguration() {
    Assert.assertNotNull(consentAdminApplicationTest.globalMethodSecurityConfiguration());
  }

  @Before
  public void setUp() throws Exception {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testGlobal() {
    assertNotNull(consentAdminApplicationTest.globalMethodSecurityConfiguration()
        .preInvocationAuthorizationAdvice());
  }
}
