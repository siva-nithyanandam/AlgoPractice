package com.ford.sca.consent.exception;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import com.ford.sca.consent.exception.ConsentRuntimeException;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ConsentRuntimeExceptionTest {

  @Test
  public void test_instance() {
    ConsentRuntimeException consentRuntimeException = new ConsentRuntimeException("sample",
        new NullPointerException("test"));
    Assert.assertEquals("sample", consentRuntimeException.getMessage());
    Assert.assertTrue(consentRuntimeException.getCause() instanceof NullPointerException);
  }
}
