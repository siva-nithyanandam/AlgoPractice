package com.ford.sca.consent.util;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.sca.consent.transport.ConsentAdminRequest;
import com.ford.sca.consent.transport.ConsentAdminResponse;
import com.ford.sca.consent.transport.POURegulation;


@RunWith(MockitoJUnitRunner.class)
public class MarshallUtilTest {
	@InjectMocks
	private MarshallUtil marshallUtil;

	@Test
	public void testMarshallResponseSuccess() {
		ConsentAdminResponse consentRulesEngineResponse = new ConsentAdminResponse();
		assertNotNull(marshallUtil.marshallResponse(consentRulesEngineResponse));
	}

	@Test
	public void testMarshallCreateRequestforConsentSuccess() {
		ConsentAdminRequest consentRequest = new ConsentAdminRequest();
		assertNotNull(marshallUtil.marshallCreateRequestforConsent(consentRequest));
	}

	@Test
	public void testMarshallCreateRequestforConsentFailure() {
		ConsentAdminRequest consentRequest1 = null;
		assertNotNull(marshallUtil.marshallCreateRequestforConsent(consentRequest1));
	}

	@Test
	public void testMarshallCreateRequest() {
		ConsentAdminRequest consentRequest1 = null;
		assertNotNull(marshallUtil.marshallCreateRequest(consentRequest1));
	}

	@Test
	public void testInvalidPouRegulationList() {
		List<POURegulation> pouRegulationList = new ArrayList<>();
		pouRegulationList.add(new POURegulation());
		assertNotNull(marshallUtil.marshallCreateRequest(pouRegulationList));
	}

}
