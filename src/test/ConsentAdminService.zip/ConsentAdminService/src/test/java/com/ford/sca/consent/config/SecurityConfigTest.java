package com.ford.sca.consent.config;

import org.junit.Test;
import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;

//import com.ford.sca.consent.config.SecurityConfig;

@RunWith(MockitoJUnitRunner.class)
public class SecurityConfigTest {
	
//	@InjectMocks
//	SecurityConfig securityConfig;
	
	@Test
	public void testConfigure() {
//		try {
//			HttpSecurity security = Mockito.mock(HttpSecurity.class);
//			securityConfig.configure(security);
//		} catch (Exception e) {
//		}
	}

}
