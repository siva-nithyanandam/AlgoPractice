package com.ford.sca.consent.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ConsentAdminUtilTest {
    
    @InjectMocks
    private ConsentAdminUtil consentAdminUtil;
    
    
    @Test
    public void testIsActiveFlag() {
        assertEquals(true,consentAdminUtil.isActiveFlag("Y"));        
    
    }

    @Test
    public void testIsNotActiveFlag() {
        assertEquals(false,consentAdminUtil.isActiveFlag("N"));        
    
    }
}
