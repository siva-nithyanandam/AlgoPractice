package com.ford.sca.consent.util;

import javax.servlet.http.HttpServletResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ResponseGeneratorTest {
	@Mock
	private HttpServletResponse HttpServletResponse;
	
	@InjectMocks
	private ResponseGenerator responseGenerator=new ResponseGenerator();
	
	 @Test
	    public void setResponseHeaders() {
	       //responseGenerator.setResponseHeaders(HttpServletResponse);
	       //assertEquals("Corelation", MDC.get(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME));
	    }
}
