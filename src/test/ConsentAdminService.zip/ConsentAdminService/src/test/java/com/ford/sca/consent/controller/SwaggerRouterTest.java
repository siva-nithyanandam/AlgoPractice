package com.ford.sca.consent.controller;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import com.ford.sca.consent.controller.SwaggerRouter;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SwaggerRouterTest {
  @InjectMocks
  SwaggerRouter swag;
  
  @Test
  public void getApiInfoTest(){
    assertNotNull(swag.getApiInfo());
  }
}
