package com.ford.sca.consent.domain;

import org.junit.Test;
import org.meanbean.test.BeanTester;
import com.ford.sca.consent.admin.domain.PurposeOfUse;

public class PurposeOfUseTest {
  @Test
  public void getterAndSetterCorrectness() {
    new BeanTester().testBean(PurposeOfUse.class);
  }


}
