
package com.ford.sca.consent.util;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

import com.ford.sca.consent.domain.AppCodeBO;
import com.ford.sca.consent.domain.CountryCodeBO;
import com.ford.sca.consent.repository.AppCodeRepository;
import com.ford.sca.consent.repository.CountryCodeRepository;
import com.ford.sca.consent.repository.MessageLangServiceViewRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CacheUtilTest {

	@InjectMocks
	private CacheUtil cacheUtil;

	@Mock
	private AppCodeRepository appCodeRepository;

	@Mock
	private MessageLangServiceViewRepository messageLangServiceViewRepository;

	@Mock
	private CountryCodeRepository countryCodeRepository;

	AppCodeBO appcodeBO;

	private Integer appId;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		appId = Integer.valueOf(100424);
		setUpAppCodeBO(appId);
		MDC.put(ConsentAdminServiceConstants.SPAN_ID_HEADER_NAME, "sad838");
		MDC.put(ConsentAdminServiceConstants.TRACE_ID_HEADER_NAME, "sdj488");
		MDC.put(ConsentAdminServiceConstants.CORRELATION_ID_HEADER_NAME, "AdminConsentServiceCorrelation");
		MDC.put(ConsentAdminServiceConstants.SERVICE, "AdminConsentService-1.0.0");

	}

	private void setUpAppCodeBO(Integer appID) {
		appcodeBO = new AppCodeBO();
		appcodeBO.setActiveFlag(ConsentAdminServiceConstants.ACTIVE_FLAG);
		appcodeBO.setAppId(appID);
	}

	@Test
	public void testGetAppCode() {
		when(appCodeRepository.findByAppIdAndActiveFlag(appId, "Y")).thenReturn(appcodeBO);
		when(cacheUtil.getAppCodeDtls(appId)).thenReturn(appcodeBO);

	}

	@Test
	public void testErrorMessage() {
		Mockito.when(messageLangServiceViewRepository.getOne("MSG-0023")).thenReturn(null);
		assertNull(cacheUtil.getErrorMessage("MSG-0023"));

	}

	@Test
	public void testgetCountryCodeByISO3() {
		CountryCodeBO countryCodeBO = new CountryCodeBO();
		countryCodeBO.setIso3CodeCountry("USA");

		when(countryCodeRepository.findByIso3CodeCountry("USA")).thenReturn(countryCodeBO);
		when(cacheUtil.getCountryCodeByISO3("USA")).thenReturn(countryCodeBO);

	}

}
