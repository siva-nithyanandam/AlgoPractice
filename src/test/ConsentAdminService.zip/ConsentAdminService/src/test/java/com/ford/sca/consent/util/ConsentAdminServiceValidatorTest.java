package com.ford.sca.consent.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;
import org.springframework.test.util.ReflectionTestUtils;
//import com.ford.sca.consent.admin.domain.ConsentStatusBO;
import com.ford.sca.consent.domain.AppCodeBO;
import com.ford.sca.consent.domain.PrivacyStatusBO;
import com.ford.sca.consent.exception.AppCountryCodeNotExistsException;
import com.ford.sca.consent.exception.AppIdNotExistsException;
import com.ford.sca.consent.exception.ConsentBaseException;
import com.ford.sca.consent.exception.InvalidDateFormatException;
import com.ford.sca.consent.exception.InvalidPouStatusException;
import com.ford.sca.consent.exception.MissingPouFieldsException;
import com.ford.sca.consent.exception.PouIdNotExistsException;
import com.ford.sca.consent.exception.RequiredFieldsException;
import com.ford.sca.consent.service.ConsentAdminService;
import com.ford.sca.consent.transport.ConsentAdminRequest;
import com.ford.sca.consent.transport.POURegulation;


@RunWith(MockitoJUnitRunner.class)
public class ConsentAdminServiceValidatorTest {

	@InjectMocks
	private ConsentAdminServiceValidator consentAdminServiceValidator;

	@Mock
	private ConsentAdminRequest consentAdminRequest;

	@Mock
	private AppCodeBO appCodeBO;

	@Mock
	private ConsentAdminService consentAdminService;

	@Mock
	private CacheUtil cacheUtil;

	private List<POURegulation> pouRegulationList;

	@Before
	public void setUp() {
		appCodeBO = new AppCodeBO();
		pouRegulationList = new ArrayList<>();

	}

	@Test(expected = RequiredFieldsException.class)
	public void testMissingAppID() {
		MDC.setContextMap(new HashMap<>());
		consentAdminServiceValidator.validateInputField("USA", "", consentAdminRequest);
		Assert.fail();
	}

	@Test(expected = AppIdNotExistsException.class)
	public void testInvalidAppID() {
		MDC.setContextMap(new HashMap<>());
		consentAdminServiceValidator.validateInputField("USA", "100504A", consentAdminRequest);
		Assert.fail();
	}

	@Test(expected = AppIdNotExistsException.class)
	public void testValidAppID() {
		MDC.setContextMap(new HashMap<>());
		Mockito.when(ReflectionTestUtils.invokeMethod(consentAdminServiceValidator, "retrieveAppCode", 100504))
				.thenReturn(appCodeBO);
		consentAdminServiceValidator.validateInputField("USA", "100504", consentAdminRequest);
		Assert.fail();
	}

	@Test(expected = RequiredFieldsException.class)
	public void testMissingEffectiveDates() {
		MDC.setContextMap(new HashMap<>());
		pouRegulationList.add(new POURegulation());
		consentAdminServiceValidator.validateEffectiveDates(pouRegulationList);
		Assert.fail();
	}

	@Test(expected = InvalidDateFormatException.class)
	public void testInValidEffectiveDates() {
		MDC.setContextMap(new HashMap<>());
		pouRegulationList = new ArrayList<>();
		POURegulation pouRegulation = new POURegulation();
		pouRegulation.setEffectiveStartDate("2019-04-21");
		pouRegulationList.add(pouRegulation);
		consentAdminServiceValidator.validateEffectiveDates(pouRegulationList);
		Assert.fail();
	}

	@Test(expected = InvalidDateFormatException.class)
	public void testInValidEffectiveEndDate() {
		MDC.setContextMap(new HashMap<>());
		pouRegulationList = new ArrayList<>();
		POURegulation pouRegulation = new POURegulation();
		pouRegulation.setEffectiveStartDate("2019-04-21T12:00:00.000Z");
		pouRegulation.setEffectiveEndDate("2019-04-12");
		pouRegulationList.add(pouRegulation);
		consentAdminServiceValidator.validateEffectiveDates(pouRegulationList);
		Assert.fail();
	}

	@Test(expected = ConsentBaseException.class)
	public void testEndDateBeforeStratDate() {
		MDC.setContextMap(new HashMap<>());
		pouRegulationList = new ArrayList<>();
		POURegulation pouRegulation = new POURegulation();
		pouRegulation.setEffectiveStartDate("2019-04-21T12:00:00.000Z");
		pouRegulation.setEffectiveEndDate("2019-04-12T12:00:00.000Z");
		pouRegulationList.add(pouRegulation);
		consentAdminServiceValidator.validateEffectiveDates(pouRegulationList);
		Assert.fail();
	}

	@Test(expected = MissingPouFieldsException.class)
	public void testPouIsMissing() {
		MDC.setContextMap(new HashMap<>());
		pouRegulationList = new ArrayList<>();
		POURegulation pouRegulation = new POURegulation();
		pouRegulation.setEffectiveStartDate("2019-04-21T12:00:00.000Z");
		pouRegulation.setEffectiveEndDate("2019-04-12T12:00:00.000Z");
		pouRegulationList.add(pouRegulation);
		ReflectionTestUtils.invokeMethod(consentAdminServiceValidator, "validatePouIsPresent", pouRegulationList);
		Assert.fail();
	}

	@Test(expected = MissingPouFieldsException.class)
	public void testPouListMissing() {
		MDC.setContextMap(new HashMap<>());
		ReflectionTestUtils.invokeMethod(consentAdminServiceValidator, "validatePouIsPresent", Collections.emptyList());
		Assert.fail();
	}

	@Test(expected = MissingPouFieldsException.class)
	public void testPouStatusMissing() {
		MDC.setContextMap(new HashMap<>());
		pouRegulationList = new ArrayList<>();
		POURegulation pouRegulation = new POURegulation();
		pouRegulation.setPouID(1002);
		pouRegulationList.add(pouRegulation);
		ReflectionTestUtils.invokeMethod(consentAdminServiceValidator, "validatePouIsPresent", pouRegulationList);
		Assert.fail();
	}

	@Test(expected = InvalidPouStatusException.class)
	public void testInvalidPouStatus() {
		MDC.setContextMap(new HashMap<>());
		pouRegulationList = new ArrayList<>();
		POURegulation pouRegulation = new POURegulation();
		pouRegulation.setPouID(1002);
		pouRegulation.setPouStatus("F");
		pouRegulationList.add(pouRegulation);
		ReflectionTestUtils.invokeMethod(consentAdminServiceValidator, "validatePouIsPresent", pouRegulationList);
		Assert.fail();
	}

	@Ignore
	@Test(expected = PouIdNotExistsException.class)
	public void testInvalidPouId() {
		MDC.setContextMap(new HashMap<>());
		pouRegulationList = new ArrayList<>();
		POURegulation pouRegulation = new POURegulation();
		pouRegulation.setPouID(1002);
		pouRegulation.setPouStatus("G");
		pouRegulationList.add(pouRegulation);
		Mockito.when(cacheUtil.getPrivacyStatusDtls(pouRegulation.getPouStatus()))
				.thenReturn(new PrivacyStatusBO());
		ReflectionTestUtils.invokeMethod(consentAdminServiceValidator, "validatePouIsPresent", pouRegulationList);
		Assert.fail();
	}

	@Test(expected = RequiredFieldsException.class)
	public void testMissingCountryCode() {
		MDC.setContextMap(new HashMap<>());
		String appCountryCode = null;
		ReflectionTestUtils.invokeMethod(consentAdminServiceValidator, "validateCountryCode", appCountryCode);
		Assert.fail();
	}

	@Ignore
	@Test(expected = AppCountryCodeNotExistsException.class)
	public void testInvalidCountryCode() {
		MDC.setContextMap(new HashMap<>());
		ReflectionTestUtils.invokeMethod(consentAdminServiceValidator, "validateCountryCode", "US");
		Assert.fail();
	}

	/*
	 * @Test public void testValidCountryCode() { MDC.setContextMap(new
	 * HashMap<>());
	 * Mockito.when(cacheUtil.getAppCode(100504f)).thenReturn(appCodeBO);
	 * consentAdminServiceValidator.validateInputField("USA", "100504",
	 * consentAdminRequest); Assert.fail(); }
	 */

}
