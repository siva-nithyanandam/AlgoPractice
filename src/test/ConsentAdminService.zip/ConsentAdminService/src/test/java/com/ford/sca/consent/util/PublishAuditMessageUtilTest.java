package com.ford.sca.consent.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

import java.io.UnsupportedEncodingException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.sca.consent.messaging.AuditSender;
import com.ford.sca.consent.transport.AuditServiceRequest;



@RunWith(MockitoJUnitRunner.class)
public class PublishAuditMessageUtilTest {

	@InjectMocks
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Mock
    private AuditSender auditSender;

    @Test
    public void publishAuditMessageTest() throws UnsupportedEncodingException {
        publishAuditMessageUtil.publishAuditMessage(new AuditServiceRequest());
        verify(auditSender).send(any(String.class));
    }
    @Test
    public void publishAuditMessageTestException() throws UnsupportedEncodingException {
        doThrow(new RuntimeException()).when(auditSender).send(any(String.class));
        publishAuditMessageUtil.publishAuditMessage(new AuditServiceRequest());
        verify(auditSender).send(any(String.class));
    }
}
