/*package com.ford.sca.cap.config;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.ford.sca.cap.service.ConsentAdminService;
import com.ford.sca.cap.util.ConsentAdminUtil;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ConsentRegulationStatusBatchConfigTest {
	
	@InjectMocks
	@Autowired
	ConsentRegulationStatusBatchConfig batchConfig;
	
	@InjectMocks
	ConsentAdminUtil consentAdminUtil;
	
	
	@Mock
	ConsentAdminService consentAdminService;
	
	public void init()	{
	}
	
	@Test
	public void testTriggerScheduledJob()	{
		Mockito.when(consentAdminService.createOrUpdateUserPOUData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
		batchConfig.triggerScheduledJob();
	}
	
	@Test
    public void testTriggerScheduledJob1()   {
        Mockito.when(consentAdminService.createOrUpdateUserPOUData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
        consentAdminService.createOrUpdateBatchUserPOUData();
    }
	
	
	
	
	@Test
	public void testConsentAdminUtil()	{
		consentAdminUtil.getConsentDateFormat();
		consentAdminUtil.getConsentEffectiveDateFormat();
		consentAdminUtil.getInstance();
		consentAdminUtil.format(new Date());
		consentAdminUtil.today();
		consentAdminUtil.isValidDate("");
		consentAdminUtil.isValidDate("11/24/2018");
		consentAdminUtil.isActiveFlag("");
		consentAdminUtil.isEmpty("");
		consentAdminUtil.setConsentDateFormat(consentAdminUtil.getConsentDateFormat());
		consentAdminUtil.setConsentEffectiveDateFormat(consentAdminUtil.getConsentDateFormat());
		consentAdminUtil.parseDate(null);
		consentAdminUtil.parseDate("11/24/2018");
		consentAdminUtil.todayString();
		
	}

}
*/