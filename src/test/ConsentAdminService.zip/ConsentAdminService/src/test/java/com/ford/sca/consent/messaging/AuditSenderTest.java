package com.ford.sca.consent.messaging;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import java.io.UnsupportedEncodingException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AuditSenderTest {

  @InjectMocks
  private AuditSender sender;

  @Mock
  private RabbitTemplate rabbitTemplate;

  @Before
  public void setUp() throws Exception {
    MockitoAnnotations.initMocks(this);
    Mockito.doNothing().when(rabbitTemplate).send(any(String.class), any(String.class),
        any(Message.class));
  }

  @Test
  public void sendTest() throws UnsupportedEncodingException {
    String requestJson = "Dummy Json String";
    sender.send(requestJson);
    verify(rabbitTemplate, times(1)).send(any(String.class), any(String.class), any(Message.class));
  }

}
